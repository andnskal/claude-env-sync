"""이전 시트 4/30 수식 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 이전 시트 4/30 행 수식 (행 6 또는 4/30 위치)
data = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!A6:A60",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
target_row = None
for ri, r in enumerate(data):
    if r and r[0] and "2026-04-30" in r[0]:
        target_row = ri + 6
        break
print(f"4/30 위치: 행 {target_row}")

if target_row:
    formulas = _sheets.spreadsheets().values().get(
        spreadsheetId=OLD, range=f"'1.일별 전체 통계'!A{target_row}:AT{target_row}",
        valueRenderOption="FORMULA",
    ).execute().get("values", [[]])
    
    if formulas and formulas[0]:
        labels_full = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N",
                       "O","P","Q","R","S","T","U","V","W","X","Y","Z",
                       "AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT"]
        for ci, v in enumerate(formulas[0]):
            if v and isinstance(v, str) and v.startswith("="):
                lbl = labels_full[ci] if ci < len(labels_full) else f"col{ci}"
                print(f"\n{lbl}: {v[:300]}")

# 이전 시트 ★설정 운영시간 정의
print("\n" + "=" * 60)
print("[이전 시트 ★설정 운영시간]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'★설정'!B1:B5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    print(f"  B{ri+1}: {r}")

# 이전 시트 5.콜 컬럼 헤더 (구조 차이)
print("\n[이전 시트 5.콜 헤더]")
old_5 = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'5.콜 상담내역'!A1:AD1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if old_5 and old_5[0]:
    for ci, v in enumerate(old_5[0]):
        if v:
            col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
            print(f"  {col}: {v[:30]}")
