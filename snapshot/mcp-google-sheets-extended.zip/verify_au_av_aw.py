"""AU/AV/AW 검증 + 그룹화 확인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

time.sleep(5)

# 1) 데이터 검증
print("=" * 100)
print("AU/AV/AW 데이터 검증")
print("=" * 100)

# 1.일별 모든 일자
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AW60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 5.콜 직접 카운트로 검증
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_data = defaultdict(lambda: {"ib_in": 0, "ib_succ_all": 0, "off_ib_aban": 0, "off_ob_succ": 0})
for row in all_calls:
    if len(row) > 29:
        N, B, Q, AC, AD = row[13], row[1], row[16], row[28], row[29]
        if not N: continue
        # 전체 IB
        if B == "inbound":
            date_data[N]["ib_in"] += 1
            if Q == "IB_성공": date_data[N]["ib_succ_all"] += 1
        # 운영시간 외 IB 부재
        if B == "inbound" and AD == "외" and Q == "IB_포기호":
            date_data[N]["off_ib_aban"] += 1
        # 운영시간 외 OB 처리
        if Q == "OB_성공" and AD == "외" and AC in ("본사", "외주 고객센터"):
            date_data[N]["off_ob_succ"] += 1

print(f"\n{'날짜':>12} | {'AU 시트':>10} | {'AU 직접':>10} | {'AV 시트':>8} | {'AV 직접':>8} | {'AW 시트':>8} | {'AW 직접':>8}")
print("-" * 100)
all_ok = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_data: continue
    
    AU = row[46] if len(row) > 46 else 0
    AV = row[47] if len(row) > 47 else 0
    AW = row[48] if len(row) > 48 else 0
    
    d = date_data[date]
    exp_au = d["ib_succ_all"] / d["ib_in"] if d["ib_in"] else 0
    exp_av = d["off_ib_aban"]
    exp_aw = d["off_ob_succ"]
    
    au_ok = isinstance(AU, (int, float)) and abs(AU - exp_au) < 0.001
    av_ok = AV == exp_av
    aw_ok = AW == exp_aw
    
    print(f"{date:>12} | {AU*100 if isinstance(AU, (int, float)) else AU:>9.1f}% | {exp_au*100:>9.1f}% | {AV:>8} | {exp_av:>8} | {AW:>8} | {exp_aw:>8}")
    if not (au_ok and av_ok and aw_ok):
        all_ok = False

# 2) 그룹화 확인
print("\n" + "=" * 100)
print("컬럼 그룹화 확인")
print("=" * 100)
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties,columnGroups)"
).execute()
for s in meta.get("sheets", []):
    if s["properties"]["title"] == "1.일별 전체 통계":
        groups = s.get("columnGroups", [])
        print(f"  총 그룹: {len(groups)}개")
        for g in groups:
            r = g["range"]
            si = r.get("startIndex", 0)
            ei = r.get("endIndex", 0)
            depth = g.get("depth", 0)
            collapsed = g.get("collapsed", False)
            def cl(idx):
                s, n = "", idx + 1
                while n > 0:
                    n, r = divmod(n - 1, 26)
                    s = chr(ord("A") + r) + s
                return s
            print(f"  - {cl(si)}-{cl(ei-1)} (col {si}-{ei-1}) depth={depth} {'접힘' if collapsed else '펼침'}")
        break

# 3) AU/AV/AW 헤더 표시
print("\n" + "=" * 100)
print("AU/AV/AW 헤더 표시")
print("=" * 100)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AU1:AW3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    print(f"  Row {ri+1}: {row}")

print("\n" + "=" * 100)
if all_ok:
    print(">>> AU/AV/AW 모든 데이터 일치 <<<")
else:
    print("⚠️ 불일치")
print("=" * 100)
