"""수정 후 재점검."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

import re

issues = []

# 1) 모든 시트 모든 셀 오류
print("=" * 100)
print("[검증 1] 셀 오류 재점검")
print("=" * 100)
ERR = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = p["gridProperties"].get("rowCount", 0)
    cols = p["gridProperties"].get("columnCount", 0)
    if rows == 0: continue
    rng = f"'{name}'!A1:{col_letter(cols-1)}{min(rows, 600)}"
    try:
        v = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue
    err_count = sum(1 for r in v for c in r if isinstance(c, str) and any(p in c for p in ERR))
    if err_count > 0:
        issues.append(f"{name}: {err_count}개 오류")
        print(f"  ❌ {name}: {err_count}개 오류")
    else:
        print(f"  ✅ {name}")

# 2) BYROW 범위 재확인
print("\n[검증 2] 모든 BYROW 범위")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AT6",
    valueRenderOption="FORMULA",
).execute().get("values", [])
limited_count = 0
for ri, row in enumerate(res):
    for ci, v in enumerate(row):
        if v and isinstance(v, str):
            patterns = re.findall(r"[A-Z]+\d+:[A-Z]+(\d+)", v)
            for p in patterns:
                if int(p) < 1000:
                    limited_count += 1
                    issues.append(f"1.일별 행{ri+4} {col_letter(ci)}: 범위 한정 {p}")
print(f"  한정 범위: {limited_count}개")

# 3) freeze 재확인
print("\n[검증 3] 모든 시트 freeze")
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    fr = p.get("gridProperties", {}).get("frozenRowCount", 0)
    if fr == 0:
        issues.append(f"{name}: freeze 0")
        print(f"  ⚠️ {name}: freeze 0")
    else:
        print(f"  ✅ {name}: {fr}")

# 4) 디버깅 잔재
print("\n[검증 4] 디버깅 잔재")
잔재_검사 = [
    ("1분 단위 포기호, 통화상세", "W1:Z1000"),
    ("5분 단위 포기호, 통화상세", "W1:Z1000"),
    ("1.일별 전체 통계", "AU1:AX200"),
]
for sheet, rng in 잔재_검사:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{rng}",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    non_empty = [(ri, ci, c) for ri, row in enumerate(res) for ci, c in enumerate(row) if c]
    if non_empty:
        issues.append(f"{sheet} {rng}: 잔재 {len(non_empty)}개")
        print(f"  ⚠️ {sheet} {rng}: 잔재 {len(non_empty)}개")
    else:
        print(f"  ✅ {sheet} {rng}: 깨끗")

# 5) 1분단위 E2 서식
print("\n[검증 5] 1분/5분단위 E2 DATE 서식")
for sheet in ["1분 단위 포기호, 통화상세", "5분 단위 포기호, 통화상세"]:
    fmt = _sheets.spreadsheets().get(
        spreadsheetId=NEW, ranges=[f"'{sheet}'!E2"],
        includeGridData=True,
        fields="sheets(data(rowData(values(userEnteredFormat,formattedValue))))"
    ).execute()
    cell = fmt["sheets"][0]["data"][0]["rowData"][0]["values"][0]
    fmt_type = cell.get("userEnteredFormat", {}).get("numberFormat", {}).get("type", "?")
    val = cell.get("formattedValue", "?")
    if fmt_type == "DATE":
        print(f"  ✅ {sheet} E2: '{val}' DATE")
    else:
        issues.append(f"{sheet} E2: 서식 {fmt_type}")
        print(f"  ⚠️ {sheet} E2: '{val}' {fmt_type}")

# 6) 1.일별 5/1 (근로자날) + 5/5 (어린이날) 제외
print("\n[검증 6] 공휴일 제외 (5/1, 5/5)")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:A20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
dates = [r[0] for r in res if r and r[0]]
if "2026-05-01" in dates or "2026-05-05" in dates:
    issues.append(f"공휴일 미제외: {[d for d in dates if d in ['2026-05-01','2026-05-05']]}")
    print(f"  ❌ 공휴일 표시: {dates}")
else:
    print(f"  ✅ 공휴일 제외 정상: {dates}")

# 7) 운영시간 분류 컬럼 (5.콜 AD, 6.채팅 Z) ARRAYFORMULA 확장
print("\n[검증 7] 운영시간 분류 컬럼 자동 확장")
for sheet, col, range_check in [
    ("5.콜 상담내역", "AD", "AD2:AD3500"),
    ("6.채팅 상담내역", "Z", "Z2:Z3500"),
]:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{range_check}",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    filled = sum(1 for r in res if r and r[0])
    # 비교: 같은 시트 A 컬럼 (또는 동일한 길이 컬럼)
    a_res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!A2:A3500",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    a_filled = sum(1 for r in a_res if r and r[0])
    print(f"  {sheet} {col}: 채워진 셀 {filled} / A 컬럼 {a_filled}")
    if filled != a_filled:
        issues.append(f"{sheet} {col}: 자동확장 불일치 ({filled} vs {a_filled})")

print("\n" + "=" * 100)
if issues:
    print(f"발견된 이슈: {len(issues)}개")
    for i, iss in enumerate(issues, 1):
        print(f"  {i}. {iss}")
else:
    print(">>> 모든 이슈 해결 <<<")
print("=" * 100)
