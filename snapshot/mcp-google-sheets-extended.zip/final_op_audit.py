"""최종 운영시간 기준 종합 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 80)
print("🏁 운영시간 기준 일관화 최종 검증")
print("=" * 80)

# 1) 모든 시트 오류 확인
print("\n[1️⃣ 셀 단위 오류 재검증]")
ERROR_PATTERNS = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
total_errors = 0
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0 or cols == 0: continue
    rng = f"'{name}'!A1:{col_letter(cols-1)}{rows}"
    try:
        vals = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue
    errs = 0
    for ri, row in enumerate(vals):
        for ci, cell in enumerate(row):
            if isinstance(cell, str):
                for ptn in ERROR_PATTERNS:
                    if ptn in cell:
                        errs += 1
                        if errs <= 2:
                            print(f"  ❌ {name}!{col_letter(ci)}{ri+1} = {ptn}")
                        break
    total_errors += errs
    if errs == 0:
        print(f"  ✅ {name}")
    else:
        print(f"  ❌ {name}: {errs}개 오류")
print(f"\n총 오류: {total_errors}개")

# 2) 시트 간 일치성 검증 (5/8)
print("\n" + "=" * 80)
print("[2️⃣ 시트 간 일치성 검증 (운영시간 기준)]")

# 5.콜 5/8 운영시간 내 카운트
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

ib_succ_in = 0
ib_aban_in = 0
ib_aban_in_alf_excl = 0
ib_aban_in_tech_excl = 0
ob_succ_in = 0
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        Z = row[25] if len(row) > 25 else ""
        AD = row[29] if len(row) > 29 else ""
        if N == "2026-05-08" and AD == "내":
            if Q == "IB_성공": ib_succ_in += 1
            elif Q == "OB_성공": ob_succ_in += 1
            elif Q == "IB_포기호":
                ib_aban_in += 1
                if Y != "알림톡발송":
                    ib_aban_in_alf_excl += 1
                    if Z != "기술부재포기호":
                        ib_aban_in_tech_excl += 1

print(f"\n[5.콜 5/8 운영시간 내 직접 카운트]")
print(f"  IB_성공: {ib_succ_in}")
print(f"  IB_포기호 (알림톡 제외): {ib_aban_in_alf_excl}")
print(f"  IB_포기호 (알림톡+기술포기호 제외): {ib_aban_in_tech_excl}")
print(f"  OB_성공: {ob_succ_in}")

# 1.일별 5/8
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        P = row[15] if len(row) > 15 else "?"
        Q = row[16] if len(row) > 16 else "?"
        U = row[20] if len(row) > 20 else "?"
        AC = row[28] if len(row) > 28 else "?"
        print(f"\n[1.일별 5/8 운영시간 기준]")
        print(f"  P (응대호): {P} {'✅' if P == ib_succ_in else '❌ (5.콜과 차이: ' + str(abs(P-ib_succ_in)) + ')'}")
        print(f"  Q (포기호 알림제외): {Q} {'✅' if Q == ib_aban_in_alf_excl else '❌'}")
        print(f"  U (포기호 기술제외): {U} {'✅' if U == ib_aban_in_tech_excl else '❌'}")
        print(f"  AC (OB 성공): {AC} {'✅' if AC == ob_succ_in else '❌'}")
        break

# 2.시간대별
hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_l = sum_q = 0
for row in hourly:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == "2026-05-08":
        if isinstance(row[11], (int, float)): sum_l += row[11]
        if isinstance(row[16], (int, float)): sum_q += row[16]
print(f"\n[2.시간대별 5/8 운영시간 기준]")
print(f"  L (IB_성공) 합: {sum_l} {'✅' if sum_l == ib_succ_in else '❌'}")
print(f"  Q (포기호 알림제외) 합: {sum_q} {'✅' if sum_q == ib_aban_in_alf_excl else '❌'}")

# 3.상담사별 합
res3 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_chann = 0
for ci, (d, ch) in enumerate(zip(res3[0], res3[1])):
    if isinstance(d, str) and d == "2026-05-08" and ch == "채널톡":
        for ri in range(2, len(res3)):
            if ci < len(res3[ri]) and isinstance(res3[ri][ci], (int, float)):
                sum_chann += res3[ri][ci]

# 4.상담사별 합
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_ib = 0
for ci, (d, t) in enumerate(zip(res4[0], res4[1])):
    if isinstance(d, str) and d == "2026-05-08" and t == "IB_성공":
        for ri in range(2, len(res4)):
            if ci < len(res4[ri]) and isinstance(res4[ri][ci], (int, float)):
                sum_ib += res4[ri][ci]

print(f"\n[상담사별 5/8 운영시간 기준]")
print(f"  3.상담사별 채널톡: {sum_chann}")
print(f"  4.상담사별 IB_성공: {sum_ib} {'✅' if sum_ib == ib_succ_in else '❌'}")

# RAW시간대별 5/8 포기호 
raw_a = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
raw_cnt = sum(1 for r in raw_a if r and r[0])
print(f"\n[RAW시간대별 5/8 포기호 (운영시간 내 알림+기술 제외)]")
print(f"  카운트: {raw_cnt} {'✅' if raw_cnt == ib_aban_in_tech_excl else '❌'}")

print("\n" + "=" * 80)
if total_errors == 0:
    print("🎉 운영시간 기준 일관화 100% 완료!")
else:
    print(f"⚠️ {total_errors}개 오류")
print("=" * 80)
