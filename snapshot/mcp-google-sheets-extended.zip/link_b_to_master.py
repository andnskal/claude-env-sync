"""B 컬럼 수식을 ★설정 Z-AB 마스터에 동적 연동."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# B2 수식: AA2 (점심 시작), AB2 (점심 종료) 마스터 참조
new_b2 = (
    '=ARRAYFORMULA(IF('
    '(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440>=$AA$2)*'
    '(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440<$AB$2),'
    '"🍱 점심",'
    'TEXT(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440,"hh:mm")))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!B2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_b2]]},
).execute()
print("OK B2 수식 — $AA$2, $AB$2 마스터 동적 연동")
time.sleep(5)

# 현재 마스터 + B 컬럼 동기 확인
master = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!Z2:AB3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[현재 점심 마스터]")
print(f"  기본 점심: {master[0][1] if master and len(master[0])>1 else '?'} ~ {master[0][2] if master and len(master[0])>2 else '?'}")
if len(master) > 1:
    print(f"  예외 일자: {master[1][0]} → {master[1][1]} ~ {master[1][2]}")

# B 컬럼에서 🍱 점심 표시되는 시간대 범위 확인
b_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B2:B600",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 점심 시작과 끝의 직전 시간 찾기
lunch_start_row = None
lunch_end_row = None
for ri, r in enumerate(b_data):
    if r and r[0] == "🍱 점심":
        if lunch_start_row is None:
            lunch_start_row = ri + 2  # 행번호 (B2부터)
        lunch_end_row = ri + 2

if lunch_start_row:
    # 점심 시작 직전, 직후
    before_lunch = b_data[lunch_start_row - 3][0] if lunch_start_row - 3 >= 0 else "?"
    after_lunch = b_data[lunch_end_row - 1][0] if lunch_end_row - 1 < len(b_data) else "?"
    print(f"\n[B 컬럼 점심 영역 확인]")
    print(f"  점심 직전: B{lunch_start_row-1} = '{before_lunch}'")
    print(f"  점심 시작: B{lunch_start_row} = '🍱 점심'")
    print(f"  점심 끝: B{lunch_end_row} = '🍱 점심'")
    print(f"  점심 직후: B{lunch_end_row+1} = '{after_lunch}'")
    print(f"  점심 영역 셀 수: {lunch_end_row - lunch_start_row + 1}개")

# 5/8 이윤애 재검증
print("\n[5/8 이윤애 IB_성공]")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

iyunae_calls = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08" or row[22] != "CS_이윤애" or row[16] != "IB_성공": continue
    iyunae_calls.append((row[2], row[29]))

in_count = sum(1 for _, ad in iyunae_calls if ad == "내")
out_count = sum(1 for _, ad in iyunae_calls if ad == "외")
print(f"  운영시간 내: {in_count}건")
print(f"  운영시간 외: {out_count}건 (점심 등)")
print(f"  채널톡 대시보드: 15건")
print(f"  → {'✅ 일치' if in_count == 15 else '⚠️ 차이 ' + str(in_count - 15)}")

print(f"\n  이윤애 콜 상세 (마스터 12:50-14:00 적용 시):")
for c, ad in iyunae_calls:
    h, m = c.split(" ")[1].split(":")[:2]
    h, m = int(h), int(m)
    tm = h*60+m
    note = ""
    if 770 <= tm < 840:  # 12:50 - 14:00
        note = "← 점심 (12:50-14:00)"
    print(f"    {c} | AD={ad} {note}")
