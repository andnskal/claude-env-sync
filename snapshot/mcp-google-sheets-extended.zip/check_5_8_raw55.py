"""5/8 RAW 55 데이터 J 컬럼 분포 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5/8 + 채팅 데이터의 J (요청자)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:M10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter
j_counter = Counter()
total = 0
for row in res:
    if len(row) > 5:
        H = row[0]
        M = row[5]
        if H == "채팅" and M == "2026-05-08":
            # J는 row 안에 있음 (인덱스 차이)
            # range가 H2:M이면 H=0, I=1, J=2, K=3, L=4, M=5
            J = row[2] if len(row) > 2 else ""
            j_counter[J] += 1
            total += 1

print(f"5/8 채팅 기술이관 RAW 55 데이터: {total}건")
print("\nJ (요청자 한글) 분포:")
for k, v in j_counter.most_common():
    print(f"  {k}: {v}건")
