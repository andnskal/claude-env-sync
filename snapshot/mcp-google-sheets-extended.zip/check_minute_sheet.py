"""신 시스템 1분단위/RAW시간대별 포기호 시트 현황 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 시트 목록
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
print("=" * 70)
print("신 시스템 시트 목록")
print("=" * 70)
for s in meta.get("sheets", []):
    p = s["properties"]
    print(f"  - {p['title']} ({p['gridProperties'].get('rowCount', 0)}행 × {p['gridProperties'].get('columnCount', 0)}열)")

# 1분단위/5분단위/RAW시간대별 시트 헤더+5행
for sname in ["1분 단위 포기호, 통화상세", "5분단위 포기호 차트", "RAW시간대별 포기호, 통화상세"]:
    print(f"\n{'='*70}")
    print(f"📋 {sname}")
    print("=" * 70)
    try:
        # 수식 보기
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=f"'{sname}'!A1:Z10",
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        # 표시 값
        values = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=f"'{sname}'!A1:Z10",
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        
        print("\n[수식]")
        for ri, row in enumerate(formulas[:10]):
            for ci, cell in enumerate(row[:25]):
                if cell:
                    col = chr(ord('A') + ci) if ci < 26 else f"A{chr(ord('A') + ci - 26)}"
                    if str(cell).startswith("=") or len(str(cell)) > 15:
                        print(f"  [{col}{ri+1}] {str(cell)[:200]}")
                    elif ci < 5 or ri < 4:
                        print(f"  {col}{ri+1}: {cell}")
    except Exception as e:
        print(f"  ❌ 시트 없음 또는 오류: {e}")
