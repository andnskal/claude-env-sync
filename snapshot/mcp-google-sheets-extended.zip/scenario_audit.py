"""모든 시나리오 검증 - 시트 간 일치성 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def get_val(sheet, range_):
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{range_}",
        valueRenderOption="UNFORMATTED_VALUE",
    ).execute().get("values", [])
    return res

# 1) 5/8 데이터 검증 (가장 최근 + 데이터 풍부)
print("=" * 80)
print("📊 시나리오 검증 (2026-05-08)")
print("=" * 80)

# 5.콜에서 5/8 카운트
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

ib_succ = ib_aban = ob_succ = ob_fail = 0
ib_aban_excl_alf = 0  # 알림톡 제외
ib_aban_excl_tech = 0  # 기술포기호 제외
for row in all_calls:
    if len(row) >= 4 and row[0] == "2026-05-08":
        Q = row[3] if len(row) > 3 else ""
        Y = row[11] if len(row) > 11 else ""
        Z = row[12] if len(row) > 12 else ""
        if Q == "IB_성공":
            ib_succ += 1
        elif Q == "OB_성공":
            ob_succ += 1
        elif Q == "OB_실패":
            ob_fail += 1
        elif Q == "IB_포기호":
            ib_aban += 1
            if Y != "알림톡발송":
                ib_aban_excl_alf += 1
                if Z != "기술부재포기호":
                    ib_aban_excl_tech += 1

print(f"\n[5.콜 5/8 카운트]")
print(f"  IB_성공: {ib_succ}")
print(f"  IB_포기호: {ib_aban}")
print(f"    └─ 알림톡 제외: {ib_aban_excl_alf}")
print(f"    └─ 기술포기호 제외: {ib_aban_excl_tech}")
print(f"  OB_성공: {ob_succ}")
print(f"  OB_실패: {ob_fail}")

# 1.일별 5/8 값 확인
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0].startswith("2026-05-08"):
        print(f"\n[1.일별 5/8 값]")
        # O=14, P=15, Q=16 (접수호 알림톡만 제외)
        # S=18, T=19, U=20 (접수호 기술포기호 제외)
        cols_map = {
            14: 'O 접수호(알림톡만 제외)', 15: 'P 응대호', 16: 'Q 포기호(알림톡만 제외)',
            17: 'R 응대율(알림톡만 제외)', 18: 'S 접수호(기술포기호 제외)', 19: 'T 응대호',
            20: 'U 포기호(기술포기호 제외)', 21: 'V 응대율(기술포기호 제외)',
            27: 'AB OB 시도', 28: 'AC OB 성공', 29: 'AD OB(콜백제외)',
        }
        for ci, label in cols_map.items():
            v = row[ci] if ci < len(row) else "?"
            print(f"  {label}: {v}")
        break

# 검증 1: O = P + Q (접수호 = 응대호 + 포기호)
print(f"\n[검증 1] 접수호 알림톡 제외 = 응대호 + 포기호")
print(f"  계산: 5.콜 IB_성공({ib_succ}) + IB_포기호 알림톡 제외({ib_aban_excl_alf})")
print(f"  = {ib_succ + ib_aban_excl_alf}")
print(f"  → 1.일별 O 값과 비교")

# 시간대별과 일별 일치 검증 (5/8 합계)
print("\n" + "=" * 80)
print("[시간대별 → 일별 합산 검증 (5/8)]")
print("=" * 80)

hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 시간대별 5/8 데이터 합산 (G=총접수호, H=포기호, J=알림톡제외 접수호, K=기술포기호제외 포기호 등)
sum_g = sum_h = sum_j = sum_k = 0
for row in hourly:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == "2026-05-08":
        if isinstance(row[6], (int, float)): sum_g += row[6]
        if isinstance(row[7], (int, float)): sum_h += row[7]
        if isinstance(row[9], (int, float)): sum_j += row[9]
        if isinstance(row[10], (int, float)): sum_k += row[10]

print(f"  2.시간대별 5/8 G(총접수호) 합계: {sum_g}")
print(f"  2.시간대별 5/8 H(포기호) 합계: {sum_h}")
print(f"  → 1.일별 5/8 O와 비교")
