"""1분/5분단위 + RAW시간대별 모든 수식과 현재 값 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# RAW시간대별 - row 3 모든 수식 + row 1 헤더 + 첫 데이터
print("=" * 80)
print("RAW시간대별 포기호 — 수식 분석")
print("=" * 80)
formulas = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A1:AF5",
    valueRenderOption="FORMULA",
).execute().get("values", [])
values = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A1:AF6",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# Row 3 — 모든 수식
print("\n[Row 3 수식 — 데이터 시작]")
for ci, cell in enumerate(formulas[2] if len(formulas) > 2 else []):
    if cell:
        col = col_letter(ci)
        # Row 1 헤더
        h1 = formulas[0][ci] if len(formulas) > 0 and ci < len(formulas[0]) else ""
        h2 = formulas[1][ci] if len(formulas) > 1 and ci < len(formulas[1]) else ""
        print(f"  [{col}3] {h1} | {h2}")
        print(f"    수식: {str(cell)[:200]}")

print("\n[Row 3-5 표시값]")
for ri in range(2, 6):
    if ri < len(values):
        print(f"  Row {ri+1}: {values[ri][:10]}")

# 1분단위 — 핵심 수식 추출
print("\n" + "=" * 80)
print("1분 단위 포기호 — 수식 분석")
print("=" * 80)
formulas_1min = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A1:V20",
    valueRenderOption="FORMULA",
).execute().get("values", [])
values_1min = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A1:V20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# Row 4 모든 컬럼 수식
print("\n[Row 4 수식]")
for ci, cell in enumerate(formulas_1min[3] if len(formulas_1min) > 3 else []):
    if cell:
        col = col_letter(ci)
        h2 = formulas_1min[1][ci] if len(formulas_1min) > 1 and ci < len(formulas_1min[1]) else ""
        h3 = formulas_1min[2][ci] if len(formulas_1min) > 2 and ci < len(formulas_1min[2]) else ""
        print(f"  [{col}4] 헤더: {h2} | {h3}")
        print(f"    수식: {str(cell)[:300]}")

# 표시값 — 4-15행
print("\n[Row 4-15 표시값 (포기호 발생 시간)]")
for ri in range(3, 16):
    if ri < len(values_1min):
        row = values_1min[ri][:12]
        # 빈 값이 아닌 것만
        if any(c for c in row):
            print(f"  Row {ri+1}: {row}")
