"""모든 시트 number format 점검."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 점검 대상: (시트, [(셀, 기대 type, 기대 패턴, 라벨)])
TARGETS = {
    "1분 단위 포기호, 통화상세": [
        ("E2", "DATE", "yyyy-mm-dd", "날짜설정 (사용자 입력)"),
    ],
    "1.일별 전체 통계": [
        ("K6", "PERCENT", "0.0%", "K 답변율"),
        ("R6", "PERCENT", "0.0%", "R 응대율 (알림제외)"),
        ("V6", "PERCENT", "0.0%", "V 응대율 (기술제외)"),
        ("W6", "TIME", "[h]:mm:ss", "W IB 통화시간 총"),
        ("X6", "TIME", "[m]:ss", "X IB ATT"),
        ("AF6", "TIME", "[h]:mm:ss", "AF OB 통화시간 총"),
        ("AG6", "TIME", "[m]:ss", "AG OB ATT"),
        ("AJ6", "PERCENT", "0.0%", "AJ 콜백 처리율"),
        ("AK6", "PERCENT", "0.0%", "AK 서비스 레벨"),
        ("AL6", "PERCENT", "0.0%", "AL 응답속도 준수율"),
        ("AM6", "NUMBER", "0", "AM 평균통화 (초)"),
        ("O6", "NUMBER", "#,##0", "O 접수호"),
        ("P6", "NUMBER", "#,##0", "P 응대호"),
        ("Q6", "NUMBER", "#,##0", "Q 포기호"),
        ("AC6", "NUMBER", "#,##0", "AC OB 성공"),
        ("AD6", "NUMBER", "#,##0", "AD OB(콜백제외)"),
        ("AE6", "NUMBER", "#,##0", "AE 콜백 신청"),
        ("AI6", "NUMBER", "#,##0", "AI 콜백 OB 처리"),
        ("Y6", "NUMBER", "0.0", "Y IB 투입인원"),
        ("Z6", "NUMBER", "0.0", "Z IB 투입인원 시간대별합÷10"),
        ("AA6", "NUMBER", "#,##0", "AA OB부재"),
    ],
    "2.시간대별 전체통계": [
        ("I4", "PERCENT", "0.0%", "I 응대율"),
        ("M4", "PERCENT", "0.0%", "M 응대율"),
        ("S4", "PERCENT", "0.0%", "S 응대율"),
        ("AA4", "TIME", "[m]:ss", "AA OB 평균통화"),
        ("AD4", "PERCENT", "0.0%", "AD 채팅 응답률"),
        ("AF4", "PERCENT", "0.0%", "AF 채팅 매니저 응답률"),
        ("T4", "TIME", "[h]:mm:ss", "T IB 통화시간"),
        ("U4", "TIME", "[m]:ss", "U IB ATT"),
        ("Z4", "TIME", "[h]:mm:ss", "Z OB 통화시간"),
    ],
    "5.콜 상담내역": [
        ("C2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "C startedAt"),
        ("D2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "D firstEngagedAt"),
        ("E2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "E endedAt"),
        ("J2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "J firstPostCallStartedAt"),
        ("K2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "K firstPostCallEndedAt"),
        ("S2", "TIME", "[h]:mm:ss", "S 통화시간"),
        ("T2", "TIME", "[h]:mm:ss", "T 후처리시간"),
        ("U2", "TIME", "[h]:mm:ss", "U 대기시간"),
        ("V2", "TIME", "[h]:mm:ss", "V 보류시간"),
        ("AB2", "TIME", "[h]:mm:ss", "AB ringWaitTime"),
    ],
    "6.채팅 상담내역": [
        ("B2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "B createdAt"),
        ("C2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "C firstAskedAt"),
        ("D2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "D firstOpenedAt"),
        ("E2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "E firstAnsweredAt"),
        ("F2", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "F closedAt"),
    ],
    "★설정": [
        ("B2", "TIME", "hh:mm", "B 업무시간"),
        ("C2", "DATE", "yyyy-mm-dd", "C 공휴일"),
    ],
}

# 모든 셀 서식 검사
issues = []
for sheet_name, checks in TARGETS.items():
    for cell, exp_type, exp_pat, label in checks:
        try:
            fmt = _sheets.spreadsheets().get(
                spreadsheetId=NEW, ranges=[f"'{sheet_name}'!{cell}"],
                includeGridData=True,
                fields="sheets(data(rowData(values(userEnteredFormat,formattedValue))))"
            ).execute()
            row_data = fmt["sheets"][0]["data"][0].get("rowData", [])
            if not row_data or "values" not in row_data[0] or not row_data[0]["values"]:
                issues.append((sheet_name, cell, label, "빈 셀", "?"))
                continue
            cell_obj = row_data[0]["values"][0]
            fmt_obj = cell_obj.get("userEnteredFormat", {}).get("numberFormat", {})
            actual_type = fmt_obj.get("type", "AUTO")
            actual_pat = fmt_obj.get("pattern", "")
            val = cell_obj.get("formattedValue", "")
            
            if actual_type != exp_type:
                issues.append((sheet_name, cell, label, f"{actual_type} pat='{actual_pat}'", f"{exp_type} pat='{exp_pat}'"))
        except Exception as e:
            issues.append((sheet_name, cell, label, f"오류: {e}", "?"))

# 결과 출력
print("=" * 100)
print("서식 점검 결과")
print("=" * 100)
if issues:
    print(f"\n발견된 이슈: {len(issues)}개")
    for s, c, lbl, actual, exp in issues:
        print(f"  [{s}!{c}] {lbl}")
        print(f"    현재: {actual}")
        print(f"    기대: {exp}")
else:
    print("\n모든 서식 정상")
