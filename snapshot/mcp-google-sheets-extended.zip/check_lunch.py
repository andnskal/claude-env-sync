"""★설정 B 컬럼과 점심시간 처리 방식 정확히 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) ★설정 B 컬럼 전체
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B700",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

non_empty = [(i+1, r[0]) for i, r in enumerate(res) if r and r[0]]
print(f"★설정 B 컬럼 (업무시간) 분석")
print(f"  비어있지 않은 셀: {len(non_empty)}개")
print(f"  첫 5개: {non_empty[:5]}")
print(f"  마지막 5개: {non_empty[-5:]}")

# 점심시간대 B 컬럼에 있는지 확인
print(f"\n점심시간대 (12:30~13:30) B 컬럼 포함 여부:")
lunch_times = ["12:30", "12:31", "12:45", "13:00", "13:15", "13:29", "13:30"]
for t in lunch_times:
    found = any(t == val for _, val in non_empty)
    print(f"  {t}: {'있음' if found else '없음'}")

# 2) 신 시스템 AD 수식 (운영시간 분류)
print(f"\n[신 시스템 5.콜 AD 수식 = 운영시간 분류 로직]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print(f"  AD2: {res[0][0] if res and res[0] else '없음'}")

# 3) 점심시간 콜의 실제 분류 (5/8 12:30-13:30)
print(f"\n[5/8 12:30-13:30 콜의 AD 분류 확인]")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"\n{'시각':>20} | {'B방향':>8} | {'Q구분':>10} | {'AD':>4}")
print("-" * 60)
cnt = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    C = row[2]
    if " " not in C: continue
    try:
        time_part = C.split(" ")[1]
        h, m = int(time_part.split(":")[0]), int(time_part.split(":")[1])
        total_min = h * 60 + m
    except:
        continue
    # 12:30 ~ 13:30 사이만
    if 750 <= total_min <= 810:
        cnt += 1
        if cnt <= 10:
            print(f"  {C:>20} | {row[1]:>8} | {row[16]:>10} | {row[29]:>4}")

print(f"\n총 12:30-13:30 콜: {cnt}건")

# 4) 결론
print(f"\n" + "=" * 80)
print("결론")
print("=" * 80)
print("""
★설정 B 컬럼 = 09:00~17:29 (510셀, 1분 단위 시계열)
  → 점심시간(12:30~13:30) **포함**되어 있음
  → 즉 ★설정은 "점심을 운영시간으로" 정의

신 시스템 AD/Z 수식 = "X 태그 + 시간 09:00-17:30" 로직
  → 점심시간 별도 처리 **없음**
  → 12:30-13:30 콜도 운영시간 내("내")로 분류

→ 결론: 점심시간은 별도 정의 안 됨. 운영시간 내로 처리.
""")
