"""R 분류 21건 차이 추적."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

raw55 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:R10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 차이 행 추출
mismatch = []
for ri, row in enumerate(raw55):
    if len(row) < 11: continue
    H = row[0]
    J = row[2] if len(row) > 2 else ""
    R = row[10] if len(row) > 10 else ""

    if J.startswith("@@"):
        expected = "미매핑"
    elif J.startswith("TCK_") or J.startswith("CS쉐어링"):
        expected = "외주_채팅" if H == "채팅" else "외주_비채팅"
    else:
        expected = "본사_채팅" if H == "채팅" else "본사_비채팅"

    if R != expected:
        mismatch.append((ri+2, H, J, R, expected))

print(f"불일치 {len(mismatch)}건")
for row_num, H, J, R, exp in mismatch[:25]:
    print(f"  Row {row_num}: H='{H}' J='{J}' / 시트R='{R}' 기대='{exp}'")
