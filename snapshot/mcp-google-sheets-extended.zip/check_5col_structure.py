"""신 시스템 5.콜 컬럼 구조 정확히 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 헤더 + 첫 데이터 행 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A1:AC3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("=" * 80)
print("5.콜 상담내역 헤더 및 데이터")
print("=" * 80)
if res:
    headers = res[0] if len(res) > 0 else []
    data1 = res[1] if len(res) > 1 else []
    data2 = res[2] if len(res) > 2 else []
    
    def col_letter(idx):
        s, n = "", idx + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(ord("A") + r) + s
        return s
    
    for i, h in enumerate(headers):
        v1 = data1[i] if i < len(data1) else ""
        v2 = data2[i] if i < len(data2) else ""
        print(f"  {col_letter(i):>3} | {h:>30} | {str(v1)[:30]:>30} | {str(v2)[:30]}")

# 4/30 IB_포기호 샘플
print("\n" + "=" * 80)
print("4/30 IB_포기호 샘플 (Q='IB_포기호', N='2026-04-30')")
print("=" * 80)

# 데이터 행
all_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AC5000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

count = 0
for row in all_data:
    if len(row) > 16 and row[13] == "2026-04-30" and row[16] == "IB_포기호":
        # A C D E F H N Q W X Y Z
        cols = {0: 'A', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 7: 'H', 13: 'N', 16: 'Q', 22: 'W', 23: 'X', 24: 'Y', 25: 'Z'}
        sample = {col_letter: row[i] if i < len(row) else "" for i, col_letter in cols.items()}
        print(sample)
        count += 1
        if count >= 5:
            break

print(f"\n4/30 IB_포기호 총 건수: {sum(1 for r in all_data if len(r)>16 and r[13]=='2026-04-30' and r[16]=='IB_포기호')}")
