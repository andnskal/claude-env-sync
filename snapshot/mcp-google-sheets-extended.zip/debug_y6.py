"""Y6 BYROW 어디서 실패하는지 추적."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1행씩 검증
test_formulas = [
    # 4/30 (A6에 해당)
    ("AX1", '=COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,\'5.콜 상담내역\'!$N:$N="2026-04-30",\'5.콜 상담내역\'!$Q:$Q="IB_성공",\'5.콜 상담내역\'!$W:$W<>"기타",\'5.콜 상담내역\'!$W:$W<>"")))'),
    # 5/2 (휴일이면 IB_성공 0건일 수도)
    ("AX2", '=COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,\'5.콜 상담내역\'!$N:$N="2026-05-02",\'5.콜 상담내역\'!$Q:$Q="IB_성공",\'5.콜 상담내역\'!$W:$W<>"기타",\'5.콜 상담내역\'!$W:$W<>"")))'),
    # 5/3
    ("AX3", '=COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,\'5.콜 상담내역\'!$N:$N="2026-05-03",\'5.콜 상담내역\'!$Q:$Q="IB_성공",\'5.콜 상담내역\'!$W:$W<>"기타",\'5.콜 상담내역\'!$W:$W<>"")))'),
    # 5/4
    ("AX4", '=COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,\'5.콜 상담내역\'!$N:$N="2026-05-04",\'5.콜 상담내역\'!$Q:$Q="IB_성공",\'5.콜 상담내역\'!$W:$W<>"기타",\'5.콜 상담내역\'!$W:$W<>"")))'),
    # IFERROR으로 감싸기
    ("AX5", '=IFERROR(COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,\'5.콜 상담내역\'!$N:$N="2026-05-02",\'5.콜 상담내역\'!$Q:$Q="IB_성공",\'5.콜 상담내역\'!$W:$W<>"기타",\'5.콜 상담내역\'!$W:$W<>""))),0)'),
]

for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(3)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1:AX5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
labels = ["4/30 IB_성공 unique 상담사", "5/2", "5/3", "5/4", "5/2 with IFERROR"]
for i, label in enumerate(labels):
    val = res[i][0] if i < len(res) and res[i] else 'N/A'
    print(f"  {label}: {val}")

_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1:AX10"
).execute()
