"""강제 재계산 트리거."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 A6 수식 재입력 (강제 재계산 트리거)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
a6_formula = res[0][0] if res and res[0] else ""
print(f"A6 수식: {a6_formula[:100]}")

# 다시 입력
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6",
    valueInputOption="USER_ENTERED",
    body={"values": [[a6_formula]]},
).execute()
print("OK A6 재입력 (재계산 트리거)")

time.sleep(15)

# 1.일별 데이터 확인
print("\n[1.일별 행 6-15 데이터]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:H15",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+6}: {row}")
