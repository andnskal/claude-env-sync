"""IMPORTRANGE 로딩 후 최종 확인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW_UserChat 데이터 확인
print("[RAW_UserChat 상태]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1:CS3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if res:
    print(f"  헤더 컬럼 수: {len(res[0])}")
    if len(res[0]) > 5:
        print(f"  헤더 첫 5: {res[0][:5]}")
        print(f"  헤더 마지막 5: {res[0][-5:]}")
    print(f"  Row 2 컬럼 수: {len(res[1]) if len(res) > 1 else 0}")
    if len(res) > 1 and len(res[1]) > 5:
        print(f"  Row 2 일부: {res[1][:5]}")

# 6.채팅 5/8 데이터
print("\n[6.채팅 5/8 데이터 샘플]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:V5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res[:3]):
    if row:
        non_empty = [(chr(ord('A')+ci), str(c)[:25]) for ci, c in enumerate(row) if c]
        print(f"  Row {ri+2}: {non_empty[:8]}...")

# 1.일별 KPI
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 5/8 KPI]")
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  P (응대호): {row[15]}")
        print(f"  H (채널톡 답변): {row[7]}")
        print(f"  M (기술이관): {row[12]}")
        print(f"  AC (OB 성공): {row[28]}")
        break
