"""5.콜 AC 분포 (인하우스 분류) + OB 성공 매핑 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 AC 분포 (모든)
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter

# 5/8 OB_성공 운영시간 내, AC 분류
ob_5_8 = Counter()
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        if N == "2026-05-08" and Q == "OB_성공" and AD == "내":
            ob_5_8[AC] += 1

print("[5/8 OB_성공 운영시간 내 - AC 분포]")
for ac, c in ob_5_8.most_common():
    print(f"  '{ac}': {c}건")
print(f"  → 본사+외주: {ob_5_8.get('본사', 0) + ob_5_8.get('외주 고객센터', 0)}")
print(f"  → 전체: {sum(ob_5_8.values())}")

# 모든 일자 OB 검증 (본사+외주만)
print("\n[모든 일자 OB_성공 본사+외주만, 운영시간 내]")
date_ob_all = Counter()
date_ob_in_house = Counter()
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        if Q == "OB_성공" and AD == "내" and N:
            date_ob_all[N] += 1
            if AC in ("본사", "외주 고객센터"):
                date_ob_in_house[N] += 1

# 1.일별 AC 비교
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AC60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    AC_val = row[28] if len(row) > 28 else "?"
    direct_in_house = date_ob_in_house.get(date, 0)
    direct_all = date_ob_all.get(date, 0)
    match = "✅" if AC_val == direct_in_house else "❌"
    print(f"  {date}: 1.일별 AC={AC_val} | 본사+외주={direct_in_house} {match} | 전체 OB_성공={direct_all}")
