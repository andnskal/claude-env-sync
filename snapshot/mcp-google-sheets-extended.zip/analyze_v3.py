"""4/30 IB 시간대 분포 - FORMATTED_VALUE로 확실히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# FORMATTED + 더 큰 범위
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"총 행 수: {len(all_calls)}")
print(f"\n첫 행 전체: {all_calls[0] if all_calls else 'empty'}")

# 4/30 카운트
date_filter = "2026-04-30"
match_count = 0
samples = []
for row in all_calls:
    if len(row) > 13 and row[13] == date_filter:
        match_count += 1
        if len(samples) < 3:
            samples.append(row)

print(f"\n4/30 행 수: {match_count}")
print(f"\n샘플:")
for s in samples:
    print(f"  C={s[2] if len(s)>2 else '?'} | B={s[1] if len(s)>1 else '?'} | Q={s[16] if len(s)>16 else '?'} | N={s[13] if len(s)>13 else '?'}")

# 4/30 IB 모두 카운트
from collections import defaultdict
ib_aban_by_hour = defaultdict(int)
ib_succ_by_hour = defaultdict(int)
ib_aban_op = defaultdict(int)
ib_aban_alert = defaultdict(int)

for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-04-30": continue
    B = row[1] if len(row) > 1 else ""
    if B != "inbound": continue
    
    Q = row[16] if len(row) > 16 else ""
    C = row[2] if len(row) > 2 else ""
    X = row[23] if len(row) > 23 else ""
    Y = row[24] if len(row) > 24 else ""
    
    # C 형식: "2026-04-30 09:30:00"
    try:
        hour = int(C.split(" ")[1].split(":")[0])
    except:
        continue
    
    if Q == "IB_성공":
        ib_succ_by_hour[hour] += 1
    elif Q == "IB_포기호":
        ib_aban_by_hour[hour] += 1
        if "운영시간아님" in X:
            ib_aban_op[hour] += 1
        if Y == "알림톡발송":
            ib_aban_alert[hour] += 1

print("\n[4/30 IB 시간대 분포]")
print(f"{'시간':>4} | {'IB_성공':>8} | {'IB_포기호':>10} | {'운영외태그':>10} | {'알림톡':>8}")
print("-" * 70)

total_aban = sum(ib_aban_by_hour.values())
total_succ = sum(ib_succ_by_hour.values())
total_op = sum(ib_aban_op.values())
total_alert = sum(ib_aban_alert.values())

for h in sorted(set(list(ib_aban_by_hour.keys()) + list(ib_succ_by_hour.keys()))):
    s = ib_succ_by_hour[h]
    a = ib_aban_by_hour[h]
    ao = ib_aban_op[h]
    al = ib_aban_alert[h]
    print(f"  {h:>2}시 | {s:>8} | {a:>10} | {ao:>10} | {al:>8}")

print(f"\n4/30 총 IB_성공: {total_succ}")
print(f"4/30 총 IB_포기호 (전체 시간): {total_aban}")
print(f"4/30 IB_포기호 중 X태그 운영외: {total_op}")
print(f"4/30 IB_포기호 중 알림톡: {total_alert}")

# 구간별
print("\n[구간별 4/30 IB_포기호]")
sec_sum = {
    "🌙 새벽 00-06": 0,
    "🌅 새벽 06-09": 0,
    "📞 오전 09-12": 0,
    "🍱 점심 12-14": 0,
    "📞 오후 14-17": 0,
    "🌆 17시 이후 17-19": 0,
    "🌙 야간 19-24": 0,
}
for h, c in ib_aban_by_hour.items():
    if h < 6: sec_sum["🌙 새벽 00-06"] += c
    elif h < 9: sec_sum["🌅 새벽 06-09"] += c
    elif h < 12: sec_sum["📞 오전 09-12"] += c
    elif h < 14: sec_sum["🍱 점심 12-14"] += c
    elif h < 17: sec_sum["📞 오후 14-17"] += c
    elif h < 19: sec_sum["🌆 17시 이후 17-19"] += c
    else: sec_sum["🌙 야간 19-24"] += c

for s, c in sec_sum.items():
    pct = c / total_aban * 100 if total_aban else 0
    print(f"  {s:>30}: {c:>3}건 ({pct:>5.1f}%)")
