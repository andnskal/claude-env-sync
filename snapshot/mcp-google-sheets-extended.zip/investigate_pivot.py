"""3,4번 시트 구조 — A:K 자세히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

for sheet_name in ["3.상담사별 채팅 실적", "4.상담사별 콜 실적"]:
    print("\n" + "=" * 80)
    print(f"📋 {sheet_name}")
    print("=" * 80)
    
    formulas = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A1:K20",
        valueRenderOption="FORMULA",
    ).execute().get("values", [])
    values = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A1:K20",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    
    # 헤더
    if formulas:
        for ri in range(min(5, len(formulas))):
            print(f"\n  Row {ri+1}:")
            for ci in range(11):
                f = formulas[ri][ci] if ri < len(formulas) and ci < len(formulas[ri]) else ""
                v = values[ri][ci] if ri < len(values) and ci < len(values[ri]) else ""
                col = chr(ord('A') + ci)
                if f or v:
                    print(f"    {col}{ri+1}: F='{str(f)[:60]}' / V='{str(v)[:30]}'")
    
    print("\n  [데이터 영역 샘플 (A6:K10)]")
    for ri in range(5, min(15, len(formulas))):
        row_data = []
        for ci in range(11):
            v = values[ri][ci] if ri < len(values) and ci < len(values[ri]) else ""
            if v:
                col = chr(ord('A') + ci)
                row_data.append(f"{col}={str(v)[:15]}")
        if row_data:
            print(f"    Row {ri+1}: {row_data}")
