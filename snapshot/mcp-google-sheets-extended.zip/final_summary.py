"""최종 정합성 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 모든 일자 KPI
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AW60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 80)
print("점심시간 예외 적용 후 1.일별 KPI")
print("=" * 80)
print(f"{'날짜':>12} | {'P':>4} | {'Q':>4} | {'R응대율':>8} | {'AC':>4} | 비고")
print("-" * 80)
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    P = row[15] if len(row) > 15 else "?"
    Q = row[16] if len(row) > 16 else "?"
    R = row[17] if len(row) > 17 else 0
    AC = row[28] if len(row) > 28 else "?"
    r_str = f"{R*100:.1f}%" if isinstance(R, (int, float)) else str(R)
    note = ""
    if date == "2026-05-11":
        note = "← 예외 점심 11:50-13:00 적용"
    print(f"  {date} | {P:>4} | {Q:>4} | {r_str:>8} | {AC:>4} | {note}")

# 5/11 핵심 검증 — 점심 시간 외 모두 정상
print("\n" + "=" * 80)
print("[5/11 예외 점심 (11:50-13:00) 시간대 분포 (운영시간 외)]")
print("=" * 80)

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
counts = defaultdict(lambda: defaultdict(int))
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h*60+m
    except:
        continue
    section = None
    if tm < 540: section = "09시 미만"
    elif tm < 710: section = "09:00-11:50"
    elif tm < 780: section = "11:50-13:00 (예외 점심)"
    elif tm < 1050: section = "13:00-17:30"
    else: section = "17:30 이후"
    counts[section][row[29]] += 1

for sec, ad_counts in sorted(counts.items()):
    total = sum(ad_counts.values())
    내 = ad_counts.get("내", 0)
    외 = ad_counts.get("외", 0)
    print(f"  {sec:>20}: 총 {total:>4}건 (내={내}, 외={외})")
