"""운영시간 외 OB 콜 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict, Counter
date_ob_in = defaultdict(int)
date_ob_out = defaultdict(int)
date_ob_out_succ = defaultdict(int)
date_ib_in = defaultdict(int)
date_ib_out_aban = defaultdict(int)  # 운영시간 외 IB 부재

ob_out_hours = Counter()
ob_out_agents = Counter()

for row in all_calls:
    if len(row) > 29:
        N, B, Q, AC, AD = row[13], row[1], row[16], row[28], row[29]
        P_time = row[15] if len(row) > 15 else ""
        W = row[22] if len(row) > 22 else ""
        if not N: continue
        
        # OB
        if B == "outbound":
            if AD == "내": date_ob_in[N] += 1
            elif AD == "외":
                date_ob_out[N] += 1
                ob_out_hours[P_time] += 1
                ob_out_agents[W] += 1
                if Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
                    date_ob_out_succ[N] += 1
        # IB
        elif B == "inbound":
            if AD == "내": date_ib_in[N] += 1
            elif AD == "외":
                if Q == "IB_포기호":
                    date_ib_out_aban[N] += 1

# 일자별 출력
print("=" * 80)
print("[일자별 OB 분포]")
print("=" * 80)
print(f"{'날짜':>12} | {'OB 운영시간내':>10} | {'OB 운영시간외':>10} | {'중 OB_성공 (외)':>10} | {'IB 운영시간외 부재':>10}")
for date in sorted(set(list(date_ob_in.keys()) + list(date_ob_out.keys()))):
    ob_i = date_ob_in[date]
    ob_o = date_ob_out[date]
    ob_o_s = date_ob_out_succ[date]
    ib_o = date_ib_out_aban[date]
    if ob_i or ob_o or ib_o:
        print(f"{date:>12} | {ob_i:>10} | {ob_o:>10} | {ob_o_s:>10} | {ib_o:>10}")

print("\n[OB 운영시간 외 - 시간대 분포]")
for tb in sorted(ob_out_hours.keys()):
    print(f"  {tb}: {ob_out_hours[tb]}건")

print("\n[OB 운영시간 외 - 상담사]")
for ag, cnt in ob_out_agents.most_common(10):
    print(f"  {ag}: {cnt}건")
