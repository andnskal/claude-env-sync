"""3,4 시트 C3 수식에 운영시간 필터 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 3.상담사별 채팅 C3
chat_c3 = (
    '=ARRAYFORMULA(IF(ISBLANK(B3:B50),,IF(ISBLANK($C$2:$LG$2),,'
    'MAP(B3:B50,LAMBDA(상담사,'
    "COUNTIFS('6.채팅 상담내역'!$N:$N,상담사,"
    "'6.채팅 상담내역'!$O:$O,$C$1:$LG$1,"
    "'6.채팅 상담내역'!$M:$M,$C$2:$LG$2,"
    "'6.채팅 상담내역'!$Y:$Y," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + "))))))"
)

# 4.상담사별 콜 C3
call_c3 = (
    '=ARRAYFORMULA(IF(ISBLANK(B3:B50),,IF(ISBLANK($C$2:$LG$2),,'
    'MAP(B3:B50,LAMBDA(상담사,'
    "COUNTIFS('5.콜 상담내역'!$W:$W,상담사,"
    "'5.콜 상담내역'!$N:$N,$C$1:$LG$1,"
    "'5.콜 상담내역'!$Q:$Q,$C$2:$LG$2,"
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + "))))))"
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!C3",
    valueInputOption="USER_ENTERED",
    body={"values": [[chat_c3]]},
).execute()
print("OK 3.상담사별 채팅 C3 수식 업데이트 (운영시간 필터)")

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!C3",
    valueInputOption="USER_ENTERED",
    body={"values": [[call_c3]]},
).execute()
print("OK 4.상담사별 콜 C3 수식 업데이트 (운영시간 필터)")

time.sleep(8)

# 검증
print("\n[3.상담사별 5/8 채널톡 답변 합 (운영시간 필터)]")
res3 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_chann = 0
if res3 and len(res3) >= 3:
    for ci, (d, ch) in enumerate(zip(res3[0], res3[1])):
        if isinstance(d, str) and d == "2026-05-08" and ch == "채널톡":
            for ri in range(2, len(res3)):
                if ci < len(res3[ri]) and isinstance(res3[ri][ci], (int, float)):
                    sum_chann += res3[ri][ci]
print(f"  3.상담사별 5/8 채널톡: {sum_chann}")

# 1.일별 5/8 H 비교
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:H60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        H_val = row[7] if len(row) > 7 else "?"
        print(f"  1.일별 5/8 H (채널톡 답변): {H_val}")
        if sum_chann == H_val:
            print(f"  -> 일치 (운영시간 기준)")
        break

# 4.상담사별 5/8 IB_성공 합
print("\n[4.상담사별 5/8 IB_성공 합 (운영시간 필터)]")
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_ib = sum_ob = 0
if res4 and len(res4) >= 3:
    for ci, (d, t) in enumerate(zip(res4[0], res4[1])):
        if isinstance(d, str) and d == "2026-05-08":
            for ri in range(2, len(res4)):
                if ci < len(res4[ri]) and isinstance(res4[ri][ci], (int, float)):
                    if t == "IB_성공":
                        sum_ib += res4[ri][ci]
                    elif t == "OB_성공":
                        sum_ob += res4[ri][ci]
print(f"  4.상담사별 5/8 IB_성공: {sum_ib}")
print(f"  4.상담사별 5/8 OB_성공: {sum_ob}")
