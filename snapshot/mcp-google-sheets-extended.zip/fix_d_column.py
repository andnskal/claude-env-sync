"""1분단위 D4 수식 — 행별 COUNTA로 통화중 인원 카운트."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# D4: 통화중 인원 = 각 행에서 F:T의 '********' 카운트
d4_formula = '=BYROW(F4:T513, LAMBDA(row, IF(COUNTA(row)=0,, COUNTA(row))))'

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!D4",
    valueInputOption="USER_ENTERED",
    body={"values": [[d4_formula]]},
).execute()
print("✅ D4 — BYROW 행별 COUNTA")

time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A30:V100",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[1분단위 9:25~10:33 — 통화중/포기호 검증]")
print(f"{'행':>4} | {'시간':>6} | {'통화중':>4} | {'포기호':>10} | {'F':>10} | {'G':>10} | {'H':>10} | {'I':>10}")
for ri, row in enumerate(res):
    if not row: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    e = row[4] if len(row) > 4 else ""
    f = row[5] if len(row) > 5 else ""
    g = row[6] if len(row) > 6 else ""
    h = row[7] if len(row) > 7 else ""
    i = row[8] if len(row) > 8 else ""
    # 매칭된 행만
    if e or f or g or h or i:
        print(f"{ri+30:>4} | {time_str:>6} | {counta:>4} | {e:>10} | {f:>10} | {g:>10} | {h:>10} | {i:>10}")
