"""5분단위 시트 디버그 - 무엇이 문제인지 파악."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# A:E 표시값 확인 (행 4-15)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A4:F20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[A4:F20 표시값]")
for ri, row in enumerate(res):
    print(f"  Row {ri+4}: {row}")

# 수식
res_f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A4:F8",
    valueRenderOption="FORMULA",
).execute().get("values", [])
print("\n[A4:F8 수식]")
for ri, row in enumerate(res_f):
    print(f"  Row {ri+4}: {row}")

# E4 직접 평가 — 단순 SUMPRODUCT
test_formulas = [
    ("X1", '=ISBLANK(\'5분 단위 포기호, 통화상세\'!C4)'),
    ("X2", '=\'5분 단위 포기호, 통화상세\'!C4'),
    ("X3", '=\'5분 단위 포기호, 통화상세\'!C5'),
    ("X4", '=\'5분 단위 포기호, 통화상세\'!B4'),
    ("X5", '=\'5분 단위 포기호, 통화상세\'!B5'),
    ("X6", '=COUNTA(\'5분 단위 포기호, 통화상세\'!B4:B135)'),
    ("X7", '=HOUR(\'5분 단위 포기호, 통화상세\'!C4)'),
    ("X8", '=HOUR(\'RAW시간대별 포기호, 통화상세\'!A3)'),
]
for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'5분 단위 포기호, 통화상세'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(2)
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!X1:X8",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[테스트 결과]")
labels = ["C4 ISBLANK?", "C4 값", "C5 값", "B4 값", "B5 값", "B 비어있지 않은 셀 수", "HOUR(C4)", "HOUR(RAW A3)"]
for i, label in enumerate(labels):
    val = res2[i][0] if i < len(res2) and res2[i] else 'N/A'
    print(f"  {label}: {val}")
