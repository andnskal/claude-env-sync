"""최종 일관성 마무리 - 컬럼 너비 표준화 + 헤더 색상 정리."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 1.일별 컬럼 너비 표준화 (현재 90px와 100px 혼재)
print("=" * 70)
print("1️⃣ 1.일별 컬럼 너비 표준화")
print("=" * 70)
sid_daily = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")
reqs = []
# A:B (날짜/구분) 110px
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid_daily, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 2},
    "properties": {"pixelSize": 110}, "fields": "pixelSize"}})
# C:AT (모든 데이터 컬럼) 100px
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid_daily, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 46},
    "properties": {"pixelSize": 100}, "fields": "pixelSize"}})
_batch_update(NEW, reqs)
print("✅ 1.일별 너비 통일 (A:B 110px, C:AT 100px)")

# 2) 2.시간대별 컬럼 너비 표준화
print("\n" + "=" * 70)
print("2️⃣ 2.시간대별 컬럼 너비 표준화")
print("=" * 70)
sid_hourly = _get_sheet_id_by_name(NEW, "2.시간대별 전체통계")
reqs = []
# A (일자) 90, B (텍스트변환) 110, C (시간) 80
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid_hourly, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1},
    "properties": {"pixelSize": 90}, "fields": "pixelSize"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid_hourly, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2},
    "properties": {"pixelSize": 110}, "fields": "pixelSize"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid_hourly, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 3},
    "properties": {"pixelSize": 80}, "fields": "pixelSize"}})
# D-AL 모두 90px
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid_hourly, "dimension": "COLUMNS", "startIndex": 3, "endIndex": 38},
    "properties": {"pixelSize": 90}, "fields": "pixelSize"}})
_batch_update(NEW, reqs)
print("✅ 2.시간대별 너비 통일")

# 3) 3,4번 시트 동일 (B 넓게, 나머지 100px)
for sheet_name, last_col in [("3.상담사별 채팅 실적", 56), ("4.상담사별 콜 실적", 39)]:
    sid = _get_sheet_id_by_name(NEW, sheet_name)
    reqs = []
    # A (정렬 토글) 80
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1},
        "properties": {"pixelSize": 80}, "fields": "pixelSize"}})
    # B (상담사 이름) 150
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2},
        "properties": {"pixelSize": 150}, "fields": "pixelSize"}})
    # C+ 90
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": last_col},
        "properties": {"pixelSize": 90}, "fields": "pixelSize"}})
    _batch_update(NEW, reqs)
    print(f"✅ {sheet_name} 너비 통일")

# 4) ★설정 너비 (이미 적절. 유지)
print("\n[★설정 너비 유지 — 이미 최적화]")

# 5) 시간대별 + 일별 + 3,4 헤더에 그룹 색상 강화
print("\n" + "=" * 70)
print("3️⃣ 헤더 색상 강화 (각 그룹별 명확한 구분)")
print("=" * 70)

# 1.일별 그룹 색상 적용
group_colors_daily = [
    # (start_col, end_col, color)
    (0, 2, (0.4, 0.5, 0.6)),    # A:B 날짜/구분 - 회색
    (2, 11, (0.20, 0.55, 0.55)),  # C:K 채팅 전체 - 청록
    (11, 14, (0.30, 0.65, 0.65)),  # L:N 채팅 합계 - 더 밝은 청록
    (14, 33, (0.20, 0.40, 0.65)),  # O:AG IB/OB - 진한 파랑
    (33, 34, (0.45, 0.55, 0.75)),  # AH 상담톡 - 보라
    (34, 36, (0.85, 0.78, 0.55)),  # AI:AJ 콜백 - 베이지
    (36, 39, (0.85, 0.55, 0.40)),  # AK:AM KPI - 주황
    (39, 46, (0.80, 0.40, 0.40)),  # AN:AT 부재중 사유 - 빨강
]
reqs = []
for start, end, (r, g, b) in group_colors_daily:
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid_daily, "startRowIndex": 0, "endRowIndex": 3, "startColumnIndex": start, "endColumnIndex": end},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": r, "green": g, "blue": b},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }})
_batch_update(NEW, reqs)
print("✅ 1.일별 그룹별 색상 적용")

# 2.시간대별 그룹 색상
group_colors_hourly = [
    (0, 3, (0.4, 0.5, 0.6)),     # A:C 날짜/시간 - 회색
    (3, 6, (0.5, 0.6, 0.45)),    # D:F 투입인원 - 녹색
    (6, 23, (0.20, 0.40, 0.65)), # G:W IB - 진한 파랑
    (23, 27, (0.45, 0.40, 0.65)), # X:AA OB - 보라
    (27, 38, (0.20, 0.55, 0.55)), # AB:AL 채팅 - 청록
]
reqs = []
for start, end, (r, g, b) in group_colors_hourly:
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid_hourly, "startRowIndex": 0, "endRowIndex": 3, "startColumnIndex": start, "endColumnIndex": end},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": r, "green": g, "blue": b},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }})
_batch_update(NEW, reqs)
print("✅ 2.시간대별 그룹별 색상 적용")

# 3,4번 시트 헤더 통일 색상 (행 1, 2 진한 색)
for sheet_name in ["3.상담사별 채팅 실적", "4.상담사별 콜 실적"]:
    sid = _get_sheet_id_by_name(NEW, sheet_name)
    reqs = []
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 2, "startColumnIndex": 0, "endColumnIndex": 60},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.20, "green": 0.30, "blue": 0.50},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
    }})
    _batch_update(NEW, reqs)
print("✅ 3,4번 시트 헤더 색상 통일")

print("\n🎉 종합 서식 정리 완료")
