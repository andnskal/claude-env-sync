"""권한 안내문 제거 + SPLIT 충돌 해결."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
sid = _get_sheet_id_by_name(NEW, "RAW 55번 기술 이관")

# 1) 권한 안내문 제거 (N1:Q2)
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!N1:Q2"
).execute()
# 병합 해제
_batch_update(NEW, [{
    "unmergeCells": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 2, "startColumnIndex": 13, "endColumnIndex": 17}
    }
}])
print("OK 권한 안내 제거")

# 2) 헤더 다시 입력 (M-Q)
headers = [["날짜 텍스트변환", "운영시간 분류", "팀(★설정 분리)", "이름(★설정 분리)", "비고"]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!M1:Q1",
    valueInputOption="USER_ENTERED",
    body={"values": headers},
).execute()

# 3) Q2 비고 (다른 컬럼 spillover 막지 않도록)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!Q2",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(ISBLANK(C2:C),,"외주 도급사 데이터"))']]},
).execute()

time.sleep(8)

# 4) 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!M1:Q5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[M-Q 정상 작동 확인]")
for ri, row in enumerate(res):
    print(f"  Row {ri+1}: {row}")

# 5) J 매핑 재확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2:J10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
j_dist = Counter(r[0][:30] for r in res if r and r[0])
matched = sum(v for k, v in j_dist.items() if not k.startswith("@@"))
unmatched = sum(v for k, v in j_dist.items() if k.startswith("@@"))
print(f"\n[J 매핑 결과]")
print(f"  매핑 성공: {matched}건")
print(f"  매핑 실패: {unmatched}건")
print(f"\n매핑 성공 상위 5:")
for k, v in j_dist.most_common(15):
    if not k.startswith("@@"):
        print(f"  {k}: {v}건")
