"""기존 시트의 시각적 서식을 핵심 부분만 추출 (헤더부 + 첫 데이터 행)"""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

LEGACY = "1iGF-f5kvcGBZtoY4efjkBMNCfeFhW6shp2wWRLKkJEo"

TARGETS = [
    ("★설정", "A1:S20"),
    ("1.일별 전체 통계", "A1:AH7"),
    ("2.시간대별 전체통계", "A1:AM6"),
    ("3.상담사별 채팅 실적", "A1:K5"),
    ("4.상담사별 콜 실적", "A1:K5"),
    ("5.콜 상담내역", "A1:U2"),
    ("6.채팅 상담내역", "A1:N2"),
]


def hex_from_rgb(c):
    if not c: return None
    r = int(round(c.get("red",0)*255))
    g = int(round(c.get("green",0)*255))
    b = int(round(c.get("blue",0)*255))
    return f"#{r:02X}{g:02X}{b:02X}"


def col_letter(idx):
    s = ""
    n = idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


def analyze(sheet_name, range_str):
    result = _sheets.spreadsheets().get(
        spreadsheetId=LEGACY,
        ranges=[f"'{sheet_name}'!{range_str}"],
        includeGridData=True,
        fields="sheets(properties(title,sheetId,gridProperties),merges,data(startRow,startColumn,rowData(values(userEnteredValue,userEnteredFormat))))"
    ).execute()
    sheet = result["sheets"][0]
    out = {
        "title": sheet["properties"]["title"],
        "frozen_rows": sheet["properties"]["gridProperties"].get("frozenRowCount", 0),
        "frozen_cols": sheet["properties"]["gridProperties"].get("frozenColumnCount", 0),
        "total_rows": sheet["properties"]["gridProperties"].get("rowCount", 0),
        "total_cols": sheet["properties"]["gridProperties"].get("columnCount", 0),
        "merges": [
            {"row": f"{m['startRowIndex']+1}-{m['endRowIndex']}",
             "col": f"{col_letter(m['startColumnIndex'])}-{col_letter(m['endColumnIndex']-1)}"}
            for m in sheet.get("merges", [])
            if m['startRowIndex'] < {"A1:S20":20,"A1:AH7":7,"A1:AM6":6,"A1:K5":5,"A1:U2":2,"A1:N2":2}.get(range_str, 100)
        ],
        "header_styles": {},
        "data_row_format": {},
    }
    # 헤더 행별 스타일 (행 1-3)
    rows = sheet.get("data", [{}])[0].get("rowData", [])
    for ri in range(min(3, len(rows))):
        row = rows[ri].get("values", [])
        styles = []
        for ci, cell in enumerate(row):
            fmt = cell.get("userEnteredFormat", {})
            bg = hex_from_rgb(fmt.get("backgroundColor"))
            tf = fmt.get("textFormat", {})
            fc = hex_from_rgb(tf.get("foregroundColor"))
            sty = {
                "col": col_letter(ci),
                "bg": bg if bg and bg != "#FFFFFF" else None,
                "bold": tf.get("bold"),
                "fontSize": tf.get("fontSize"),
                "fg": fc if fc and fc != "#000000" else None,
                "halign": fmt.get("horizontalAlignment"),
                "valign": fmt.get("verticalAlignment"),
                "numFmt": fmt.get("numberFormat", {}).get("type"),
                "numPattern": fmt.get("numberFormat", {}).get("pattern"),
            }
            sty = {k: v for k, v in sty.items() if v is not None}
            if len(sty) > 1:  # col 외에 뭔가 있을 때만
                styles.append(sty)
        out["header_styles"][f"row{ri+1}"] = styles
    # 첫 데이터 행 (보통 4-6행) 형식 — A열 외 대표 컬럼
    if len(rows) > 3:
        data_row = rows[3].get("values", [])
        for ci, cell in enumerate(data_row[:30]):
            fmt = cell.get("userEnteredFormat", {})
            nf = fmt.get("numberFormat", {})
            if nf.get("type") and nf.get("type") != "TEXT":
                out["data_row_format"][col_letter(ci)] = {
                    "type": nf.get("type"),
                    "pattern": nf.get("pattern"),
                }
    return out


results = {}
for name, rng in TARGETS:
    try:
        results[name] = analyze(name, rng)
        print(f"✅ {name} 분석 완료")
    except Exception as e:
        results[name] = {"error": str(e)}
        print(f"❌ {name}: {e}")

with open(os.path.join(os.path.dirname(__file__), "legacy_format.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print(f"\n저장: legacy_format.json")
