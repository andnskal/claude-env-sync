"""5/11 박슬기 / 정현호 — 채널톡 vs 우리 시스템 1건 차이.
가설 검증:
  - 박슬기 09:37:21: 콜백대상/부재중전화 태그 → 채널톡에서 콜백 콜로 별도 처리?
  - 정현호 17:18:08: 17:30 이후 종료 → 채널톡 운영시간 종료 기준?
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"

# 박슬기 09:37:21 case 분석
# 이 chatId의 RAW 원본을 확인 (UserChat 97열)
print("=" * 80)
print("[가설 A] 박슬기 09:37:21 — '콜백대상, 부재중전화' 태그")
print("=" * 80)

# 5.콜에서 chatId 확보
calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

ps_target_chatid = None
ps_call = None
for row in calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_박슬기": continue
    if row[2] == "2026-05-11 09:37:21":
        ps_target_chatid = row[0]
        ps_call = row
        break

print(f"  chatId: {ps_target_chatid}")
print(f"  startedAt: {ps_call[2]}")
print(f"  firstEngagedAt: {ps_call[3]}")
print(f"  endedAt: {ps_call[4]}")
print(f"  duration: {ps_call[17]}")
print(f"  tags: {ps_call[23]}")
print(f"  콜백/알림톡 분류 (Y): {ps_call[24]}")

# 같은 chatId가 RAW에 몇 건? (콜백 = 같은 chatId에 inbound + outbound 가능)
raw_meet = _sheets.spreadsheets().values().get(
    spreadsheetId=RAW, range="'UserChat meet data'!A1:AG5000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

raw_h = raw_meet[0] if raw_meet else []
print(f"\n  RAW UserChat meet data — chatId {ps_target_chatid} 매칭:")
for ri in range(1, len(raw_meet)):
    r = raw_meet[ri]
    if r and r[0] == ps_target_chatid:
        # 33열 모두 출력
        for ci, h in enumerate(raw_h):
            v = r[ci] if ci < len(r) else ""
            if v: print(f"    {h}: {v}")
        print()

# 채널톡 부재중 콜 처리: 부재중에서 IB_성공으로 전환된 케이스 분석
# 같은 시간대에 같은 chatId의 다른 meet 레코드(IB_포기호)가 있는지?
print("\n  같은 chatId의 RAW 모든 meet 레코드:")
same_id_meets = []
for ri in range(1, len(raw_meet)):
    r = raw_meet[ri]
    if r and r[0] == ps_target_chatid:
        same_id_meets.append((ri, r))

print(f"  → 총 {len(same_id_meets)}건")
for ri, r in same_id_meets:
    print(f"    행 {ri}: startedAt={r[6] if len(r)>6 else ''} | direction={r[7] if len(r)>7 else ''} | "
          f"firstEng={r[19] if len(r)>19 else ''} | missedReason={r[31] if len(r)>31 else ''}")

# 정현호 17:18:08 case 분석
print("\n" + "=" * 80)
print("[가설 B] 정현호 17:18:08 — 종료시간이 17:30 이후 (17:33:22)")
print("=" * 80)

jh_target_chatid = None
jh_call = None
for row in calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_정현호": continue
    if row[2] == "2026-05-11 17:18:08":
        jh_target_chatid = row[0]
        jh_call = row
        break

print(f"  chatId: {jh_target_chatid}")
print(f"  startedAt: {jh_call[2]} (09:00-17:30 내)")
print(f"  firstRingStartedAt: {jh_call[26]} (17:21:13)")
print(f"  firstEngagedAt: {jh_call[3]} (17:21:17)")
print(f"  endedAt: {jh_call[4]} (17:33:22 → 17:30 종료 후 3분 22초)")
print(f"  duration: {jh_call[17]}")
print(f"  AD (운영시간 분류): {jh_call[29]}")
print(f"  → 우리 시스템: startedAt 기준 → '내' → IB_성공 카운트")
print(f"  → 채널톡 추정: endedAt 기준 운영시간 외 → IB에서 제외 가능")

# 같은 패턴(17:30 이후 종료) 다른 상담사 콜이 있는지 — 일관성 검증
print("\n  [5/11 모든 IB_성공 콜 중 endedAt이 17:30 이후인 케이스]")
for row in calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[16] != "IB_성공": continue
    E = row[4] if len(row) > 4 else ""
    if not E or "2026-05-11" not in E: continue
    try:
        h, m = int(E.split(" ")[1].split(":")[0]), int(E.split(" ")[1].split(":")[1])
        tm = h*60+m
        if tm >= 1050:  # 17:30 이후
            print(f"    {row[22]:>10}: started={row[2]} | ended={E}")
    except:
        pass

# 다른 의심 케이스: ringStartedAt이 17:30 이후 시작?
print("\n  [5/11 IB_성공 중 firstRingStartedAt이 17:30 이후]")
for row in calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[16] != "IB_성공": continue
    AA = row[26] if len(row) > 26 else ""
    if not AA or "2026-05-11" not in AA: continue
    try:
        h, m = int(AA.split(" ")[1].split(":")[0]), int(AA.split(" ")[1].split(":")[1])
        tm = h*60+m
        if tm >= 1050:
            print(f"    {row[22]:>10}: started={row[2]} | ringStarted={AA}")
    except:
        pass

# 같은 chatId가 다른 시트에도 있는지 (UserChat 97열)
print("\n  [정현호 17:18 chatId의 UserChat 레코드]")
uc_h = _sheets.spreadsheets().values().get(
    spreadsheetId=RAW, range="'UserChat'!A1:CS1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if uc_h:
    uc_headers = uc_h[0]
    # firstAnsweredAt 등 필드
    target_cols = []
    for ci, h in enumerate(uc_headers):
        if h in ("id", "firstAnsweredAt", "closedAt", "createdAt", "operationOpenedAt", "operationClosedAt", "missedReason", "state"):
            target_cols.append((ci, h))

    # UserChat full
    uc_data = _sheets.spreadsheets().values().get(
        spreadsheetId=RAW, range="'UserChat'!A1:CS",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])

    for r in uc_data[1:]:
        if r and r[0] == jh_target_chatid:
            for ci, h in target_cols:
                v = r[ci] if ci < len(r) else ""
                if v: print(f"    {h}: {v}")
            break

# 정현호 11:26:28 매우 짧은 콜 (30초)
print("\n" + "=" * 80)
print("[보조 가설] 정현호 11:26:28 — 통화시간 30초 (매우 짧음)")
print("=" * 80)
for row in calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_정현호": continue
    if row[2] == "2026-05-11 11:26:28":
        print(f"  chatId: {row[0]}")
        print(f"  duration: {row[17]} (30초)")
        print(f"  firstEng: {row[3]}")
        print(f"  endedAt: {row[4]}")
        print(f"  → 30초 통화: 채널톡 dashboard에서 '실패/연결 즉시 종료'로 처리될 가능성")
        break

# 결론
print("\n" + "=" * 80)
print("[결론]")
print("=" * 80)
print("""
박슬기 36 vs 35:
  → 의심 콜: 2026-05-11 09:37:21 (chatId={ps})
    - 태그: '콜백대상, 부재중전화, 만족도조사, AS문의/자전거'
    - direction: inbound, firstEngagedAt 채워짐 → 우리는 IB_성공 카운트
    - 채널톡: '부재중 → 콜백' 태그를 가진 콜을 별도 카테고리로 처리할 가능성

정현호 26 vs 25:
  → 의심 콜: 2026-05-11 17:18:08 (chatId={jh})
    - startedAt: 17:18 (운영시간 내) → 우리는 '내' → IB_성공
    - endedAt: 17:33:22 (운영시간 17:30 종료 후 3분 22초)
    - 채널톡 추정: endedAt이 운영시간 외에 위치 → '운영시간 외' 콜로 제외
    - 또는 다른 30초 짧은 콜 (11:26:28)

종합: 두 케이스 모두 우리 시스템의 분류 룰이 채널톡과 미세하게 다른 케이스.
""".format(ps=ps_target_chatid, jh=jh_target_chatid))
