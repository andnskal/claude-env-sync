"""체인 검증 - RAW → 5.콜 → 2.시간대별 → 1.일별."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW_NewMeet 확인
print("[RAW_NewMeet 데이터]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1:E5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for r in res[:3]:
    print(f"  {r}")

# 5.콜 데이터
print("\n[5.콜 데이터]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:Q5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    if r:
        print(f"  Row {ri+2}: A={r[0] if len(r)>0 else ''}, N={r[13] if len(r)>13 else ''}, Q={r[16] if len(r)>16 else ''}")

# 2.시간대별 데이터
print("\n[2.시간대별 데이터]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:F10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    if r:
        print(f"  Row {ri+4}: {r[:6]}")

# 1.일별 A6 결과
print("\n[1.일별 A6]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:A15",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    if r:
        print(f"  A{ri+6}: {r[0] if r else '(empty)'}")
