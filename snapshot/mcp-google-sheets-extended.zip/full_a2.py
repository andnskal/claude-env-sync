"""이전 시트 6.채팅 A2 전체 수식 + 신 시스템 비교."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 이전 시트 6.채팅 A2 전체 수식 (잘리지 않게)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'6.채팅 상담내역'!A2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
old_a2 = res[0][0] if res and res[0] else ""
print("=" * 80)
print("이전 시트 6.채팅!A2 전체 수식")
print("=" * 80)
print(old_a2)

# 신 시스템 6.채팅 A2
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
new_a2 = res[0][0] if res and res[0] else ""
print("\n" + "=" * 80)
print("신 시스템 6.채팅!A2 수식")
print("=" * 80)
print(new_a2)

# 차이 분석
print("\n" + "=" * 80)
print("[분석]")
print("=" * 80)
if "RAW 55" in old_a2:
    print("✅ 이전 시트 A2 = 채널톡 채팅 + RAW 55번 기술 이관 데이터를 VSTACK으로 합침")
if "RAW 55" not in new_a2:
    print("❌ 신 시스템 A2 = RAW 55번 기술 이관 데이터 미포함 (누락)")

# 이전 시트 6.채팅에서 기술이관 행 카운트
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'6.채팅 상담내역'!M:M",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
tech_count = sum(1 for r in res if r and r[0] == "기술이관")
print(f"\n이전 시트 6.채팅 기술이관 행 수: {tech_count}")

# 이전 시트의 RAW 55 데이터 행 수
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW 55번 기술 이관'!A:A",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
raw55_count = sum(1 for r in res if r and r[0])
print(f"이전 시트 RAW 55번 기술 이관 데이터 행 수: {raw55_count}")
