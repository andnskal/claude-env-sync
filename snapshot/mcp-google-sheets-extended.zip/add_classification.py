"""RAW 55 R 컬럼 = 직원+채널 분류 추가 + 1.일별 M 통합 수식 정정."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) RAW 55에 R 컬럼 추가
print("[1] RAW 55 R 컬럼 (분류) 추가")

# R1 헤더
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!R1",
    valueInputOption="USER_ENTERED",
    body={"values": [["분류 (직원_채널)"]]},
).execute()

# R2 분류 수식
# 미매핑 (J가 "@@" 시작) → "미매핑" (제외)
# 외주 (J가 "TCK_" 또는 "CS쉐어링_" 시작) + 채팅 → "외주_채팅"
# 외주 + 비채팅 → "외주_비채팅"
# 본사 (J가 "CS_", "CX_", "기술_" 등 그 외 매핑) + 채팅 → "본사_채팅" (채널톡 중복으로 카운트 제외)
# 본사 + 비채팅 → "본사_비채팅" (RAW 55 카운트)
r2_formula = (
    '=ARRAYFORMULA(IF(ISBLANK(C2:C),,'
    'IF(LEFT(J2:J,2)="@@", "미매핑",'
    'IF((LEFT(J2:J,4)="TCK_")+(LEFT(J2:J,6)="CS쉐어링"),'
    'IF(H2:H="채팅","외주_채팅","외주_비채팅"),'
    'IF(H2:H="채팅","본사_채팅","본사_비채팅")))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!R2",
    valueInputOption="USER_ENTERED",
    body={"values": [[r2_formula]]},
).execute()
print("  OK R2 분류 수식")

time.sleep(8)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!R2:R10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
r_dist = Counter(r[0] for r in res if r and r[0])
print(f"\n[R 분류 분포]")
for k, v in r_dist.most_common():
    print(f"  {k}: {v}건")

# 2) 1.일별 M (기술이관) 수식 정정
print("\n[2] 1.일별 M (기술이관) 통합 수식 정정")

# M = 본사 채널톡 채팅 + RAW 55 외주_채팅 + RAW 55 외주_비채팅 + RAW 55 본사_비채팅
# (본사_채팅 제외 — 채널톡 중복 / 미매핑 제외)
new_m = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    # 본사 채널톡 채팅 기술이관
    "COUNTIFS('6.채팅 상담내역'!$O:$O,LEFT(d,10),"
    "'6.채팅 상담내역'!$M:$M," + '"기술이관"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")"
    # RAW 55 외주_채팅
    "+COUNTIFS('RAW 55번 기술 이관'!$M:$M,LEFT(d,10),"
    "'RAW 55번 기술 이관'!$K:$K," + '"기술이관"' + ","
    "'RAW 55번 기술 이관'!$N:$N," + '"내"' + ","
    "'RAW 55번 기술 이관'!$R:$R," + '"외주_채팅"' + ")"
    # RAW 55 외주_비채팅
    "+COUNTIFS('RAW 55번 기술 이관'!$M:$M,LEFT(d,10),"
    "'RAW 55번 기술 이관'!$K:$K," + '"기술이관"' + ","
    "'RAW 55번 기술 이관'!$N:$N," + '"내"' + ","
    "'RAW 55번 기술 이관'!$R:$R," + '"외주_비채팅"' + ")"
    # RAW 55 본사_비채팅 (전화/게시판/메일/핫라인 등)
    "+COUNTIFS('RAW 55번 기술 이관'!$M:$M,LEFT(d,10),"
    "'RAW 55번 기술 이관'!$K:$K," + '"기술이관"' + ","
    "'RAW 55번 기술 이관'!$N:$N," + '"내"' + ","
    "'RAW 55번 기술 이관'!$R:$R," + '"본사_비채팅"' + "))))"
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!M6",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_m]]},
).execute()
print("  OK M6 통합 수식 (4개 카테고리 합산)")

time.sleep(8)

# 3) 검증
print("\n[3] 1.일별 M 결과 (수정 후)]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:M30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in res:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        date = row[0]
        H = row[7] if len(row) > 7 else "?"
        L = row[11] if len(row) > 11 else "?"
        M = row[12] if len(row) > 12 else "?"
        print(f"  {date}: H={H}, L={L}, M={M}")

# 4) RAW 55 헤더 서식 강화 (R 컬럼)
from server import _get_sheet_id_by_name, _batch_update
sid = _get_sheet_id_by_name(NEW, "RAW 55번 기술 이관")
_batch_update(NEW, [
    {"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 17, "endColumnIndex": 18},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.95, "green": 0.6, "blue": 0.2},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 17, "endIndex": 18},
        "properties": {"pixelSize": 130}, "fields": "pixelSize"}},
])
print("\n  OK R 컬럼 서식 (강조)")
