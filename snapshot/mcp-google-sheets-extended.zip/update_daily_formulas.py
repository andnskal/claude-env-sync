"""1.일별의 직접 카운트 수식에 운영시간 필터 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 직접 카운트 수식: M6, Y6, AI6, AK6, AL6, AN-AS6
formulas = {}

# M6: 6.채팅 기술이관 (Z=내 필터)
formulas["M6"] = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,LEFT(d,10),"
    "'6.채팅 상담내역'!$M:$M," + '"기술이관"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + "))))"
)

# Y6: IB 투입인원 (AD=내 필터)
formulas["Y6"] = (
    '=BYROW(A6:A100,LAMBDA(d,IFERROR('
    'IF(d="",,IF(COUNTIFS(\'5.콜 상담내역\'!$N:$N,LEFT(d,10),'
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")=0,0,"
    'COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,'
    "'5.콜 상담내역'!$N:$N=LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q=" + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD=" + '"내"' + ","
    "'5.콜 상담내역'!$W:$W<>" + '"기타"' + ","
    "'5.콜 상담내역'!$W:$W<>" + '""' + ")))))"
    ',0)))'
)

# AI6: OB 콜백 처리 (AD=내 필터 추가)
formulas["AI6"] = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$X:$X," + '"*콜백*"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"본사"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$X:$X," + '"*콜백*"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"외주 고객센터"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Y:$Y," + '"콜백"' + ","
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + "))))"
)

# AK6: 서비스 레벨 (20초 내 응답률) - 운영시간 내만
formulas["AK6"] = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,IFERROR('
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$U:$U," + '"<="' + '&(20/86400),'
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "/COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + "),))))"
)

# AL6: 응답 속도 준수율 (ringWaitTime ≤20초) - 운영시간 내만
formulas["AL6"] = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,IFERROR('
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AB:$AB," + '"<="' + '&(20/86400),'
    "'5.콜 상담내역'!$AB:$AB," + '">0"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "/COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AB:$AB," + '">0"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + "),))))"
)

# AN-AS: 부재중 사유 분류 - 운영시간 내만
missed_reasons = [
    ("AN6", "notInOperation"),
    ("AO6", "userLeftInIvrWithoutInput"),
    ("AP6", "userLeftInIvr"),
    ("AQ6", "userLeftInQueued"),
    ("AR6", "ringTimeOver"),
    ("AS6", "wfEndCall"),
]
for cell, reason in missed_reasons:
    formulas[cell] = (
        '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
        "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
        "'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
        "'5.콜 상담내역'!$F:$F," + '"' + reason + '"' + ","
        "'5.콜 상담내역'!$AD:$AD," + '"내"' + "))))"
    )

# AT6: 기타 부재중 (전체 IB_포기호 - AN~AS) - 운영시간 내만
formulas["AT6"] = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-(AN6+AO6+AP6+AQ6+AR6+AS6))))"
)

# AM6: 평균 통화시간 (IB+OB) - 운영시간 내만
formulas["AM6"] = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,IFERROR('
    "(SUMIFS('5.콜 상담내역'!$S:$S,'5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")*86400"
    "+SUMIFS('5.콜 상담내역'!$S:$S,'5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")*86400)"
    "/(COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")),))))"
)

# AJ6: 콜백 처리율 = AI / AE
formulas["AJ6"] = (
    '=ARRAYFORMULA(IF(AE6:AE=0,,AI6:AI/AE6:AE))'
)

print("=" * 80)
print("1.일별 직접 카운트 수식 운영시간 필터 추가")
print("=" * 80)
for cell, f in formulas.items():
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[f]]},
    ).execute()
    print(f"  OK {cell}")
print(f"\n총 {len(formulas)}개 수식 업데이트")

time.sleep(8)

# 5/8 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("\n[1.일별 5/8 모든 컬럼 (운영시간 필터 적용 후)]")
for row in res:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        cols_map = {
            14: 'O 접수호(알림톡만 제외)',
            15: 'P 응대호',
            16: 'Q 포기호(알림톡만 제외)',
            17: 'R 응대율',
            18: 'S 접수호(기술포기호 제외)',
            20: 'U 포기호(기술포기호 제외)',
            24: 'Y IB 투입인원',
            27: 'AB OB 시도',
            28: 'AC OB 성공',
            29: 'AD OB(콜백제외)',
            30: 'AE 콜백 대상 등록',
            34: 'AI OB 콜백 처리',
            35: 'AJ 콜백 처리율',
            36: 'AK 서비스 레벨',
            37: 'AL 응답 속도 준수율',
            38: 'AM 평균 통화시간',
            39: 'AN 운영시간 외',
            40: 'AO IVR 입력 없음',
            41: 'AP IVR 도중 떠남',
            42: 'AQ 대기열 떠남',
            43: 'AR 링 시간 초과',
            44: 'AS 워크플로우 종료',
            45: 'AT 기타',
        }
        for ci, label in sorted(cols_map.items()):
            v = row[ci] if ci < len(row) else "?"
            if isinstance(v, float):
                print(f"  {label}: {v:.4f}")
            else:
                print(f"  {label}: {v}")
        break
