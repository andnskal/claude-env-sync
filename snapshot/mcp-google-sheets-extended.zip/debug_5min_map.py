"""5분단위 MAP 동작 디버그."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 단순 MAP 테스트
test_formulas = [
    # 1) MAP 자체 작동 확인
    ("Y1", '=MAP($C$4:$C$10, LAMBDA(일시, 일시))'),
    # 2) HOUR/MINUTE 작동 확인
    ("Y2", '=MAP($C$4:$C$10, LAMBDA(일시, HOUR(일시)*60+MINUTE(일시)))'),
    # 3) 단순 SUMPRODUCT 안에 매개변수
    ("Y3", '=MAP($C$4:$C$10, LAMBDA(일시, SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300<>"")*1)))'),
    # 4) HOUR 비교까지
    ("Y4", '=MAP($C$4:$C$10, LAMBDA(일시, SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300<>"")*((HOUR(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300))<HOUR(일시)*60+MINUTE(일시)+5))))'),
    # 5) 전체 SUMPRODUCT
    ("Y5", '=MAP($C$4:$C$10, LAMBDA(일시, SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300<>"")*(LEFT(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300,10)=LEFT(일시,10))*((HOUR(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300))<HOUR(일시)*60+MINUTE(일시)+5)*((HOUR(\'RAW시간대별 포기호, 통화상세\'!$B$3:$B$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!$B$3:$B$300))>=HOUR(일시)*60+MINUTE(일시)))))'),
]

# Y열에 입력
for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'5분 단위 포기호, 통화상세'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()

time.sleep(3)
# Y1:Y5 결과 확인 (각 셀이 array를 반환하므로 인접 셀에 spillover)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!Y1:Y15",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    print(f"Y{ri+1}: {row}")
