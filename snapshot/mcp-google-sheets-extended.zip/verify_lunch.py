"""점심시간 분리 후 영향 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 최신 날짜
from collections import Counter
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N:N",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
dates = Counter()
for r in res:
    if r and r[0] and "2026" in str(r[0]):
        dates[r[0]] += 1
print(f"5.콜 데이터 일자: {sorted(dates.keys())}")

# 이윤애 5/8 IB_성공 카운트 (점심 분리 후)
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

iyunae_in = 0
iyunae_out = 0
iyunae_calls = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    if row[22] != "CS_이윤애": continue
    if row[16] != "IB_성공": continue
    
    AD = row[29]
    iyunae_calls.append((row[2], AD))
    if AD == "내": iyunae_in += 1
    elif AD == "외": iyunae_out += 1

print(f"\n[이윤애 5/8 IB_성공]")
print(f"  운영시간 내 (점심 제외): {iyunae_in}건")
print(f"  운영시간 외 (점심 포함): {iyunae_out}건")
print(f"  총: {iyunae_in + iyunae_out}건")
print(f"  채널톡 대시보드: 15건 (예상)")
print(f"  → 일치 여부: {'✅ 일치' if iyunae_in == 15 else '❌ 불일치 (점심 분리 후 ' + str(iyunae_in) + '건)'}")

print(f"\n이윤애 콜 상세 (점심 분류 표시):")
for c, ad in iyunae_calls:
    h, m = c.split(" ")[1].split(":")[:2]
    h, m = int(h), int(m)
    tm = h*60+m
    note = ""
    if 750 <= tm < 810:
        note = "← 점심 (12:30-13:30)"
    print(f"  {c} | AD={ad} {note}")

# 1.일별 5/8 KPI 영향
print("\n" + "=" * 70)
print("1.일별 5/8 KPI 변경 (점심 분리 후)")
print("=" * 70)
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AW60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  P (응대호): {row[15]}")
        print(f"  Q (포기호 알림제외): {row[16]}")
        print(f"  U (포기호 기술제외): {row[20]}")
        print(f"  R (응대율): {row[17]*100:.2f}%" if isinstance(row[17], (int,float)) else f"  R: {row[17]}")
        print(f"  AC (OB 성공): {row[28]}")
        print(f"  H (채널톡): {row[7]}")
        print(f"  AV (운영외 IB 부재): {row[47] if len(row) > 47 else '?'}")
        print(f"  AW (운영외 OB): {row[48] if len(row) > 48 else '?'}")
        break

# 5/4-5/8 일별 변화
print("\n[5/4-5/8 P, Q, R 비교]")
for row in daily:
    if row and isinstance(row[0], str) and row[0].startswith("2026-05"):
        date = row[0]
        P = row[15]
        Q = row[16]
        R = row[17]
        print(f"  {date}: P={P}, Q={Q}, R={R*100:.1f}%" if isinstance(R, (int,float)) else f"  {date}: P={P}, Q={Q}")
