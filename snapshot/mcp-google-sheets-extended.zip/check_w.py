"""5.콜 W 컬럼의 상담사 이름 형식 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 W 5/4 데이터
all_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:W3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("=" * 70)
print("5.콜 5/4 상담사별 콜 카운트 (W 컬럼)")
print("=" * 70)
agent_counts = {}
for row in all_data:
    if len(row) > 9 and row[0] == "2026-05-04":
        Q = row[3] if len(row) > 3 else ""
        W = row[9] if len(row) > 9 else ""
        if Q in ("IB_성공", "OB_성공", "IB_포기호"):
            key = (W, Q)
            agent_counts[key] = agent_counts.get(key, 0) + 1

# 정렬해서 출력
print(f"{'상담사':>30} | {'IB_성공':>10} | {'OB_성공':>10} | {'IB_포기호':>10}")
print("-" * 70)
agents = set()
for (w, q) in agent_counts.keys():
    if w and w != "기타":
        agents.add(w)
for w in sorted(agents):
    ib_s = agent_counts.get((w, "IB_성공"), 0)
    ob_s = agent_counts.get((w, "OB_성공"), 0)
    ib_a = agent_counts.get((w, "IB_포기호"), 0)
    print(f"{w:>30} | {ib_s:>10} | {ob_s:>10} | {ib_a:>10}")

# RAW시간대별 헤더 (C1, E1, ...) vs 실제 5.콜 W 비교
print("\n" + "=" * 70)
print("RAW시간대별 헤더에 있는 상담사 vs 5.콜 W에 있는 상담사")
print("=" * 70)
hdr_res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A1:AF1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if hdr_res:
    hdr = hdr_res[0]
    raw_agents = set(h for h in hdr if h)
    print(f"RAW 헤더 상담사: {sorted(raw_agents)}")
    print(f"\n5.콜에 있는 상담사: {sorted(agents)}")
    
    print(f"\nRAW에만 있는 (5.콜 미매칭): {sorted(raw_agents - agents)}")
    print(f"\n5.콜에만 있는 (RAW 헤더 누락): {sorted(agents - raw_agents)}")
