"""최종 종합 검증 - 모든 시트 100% 정상 작동 확인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 80)
print("🏁 최종 종합 검증")
print("=" * 80)

ERROR_PATTERNS = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")

# 1) 모든 시트 오류 재확인
meta = _sheets.spreadsheets().get(spreadsheetId=NEW, includeGridData=False).execute()
total_errors = 0
all_ok = True

print("\n[1️⃣ 셀 단위 오류 재검증]")
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0 or cols == 0: continue
    
    rng = f"'{name}'!A1:{col_letter(cols-1)}{rows}"
    try:
        vals = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except Exception as e:
        print(f"  ❌ {name}: {str(e)[:50]}")
        all_ok = False
        continue
    
    errs = 0
    err_locs = []
    for ri, row in enumerate(vals):
        for ci, cell in enumerate(row):
            if isinstance(cell, str):
                for ptn in ERROR_PATTERNS:
                    if ptn in cell:
                        errs += 1
                        if errs <= 3:
                            err_locs.append(f"{col_letter(ci)}{ri+1}={ptn}")
                        break
    if errs > 0:
        print(f"  ❌ {name}: {errs}개 오류 ({err_locs})")
        total_errors += errs
        all_ok = False
    else:
        print(f"  ✅ {name}: 오류 없음")

# 2) 핵심 시나리오 검증
print("\n[2️⃣ 시나리오 검증 (5/8)]")

# 5/8 5.콜 카운트
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
ib_succ = ob_succ = 0
for row in all_calls:
    if len(row) >= 4 and row[0] == "2026-05-08":
        Q = row[3] if len(row) > 3 else ""
        if Q == "IB_성공": ib_succ += 1
        elif Q == "OB_성공": ob_succ += 1

# 1.일별 5/8
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
daily_p = daily_ac = "?"
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        daily_p = row[15] if len(row) > 15 else "?"
        daily_ac = row[28] if len(row) > 28 else "?"
        break

print(f"  5.콜 5/8 IB_성공={ib_succ} → 1.일별 P (응대호)={daily_p} {'✅' if ib_succ == daily_p else '❌'}")
print(f"  5.콜 5/8 OB_성공={ob_succ} → 1.일별 AC (OB 성공)={daily_ac} {'✅' if ob_succ == daily_ac else '❌'}")

# 3.상담사별 채널톡 합 == 1.일별 H
res3 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_chann = 0
if res3 and len(res3) >= 3:
    for ci, (d, ch) in enumerate(zip(res3[0], res3[1])):
        if isinstance(d, str) and d == "2026-05-08" and ch == "채널톡":
            for ri in range(2, len(res3)):
                if ci < len(res3[ri]) and isinstance(res3[ri][ci], (int, float)):
                    sum_chann += res3[ri][ci]
H_val = "?"
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        H_val = row[7] if len(row) > 7 else "?"
        break
print(f"  3.상담사별 5/8 채널톡 합={sum_chann} → 1.일별 H (채널톡 답변)={H_val} {'✅' if sum_chann == H_val else '❌'}")

# 4.상담사별 IB_성공 합 == 1.일별 P
sum_ib = 0
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
if res4 and len(res4) >= 3:
    for ci, (d, t) in enumerate(zip(res4[0], res4[1])):
        if isinstance(d, str) and d == "2026-05-08" and t == "IB_성공":
            for ri in range(2, len(res4)):
                if ci < len(res4[ri]) and isinstance(res4[ri][ci], (int, float)):
                    sum_ib += res4[ri][ci]
print(f"  4.상담사별 5/8 IB_성공 합={sum_ib} → 1.일별 P={daily_p} {'✅' if sum_ib == daily_p else '❌'}")

# 2.시간대별 → 1.일별
hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_p = sum_q = 0
for row in hourly:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == "2026-05-08":
        if isinstance(row[15], (int, float)): sum_p += row[15]
        if isinstance(row[16], (int, float)): sum_q += row[16]
daily_o = daily_q = "?"
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        daily_o = row[14] if len(row) > 14 else "?"
        daily_q = row[16] if len(row) > 16 else "?"
        break
print(f"  2.시간대별 5/8 P 합={sum_p} → 1.일별 O={daily_o} {'✅' if sum_p == daily_o else '❌'}")
print(f"  2.시간대별 5/8 Q 합={sum_q} → 1.일별 Q={daily_q} {'✅' if sum_q == daily_q else '❌'}")

# 3) 1분단위 RAW vs 1.일별 검증
print("\n[3️⃣ 1분단위 검증 (4/30, 5/4, 5/8)]")
for serial, date in [("46142", "4/30"), ("46146", "5/4"), ("46150", "5/8")]:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
        valueInputOption="USER_ENTERED",
        body={"values": [[serial]]},
    ).execute()
    time.sleep(5)
    raw = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    cnt = sum(1 for r in raw if r and r[0])
    one_min = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E4:E513",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    one_cnt = sum(1 for r in one_min if r and "*" in (r[0] if r else ""))
    five_min = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E4:E135",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    five_cnt = sum(1 for r in five_min if r and "*" in (r[0] if r else ""))
    print(f"  📅 {date}: RAW={cnt}건, 1분단위 매칭 분={one_cnt}, 5분단위 buckets={five_cnt}")

print("\n" + "=" * 80)
if all_ok and total_errors == 0:
    print("🎉 모든 검증 통과! 신 시스템 100% 정상 작동.")
else:
    print(f"⚠️ 발견된 오류: {total_errors}개. 추가 수정 필요.")
print("=" * 80)
