"""6.채팅 운영시간외 태그 확인 + ★설정 운영시간 정확한 정의."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 6.채팅 헤더 확인
res_h = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A1:Z1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[6.채팅 헤더]")
if res_h and res_h[0]:
    for ci, h in enumerate(res_h[0]):
        col = chr(ord('A') + ci) if ci < 26 else 'AA'
        print(f"  {col}: {h}")

# 6.채팅 K (tags) 컬럼 확인
res_k = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!K2:K3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter
tags_counts = Counter()
ops_outside = 0
ops_inside = 0
for row in res_k:
    if row and row[0]:
        # tags는 보통 ;로 구분
        t = row[0]
        if "운영시간아님" in t or "out_of_office" in t.lower() or "off_hour" in t.lower():
            ops_outside += 1
        else:
            ops_inside += 1
        tags_counts[t[:60]] += 1
    else:
        ops_inside += 1

print(f"\n[6.채팅 운영시간 분류]")
print(f"  운영시간 외 (tags에 '운영시간아님' 포함): {ops_outside}건")
print(f"  운영시간 내 (또는 빈 tags): {ops_inside}건")

# 가장 흔한 태그 패턴
print(f"\n[6.채팅 tags 패턴 상위 15개]")
for tag, cnt in tags_counts.most_common(15):
    print(f"  {tag}: {cnt}건")

# 5.콜 X 컬럼 어떤 형식인지 다시
print(f"\n[5.콜 X 컬럼 패턴 상위 15개]")
res_x = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!X2:X3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
x_counts = Counter()
for r in res_x:
    if r:
        x_counts[r[0][:60] if r[0] else "(빈값)"] += 1
    else:
        x_counts["(빈값)"] += 1
for tag, cnt in x_counts.most_common(15):
    print(f"  {tag}: {cnt}건")
