"""2.시간대별 5/8 데이터 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 2.시간대별 5/8 데이터
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 5/8 행만
print("=" * 80)
print("2.시간대별 5/8 데이터 (B=날짜텍스트 = 2026-05-08)")
print("=" * 80)
print(f"{'시간':>10} | {'D=IB':>6} | {'E=OB':>6} | {'F=채팅':>6} | {'G=총접수':>6} | {'H=포기':>6} | {'I=응대율':>6} | {'J=접수(기술제외)':>10} | {'K=포기(기술제외)':>10} | {'P=접수(알림제외)':>10} | {'Q=포기(알림제외)':>10}")
total = {ci: 0 for ci in [3, 4, 5, 6, 7, 9, 10, 15, 16]}
hours_with_data = 0
for row in res:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == "2026-05-08":
        hours_with_data += 1
        time_str = row[2] if len(row) > 2 else ""
        d = row[3] if len(row) > 3 and isinstance(row[3], (int, float)) else 0
        e = row[4] if len(row) > 4 and isinstance(row[4], (int, float)) else 0
        f = row[5] if len(row) > 5 and isinstance(row[5], (int, float)) else 0
        g = row[6] if len(row) > 6 and isinstance(row[6], (int, float)) else 0
        h = row[7] if len(row) > 7 and isinstance(row[7], (int, float)) else 0
        i_ = row[8] if len(row) > 8 and isinstance(row[8], (int, float)) else 0
        j = row[9] if len(row) > 9 and isinstance(row[9], (int, float)) else 0
        k = row[10] if len(row) > 10 and isinstance(row[10], (int, float)) else 0
        p = row[15] if len(row) > 15 and isinstance(row[15], (int, float)) else 0
        q = row[16] if len(row) > 16 and isinstance(row[16], (int, float)) else 0
        for ci, val in zip([3,4,5,6,7,9,10,15,16], [d,e,f,g,h,j,k,p,q]):
            total[ci] += val
        print(f"{time_str:>10} | {d:>6} | {e:>6} | {f:>6} | {g:>6} | {h:>6} | {i_*100:>5.1f}% | {j:>10} | {k:>10} | {p:>10} | {q:>10}")

print(f"\n[합계] (5/8 시간대 수: {hours_with_data})")
for ci, label in [(3, "D 총IB"), (5, "F 총채팅"), (6, "G 총접수호"), (7, "H 포기호"),
                   (9, "J 접수(기술제외)"), (10, "K 포기(기술제외)"),
                   (15, "P 접수(알림제외)"), (16, "Q 포기(알림제외)")]:
    print(f"  {label}: {total[ci]}")
