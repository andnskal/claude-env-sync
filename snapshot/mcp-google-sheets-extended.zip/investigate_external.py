"""외부 시트 접근 + 이전 시트 정확한 매핑 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

EXTERNAL = "1-6uipG0sTwxFW30T1-rfXmcxiBsfiEYQMlmv_CFe8xk"
OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 외부 시트 접근 가능?
print("=" * 80)
print("[1] 외부 시트 (1-6uipG0...) 접근 확인")
print("=" * 80)
try:
    meta = _sheets.spreadsheets().get(spreadsheetId=EXTERNAL).execute()
    print("✅ 접근 가능")
    print(f"  스프레드시트 이름: {meta.get('properties', {}).get('title', '?')}")
    print(f"  시트 목록:")
    for s in meta.get("sheets", []):
        p = s["properties"]
        print(f"    - {p['title']} ({p['gridProperties'].get('rowCount', 0)}행 × {p['gridProperties'].get('columnCount', 0)}열)")
except Exception as e:
    print(f"❌ 접근 불가: {e}")

# 2) 이전 시트 RAW 55번 기술 이관 — 모든 컬럼 헤더 + ★설정과의 연결
print("\n" + "=" * 80)
print("[2] 이전 시트 RAW 55번 기술 이관 — O, P 컬럼 (★설정 매핑)")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW 55번 기술 이관'!N1:R10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\nN-R 컬럼 (★설정 인별 분류):")
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+1}: {row}")

res_f = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW 55번 기술 이관'!N2:R3",
    valueRenderOption="FORMULA",
).execute().get("values", [])
print("\n수식:")
for ri, row in enumerate(res_f):
    for ci, v in enumerate(row):
        if v and str(v).startswith("="):
            col = chr(ord('N') + ci)
            print(f"  {col}{ri+2}: {str(v)[:200]}")

# 3) 이전 시트 ★설정 H 컬럼 (외주 직원 매핑)
print("\n" + "=" * 80)
print("[3] 이전 시트 ★설정 H 컬럼 (외주 직원 매핑)")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'★설정'!H1:H30",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    if r and r[0]:
        print(f"  H{ri+1}: {r[0]}")

# 4) 이전 시트 6.채팅 핵심 수식들 (M, X, Y 등 분류 컬럼)
print("\n" + "=" * 80)
print("[4] 이전 시트 6.채팅 분류 수식 (M=채널, X=사람처리, Y=매니저답변)")
print("=" * 80)
res_f = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'6.채팅 상담내역'!M2:Y2",
    valueRenderOption="FORMULA",
).execute().get("values", [])
if res_f and res_f[0]:
    for ci, v in enumerate(res_f[0]):
        if v and str(v).startswith("="):
            col = chr(ord('M') + ci)
            print(f"  {col}2: {str(v)[:300]}")
