"""포기호 시간 범위 — 특히 09:08을 포함하는 범위 찾기."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW시간대별 A3:B300 전체
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:B300",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print(f"전체 행: {len(res)}")
if res:
    # 09:00 = 540, 09:08 = 548
    for ri, row in enumerate(res):
        if not row or len(row) < 2:
            continue
        try:
            from datetime import datetime, timedelta
            # A, B는 텍스트 문자열
            a_str = row[0]
            b_str = row[1]
            # ISO 형식 파싱
            a_dt = datetime.fromisoformat(a_str.replace(' ', 'T'))
            b_dt = datetime.fromisoformat(b_str.replace(' ', 'T'))
            a_min = a_dt.hour * 60 + a_dt.minute
            b_min = b_dt.hour * 60 + b_dt.minute
            # 09:08 (548) 포함하는지
            if a_min <= 548 <= b_min:
                print(f"  Row {ri+3}: A={a_str} ({a_min}분) B={b_str} ({b_min}분) ★09:08 포함")
            # 9시 ~ 12시 사이 데이터만 출력
            elif 540 <= a_min <= 720:
                print(f"  Row {ri+3}: A={a_str} ({a_min}분) B={b_str} ({b_min}분)")
        except Exception as e:
            print(f"  Row {ri+3}: 파싱 오류 - {a_str} | {b_str} | {e}")
            break

# 09:08 분에 매칭되는 케이스가 있는지 검증
print("\n[09:08 (548분) 포함 케이스 검색]")
match_count = 0
for ri, row in enumerate(res):
    if not row or len(row) < 2:
        continue
    try:
        a_str = row[0]
        b_str = row[1]
        from datetime import datetime
        a_dt = datetime.fromisoformat(a_str.replace(' ', 'T'))
        b_dt = datetime.fromisoformat(b_str.replace(' ', 'T'))
        a_min = a_dt.hour * 60 + a_dt.minute
        b_min = b_dt.hour * 60 + b_dt.minute
        if a_min <= 548 <= b_min:
            match_count += 1
            print(f"  Row {ri+3}: {a_str} - {b_str} (분: {a_min}-{b_min})")
    except:
        continue
print(f"\n총 매칭: {match_count}건")
