"""AG (OB ATT) 수식 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# AG6, AF6 수식 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AB6:AG6",
    valueRenderOption="FORMULA",
).execute().get("values", [])

if res and res[0]:
    labels = ["AB", "AC", "AD", "AE", "AF", "AG"]
    for ci, lbl in enumerate(labels):
        v = res[0][ci] if ci < len(res[0]) else ""
        print(f"\n{lbl}6: {str(v)[:300]}")
