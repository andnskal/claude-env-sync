"""Y6 정확한 수식 분석."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Y6 formula full test
y6_full = (
    '=BYROW(A6:A20,LAMBDA(d,IF(d="",,'
    'IF(COUNTIFS(\'5.콜 상담내역\'!$N:$N,LEFT(d,10),\'5.콜 상담내역\'!$Q:$Q,"IB_성공")=0,0,'
    'IFERROR(COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,'
    '\'5.콜 상담내역\'!$N:$N=LEFT(d,10),'
    '\'5.콜 상담내역\'!$Q:$Q="IB_성공",'
    '\'5.콜 상담내역\'!$W:$W<>"기타",'
    '\'5.콜 상담내역\'!$W:$W<>""))),0))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1",
    valueInputOption="USER_ENTERED",
    body={"values": [[y6_full]]},
).execute()
time.sleep(3)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1:AX20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[Y6 full formula 테스트 in AX1]")
for i, r in enumerate(res):
    if r and r[0]:
        print(f"  AX{i+1}: {r[0]}")

# 정리
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1:AX25"
).execute()

# 실제 Y6 형식 확인 (number format)
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'1.일별 전체 통계'!Y6"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat))))"
).execute()
y6_fmt = fmt["sheets"][0]["data"][0]["rowData"][0]["values"][0].get("userEnteredFormat", {})
print(f"\n[Y6 number format]: {y6_fmt.get('numberFormat', 'NONE')}")
