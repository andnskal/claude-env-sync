"""이전 시트의 RAW 55번 기술 이관 + 모니터링 시트 깊이 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 1) RAW 55번 기술 이관 — 모든 컬럼 헤더 + 첫 5행 데이터
print("=" * 80)
print("[이전 시트] RAW 55번 기술 이관 - 전체 구조")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW 55번 기술 이관'!A1:Z10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n헤더 (행 1):")
if res:
    for ci, h in enumerate(res[0]):
        if h:
            col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
            print(f"  {col}: {h}")

print("\n데이터 샘플 (행 2-6):")
for ri in range(1, min(6, len(res))):
    if res[ri]:
        non_empty = [(chr(ord('A')+ci), str(c)[:25]) for ci, c in enumerate(res[ri]) if c]
        print(f"  Row {ri+1}: {non_empty[:8]}")

# 수식 (전체 행 1-2)
print("\n수식 (행 1-2):")
res_f = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW 55번 기술 이관'!A1:Z2",
    valueRenderOption="FORMULA",
).execute().get("values", [])
for ri, row in enumerate(res_f):
    for ci, v in enumerate(row[:26]):
        if v and str(v).startswith("="):
            col = chr(ord('A') + ci)
            print(f"  {col}{ri+1}: {str(v)[:200]}")

# 2) 이전 시트 전체에서 RAW 55번 기술 이관 참조 검색 (제한 없이 광범위)
print("\n" + "=" * 80)
print("[이전 시트 전체에서 RAW 55번 기술 이관 참조 검색]")
print("=" * 80)
import re
meta = _sheets.spreadsheets().get(spreadsheetId=OLD).execute()

ref_locations = []
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    if name == "RAW 55번 기술 이관":
        continue
    rows = min(p["gridProperties"].get("rowCount", 0), 1000)
    cols = min(p["gridProperties"].get("columnCount", 0), 100)
    if rows == 0: continue
    
    def cl(idx):
        s, n = "", idx + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(ord("A") + r) + s
        return s
    
    rng = f"'{name}'!A1:{cl(cols-1)}{rows}"
    try:
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=OLD, range=rng,
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        for ri, row in enumerate(formulas):
            for ci, v in enumerate(row):
                if v and isinstance(v, str) and ("RAW 55" in v or "55번 기술" in v):
                    ref_locations.append((name, f"{cl(ci)}{ri+1}", str(v)[:150]))
    except: continue

if ref_locations:
    print(f"발견된 참조: {len(ref_locations)}건")
    for sheet, cell, formula in ref_locations[:10]:
        print(f"\n  📍 {sheet}!{cell}")
        print(f"     {formula}")
else:
    print("  ⚠️ 참조 0건 (이전 시트에서도 다른 시트가 참조하지 않음)")
