"""_보조 채팅 B 시트 삭제 재시도 + 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# _보조 채팅 B 삭제 재시도
try:
    sid_b = _get_sheet_id_by_name(NEW, "_보조 채팅 B")
    _batch_update(NEW, [{"deleteSheet": {"sheetId": sid_b}}])
    print("OK _보조 채팅 B 삭제")
except Exception as e:
    print(f"⚠️ {e}")

time.sleep(5)

# RAW_UserChat 데이터 정상 작동 확인
print("\n[RAW_UserChat A1:CS 전체 97열 데이터 확인]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1:CS3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if res:
    print(f"  헤더 컬럼 수: {len(res[0])}")
    print(f"  헤더 일부: {res[0][:5]}...{res[0][-5:]}")
    print(f"  Row 2 컬럼 수: {len(res[1]) if len(res) > 1 else 0}")

# 6.채팅 데이터 행 5/8 검증
print("\n[6.채팅 5/8 데이터 샘플]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z6",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        non_empty = [(chr(ord('A')+ci), str(c)[:20]) for ci, c in enumerate(row) if c]
        print(f"  Row {ri+2}: {non_empty[:6]}...")

# 1.일별 5/8 KPI 검증
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 5/8 KPI 검증]")
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  P (응대호): {row[15]}")
        print(f"  Q (포기호 알림제외): {row[16]}")
        print(f"  H (채널톡 답변): {row[7]}")
        print(f"  M (기술이관): {row[12]}")
        print(f"  AC (OB 성공): {row[28]}")
        break

# 모든 일자 핵심 KPI 직접 카운트 vs 시트
print("\n[KPI 일치성 재검증]")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_p = defaultdict(int)
date_h = defaultdict(int)
for row in all_calls:
    if len(row) > 29:
        N, Q, AD = row[13], row[16], row[29]
        if N and AD == "내" and Q == "IB_성공":
            date_p[N] += 1

for row in all_chats:
    if len(row) > 25:
        O, M, Y, Z = row[14], row[12], row[24], row[25]
        if O and Z == "내" and Y == "Y" and M == "채널톡":
            date_h[O] += 1

mismatches = []
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    p_actual = row[15] if len(row) > 15 else 0
    h_actual = row[7] if len(row) > 7 else 0
    p_exp = date_p.get(date, 0)
    h_exp = date_h.get(date, 0)
    if p_actual != p_exp or h_actual != h_exp:
        mismatches.append(f"{date} P={p_actual}/{p_exp} H={h_actual}/{h_exp}")

if mismatches:
    print("  ❌ 불일치:")
    for m in mismatches:
        print(f"    {m}")
else:
    print("  ✅ 모든 일자 KPI 일치")

# 시트 목록
print("\n[현재 시트 목록]")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    print(f"  - {s['properties']['title']}")
