"""B 컬럼 점심 영역에 시각적 안내 텍스트 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# B2 수식: 점심 영역에 "🍱 점심" 텍스트, 그 외 시간
new_b2 = (
    '=ARRAYFORMULA(IF('
    '(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440>=TIME(12,30,0))*'
    '(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440<TIME(13,30,0)),'
    '"🍱 점심",'
    'TEXT(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440,"hh:mm")))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!B2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_b2]]},
).execute()
print("OK B2 수식 — 점심 영역에 '🍱 점심' 표시")

time.sleep(5)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B210:B273",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[B 컬럼 점심 영역]")
for ri, r in enumerate(res):
    actual_row = 210 + ri
    val = r[0] if r and r[0] else "(빈)"
    # 변경 영역만 표시
    if 209 <= actual_row <= 215 or 268 <= actual_row <= 275:
        print(f"  B{actual_row}: {val}")
    elif actual_row == 240:
        print(f"  ...")
        print(f"  B{actual_row}: {val}")
        print(f"  ...")

# 전체 사용 행 카운트
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B600",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
filled = sum(1 for r in res if r and r[0])
print(f"\nB 컬럼 사용 행: {filled}개 (헤더 + 510개)")

# B1 헤더
b1 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])
print(f"B1 헤더: {b1[0][0] if b1 and b1[0] else '?'}")
