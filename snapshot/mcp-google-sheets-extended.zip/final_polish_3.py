"""3·4 헤더 색상 + 날짜 형식 + 시간대별 B 수식 보정."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _hex_to_rgb_dict, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 시간대별 B (날짜 텍스트) 수식 보정 — A 셀이 텍스트 yyyy-mm-dd 그대로
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!B4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(A4:A="",,A4:A))']]},  # 그대로 복사 (텍스트)
).execute()
print("✅ 2.시간대별 B 수식 보정")

# 3·4 헤더 색상 + DATE 형식
sid3 = _get_sheet_id_by_name(NEW, "3.상담사별 채팅 실적")
sid4 = _get_sheet_id_by_name(NEW, "4.상담사별 콜 실적")

reqs = []
for sid in [sid3, sid4]:
    # 행1 (날짜) DATE 형식
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 2, "endColumnIndex": 320},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": "DATE", "pattern": "yyyy\"-\"mm\"-\"dd"}}},
            "fields": "userEnteredFormat.numberFormat",
        }
    })
    # 행1, 2 배경색 + 글씨
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 0, "endColumnIndex": 320},
            "cell": {"userEnteredFormat": {
                "backgroundColor": _hex_to_rgb_dict("134F5C"),
                "textFormat": {"bold": True, "fontSize": 10, "foregroundColor": _hex_to_rgb_dict("FFFFFF")},
                "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat.backgroundColor,userEnteredFormat.textFormat,userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
        }
    })
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 0, "endColumnIndex": 320},
            "cell": {"userEnteredFormat": {
                "backgroundColor": _hex_to_rgb_dict("9BBB59"),
                "textFormat": {"bold": True, "fontSize": 9},
                "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat.backgroundColor,userEnteredFormat.textFormat,userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
        }
    })
    # B열 색상 (상담사명) - 강조
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 2, "endRowIndex": 100, "startColumnIndex": 1, "endColumnIndex": 2},
            "cell": {"userEnteredFormat": {
                "backgroundColor": _hex_to_rgb_dict("FCE5CD"),
                "textFormat": {"bold": True, "fontSize": 10},
                "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat.backgroundColor,userEnteredFormat.textFormat,userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
        }
    })

_batch_update(NEW, reqs)
print(f"✅ 3·4 헤더 서식 + DATE 형식 ({len(reqs)}개 요청)")

# 1.일별 행4-5 평균/합계도 데이터 형식 적용 (PERCENT/TIME 그대로)
# 이미 자동 적용됨

# 1.일별 행 4-5 색상 (강조)
sid1 = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")
reqs2 = [
    {
        "repeatCell": {
            "range": {"sheetId": sid1, "startRowIndex": 3, "endRowIndex": 5, "startColumnIndex": 0, "endColumnIndex": 34},
            "cell": {"userEnteredFormat": {
                "backgroundColor": _hex_to_rgb_dict("FFF2CC"),
                "textFormat": {"bold": True, "fontSize": 10},
                "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat.backgroundColor,userEnteredFormat.textFormat,userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
        }
    }
]
_batch_update(NEW, reqs2)
print("✅ 1.일별 행4-5 (일평균/합계) 강조 색상")

print("\n🎉 마지막 폴리시 완료")
