"""1분단위 시트 정확성 검증 (행 단위)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 9:32:25 ~ 9:33:51 콜이 9:32, 9:33 모두 매칭되는지
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A30:V42",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("=" * 80)
print("1분단위 행 30~42 (9:25~9:38 영역, 행 30=9:25)")
print("=" * 80)
print(f"{'행':>4} | {'시간':>6} | {'CTtotalC':>10} | {'F(기술_김진향)':>20}")
for ri, row in enumerate(res):
    if not row: continue
    time_str = row[1] if len(row) > 1 else ""
    c = row[2] if len(row) > 2 else ""
    counta = row[3] if len(row) > 3 else ""
    f = row[5] if len(row) > 5 else ""
    print(f"{ri+30:>4} | {time_str:>6} | {c:>20} | {counta:>3} | F={f:>20}")

# C6 (RAW C3 = 9:32:25) 콜 시간이 1분단위 어디에 매칭되는지 직접 SUMPRODUCT 검증
# 임시로 다음 셀에 검증:
test_formulas = [
    ("X20", '=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C36)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C36)))*1440)'),  # 9:32 분
    ("X21", '=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C37)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C37)))*1440)'),  # 9:33 분
    ("X22", '=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C38)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C38)))*1440)'),  # 9:34 분
    # C6 in RAW = 9:32:25 (기술_김진향 통화시작)
    ("X23", '=INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!C6)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!C6)))*1440)'),
    ("X24", '=INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!D6)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!D6)))*1440)'),
    # 9:32 일시에 대한 SUMPRODUCT
    ("X25", '=SUMPRODUCT((INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!$C$3:$C$300))=INT(VALUE(\'1분 단위 포기호, 통화상세\'!C36)))*(INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!$C$3:$C$300)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!$C$3:$C$300)))*1440)<=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C36)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C36)))*1440))*(INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!$D$3:$D$300)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!$D$3:$D$300)))*1440)>=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C36)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C36)))*1440)))'),
]
for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1분 단위 포기호, 통화상세'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()

import time; time.sleep(2)
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!X20:X25",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
labels = ["C36 9:32 분", "C37 9:33 분", "C38 9:34 분", "RAW C6 9:32:25 분", "RAW D6 9:33:51 분", "9:32 SUMPRODUCT for F4"]
for i, label in enumerate(labels):
    val = res2[i][0] if i < len(res2) and res2[i] else 'N/A'
    print(f"  {label}: {val}")
