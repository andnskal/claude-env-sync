"""AG (OB ATT) 수식 수정 — AF/AC (모든 OB 성공 분모) 사용."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# AG6: AF/AC (OB 통화시간 / OB 성공)
ag_formula = '=ARRAYFORMULA(IF(AC6:AC=0,,AF6:AF/AC6:AC))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AG6",
    valueInputOption="USER_ENTERED",
    body={"values": [[ag_formula]]},
).execute()
print("OK AG6 수식 수정 (AF/AC)")

# X (IB ATT) 수식도 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!X6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print(f"\nX6 현재 수식: {res[0][0] if res and res[0] else '없음'}")

time.sleep(5)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AG60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("\n[AG OB ATT 재검증 (AF/AC)]")
for row in res:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    AC = row[28] if len(row) > 28 else 0
    AF = row[31] if len(row) > 31 else 0
    AG = row[32] if len(row) > 32 else 0
    AF_sec = AF * 86400 if isinstance(AF, (int, float)) else 0
    AG_sec = AG * 86400 if isinstance(AG, (int, float)) else 0
    expected_ag = AF_sec / AC if AC else 0
    match = "✅" if abs(AG_sec - expected_ag) < 1 else "❌"
    print(f"  {date}: AC={AC}, AF={AF_sec:.0f}초, AG={AG_sec:.1f}초 (수동 AF/AC={expected_ag:.1f}) {match}")
