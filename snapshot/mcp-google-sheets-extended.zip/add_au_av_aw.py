"""1.일별 AU/AV/AW 추가 + 컬럼 그룹화 적용."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 1) 시트 컬럼 50 → 53 확장
print("[1] 시트 컬럼 확장 50 -> 53")
reqs = [{
    "appendDimension": {
        "sheetId": sid,
        "dimension": "COLUMNS",
        "length": 3,
    }
}]
_batch_update(NEW, reqs)
print("OK 53열")

time.sleep(2)

# 2) 헤더 입력 (행 1, 2, 3)
print("\n[2] 헤더 입력")
# AU = 47번 컬럼 (0-indexed)
# 행 1: 그룹 헤더 (병합)
# 행 2: 세부
# 행 3: 상세
header_data = {
    "AU1": "전체 시간 기준 (참고용)",  # 그룹 헤더 - AU1:AW1 병합
    "AU2": "전체 IB 응대율",
    "AV2": "운영시간 외 IB",
    "AW2": "운영시간 외 OB",
    "AU3": "응대호 / 접수호\n(전체 시간)",
    "AV3": "자동 부재 (notInOperation 외)\n(채널톡 알림톡 발송)",
    "AW3": "직원 야근/조기 OB 처리\n(본사+외주, OB_성공)",
}
for cell, val in header_data.items():
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[val]]},
    ).execute()
print("OK 헤더 입력")

# 3) AU/AV/AW 데이터 수식 (행 6 시작, BYROW)
print("\n[3] 수식 입력")

# AU = 전체 IB_성공 / 전체 IB inbound (시간 무관, 운영시간 필터 없음)
au_formula = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,IFERROR('
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ")"
    "/COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$B:$B," + '"inbound"' + "),))))"
)

# AV = 운영시간 외 IB 자동 부재 (B=inbound, AD=외, IB_포기호)
av_formula = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"외"' + ","
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + "))))"
)

# AW = 운영시간 외 OB 처리 (Q=OB_성공, AD=외, AC=본사 or 외주)
aw_formula = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"외"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"본사"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"외"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"외주 고객센터"' + "))))"
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AU6",
    valueInputOption="USER_ENTERED",
    body={"values": [[au_formula]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AV6",
    valueInputOption="USER_ENTERED",
    body={"values": [[av_formula]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AW6",
    valueInputOption="USER_ENTERED",
    body={"values": [[aw_formula]]},
).execute()
print("OK AU6, AV6, AW6 수식")

# 4) 합계 행 5, 평균 행 4
print("\n[4] 합계/평균 행")
# AV, AW = SUM, AU = AVERAGE (비율이라 단순합 의미 없음)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AU5",
    valueInputOption="USER_ENTERED",
    body={"values": [["=IFERROR(AVERAGE(AU6:AU1000),)"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AV5",
    valueInputOption="USER_ENTERED",
    body={"values": [["=IFERROR(SUM(AV6:AV1000),)"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AW5",
    valueInputOption="USER_ENTERED",
    body={"values": [["=IFERROR(SUM(AW6:AW1000),)"]]},
).execute()
# 평균 행 4
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AU4",
    valueInputOption="USER_ENTERED",
    body={"values": [["=IFERROR(AVERAGE(AU6:AU1000),)"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AV4",
    valueInputOption="USER_ENTERED",
    body={"values": [["=IFERROR(AVERAGE(AV6:AV1000),)"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AW4",
    valueInputOption="USER_ENTERED",
    body={"values": [["=IFERROR(AVERAGE(AW6:AW1000),)"]]},
).execute()
print("OK 합계/평균 행")

time.sleep(3)

# 5) 서식 적용
print("\n[5] 서식 적용")
reqs = []

# AU1:AW1 병합 (그룹 헤더)
reqs.append({
    "mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 46, "endColumnIndex": 49},
        "mergeType": "MERGE_ALL"
    }
})

# AU1:AW3 헤더 색상 (회색계 - 참고 영역)
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 3, "startColumnIndex": 46, "endColumnIndex": 49},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.55, "green": 0.55, "blue": 0.55},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }
})

# AU 컬럼: PERCENT 서식
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 46, "endColumnIndex": 47},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "PERCENT", "pattern": "0.0%"}}},
        "fields": "userEnteredFormat.numberFormat"
    }
})
# AV, AW: NUMBER
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 47, "endColumnIndex": 49},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
        "fields": "userEnteredFormat.numberFormat"
    }
})

# 데이터 영역 정렬
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 46, "endColumnIndex": 49},
        "cell": {"userEnteredFormat": {
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
            "textFormat": {"fontSize": 9},
        }},
        "fields": "userEnteredFormat(horizontalAlignment,verticalAlignment,textFormat)"
    }
})

# 컬럼 너비
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 46, "endIndex": 49},
    "properties": {"pixelSize": 100}, "fields": "pixelSize"}})

_batch_update(NEW, reqs)
print("OK 서식 적용")

time.sleep(3)

# 6) 컬럼 그룹화 적용
print("\n[6] 컬럼 그룹화")
# 기존 그룹 제거 (있다면)
# 새 그룹 7개:
# Group 1: C-N 채팅 (col 2-13)
# Group 2: O-Z IB (col 14-25)
# Group 3: AA-AH OB (col 26-33)
# Group 4: AI-AJ 콜백 (col 34-35)
# Group 5: AK-AM KPI (col 36-38)
# Group 6: AN-AT 부재중사유 (col 39-45)
# Group 7: AU-AW 참고 (col 46-48)
group_reqs = []
groups = [
    (2, 14, "채팅"),       # C-N
    (14, 26, "IB"),        # O-Z
    (26, 34, "OB"),        # AA-AH
    (34, 36, "콜백"),       # AI-AJ
    (36, 39, "KPI"),       # AK-AM
    (39, 46, "부재중사유"),  # AN-AT
    (46, 49, "참고"),       # AU-AW (신규)
]
for start, end, label in groups:
    group_reqs.append({
        "addDimensionGroup": {
            "range": {
                "sheetId": sid,
                "dimension": "COLUMNS",
                "startIndex": start,
                "endIndex": end,
            }
        }
    })
_batch_update(NEW, group_reqs)
print("OK 7개 그룹 적용")

print("\n✅ 모든 작업 완료")
