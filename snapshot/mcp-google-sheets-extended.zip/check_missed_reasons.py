"""부재중 사유 (AN-AT) 모든 일자 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

all_f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!F2:F3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict, Counter

# 일자별 missedReason 분포 (운영시간 내, IB inbound)
date_missed = defaultdict(Counter)
date_aban_total = defaultdict(int)

for ri, row in enumerate(all_calls):
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        AD = row[29] if len(row) > 29 else ""
        F = all_f[ri][0] if ri < len(all_f) and all_f[ri] else ""
        B = row[1] if len(row) > 1 else ""
        if not N or AD != "내": continue
        if B == "inbound" and F:
            date_missed[N][F] += 1
        if Q == "IB_포기호":
            date_aban_total[N] += 1

# 1.일별 AN-AT 컬럼
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

reasons_map = [
    (39, "AN notInOperation"),
    (40, "AO userLeftInIvrWithoutInput"),
    (41, "AP userLeftInIvr"),
    (42, "AQ userLeftInQueued"),
    (43, "AR ringTimeOver"),
    (44, "AS wfEndCall"),
    (45, "AT 기타"),
]
reason_keys = [
    "notInOperation",
    "userLeftInIvrWithoutInput",
    "userLeftInIvr",
    "userLeftInQueued",
    "ringTimeOver",
    "wfEndCall",
]

print("=" * 100)
print("부재중 사유 (AN-AT) 모든 일자 검증")
print("=" * 100)

all_match = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_missed: continue
    
    print(f"\n📅 {date}:")
    classified = 0
    for ci, label in reasons_map[:6]:
        actual = row[ci] if ci < len(row) else "?"
        if "기타" in label:
            continue
        key = reason_keys[reasons_map.index((ci, label))]
        expected = date_missed[date].get(key, 0)
        classified += expected
        match = "✅" if actual == expected else "❌"
        if not match == "✅":
            all_match = False
            print(f"  {match} {label}: 1.일별={actual} vs 직접={expected}")
        else:
            print(f"  {match} {label}: {actual}")
    
    # AT (기타) = total - classified
    total_aban_in = sum(date_missed[date].values())  # 모든 inbound + missedReason 있음
    expected_at = total_aban_in - classified
    actual_at = row[45] if len(row) > 45 else "?"
    match_at = "✅" if actual_at == expected_at else "❌"
    if match_at != "✅":
        all_match = False
    print(f"  {match_at} AT 기타: 1.일별={actual_at} vs 직접={expected_at}")
    
    # 합 검증
    sum_aban = sum(row[ci] if ci < len(row) and isinstance(row[ci], (int, float)) else 0 for ci, _ in reasons_map)
    print(f"     합 = {sum_aban} (직접 IB inbound + missedReason 있는 콜 = {total_aban_in})")

print("\n" + "=" * 100)
if all_match:
    print("🎉 부재중 사유 100% 일치!")
else:
    print("⚠️ 불일치")
print("=" * 100)
