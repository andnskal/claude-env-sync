"""최종 100% 종합 검증."""
import os, sys, time as time_mod
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 100)
print("최종 100% 종합 검증")
print("=" * 100)

# 1) 셀 오류
print("\n[1] 셀 단위 오류")
ERROR_PATTERNS = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
total_errors = 0
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0 or cols == 0: continue
    rng = f"'{name}'!A1:{col_letter(cols-1)}{rows}"
    try:
        vals = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue
    errs = sum(1 for ri, row in enumerate(vals) for ci, c in enumerate(row)
               if isinstance(c, str) and any(p in c for p in ERROR_PATTERNS))
    total_errors += errs
print(f"  총 오류: {total_errors}개")

# 2) 직접 카운트 vs 시트 일치
print("\n[2] 모든 일자 모든 KPI 일치")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict

date_counts = defaultdict(lambda: defaultdict(int))
for row in all_calls:
    if len(row) > 29:
        N = row[13]
        Q = row[16]
        Y = row[24]
        Z = row[25]
        X = row[23]
        AC = row[28]
        AD = row[29]
        if not N or AD != "내": continue
        if Q == "IB_성공": date_counts[N]["P"] += 1
        elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
            date_counts[N]["AC"] += 1
            if "콜백" in X:
                date_counts[N]["AI"] += 1
        elif Q == "IB_포기호":
            if Y != "알림톡발송":
                date_counts[N]["Q"] += 1
                if Z != "기술부재포기호":
                    date_counts[N]["U"] += 1
            if Y == "콜백":
                date_counts[N]["AE"] += 1
        if Y == "알림톡발송":
            date_counts[N]["AH"] += 1
        if row[1] == "outbound":
            date_counts[N]["AB"] += 1

for row in all_chats:
    if len(row) > 25:
        O = row[14]
        M = row[12]
        Y_chat = row[24]
        Z_chat = row[25]
        if not O or Z_chat != "내": continue
        if Y_chat == "Y":
            if M == "카카오": date_counts[O]["D"] += 1
            elif M == "네이버": date_counts[O]["F"] += 1
            elif M == "채널톡": date_counts[O]["H"] += 1
            elif M == "기술이관": date_counts[O]["M"] += 1

daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

mismatches = []
total_checks = 0
matches = 0
daily_map = {
    "D": 3, "F": 5, "H": 7, "M": 12,
    "P": 15, "Q": 16, "U": 20,
    "AB": 27, "AC": 28, "AE": 30, "AH": 33, "AI": 34,
}
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_counts: continue
    for key, idx in daily_map.items():
        actual = row[idx] if idx < len(row) else None
        expected = date_counts[date].get(key, 0)
        total_checks += 1
        if actual == expected:
            matches += 1
        else:
            mismatches.append((date, key, actual, expected))

print(f"  검증: {total_checks}건 / 일치: {matches}건 / 불일치: {len(mismatches)}건")
for d, k, a, e in mismatches[:5]:
    print(f"    !!{d} {k}: {a} vs {e}")

# 3) 시간 KPI
print("\n[3] 시간 KPI")
all_s = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!S2:S3500",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
date_ib_total = defaultdict(float)
date_ib_cnt = defaultdict(int)
date_ob_total = defaultdict(float)
date_ob_cnt = defaultdict(int)
for ri, row in enumerate(all_calls):
    if len(row) > 29:
        N = row[13]
        Q = row[16]
        AD = row[29]
        AC = row[28]
        s_v = all_s[ri][0] if ri < len(all_s) and all_s[ri] else 0
        if not isinstance(s_v, (int, float)): s_v = 0
        if not N or AD != "내": continue
        s_sec = s_v * 86400
        if Q == "IB_성공":
            date_ib_total[N] += s_sec
            date_ib_cnt[N] += 1
        elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
            date_ob_total[N] += s_sec
            date_ob_cnt[N] += 1

time_match = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    W = (row[22] if len(row) > 22 else 0)
    X = (row[23] if len(row) > 23 else 0)
    AF = (row[31] if len(row) > 31 else 0)
    AG = (row[32] if len(row) > 32 else 0)
    AM = (row[38] if len(row) > 38 else 0)
    W_sec = W * 86400 if isinstance(W, (int, float)) else 0
    X_sec = X * 86400 if isinstance(X, (int, float)) else 0
    AF_sec = AF * 86400 if isinstance(AF, (int, float)) else 0
    AG_sec = AG * 86400 if isinstance(AG, (int, float)) else 0
    AM_val = AM if isinstance(AM, (int, float)) else 0

    exp_w = date_ib_total[date]
    exp_x = date_ib_total[date] / date_ib_cnt[date] if date_ib_cnt[date] else 0
    exp_af = date_ob_total[date]
    exp_ag = date_ob_total[date] / date_ob_cnt[date] if date_ob_cnt[date] else 0
    exp_am = (date_ib_total[date] + date_ob_total[date]) / (date_ib_cnt[date] + date_ob_cnt[date]) if (date_ib_cnt[date] + date_ob_cnt[date]) else 0

    if abs(W_sec - exp_w) > 5 or abs(X_sec - exp_x) > 1 or abs(AF_sec - exp_af) > 5 or abs(AG_sec - exp_ag) > 1 or abs(AM_val - exp_am) > 1:
        time_match = False
        print(f"  !! {date} W={W_sec:.0f}/{exp_w:.0f} X={X_sec:.1f}/{exp_x:.1f} AF={AF_sec:.0f}/{exp_af:.0f} AG={AG_sec:.1f}/{exp_ag:.1f} AM={AM_val:.1f}/{exp_am:.1f}")
print(f"  -> {'OK 일치' if time_match else 'NG'}")

# 4) 1분/5분 단위
print("\n[4] 1분/5분단위 동기")
match_minute = True
for serial, date in [("46142", "2026-04-30"), ("46146", "2026-05-04"), ("46150", "2026-05-08")]:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
        valueInputOption="USER_ENTERED",
        body={"values": [[serial]]},
    ).execute()
    time_mod.sleep(8)
    raw = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    raw_cnt = sum(1 for r in raw if r and r[0])
    daily_u = "?"
    for row in daily:
        if row and isinstance(row[0], str) and row[0] == date:
            daily_u = row[20] if len(row) > 20 else "?"
            break
    if raw_cnt != daily_u:
        match_minute = False
    print(f"  {date}: RAW={raw_cnt} 1.일별 U={daily_u} {'OK' if raw_cnt == daily_u else 'NG'}")

print("\n" + "=" * 100)
all_ok = (total_errors == 0 and len(mismatches) == 0 and time_match and match_minute)
if all_ok:
    print(">>> 모든 검증 100% 통과 <<<")
else:
    print("!!! 추가 점검 필요 !!!")
print("=" * 100)
