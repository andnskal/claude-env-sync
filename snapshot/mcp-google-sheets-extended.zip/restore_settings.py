"""★설정을 신 시스템 원래 구조로 복원 (헤더 행1 + 데이터 행2부터).
다른 시트의 참조 (G2:I16, D2:D15 등)와 일치하도록.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 클리어
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'★설정'!A1:Z200", body={}
).execute()

# 행1 헤더
header_row1 = [[
    "RAW 시트 주소",                    # A
    "운영시간",                         # B
    "점심시간",                         # C
    "공휴일 (입력)",                    # D
    "비고",                             # E
    "날짜 텍스트변환",                  # F
    "assigneeId(텍스트)",                # G
    "assigneeId",                       # H
    "상담사 이름",                      # I
    "팀 (인하우스/도급사)",             # J
    "이메일",                           # K
    "활성여부",                         # L
    "",                                 # M
    "team_id",                          # N
    "팀명",                             # O
    "구분",                             # P
    "",                                 # Q
    "phoneNumber",                      # R (채널 매핑 키)
    "전화",                             # S (채널 매핑 값)
    "",                                 # T
    "",                                 # U
    "운영시간(1분)",                    # V
    "운영여부",                         # W
    "인하우스 명단",                    # X
    "도급사 명단",                      # Y
]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!A1:Y1",
    valueInputOption="USER_ENTERED", body={"values": header_row1},
).execute()

# 행2부터 데이터 (15명 매니저 + 운영시간 + 공휴일)
# 행 인덱스가 다른 데이터들이 어우러진 형태 (기존 신 시스템 그대로)
data = [
    # row 2
    ["https://docs.google.com/spreadsheets/d/10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8/edit",
     "9:00", "12:50", "2026-05-01", "근로자의 날", "2026-05-01",
     "manager-492537", "492537", "김진향(기술)", "기술", "kjh2311@melkin.co.kr", "활성",
     "", "10268", "고객센터", "CS", "",
     "phoneNumber", "전화"],
    # row 3
    ["", "17:30", "14:00", "2026-05-05", "어린이날 (대체)", "2026-05-05",
     "manager-540982", "540982", "윤준규(기술)", "기술", "yjkyjk2506@melkin.co.kr", "활성",
     "", "10308", "기술CS", "기술", "",
     "appkakao", "카카오"],
    # row 4
    ["", "", "", "2026-05-25", "부처님 오신 날", "",
     "manager-557415", "557415", "최종수(CS)", "인하우스", "cjswe@melkin.co.kr", "활성",
     "", "10367", "채팅담당자", "채팅", "",
     "appnavertalk", "네이버"],
    # row 5
    ["", "", "", "2026-06-06", "현충일", "",
     "manager-620022", "620022", "김지은(CS)", "인하우스", "jieunkimtime@melkin.co.kr", "활성",
     "", "", "(정의 없음)", "기타", "",
     "", "채널톡"],
    # row 6
    ["", "", "", "2026-08-15", "광복절", "",
     "manager-623467", "623467", "한송희(기술)", "기술", "hangsonghee86@melkin.co.kr", "활성",
     "", "", "", "", "",
     "기술이관", "기술이관"],
    ["", "", "", "2026-09-24", "추석", "",
     "manager-629462", "629462", "정현호(CS)", "인하우스", "jhh2604@melkin.co.kr", "활성"],
    ["", "", "", "2026-09-25", "추석", "",
     "manager-631540", "631540", "지상호(CS)", "인하우스", "jsh2604@melkin.co.kr", "활성"],
    ["", "", "", "2026-09-26", "추석", "",
     "manager-631655", "631655", "박슬기(CS)", "인하우스", "seulki4544@gmail.com", "활성"],
    ["", "", "", "2026-10-03", "개천절", "",
     "manager-631668", "631668", "한승연(CS)", "인하우스", "seungyeon@melkin.co.kr", "활성"],
    ["", "", "", "2026-10-05", "추석 대체", "",
     "manager-633677", "633677", "이윤애(CS)", "인하우스", "tshwpll147@gmail.com", "활성"],
    ["", "", "", "2026-10-09", "한글날", "",
     "manager-631394", "631394", "CS쉐어링_안준모", "도급사", "css.melkin5@gmail.com", "비활성(5월~)"],
    ["", "", "", "2026-12-25", "크리스마스", "",
     "manager-589223", "589223", "CS쉐어링_김혜림", "도급사", "css.melkin7@gmail.com", "비활성(5월~)"],
    ["", "", "", "", "", "",
     "manager-601163", "601163", "CS쉐어링_이혜미", "도급사", "css.melkin10@gmail.com", "비활성(5월~)"],
    ["", "", "", "", "", "",
     "manager-617407", "617407", "CS쉐어링_신화영", "도급사", "css.melkin13@gmail.com", "비활성(5월~)"],
    ["", "", "", "", "", "",
     "manager-621571", "621571", "CS쉐어링_천승현", "도급사", "css.melkin.14@gmail.com", "비활성(5월~)"],
]

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!A2:S16",
    valueInputOption="USER_ENTERED", body={"values": data},
).execute()

# X (인하우스 명단), Y (도급사 명단) 자동 수식
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!X2",
    valueInputOption="USER_ENTERED",
    body={"values": [["=ARRAYFORMULA(IF((I2:I16<>\"\")*((J2:J16=\"인하우스\")+(J2:J16=\"기술\"))>0,I2:I16,\"\"))"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!Y2",
    valueInputOption="USER_ENTERED",
    body={"values": [["=ARRAYFORMULA(IF((I2:I16<>\"\")*(J2:J16=\"도급사\"),I2:I16,\"\"))"]]},
).execute()

print("✅ ★설정 복원 완료 (참조 호환)")
