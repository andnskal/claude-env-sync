"""5/11 정현호 26건 vs 25건 — 통화시간/대기시간/끝시간/RAW callDuration 비교.
채널톡이 어떤 룰로 1건을 제외했는지 추적.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"

# 정현호 5/11 IB_성공 콜 (5.콜에서)
calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("[5.콜 정현호 5/11 IB_성공 — 모든 컬럼]")
print(f"{'시각':>20} | {'D firstEng':>20} | {'E endedAt':>20} | {'R duration':>12} | {'S secs':>8} | {'U queue':>8} | {'V hold':>8}")
print("-" * 130)
jh = []
for row in calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_정현호" or row[16] != "IB_성공": continue
    jh.append(row)

jh.sort(key=lambda r: r[2])
for row in jh:
    C = row[2]
    D = row[3] if len(row) > 3 else ""
    E = row[4] if len(row) > 4 else ""
    R = row[17] if len(row) > 17 else ""
    S = row[18] if len(row) > 18 else ""
    U = row[20] if len(row) > 20 else ""
    V = row[21] if len(row) > 21 else ""
    AA = row[26] if len(row) > 26 else ""
    AB = row[27] if len(row) > 27 else ""
    print(f"  {C} | {D[-20:] if D else '-':>20} | {E[-20:] if E else '-':>20} | {R:>12} | {S:>8} | {U:>8} | {V:>8}")
    print(f"    firstRingStartedAt={AA} | ringWait={AB}")

print(f"\n총 {len(jh)}건")

# 매우 짧은 통화나 미응대 의심
print("\n[정현호 IB_성공 중 통화시간 5초 이하]")
for row in jh:
    R = row[17] if len(row) > 17 else "0"
    try:
        parts = str(R).split(":")
        if len(parts) >= 3:
            secs = int(parts[0])*3600 + int(parts[1])*60 + int(parts[2])
            if secs <= 5:
                print(f"  {row[2]} | duration={R} ({secs}초) | tags={row[23] if len(row)>23 else ''}")
    except:
        pass

# 정현호 5/11 채널톡 vs 우리 비교 위해 chatId 추출
print("\n[정현호 5/11 IB_성공 chatId 목록]")
for row in jh:
    print(f"  {row[0]} | {row[2]}")

# RAW에서 정현호 5/11 데이터 직접 보기 (UserChat meet data 신 33열)
print("\n" + "=" * 80)
print("[RAW UserChat meet data — 정현호 5/11 직접 확인]")
print("=" * 80)
# 정현호의 managerID 확인
mgr = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!F2:H30",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
jh_mgr_ids = []
for r in mgr:
    if len(r) >= 3 and "정현호" in str(r[2]):
        jh_mgr_ids.append(r[1])
        print(f"  정현호 ID: {r}")

# RAW UserChat meet data
raw = _sheets.spreadsheets().values().get(
    spreadsheetId=RAW, range="'UserChat meet data'!A1:AG5000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

if raw:
    raw_headers = raw[0]
    print(f"\n  RAW 헤더 ({len(raw_headers)}열): {raw_headers[:10]}...")

    # callAssigneeId 열 찾기 (대개 5번 column)
    aid_col = None
    for ci, h in enumerate(raw_headers):
        if "callAssignee" in str(h) or "assignee" in str(h).lower():
            aid_col = ci
            print(f"  → callAssigneeId 열: {chr(65+ci) if ci<26 else 'A'+chr(65+ci-26)} ({ci}) = {h}")
            break

    # direction
    dir_col = None
    for ci, h in enumerate(raw_headers):
        if str(h).lower() == "direction":
            dir_col = ci
            print(f"  → direction 열: {chr(65+ci) if ci<26 else 'A'+chr(65+ci-26)} ({ci}) = {h}")
            break

    # startedAt
    started_col = None
    for ci, h in enumerate(raw_headers):
        if "startedAt" in str(h) and "post" not in str(h).lower() and "firstEngaged" not in str(h):
            started_col = ci
            print(f"  → startedAt 열: {chr(65+ci) if ci<26 else 'A'+chr(65+ci-26)} ({ci}) = {h}")
            break

    # firstEngagedAt
    fe_col = None
    for ci, h in enumerate(raw_headers):
        if "firstEngagedAt" in str(h):
            fe_col = ci
            print(f"  → firstEngagedAt 열: {chr(65+ci) if ci<26 else 'A'+chr(65+ci-26)} ({ci}) = {h}")
            break

    # missedReason
    mr_col = None
    for ci, h in enumerate(raw_headers):
        if "missedReason" in str(h):
            mr_col = ci
            print(f"  → missedReason 열: {chr(65+ci) if ci<26 else 'A'+chr(65+ci-26)} ({ci}) = {h}")
            break

    # callDuration
    cd_col = None
    for ci, h in enumerate(raw_headers):
        if "callDuration" in str(h):
            cd_col = ci
            print(f"  → callDuration 열: {chr(65+ci) if ci<26 else 'A'+chr(65+ci-26)} ({ci}) = {h}")
            break

    if aid_col and dir_col and started_col:
        print(f"\n[RAW 5/11 정현호 inbound 콜 — 채널톡 원본]")
        cnt = 0
        for ri in range(1, len(raw)):
            row = raw[ri]
            if len(row) <= max(aid_col, dir_col, started_col): continue
            aid = row[aid_col]
            d = row[dir_col]
            s = row[started_col]
            if not s or not str(s).startswith("2026-05-11"): continue
            if str(aid) not in jh_mgr_ids: continue
            if d != "inbound": continue
            cnt += 1
            fe = row[fe_col] if fe_col and len(row) > fe_col else ""
            mr = row[mr_col] if mr_col and len(row) > mr_col else ""
            cd = row[cd_col] if cd_col and len(row) > cd_col else ""
            print(f"  {s} | firstEng={fe} | missedReason={mr} | duration={cd}")
        print(f"\n  RAW 정현호 5/11 inbound 총: {cnt}건")
