"""통계 시트에 '📐 프로그램 명세서' 시트 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 새 시트 추가
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
existing = {s["properties"]["title"] for s in meta.get("sheets", [])}

if "📐 프로그램 명세서" not in existing:
    res = _sheets.spreadsheets().batchUpdate(
        spreadsheetId=NEW,
        body={"requests": [{
            "addSheet": {
                "properties": {
                    "title": "📐 프로그램 명세서",
                    "index": 1,  # 사용 가이드 다음
                    "gridProperties": {"rowCount": 200, "columnCount": 8, "hideGridlines": True, "frozenRowCount": 1}
                }
            }
        }]}
    ).execute()
    sid = res["replies"][0]["addSheet"]["properties"]["sheetId"]
    print(f"OK 시트 추가")
else:
    sid = _get_sheet_id_by_name(NEW, "📐 프로그램 명세서")
    print(f"기존 시트 사용")
time.sleep(2)

data = [
    ["", "📐 채널톡 상담실적 통계 시스템 — 프로그램 명세서", "", "", "", ""],
    ["", "", "", "", "", ""],
    ["", "📌 안내", "", "", "", ""],
    ["", "이 시트는 현 Google Sheets 시스템을 자체 프로그램(웹/앱/대시보드)으로 이관하기 위한 핵심 요약입니다.\n전체 상세 명세는 별도 문서 'SYSTEM_SPECIFICATION.md' (개발자 전달용)를 참조하세요.", "HIGHLIGHT", "", "", ""],
    ["", "", "", "", "", ""],
    ["", "🏗 시스템 아키텍처", "", "", "", ""],
    ["", "레이어", "구성 요소", "역할", "", ""],
    ["", "Layer 0: 소스", "채널톡 API + 외부 운영 시트 (1-6uipG0...)", "RAW 데이터 출처", "", ""],
    ["", "Layer 1: RAW 동기", "RAW_UserChat (97열), RAW_NewMeet (33열), RAW 55번 기술 이관", "IMPORTRANGE 자동 동기", "", ""],
    ["", "Layer 2: 1차 가공", "5.콜 상담내역 (32열), 6.채팅 상담내역 (26열)", "상담 1건 = 1행, 분류/매핑 적용", "", ""],
    ["", "Layer 3: 집계", "2.시간대별 (38열), 1.일별 (53열)", "SUMIFS/COUNTIFS 자동 집계", "", ""],
    ["", "Layer 4: 피벗", "3.상담사별 채팅, 4.상담사별 콜", "상담사 × 일자 × 카테고리 피벗", "", ""],
    ["", "Layer 5: 분석", "RAW시간대별, 1분/5분단위 포기호", "특정 일자 시간 단위 추적", "", ""],
    ["", "", "", "", "", ""],
    ["", "🔄 데이터 흐름", "", "", "", ""],
    ["", "1단계", "채널톡 → 상담별통계.xlsx 다운로드", "사용자 수동", "매주/매월", ""],
    ["", "2단계", "RAW 시트 (10wg3x0y...) 업로드", "사용자 수동 (기존 시트 바꾸기)", "매주/매월", ""],
    ["", "3단계", "RAW_UserChat / RAW_NewMeet IMPORTRANGE 자동 갱신", "Google Sheets", "자동", ""],
    ["", "4단계", "RAW 55번 기술 이관 IMPORTRANGE (외부 시트)", "Google Sheets", "실시간", ""],
    ["", "5단계", "5.콜 / 6.채팅 ARRAYFORMULA 가공 (행 2~)", "Google Sheets", "자동", ""],
    ["", "6단계", "2.시간대별 / 1.일별 / 3,4 SUMIFS/COUNTIFS 집계", "Google Sheets", "자동", ""],
    ["", "", "", "", "", ""],
    ["", "💡 핵심 비즈니스 규칙", "", "", "", ""],
    ["", "규칙", "정의", "수식 / 로직", "", ""],
    ["", "운영시간", "09:00 ~ 17:30 (8.5시간)", "AD/Z 컬럼: 채널톡 태그 '운영시간아님' 미포함 + 시간 범위", "", ""],
    ["", "응대율 (R)", "응대호 / 접수호 (알림제외)", "P/O", "", ""],
    ["", "응대율 (V) — 기술포기호 제외", "응대호 / 접수호 (기술+알림 제외)", "T/S", "", ""],
    ["", "OB 응답률", "OB 성공 / OB 시도", "AC/AB", "", ""],
    ["", "콜백 신청 (AE)", "IB 부재 + '콜백' 태그", "COUNTIFS(Q=IB_포기호, Y=콜백)", "", ""],
    ["", "콜백 OB 처리 (AI)", "OB 성공 + X에 '콜백' 포함 + 본사/외주", "사용자 명시 정의 (5/10)", "", ""],
    ["", "콜백 처리율 (AJ)", "AI / AE", "처리 / 신청", "", ""],
    ["", "기술이관 (M)", "본사 채팅 + 외주 채팅 + 본사 비채팅 + 외주 비채팅", "6.채팅 + RAW 55 (R 분류별)", "", ""],
    ["", "본사/외주 구분", "★설정 H 컬럼 prefix", "TCK_/CS쉐어링_ = 외주, CS_/CX_/기술_ = 본사", "", ""],
    ["", "공휴일 제외", "1.일별 A6 FILTER", "★설정 C 컬럼 + WEEKDAY <= 5", "", ""],
    ["", "", "", "", "", ""],
    ["", "📊 KPI 컬럼 (1.일별 전체 통계)", "", "", "", ""],
    ["", "그룹", "컬럼", "내용", "수식 출처", ""],
    ["", "채팅", "C-J", "카카오/네이버/채널톡 인입+답변", "2.시간대별 SUMIFS", ""],
    ["", "채팅 합계", "K, L, M, N", "답변율/본사+외주합/기술이관/Total", "K=J/I, M=통합 수식", ""],
    ["", "IB", "O-R", "접수호/응대호/포기호/응대율 (알림제외)", "2.시간대별 SUMIFS", ""],
    ["", "IB (기술제외)", "S-V", "접수호/응대호/포기호/응대율 (기술포기호 제외)", "2.시간대별 SUMIFS", ""],
    ["", "IB 시간", "W, X", "총 통화시간 / ATT", "5.콜 SUMIFS / W÷P", ""],
    ["", "IB 투입", "Y, Z", "단순 인원 / 시간대별합÷10", "5.콜 unique / 시간대별합", ""],
    ["", "OB", "AA-AG", "OB부재/시도/성공/콜백제외/콜백/통화시간/ATT", "5.콜 + 시간대별", ""],
    ["", "상담톡/콜백", "AH, AI, AJ", "알림톡/콜백 OB 처리/처리율", "5.콜 COUNTIFS", ""],
    ["", "KPI", "AK, AL, AM", "서비스레벨/응답속도/평균통화", "5.콜 직접 카운트", ""],
    ["", "부재중 사유", "AN-AT", "14종 missedReason 분류", "5.콜 F (missedReason)", ""],
    ["", "참고", "AU, AV, AW", "전체시간 응대율/운영외 IB/운영외 OB", "5.콜 직접 카운트", ""],
    ["", "", "", "", "", ""],
    ["", "🛠 핵심 함수 (의사코드)", "", "", "", ""],
    ["", "함수", "역할", "수식", "", ""],
    ["", "운영시간 분류", "AD/Z 컬럼 자동 분류", "IF('운영시간아님' in tags, '외', IF(540<=분<1050, '내', '외'))", "", ""],
    ["", "콜 구분 (Q)", "IB/OB 성공/실패 분류", "IF chain on direction + firstEngagedAt", "", ""],
    ["", "RAW 55 분류 (R)", "직원_채널 자동 분류", "REGEXMATCH(^TCK|CS쉐어링_) + 채팅 여부", "", ""],
    ["", "기술이관 통합 (M)", "본사+외주, 채팅+비채팅 통합", "6.채팅 + RAW 55 (외주_채팅+외주_비채팅+본사_비채팅)", "", ""],
    ["", "", "", "", "", ""],
    ["", "💾 데이터베이스 스키마 권장사항 (PostgreSQL)", "", "", "", ""],
    ["", "테이블", "역할", "주요 컬럼", "", ""],
    ["", "employees", "직원 마스터", "id, name, team, classification, active", "", ""],
    ["", "holidays", "공휴일 마스터", "date, name", "", ""],
    ["", "operating_hours", "운영시간 마스터", "start_time, end_time, effective_from", "", ""],
    ["", "call_records", "콜 가공 1건 = 1행", "32 컬럼 (5.콜 시트와 동일)", "", ""],
    ["", "chat_records", "채팅 가공 1건 = 1행", "26 컬럼 (6.채팅 시트와 동일)", "", ""],
    ["", "external_tech_transfer", "외부 시트 통합", "received_at, requester, channel, classification", "", ""],
    ["", "daily_kpi", "일별 KPI 집계 (materialized)", "53개 컬럼 (1.일별 시트와 동일)", "", ""],
    ["", "", "", "", "", ""],
    ["", "🚀 권장 기술 스택", "", "", "", ""],
    ["", "구성", "추천", "비고", "", ""],
    ["", "백엔드", "Node.js (Express/Fastify) 또는 Python (FastAPI)", "Vercel Functions 활용 시 Node.js 24", "", ""],
    ["", "데이터베이스", "PostgreSQL + TimescaleDB", "시계열 데이터 최적화", "", ""],
    ["", "프론트엔드", "Next.js (App Router) + Recharts", "Vercel 배포", "", ""],
    ["", "캐싱", "Vercel Runtime Cache 또는 Redis", "일별 집계 캐싱", "", ""],
    ["", "데이터 수집", "채널톡 OpenAPI 또는 RAW 엑셀 파싱", "옵션 A: API / 옵션 B: 파일", "", ""],
    ["", "", "", "", "", ""],
    ["", "📋 명세 파일", "", "", "", ""],
    ["", "전체 명세서", "", "SYSTEM_SPECIFICATION.md (D:\\claude\\google sheet\\)", "", ""],
    ["", "내용", "", "16 챕터, 시트별 전 컬럼 명세 + KPI 정의 사전 + DB 스키마 + 개발 가이드", "", ""],
    ["", "", "", "", "", ""],
    ["", "💼 개발자 인수인계 체크리스트", "", "", "", ""],
    ["", "✅ 채널톡 API 키 발급", "운영팀에서 발급 필요", "API 문서: https://developers.channel.io/docs", "", ""],
    ["", "✅ 외부 시트 접근 권한", "1-6uipG0... 서비스 계정 권한", "이미 부여됨", "", ""],
    ["", "✅ DB 스키마 생성", "PostgreSQL 13+ 권장", "위 7개 테이블 + 인덱스", "", ""],
    ["", "✅ 데이터 마이그레이션", "4/30 이후 데이터 백필", "5.콜/6.채팅에서 export 후 import", "", ""],
    ["", "✅ KPI 산출 로직 구현", "1.일별 53개 컬럼 모두 구현", "Layer 2-3 의사코드 활용", "", ""],
    ["", "✅ 자동 동기 스케줄", "매일 03:00 KST 채널톡 RAW 동기", "Cron 또는 Vercel Cron", "", ""],
    ["", "✅ 권한 시스템", "임원/매니저/팀장/상담사 4단계", "Vercel + Clerk 추천", "", ""],
]

# 데이터 입력
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'📐 프로그램 명세서'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": data},
).execute()
print(f"OK 데이터 입력 ({len(data)}행)")
time.sleep(2)

# 서식 적용
# 컬럼 너비
_batch_update(NEW, [
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1},
        "properties": {"pixelSize": 30}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2},
        "properties": {"pixelSize": 200}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 3},
        "properties": {"pixelSize": 250}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 3, "endIndex": 4},
        "properties": {"pixelSize": 380}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 4, "endIndex": 5},
        "properties": {"pixelSize": 100}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 5, "endIndex": 8},
        "properties": {"hiddenByUser": True}, "fields": "hiddenByUser"}},
])

# 행별 서식
reqs = []

# 행 1 - 큰 제목
reqs.append({"mergeCells": {
    "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 1, "endColumnIndex": 5},
    "mergeType": "MERGE_ALL"}})
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 1, "endColumnIndex": 5},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 0.13, "green": 0.27, "blue": 0.45},
        "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 18},
        "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 0, "endIndex": 1},
    "properties": {"pixelSize": 55}, "fields": "pixelSize"}})

# 섹션 헤더 (행 3, 6, 15, 24, 37, 50, 56, 64, 71)
section_rows_0 = [2, 5, 14, 23, 36, 49, 55, 63, 70]
for sr in section_rows_0:
    reqs.append({"mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 5},
        "mergeType": "MERGE_ALL"}})
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 5},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.20, "green": 0.45, "blue": 0.65},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 13},
            "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": sr, "endIndex": sr+1},
        "properties": {"pixelSize": 35}, "fields": "pixelSize"}})

# HIGHLIGHT 행 (행 4)
reqs.append({"mergeCells": {
    "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 4, "startColumnIndex": 1, "endColumnIndex": 5},
    "mergeType": "MERGE_ALL"}})
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 4, "startColumnIndex": 1, "endColumnIndex": 5},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 1.0, "green": 0.95, "blue": 0.7},
        "textFormat": {"bold": True, "fontSize": 11},
        "wrapStrategy": "WRAP"}},
    "fields": "userEnteredFormat(backgroundColor,textFormat,wrapStrategy)"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 3, "endIndex": 4},
    "properties": {"pixelSize": 60}, "fields": "pixelSize"}})

# 일반 데이터 폰트
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 100, "startColumnIndex": 1, "endColumnIndex": 5},
    "cell": {"userEnteredFormat": {
        "textFormat": {"fontSize": 10},
        "verticalAlignment": "MIDDLE",
        "wrapStrategy": "WRAP"}},
    "fields": "userEnteredFormat(textFormat,verticalAlignment,wrapStrategy)"}})

# 테이블 헤더 행 (행 7, 16, 25, 38, 51, 57, 65, 72)
table_header_0 = [6, 15, 24, 37, 50, 56, 64, 71]
for sr in table_header_0:
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 5},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.85, "green": 0.85, "blue": 0.85},
            "textFormat": {"bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"}})

# 데이터 행 (테이블 행에 테두리)
data_ranges = [
    (7, 13),    # 아키텍처 (행 8-14)
    (16, 22),   # 데이터 흐름
    (25, 35),   # 비즈니스 규칙
    (38, 48),   # KPI 컬럼
    (51, 54),   # 핵심 함수
    (57, 62),   # DB 스키마
    (65, 69),   # 기술 스택
    (72, 79),   # 인수인계 체크리스트
]
for sr, er in data_ranges:
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": er+1, "startColumnIndex": 1, "endColumnIndex": 5},
        "cell": {"userEnteredFormat": {
            "borders": {
                "top": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}},
                "bottom": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}},
                "left": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}},
                "right": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}}}}},
        "fields": "userEnteredFormat.borders"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": sr, "endIndex": er+1},
        "properties": {"pixelSize": 38}, "fields": "pixelSize"}})

# 청크 분할 적용
chunk = 50
for i in range(0, len(reqs), chunk):
    _batch_update(NEW, reqs[i:i+chunk])
    time.sleep(0.5)
print("OK 서식 적용 완료")
