"""기존 vs 신 시스템 객관적 차이점 추출."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

LEGACY = "1iGF-f5kvcGBZtoY4efjkBMNCfeFhW6shp2wWRLKkJEo"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

TABS = [
    ("1.일별 전체 통계", 34, 6),    # 34열 6행
    ("2.시간대별 전체통계", 38, 6),
    ("5.콜 상담내역", 26, 2),
    ("6.채팅 상담내역", 25, 2),
    ("3.상담사별 채팅 실적", 10, 2),
    ("4.상담사별 콜 실적", 10, 2),
    ("★설정", 25, 5),
]


def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


def extract(ssid, name, ncols, nrows):
    """헤더 텍스트, 데이터 행 형식, 열 너비, 그룹, 병합 추출."""
    # 시트 구조 (열 너비, 행 높이, 그룹)
    meta = _sheets.spreadsheets().get(
        spreadsheetId=ssid,
        ranges=[f"'{name}'!A1:{col_letter(ncols-1)}{nrows}"],
        includeGridData=True,
        fields="sheets(properties,merges,columnGroups,rowGroups,data(rowData(values(userEnteredValue,userEnteredFormat,formattedValue)),columnMetadata(pixelSize,hiddenByUser),rowMetadata(pixelSize,hiddenByUser)))"
    ).execute()
    sheet = meta["sheets"][0]
    out = {
        "title": name,
        "frozen_rows": sheet["properties"]["gridProperties"].get("frozenRowCount", 0),
        "frozen_cols": sheet["properties"]["gridProperties"].get("frozenColumnCount", 0),
        "merges_count": len(sheet.get("merges", [])),
        "column_groups": sheet.get("columnGroups", []),
        "row_groups": sheet.get("rowGroups", []),
        "column_widths": [],
        "row_heights": [],
        "header_texts": {},
        "data_row_formats": {},
    }
    data = sheet.get("data", [{}])[0]
    # 열 너비
    for ci, cm in enumerate(data.get("columnMetadata", [])[:ncols]):
        out["column_widths"].append({"col": col_letter(ci), "px": cm.get("pixelSize", 100)})
    # 행 높이
    for ri, rm in enumerate(data.get("rowMetadata", [])[:nrows]):
        out["row_heights"].append({"row": ri + 1, "px": rm.get("pixelSize", 21)})
    # 헤더 텍스트 (1-3행)
    rows = data.get("rowData", [])
    for ri in range(min(3, nrows, len(rows))):
        row = rows[ri].get("values", [])
        out["header_texts"][f"row{ri+1}"] = []
        for ci, cell in enumerate(row[:ncols]):
            text = cell.get("formattedValue", "")
            out["header_texts"][f"row{ri+1}"].append({"col": col_letter(ci), "text": text})
    # 데이터 행 (마지막 행 보유 시) 형식
    if len(rows) > 3:
        data_row = rows[-1].get("values", [])
        for ci, cell in enumerate(data_row[:ncols]):
            fmt = cell.get("userEnteredFormat", {})
            nf = fmt.get("numberFormat", {})
            if nf.get("type") and nf.get("type") != "TEXT":
                out["data_row_formats"][col_letter(ci)] = {
                    "type": nf.get("type"),
                    "pattern": nf.get("pattern"),
                }
    return out


def diff_dict(legacy, new, name):
    """두 dict 비교."""
    diffs = []
    # frozen
    if legacy["frozen_rows"] != new["frozen_rows"]:
        diffs.append(f"❌ 행 고정: 기존={legacy['frozen_rows']} vs 신={new['frozen_rows']}")
    if legacy["frozen_cols"] != new["frozen_cols"]:
        diffs.append(f"❌ 열 고정: 기존={legacy['frozen_cols']} vs 신={new['frozen_cols']}")
    # 병합
    if legacy["merges_count"] != new["merges_count"]:
        diffs.append(f"❌ 병합 수: 기존={legacy['merges_count']} vs 신={new['merges_count']}")
    # 그룹
    if len(legacy["column_groups"]) != len(new["column_groups"]):
        diffs.append(f"❌ 열 그룹: 기존={len(legacy['column_groups'])}개 vs 신={len(new['column_groups'])}개")
        if legacy["column_groups"]:
            diffs.append(f"   기존 그룹: {legacy['column_groups'][:5]}")
    if len(legacy["row_groups"]) != len(new["row_groups"]):
        diffs.append(f"❌ 행 그룹: 기존={len(legacy['row_groups'])}개 vs 신={len(new['row_groups'])}개")
    # 열 너비 (각 열별 비교)
    width_diffs = []
    for lcw, ncw in zip(legacy["column_widths"], new["column_widths"]):
        if abs(lcw["px"] - ncw["px"]) > 5:  # 5px 차이 이상만
            width_diffs.append(f"{lcw['col']}: 기존={lcw['px']} vs 신={ncw['px']}")
    if width_diffs:
        diffs.append(f"❌ 열 너비 차이: {len(width_diffs)}개")
        for d in width_diffs[:8]:
            diffs.append(f"   {d}")
    # 헤더 텍스트
    for ri in ["row1", "row2", "row3"]:
        if ri not in legacy["header_texts"] or ri not in new["header_texts"]:
            continue
        text_diffs = []
        for l, n in zip(legacy["header_texts"][ri], new["header_texts"][ri]):
            if l["text"] != n["text"]:
                text_diffs.append(f"{l['col']}: 기존='{l['text'][:25]}' vs 신='{n['text'][:25]}'")
        if text_diffs:
            diffs.append(f"❌ {ri} 헤더 텍스트 차이: {len(text_diffs)}개")
            for d in text_diffs[:10]:
                diffs.append(f"   {d}")
    # 데이터 행 형식
    fmt_diffs = []
    for col, lf in legacy["data_row_formats"].items():
        nf = new["data_row_formats"].get(col)
        if nf != lf:
            fmt_diffs.append(f"{col}: 기존={lf} vs 신={nf}")
    if fmt_diffs:
        diffs.append(f"❌ 데이터 형식 차이: {len(fmt_diffs)}개")
        for d in fmt_diffs[:10]:
            diffs.append(f"   {d}")
    return diffs


print("=" * 70)
print("기존 vs 신 시스템 객관적 차이점 분석")
print("=" * 70)

all_data = {"legacy": {}, "new": {}}
for name, ncols, nrows in TABS:
    print(f"\n📋 {name}")
    print("-" * 70)
    try:
        legacy_data = extract(LEGACY, name, ncols, nrows)
        new_data = extract(NEW, name, ncols, nrows)
        all_data["legacy"][name] = legacy_data
        all_data["new"][name] = new_data
        diffs = diff_dict(legacy_data, new_data, name)
        if not diffs:
            print("  ✅ 차이 없음")
        else:
            for d in diffs:
                print(f"  {d}")
    except Exception as e:
        print(f"  ⚠️ 오류: {e}")

with open(os.path.join(os.path.dirname(__file__), "diff_result.json"), "w", encoding="utf-8") as f:
    json.dump(all_data, f, ensure_ascii=False, indent=2)
print(f"\n\n저장: diff_result.json")
