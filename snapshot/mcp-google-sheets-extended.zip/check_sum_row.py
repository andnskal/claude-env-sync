"""1.일별 합계 행 (행 5) + 행 6+ 합산 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 합계 행 (행 5) + 데이터 행 (행 6-12)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AT15",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 행 5 = 합계, 행 4 = 평균, 행 6+ = 데이터
print("=" * 80)
print("1.일별 행 4 (평균), 행 5 (합계) 검증")
print("=" * 80)

# 주요 카운트 KPI (응대율 등 평균/비율은 별도)
sum_kpis = [
    (3, "D 카카오 답변"),
    (5, "F 네이버 답변"),
    (7, "H 채널톡 답변"),
    (12, "M 기술이관"),
    (15, "P 응대호"),
    (16, "Q 포기호 알림제외"),
    (20, "U 포기호 기술제외"),
    (24, "Y IB 투입인원"),
    (27, "AB OB 시도"),
    (28, "AC OB 성공"),
    (30, "AE 콜백 등록"),
    (33, "AH 상담톡"),
    (34, "AI 콜백 OB"),
]

for col_idx, label in sum_kpis:
    sum_5 = res[1][col_idx] if len(res) > 1 and col_idx < len(res[1]) else None
    avg_4 = res[0][col_idx] if len(res) > 0 and col_idx < len(res[0]) else None
    # 행 6+ 합산
    actual_sum = 0
    n_rows = 0
    for ri in range(2, len(res)):
        if ri >= len(res): break
        row = res[ri]
        if col_idx < len(row) and isinstance(row[col_idx], (int, float)):
            actual_sum += row[col_idx]
            n_rows += 1
    actual_avg = actual_sum / n_rows if n_rows > 0 else 0
    
    sum_match = "✅" if isinstance(sum_5, (int, float)) and abs(sum_5 - actual_sum) < 0.01 else "❌"
    avg_match = "✅" if isinstance(avg_4, (int, float)) and abs(avg_4 - actual_avg) < 1 else "❌"
    
    print(f"  {label:<25} | 합계={sum_5} (수동={actual_sum}) {sum_match} | 평균={avg_4} (수동={actual_avg:.1f}) {avg_match}")
