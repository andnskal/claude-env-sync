"""5/8 이윤애 상담사 IB_성공 카운트 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 모든 데이터
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("=" * 80)
print("5/8 이윤애 상담사 분석")
print("=" * 80)

# 다양한 시나리오 카운트
scenarios = {
    "전체_IB_inbound_5/8_이윤애": 0,
    "IB_성공_5/8_이윤애_운영시간내": 0,
    "IB_성공_5/8_이윤애_운영시간외": 0,
    "IB_성공_5/8_이윤애_전체시간": 0,
    "IB_성공_5/8_W=이윤애만": 0,
    "IB_성공_5/8_W=CS_이윤애": 0,
    "Q=IB_성공_M=이윤애_assigneeId": 0,
    "이윤애_관련_모든_콜": 0,
}

samples = {"운영시간내": [], "운영시간외": [], "기타": []}

for row in all_calls:
    if len(row) < 30: continue
    N = row[13]  # 날짜
    Q = row[16]  # 구분
    B = row[1]   # direction
    W = row[22]  # 상담사
    AD = row[29]  # 운영시간
    C = row[2]   # startedAt
    D = row[3]   # firstEngagedAt
    
    if N != "2026-05-08": continue
    
    # 이윤애 관련
    if "이윤애" in str(W):
        scenarios["이윤애_관련_모든_콜"] += 1
        
        if B == "inbound":
            scenarios["전체_IB_inbound_5/8_이윤애"] += 1
        
        if Q == "IB_성공":
            scenarios["IB_성공_5/8_전체시간_temp"] = scenarios.get("IB_성공_5/8_전체시간_temp", 0) + 1
            scenarios["IB_성공_5/8_이윤애_전체시간"] += 1
            
            if AD == "내":
                scenarios["IB_성공_5/8_이윤애_운영시간내"] += 1
                samples["운영시간내"].append((C, W, D, AD))
            elif AD == "외":
                scenarios["IB_성공_5/8_이윤애_운영시간외"] += 1
                samples["운영시간외"].append((C, W, D, AD))
            else:
                samples["기타"].append((C, W, D, AD))
            
            if W == "이윤애":
                scenarios["IB_성공_5/8_W=이윤애만"] += 1
            elif W == "CS_이윤애":
                scenarios["IB_성공_5/8_W=CS_이윤애"] += 1

print("\n[카운트 결과]")
for k, v in scenarios.items():
    print(f"  {k}: {v}")

print(f"\n[운영시간 내 샘플 (이윤애 IB_성공)]:")
for s in samples["운영시간내"][:20]:
    print(f"  {s}")

print(f"\n[운영시간 외 샘플 (이윤애 IB_성공)]:")
for s in samples["운영시간외"][:20]:
    print(f"  {s}")

# W 컬럼에 "이윤애" 있는 모든 행의 상담사 unique 이름
all_iyunae = set()
for row in all_calls:
    if len(row) > 22 and row[13] == "2026-05-08":
        W = row[22]
        if W and "이윤애" in str(W):
            all_iyunae.add(W)
print(f"\n[5/8 이윤애 관련 상담사 이름 (W 컬럼)]: {all_iyunae}")

# 4.상담사별 콜 실적에서 5/8 이윤애 IB_성공 값
print("\n" + "=" * 80)
print("4.상담사별 콜 실적에서 5/8 이윤애")
print("=" * 80)
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

if res4 and len(res4) >= 3:
    # 행 1 = 날짜, 행 2 = 콜 타입
    dates = res4[0]
    types = res4[1]
    # 5/8 IB_성공 컬럼 찾기
    target_col = None
    for ci, (d, t) in enumerate(zip(dates, types)):
        if isinstance(d, str) and d == "2026-05-08" and t == "IB_성공":
            target_col = ci
            print(f"  5/8 IB_성공 컬럼 = 컬럼 {ci}")
            break
    
    if target_col:
        # 모든 상담사 행 확인
        for ri in range(2, len(res4)):
            row = res4[ri]
            if row and len(row) > target_col:
                name = row[1] if len(row) > 1 else "?"
                val = row[target_col] if target_col < len(row) else 0
                if name and "이윤애" in str(name):
                    print(f"    {name}: {val}건")
