"""Y6 수식 — 범위 제한 + IFERROR 강화."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Y6 새 수식: 범위 제한 (A6:A100) + 더 안전한 IFERROR
y6_new = (
    '=BYROW(A6:A100,LAMBDA(d,IFERROR('
    'IF(d="",,IF(COUNTIFS(\'5.콜 상담내역\'!$N:$N,LEFT(d,10),\'5.콜 상담내역\'!$Q:$Q,"IB_성공")=0,0,'
    'COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!$W:$W,'
    '\'5.콜 상담내역\'!$N:$N=LEFT(d,10),'
    '\'5.콜 상담내역\'!$Q:$Q="IB_성공",'
    '\'5.콜 상담내역\'!$W:$W<>"기타",'
    '\'5.콜 상담내역\'!$W:$W<>"")))))'
    ',0)))'
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!Y6",
    valueInputOption="USER_ENTERED",
    body={"values": [[y6_new]]},
).execute()
print("✅ Y6 새 수식 적용 (BYROW A6:A100 + IFERROR 외부)")
time.sleep(5)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:Y20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[A:Y6 검증]")
for ri, row in enumerate(res):
    if not row: continue
    a = row[0] if len(row) > 0 else ""
    y = row[24] if len(row) > 24 else ""
    if a:
        print(f"  Row {ri+6}: A={a}, Y={y}")
