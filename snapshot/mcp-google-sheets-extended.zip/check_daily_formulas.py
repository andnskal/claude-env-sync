"""1.일별의 모든 수식 (행 6) 검토 - 운영시간 필터 누락 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 행 6 모든 수식
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT6",
    valueRenderOption="FORMULA",
).execute().get("values", [])

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

if res and res[0]:
    print("[1.일별 행 6 모든 수식 — 5.콜/6.채팅 직접 카운트 식별]")
    for ci, v in enumerate(res[0]):
        col = col_letter(ci)
        if v and isinstance(v, str) and v.startswith("="):
            # 5.콜 또는 6.채팅 직접 참조 여부
            is_direct_5 = "'5.콜 상담내역'" in v
            is_direct_6 = "'6.채팅 상담내역'" in v
            via_hourly = "'2.시간대별" in v
            
            tag = ""
            if is_direct_5 and not via_hourly:
                tag = "🔴 5.콜 직접"
            elif is_direct_6 and not via_hourly:
                tag = "🔴 6.채팅 직접"
            elif via_hourly:
                tag = "✅ 시간대별 참조"
            
            if tag:
                print(f"\n  {col}6 [{tag}]: {str(v)[:200]}")
