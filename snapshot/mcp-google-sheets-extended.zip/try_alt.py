"""IMPORTRANGE 다른 형식 시도."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 작은 따옴표 없이 시도
formula = '=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat meet data!A1:AG")'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": [[formula]]},
).execute()
print(f"입력: {formula}")

time.sleep(15)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1:E3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[결과]")
for r in res[:3]:
    print(f"  {r}")

# A1 수식
f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print(f"\nA1 수식: {f[0][0] if f and f[0] else '?'}")
