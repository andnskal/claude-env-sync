"""5/11 데이터 + 점심 예외 적용 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 5/11 데이터 존재 확인
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter
dates = Counter()
for row in all_calls:
    if len(row) > 13 and row[13]:
        dates[row[13]] += 1
print(f"5.콜 데이터 일자: {sorted(dates.keys())}")

# 2) 5/11 임시 점심시간 (11:50-13:00) 시간대 콜 확인
print("\n[5/11 11:50-13:00 시간대 콜의 AD 분류 확인]")
print(f"  {'시각':>20} | {'구분':>8} | {'AD':>4} | {'기대':>4}")
print("  " + "-" * 70)
exception_count = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h * 60 + m
    except:
        continue
    # 11:50 (710분) ~ 13:00 (780분) 사이
    if 710 <= tm < 780:
        exception_count += 1
        expected = "외"  # 점심이라 외
        ad = row[29]
        match = "✅" if ad == expected else "❌ 잘못 분류됨"
        if exception_count <= 15:
            print(f"  {C:>20} | {row[16]:>8} | {ad:>4} | {expected:>4} {match}")

print(f"\n  5/11 11:50-13:00 콜 총: {exception_count}건")

# 3) 5/11 점심 기본 시간 (12:50-14:00) 시간대 콜 확인
print("\n[5/11 12:50-14:00 (기본 점심) 시간대 콜의 AD 분류]")
print(f"  → 5/11은 예외 적용되어 이 시간대는 '내'여야")
print(f"  {'시각':>20} | {'구분':>8} | {'AD':>4}")
print("  " + "-" * 50)
basic_lunch_count = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h * 60 + m
    except:
        continue
    if 770 <= tm < 840:  # 12:50 - 14:00 (기본 점심)
        basic_lunch_count += 1
        if basic_lunch_count <= 15:
            print(f"  {C:>20} | {row[16]:>8} | {row[29]:>4}")
print(f"\n  5/11 12:50-14:00 콜 총: {basic_lunch_count}건")

# 4) ★설정 Z3:AB3 (5/11 예외) 형식 확인
print("\n[★설정 Z3:AB3 (5/11 예외) 형식 확인]")
res = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'★설정'!Z3:AB3"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue,userEnteredValue))))"
).execute()
rd = res["sheets"][0]["data"][0]["rowData"][0]["values"]
for ci, cell in enumerate(rd):
    col = chr(ord('Z') + ci) if ci == 0 else ('A' + chr(ord('A') + ci - 1))
    val = cell.get("formattedValue", "")
    raw = cell.get("userEnteredValue", {})
    fmt = cell.get("userEnteredFormat", {}).get("numberFormat", {})
    print(f"  {col}3: 표시='{val}' / raw={raw} / 서식={fmt.get('type', '?')}")

# 5) XLOOKUP 직접 테스트
print("\n[XLOOKUP 직접 테스트 — 5/11 점심 lookup]")
import time
test_cells = [
    ("Y1", '=IFNA(XLOOKUP("2026-05-11",\'★설정\'!Z3:Z,\'★설정\'!AA3:AA),\'★설정\'!AA2)'),
    ("Y2", '=IFNA(XLOOKUP("2026-05-11",\'★설정\'!Z3:Z,\'★설정\'!AB3:AB),\'★설정\'!AB2)'),
    ("Y3", '=HOUR(IFNA(XLOOKUP("2026-05-11",\'★설정\'!Z3:Z,\'★설정\'!AA3:AA),\'★설정\'!AA2))*60+MINUTE(IFNA(XLOOKUP("2026-05-11",\'★설정\'!Z3:Z,\'★설정\'!AA3:AA),\'★설정\'!AA2))'),
    ("Y4", '=HOUR(IFNA(XLOOKUP("2026-05-11",\'★설정\'!Z3:Z,\'★설정\'!AB3:AB),\'★설정\'!AB2))*60+MINUTE(IFNA(XLOOKUP("2026-05-11",\'★설정\'!Z3:Z,\'★설정\'!AB3:AB),\'★설정\'!AB2))'),
]
for cell, formula in test_cells:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'★설정'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!Y1:Y4",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
labels = ["XLOOKUP 점심 시작", "XLOOKUP 점심 종료", "점심 시작 분", "점심 종료 분"]
for i, lbl in enumerate(labels):
    val = res[i][0] if i < len(res) and res[i] else "?"
    print(f"  {lbl}: {val}")

# 정리
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'★설정'!Y1:Y4"
).execute()
