"""5/8 Q (포기호) 직접 카운트로 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 5/8 IB_포기호 직접 카운트
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

q_in_no_lunch = 0
q_in_with_lunch = 0
q_out = 0
q_in_only_lunch = 0
lunch_calls = []

for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    if row[16] != "IB_포기호": continue
    if row[24] == "알림톡발송": continue
    
    AD = row[29]
    C = row[2]
    
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h * 60 + m
    except:
        continue
    
    is_lunch = 750 <= tm < 810  # 12:30-13:30
    is_op_hours = 540 <= tm < 1050  # 09:00-17:30
    
    if AD == "내":
        q_in_no_lunch += 1
    elif AD == "외":
        q_out += 1
        if is_lunch and is_op_hours:
            q_in_only_lunch += 1
            lunch_calls.append((C, AD))

# 이전 시스템 정의 (점심 포함 운영시간)
total_excl_alert = q_in_no_lunch + q_in_only_lunch
print(f"5/8 IB_포기호 (알림제외) 분포:")
print(f"  AD='내' (점심 제외 운영시간): {q_in_no_lunch}건")
print(f"  AD='외' 중 점심 (12:30-13:30): {q_in_only_lunch}건")
print(f"  AD='외' 그 외 (운영시간 명백 외): {q_out - q_in_only_lunch}건")
print(f"  ─────────────────────")
print(f"  점심 분리 후 Q (현재): {q_in_no_lunch}건")
print(f"  점심 포함 시 Q (이전): {q_in_no_lunch + q_in_only_lunch}건")

# 1.일별 5/8 Q
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:Q60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        sheet_q = row[16] if len(row) > 16 else "?"
        print(f"\n  1.일별 5/8 Q: {sheet_q}")
        match = "✅ 일치" if sheet_q == q_in_no_lunch else f"❌ 직접={q_in_no_lunch}건과 불일치"
        print(f"  검증: {match}")
        break

# 점심시간 분리된 콜 시간 분포
print(f"\n[5/8 점심 분류된 IB_포기호 콜 ({q_in_only_lunch}건)]")
for c, ad in lunch_calls:
    print(f"  {c}")

# 5/8 전체 IB_포기호 시간대 분포 (시간 외 분류 원인 추적)
print(f"\n[5/8 IB_포기호 AD='외' 모두 (왜 그렇게 분류됐는지)]")
all_out_aban = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    if row[16] != "IB_포기호": continue
    if row[24] == "알림톡발송": continue
    if row[29] != "외": continue
    
    C = row[2]
    X = row[23] if len(row) > 23 else ""
    all_out_aban.append((C, X[:30]))

print(f"  총 {len(all_out_aban)}건 AD='외':")
for c, x in all_out_aban[:30]:
    try:
        h, m = int(c.split(" ")[1].split(":")[0]), int(c.split(" ")[1].split(":")[1])
        tm = h*60+m
    except:
        continue
    cat = ""
    if tm < 540: cat = "← 09시 미만"
    elif tm >= 1050: cat = "← 17:30 이후"
    elif 750 <= tm < 810: cat = "← 점심 (12:30-13:30)"
    else: cat = "← 운영시간 중인데 외?? (X 태그: " + x + ")"
    print(f"  {c} | {cat}")
