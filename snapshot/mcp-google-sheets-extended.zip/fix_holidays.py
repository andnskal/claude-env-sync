"""1.일별 A6 수식 수정 - 공휴일 D → C 컬럼 참조."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# A6: 공휴일 명단을 D → C 변경 (또는 E - 텍스트변환)
# C는 numberValue (DATE 시리얼). E는 텍스트 yyyy-mm-dd. 둘 다 가능.
# C가 직접적이고 안전 (시리얼 그대로 비교).
new_a6 = (
    '=IFERROR(UNIQUE(FILTER(\'2.시간대별 전체통계\'!B4:B,'
    '\'2.시간대별 전체통계\'!B4:B<>"",'
    'WEEKDAY(DATEVALUE(\'2.시간대별 전체통계\'!B4:B),2)<=5,'
    'IFERROR(MATCH(DATEVALUE(\'2.시간대별 전체통계\'!B4:B),\'★설정\'!$C$2:$C$15,0),0)=0)))'
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_a6]]},
).execute()
print("OK A6 수정 - 공휴일 명단 D → C 컬럼 참조")

# 1.일별 B6 (구분/요일) 수식도 같은 D 참조 가능성 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!B6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
b6_old = res[0][0] if res and res[0] else ""
print(f"\n현재 B6: {b6_old}")

# B6도 D를 참조하면 같은 문제. 수정
if "★설정'!D$" in b6_old or "★설정'!$D$" in b6_old:
    # D → C로 변경
    new_b6 = b6_old.replace("'★설정'!$D$", "'★설정'!$C$").replace("'★설정'!D$", "'★설정'!C$")
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range="'1.일별 전체 통계'!B6",
        valueInputOption="USER_ENTERED",
        body={"values": [[new_b6]]},
    ).execute()
    print(f"OK B6 수정 - D → C 컬럼 참조")
else:
    print("B6 수정 불필요")

time.sleep(5)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:B20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 A:B 수정 후]")
for ri, row in enumerate(res):
    if row and row[0]:
        a = row[0]
        b = row[1] if len(row) > 1 else ""
        print(f"  Row {ri+6}: A={a}, B={b}")
