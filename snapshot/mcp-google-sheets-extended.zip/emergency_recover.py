"""RAW_UserChat 시트 긴급 복구."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 새 시트 RAW_UserChat 생성
res = _sheets.spreadsheets().batchUpdate(
    spreadsheetId=NEW,
    body={"requests": [{
        "addSheet": {
            "properties": {
                "title": "RAW_UserChat",
                "gridProperties": {"rowCount": 3500, "columnCount": 100}
            }
        }
    }]}
).execute()
sid = res["replies"][0]["addSheet"]["properties"]["sheetId"]
print(f"OK 새 시트 생성 (id={sid})")

# A1에 IMPORTRANGE 전체 97열
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat!A1:CS")']]},
).execute()
print("OK IMPORTRANGE A1:CS 입력")

# IMPORTRANGE 권한 부여 자동 안 됨 - 수동으로 권한 허용 필요
# 일단 대기
time.sleep(10)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1:E3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[RAW_UserChat A1:E3]")
for row in res:
    print(f"  {row}")

# 만약 권한 필요 메시지면 IMPORTRANGE 권한이 끊긴 것
print("\n📌 만약 위 결과가 '#REF!' 또는 '액세스 허용' 표시이면:")
print("   1. 통계 시트의 RAW_UserChat 시트 직접 열기")
print("   2. A1 셀 클릭 → '액세스 허용' 버튼 클릭")
print("   3. 그러면 데이터 자동 로드됨")
