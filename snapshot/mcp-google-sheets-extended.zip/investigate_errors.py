"""오류 셀의 수식 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 오류 셀 + 주변 수식 분석
targets = [
    ("1.일별 전체 통계", "Y1:Y10"),
    ("3.상담사별 채팅 실적", "A1:K3"),
    ("4.상담사별 콜 실적", "A1:K3"),
]

for sheet_name, rng in targets:
    print(f"\n{'='*70}")
    print(f"📋 {sheet_name} {rng}")
    print("=" * 70)
    formulas = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!{rng}",
        valueRenderOption="FORMULA",
    ).execute().get("values", [])
    values = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!{rng}",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    
    for ri, row in enumerate(formulas):
        for ci, cell in enumerate(row):
            if cell:
                v = values[ri][ci] if ri < len(values) and ci < len(values[ri]) else ""
                col = chr(ord('A') + ci)
                print(f"  {col}{ri+1}: {str(cell)[:120]} → {str(v)[:30]}")
