"""RAW 55번 기술 이관 시트 외부 IMPORTRANGE 복원."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
EXTERNAL = "1-6uipG0sTwxFW30T1-rfXmcxiBsfiEYQMlmv_CFe8xk"

# Step 1: RAW 55번 기술 이관 헤더 + IMPORTRANGE
print("[1] RAW 55번 기술 이관 외부 IMPORTRANGE 복원")

# A1:H1 헤더
headers_ah = [["접수날짜", "접수시간\n(ctrl+shift+;)", "요청자", "관리번호", "주문번호", "고객명", "연락처", "인입 경로"]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A1:H1",
    valueInputOption="USER_ENTERED",
    body={"values": headers_ah},
).execute()
print("  OK A1:H1 헤더")

# A2 IMPORTRANGE - 외부 시트 행 3부터 (행 1-2는 헤더 제외)
import_formula = f'=IMPORTRANGE("{EXTERNAL}","기술 이관!A3:H")'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A2",
    valueInputOption="USER_ENTERED",
    body={"values": [[import_formula]]},
).execute()
print("  OK A2 IMPORTRANGE")

# 가공 컬럼 헤더 (I-L)
headers_il = [["날짜텍스트", "요청자한글", "기술이관", "구분"]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!I1:L1",
    valueInputOption="USER_ENTERED",
    body={"values": headers_il},
).execute()

# I2: 날짜 텍스트 (A + B 결합)
i2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,TEXT(A2:A,"YYYY-MM-DD")&" "&TEXT(B2:B,"hh:mm:ss")))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!I2",
    valueInputOption="USER_ENTERED",
    body={"values": [[i2]]},
).execute()

# J2: 요청자 한글 — ★설정 H4:H에서 매핑 시도, 없으면 그대로 표시
# 신 시스템에는 통합 H 컬럼이 있으므로 그대로 활용
j2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,IFNA(XLOOKUP(C2:C,\'★설정\'!H4:H,\'★설정\'!H4:H,"@@"&C2:C&"_미매핑"),"@@"&C2:C&"_미매핑")))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2",
    valueInputOption="USER_ENTERED",
    body={"values": [[j2]]},
).execute()

# K2: 기술이관 고정값
k2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,"기술이관"))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!K2",
    valueInputOption="USER_ENTERED",
    body={"values": [[k2]]},
).execute()

# L2: "-" 고정값 (인입 분류)
l2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,"-"))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!L2",
    valueInputOption="USER_ENTERED",
    body={"values": [[l2]]},
).execute()
print("  OK I2-L2 가공 수식")

# 헤더 서식
sid = _get_sheet_id_by_name(NEW, "RAW 55번 기술 이관")
_batch_update(NEW, [
    {"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 0, "endColumnIndex": 12},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.2, "green": 0.4, "blue": 0.6},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }},
    {"updateSheetProperties": {
        "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": 1}},
        "fields": "gridProperties.frozenRowCount"
    }},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 0, "endIndex": 1},
        "properties": {"pixelSize": 50}, "fields": "pixelSize"
    }},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 12},
        "properties": {"pixelSize": 110}, "fields": "pixelSize"
    }},
])

print("\n로딩 대기 (15초)...")
time.sleep(15)

# 검증
print("\n[검증]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A1:L5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        non_empty = [(chr(ord('A')+ci), str(c)[:25]) for ci, c in enumerate(row) if c]
        print(f"  Row {ri+1}: {non_empty[:8]}")

# 데이터 행 수
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A:A",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
non_empty = sum(1 for r in res if r and r[0])
print(f"\n총 데이터 행 수: {non_empty}")
