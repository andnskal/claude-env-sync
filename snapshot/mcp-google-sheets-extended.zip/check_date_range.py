"""5.콜 시트의 모든 날짜 분포 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# N 컬럼 (날짜)만 전체 가져오기
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N:N",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter
dates = Counter()
for row in res:
    if row and row[0] and "2026" in str(row[0]):
        dates[row[0]] += 1

print(f"총 행 수: {len(res)}")
print(f"\n날짜별 카운트:")
for d in sorted(dates.keys()):
    print(f"  {d}: {dates[d]}건")
print(f"\n총 데이터 행: {sum(dates.values())}")

# 5.콜 전체 행 수 확인
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    if s["properties"]["title"] == "5.콜 상담내역":
        rows = s["properties"]["gridProperties"].get("rowCount", 0)
        print(f"\n5.콜 시트 전체 행 수: {rows}")
        break
