"""이전 시트 6.채팅 헤더 + 모든 수식 정확 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 이전 시트 6.채팅 모든 컬럼 헤더 + 행 2 수식
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'6.채팅 상담내역'!A1:Z2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[이전 시트 6.채팅 헤더 (행 1)]")
if res:
    for ci, h in enumerate(res[0]):
        if h:
            col = chr(ord('A') + ci) if ci < 26 else 'AA'
            print(f"  {col}: {h[:40]}")

print("\n[이전 시트 6.채팅 행 2 모든 수식]")
res_f = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'6.채팅 상담내역'!A2:Z2",
    valueRenderOption="FORMULA",
).execute().get("values", [])
if res_f and res_f[0]:
    for ci, v in enumerate(res_f[0]):
        if v and str(v).startswith("="):
            col = chr(ord('A') + ci) if ci < 26 else 'AA'
            print(f"\n  {col}2: {str(v)[:300]}")
