"""1.일별 + 2.시간대별 - 누락된 병합 영역 식별."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# 1.일별 AH-AJ 영역 (콜백 처리)
print("=" * 80)
print("1.일별 AH-AJ (행 1-3)")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AG1:AT3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    for ci, v in enumerate(row):
        if v:
            print(f"  {col_letter(32+ci)}{ri+1}: {v}")

# 2.시간대별 AB-AL 영역 (OB)
print("\n" + "=" * 80)
print("2.시간대별 행 1-3 (전체)")
print("=" * 80)
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A1:AL3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[Row 1]")
for ci in range(38):
    v = res2[0][ci] if len(res2) > 0 and ci < len(res2[0]) else ""
    if v:
        print(f"  {col_letter(ci)}1: {v}")
print("\n[Row 2]")
for ci in range(38):
    v = res2[1][ci] if len(res2) > 1 and ci < len(res2[1]) else ""
    if v:
        print(f"  {col_letter(ci)}2: {v}")
print("\n[Row 3]")
for ci in range(38):
    v = res2[2][ci] if len(res2) > 2 and ci < len(res2[2]) else ""
    if v:
        print(f"  {col_letter(ci)}3: {v}")
