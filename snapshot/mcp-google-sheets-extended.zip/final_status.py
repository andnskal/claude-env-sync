"""최종 상태 확인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW_NewMeet
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1:E3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[RAW_NewMeet]")
for r in res[:3]:
    print(f"  {r}")

# 5.콜
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:Q3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[5.콜]")
for r in res[:3]:
    print(f"  {r[:5] if r else 'empty'}")

# 1.일별 5/8
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 5/8]")
for row in res:
    if row and isinstance(row[0], str) and "2026-05-08" in row[0]:
        print(f"  P (응대호): {row[15] if len(row)>15 else '?'}")
        print(f"  Q (포기호 알림제외): {row[16] if len(row)>16 else '?'}")
        print(f"  H (채널톡 답변): {row[7] if len(row)>7 else '?'}")
        print(f"  AC (OB 성공): {row[28] if len(row)>28 else '?'}")
        break
