"""이전 시트 4/30 수식 정확히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 4/30 수식 (행 27)
formulas = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!A27:AT27",
    valueRenderOption="FORMULA",
).execute().get("values", [])

print(f"행 27 수식 (총 {len(formulas[0]) if formulas and formulas[0] else 0}컬럼):")
if formulas and formulas[0]:
    labels = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N",
              "O","P","Q","R","S","T","U","V","W","X","Y","Z",
              "AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT"]
    for ci, v in enumerate(formulas[0]):
        if v and isinstance(v, str) and v.startswith("="):
            lbl = labels[ci] if ci < len(labels) else f"col{ci}"
            print(f"\n[{lbl}27]")
            print(f"  {v[:400]}")
