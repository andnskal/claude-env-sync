"""마지막 데이터 정확성 수정."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

reqs = []
sid1 = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# === Fix: AD (OB 콜백제외) 형식 PERCENT → NUMBER ===
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid1, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 29, "endColumnIndex": 30},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# === Fix: AB (OB 시도 전체) NUMBER ===
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid1, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 27, "endColumnIndex": 28},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# === Fix: AC (OB 성공) NUMBER ===
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid1, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 28, "endColumnIndex": 29},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# === Fix: AE (콜백) NUMBER ===
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid1, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 30, "endColumnIndex": 31},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# === Fix: 행5 합계의 PERCENT 컬럼 (K, R, V) — 의미 없으므로 빈 처리 ===
# K5, R5, V5에 빈 값 입력
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!K5",
    valueInputOption="RAW", body={"values": [[""]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!R5",
    valueInputOption="RAW", body={"values": [[""]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!V5",
    valueInputOption="RAW", body={"values": [[""]]},
).execute()

_batch_update(NEW, reqs)
print(f"✅ 1.일별 컬럼 형식 수정 + 합계 행 PERCENT 비활성")

# === Fix: 2.시간대별의 동일한 컬럼 (X-AA OB) NUMBER 확인 ===
sid2 = _get_sheet_id_by_name(NEW, "2.시간대별 전체통계")
reqs2 = [
    # X (OB 성공) NUMBER
    {
        "repeatCell": {
            "range": {"sheetId": sid2, "startRowIndex": 3, "endRowIndex": 600, "startColumnIndex": 23, "endColumnIndex": 25},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
            "fields": "userEnteredFormat.numberFormat",
        }
    },
    # V (콜백), W (알림톡) NUMBER
    {
        "repeatCell": {
            "range": {"sheetId": sid2, "startRowIndex": 3, "endRowIndex": 600, "startColumnIndex": 21, "endColumnIndex": 23},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "#,##0"}}},
            "fields": "userEnteredFormat.numberFormat",
        }
    },
]
_batch_update(NEW, reqs2)
print(f"✅ 2.시간대별 OB/콜백/알림톡 NUMBER 형식")

# === Fix: 1.일별 행4 평균 — Z (투입인원 시간대별합÷10) ===
# 평균 = SUM(D)/10 의 평균이라 의미 적음. 평균 그대로 유지 (각 일자 평균)

print("\n🎉 데이터 형식 정상화 완료")
