"""RAW_현시간 전화 모니터링 — 이전 시트 데이터 출처 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 이전 시트의 데이터 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW_현시간 전화 모니터링'!A1:M10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[이전 시트 RAW_현시간 전화 모니터링 - 행 1-10]")
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+1}: {row[:13]}")

# 데이터 행 수 + 시간 분포
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'RAW_현시간 전화 모니터링'!C2:C20000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
non_empty = sum(1 for r in res if r and r[0])
print(f"\n총 데이터 행: {non_empty}")
if res:
    samples = [r[0] for r in res[:5] if r and r[0]]
    print(f"startedAt 샘플: {samples}")
    
    last_samples = [r[0] for r in res[-5:] if r and r[0]]
    print(f"마지막 5개: {last_samples}")
