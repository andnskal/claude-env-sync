"""헤더 텍스트(줄바꿈) + 1.일별 평균/합계 행 + ★설정 재정렬."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ===========================================
# 1.일별 행3 헤더 텍스트 정확히 (기존 시스템과 동일)
# ===========================================
daily_row3 = [[
    "날짜 텍스트변환",  # A
    "구분",            # B
    "인입",            # C
    "답변",            # D
    "인입",            # E
    "답변",            # F
    "인입",            # G
    "답변",            # H
    "인입",            # I
    "답변",            # J
    "답변율",           # K
    "카카오+네이버+채널톡",  # L
    "기술이관",          # M
    "Total",           # N
    "접수호\n(알림톡만 제외)",       # O
    "응대호",                       # P
    "포기호\n(알림톡만 제외)",       # Q
    "응대율\n(알림톡만 제외)",       # R
    "접수호\n(기술포기호 제외)",      # S
    "응대호",                       # T
    "포기호\n(기술포기호 제외)",      # U
    "응대율\n(기술포기호 제외)",      # V
    "IB 통화시간(총)",              # W
    "IB 통화시간(건별)\n- ATT",     # X
    "IB\n투입인원\n- 단순 인원 수",  # Y
    "IB\n투입인원\n- 시간대별합 ÷ 9", # Z
    "OB부재",                      # AA
    "OB 시도 (전체)",              # AB
    "O/B 성공",                    # AC
    "OB\n(콜백제외)",              # AD
    "콜백",                        # AE
    "OB 통화시간(총)",             # AF
    "OB 통화시간\n(건별평균)",      # AG
    "상담톡 발송",                  # AH
]]

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'1.일별 전체 통계'!A3:AH3",
    valueInputOption="RAW",
    body={"values": daily_row3},
).execute()
print("✅ 1.일별 행3 헤더 텍스트 (줄바꿈 포함) 갱신")

# ===========================================
# 1.일별 행2 중분류 헤더
# ===========================================
daily_row2 = [["", "구분", "카카오", "", "네이버", "", "채널톡", "", "본사 + 도급사 합계\n(카카오+네이버+채널톡)",
               "", "", "", "", "", "IB", "", "", "", "", "", "", "", "", "", "", "", "", "", "OB",
               "", "", "", "", ""]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'1.일별 전체 통계'!A2:AH2",
    valueInputOption="RAW",
    body={"values": daily_row2},
).execute()
print("✅ 1.일별 행2 중분류 헤더 갱신")

# ===========================================
# 2.시간대별 행3 헤더 (줄바꿈 추가)
# ===========================================
hourly_row3 = [[
    "일자", "날짜 텍스트변환", "시간",
    "IB", "OB", "채팅",
    "총 접수호", "포기호", "응대율",
    "총 접수호", "포기호 \n(기술포기호제외)", "응대호", "응대율", "기술 포기호", "기술포기호 고객 인원수\n(중복 제외)\n",
    "총 접수호", "포기호", "응대호", "응대율",
    "통화시간", "평균통화시간 (건별)", "콜백 접수", "알림톡 발송 건수",
    "OB 성공", "OB실패(부재)", "통화시간", "평균 통화시간 건별",
    "인입", "답변 (본사 포함)", "답변율", "답변(인하우스+도급사)", "기여도(인하우스+도급사)",
    "인입", "답변", "인입", "답변", "인입", "답변",
]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'2.시간대별 전체통계'!A3:AL3",
    valueInputOption="RAW",
    body={"values": hourly_row3},
).execute()
print("✅ 2.시간대별 행3 헤더 갱신")

# ===========================================
# 2.시간대별 행1, 2 (대분류, 중분류)
# ===========================================
hourly_row1 = [["", "", "", "투입인원 (인하우스+도급사)", "", "", "IB (인하우스+도급사)",
                "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                "OB", "", "", "", "채팅 (ALF 제외)", "", "", "", "", "카카오", "", "네이버", "", "채널톡", ""]]
hourly_row2 = [["", "", "", "", "", "",
                "(콜백+알림톡 제외)", "", "",
                "기술 인입 제외 (+ 알림톡 제외)", "", "", "", "", "",
                "알림톡만 제외", "", "", "", "", "", "", "",
                "", "", "", "",
                "합계", "", "", "", "",
                "", "", "", "", "", ""]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'2.시간대별 전체통계'!A1:AL1",
    valueInputOption="RAW",
    body={"values": hourly_row1},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'2.시간대별 전체통계'!A2:AL2",
    valueInputOption="RAW",
    body={"values": hourly_row2},
).execute()
print("✅ 2.시간대별 행1·2 헤더 갱신")

# ===========================================
# 5.콜 헤더 (한글+영어 2줄)
# ===========================================
call_h1 = [[
    "상담 ID\nuserChatId",   # A
    "구분\ndirection",        # B
    "첫 다이얼 누른 시간\nstartedAt",      # C
    "통화 연결 성공 시간\nfirstEngagedAt", # D
    "통화종료 시간\nendedAt",              # E
    "포기호 사유\nmissedReason",            # F
    "callQueueTime(text)",   # G
    "callHoldTime(text)",    # H
    "holdCount",              # I
    "firstPostCallStartedAt", # J
    "firstPostCallEndedAt",   # K
    "callAssigneeId",         # L
    "assigneeId",             # M
    "날짜",                    # N
    "요일",                    # O
    "시간대",                  # P
    "구분",                    # Q
    "callDuration(text)",     # R
    "통화시간",               # S
    "후처리시간",             # T
    "대기시간",               # U
    "보류시간",               # V
    "상담사",                 # W
    "tags(원본)",             # X
    "콜백/알림톡 분류",        # Y
    "기술IVR부재 분류",        # Z
]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'5.콜 상담내역'!A1:Z1",
    valueInputOption="RAW",
    body={"values": call_h1},
).execute()
print("✅ 5.콜 헤더 한글+영어 2줄 갱신")

# ===========================================
# 6.채팅 헤더 (한글+영어 2줄)
# ===========================================
chat_h1 = [[
    "상담 ID\nuserChatId",  # A
    "createdAt",             # B
    "firstAskedAt",          # C
    "firstOpenedAt",         # D
    "firstAnsweredAt",       # E
    "closedAt",              # F
    "assigneeId",            # G
    "direction",             # H
    "mediumType",            # I
    "mediumName",            # J
    "tags",                  # K
    "state",                 # L
    "채널 (한글)",            # M
    "상담사",                 # N
    "날짜",                   # O
    "요일",                   # P
    "시간대",                 # Q
    "구분",                   # R
    "totalReplyTime",         # S
    "avgReplyTime",           # T
    "timeToFirstAnswer",      # U
    "timeToClose",            # V
    "인하우스구분",           # W
    "사람처리여부\n(firstOpenedAt<>\"\")",  # X
    "매니저답변여부\n(D<>\"\" AND E<>\"\")",  # Y
]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'6.채팅 상담내역'!A1:Y1",
    valueInputOption="RAW",
    body={"values": chat_h1},
).execute()
print("✅ 6.채팅 헤더 한글+영어 2줄 갱신")

# ===========================================
# ★설정 구조 재정렬 (A1 라벨 / A2 URL / A3 헤더 / A4+ 데이터)
# ===========================================
# 현재 A1:Y1 헤더, A2:Y2+ 데이터인 상태를 → A1=라벨, A2=URL, A3=헤더, A4+=데이터로 변경
# 1) 기존 데이터 백업
existing = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!A1:Y20",
).execute().get("values", [])
print(f"  ★설정 기존 데이터 {len(existing)}행 백업")

# 2) 시트 클리어
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'★설정'!A1:Z200", body={}
).execute()

# 3) 새 구조로 작성
new_settings = [
    ["RAW 업데이트용 시트 주소"],  # A1
    ["https://docs.google.com/spreadsheets/d/10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8/edit",
     "", "", "", "", "", "", "", "", "신규 입사자 발생 시 아래에 누적"],  # A2
    # 헤더 (A3)
    ["시트명", "업무시간", "공휴일 (입력)", "비고", "날짜 텍스트변환",
     "매니저 아이디텍스트변환", "매니저 아이디", "담당자",
     "",
     "인하우스 CS ID", "인하우스 CS 이름",
     "인하우스 기술 ID", "인하우스 기술 이름",
     "도급사 CS ID", "도급사 CS 이름",
     "", "", "", "",
     "운영시간(1분)", "운영여부",
     "", "",
     "인하우스 명단 (CS+기술)", "도급사 명단 (추후 활성)"],
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'★설정'!A1:Y3",
    valueInputOption="USER_ENTERED",
    body={"values": new_settings},
).execute()

# 4) 데이터 행 재작성 (A4+) - 기존 데이터 매핑
# 기존: A1행 헤더, A2-A16 데이터
# 신: A4-A18 데이터 (15명 매니저)
# B 업무시간 (B2=9:00, B3=17:30) → B4=9:00, B5=17:30 별도
# C 점심시간 (C2=12:50, C3=14:00) → 별도 처리
# D-E 공휴일 → 그대로
# F-L 매니저 매핑 → 그대로

# 데이터를 다시 입력
sheet_names_data = [
    ["UserChatCase", "9:00", "2026-05-01", "근로자의 날", "2026-05-01"],
    ["UserChat meet data", "17:30", "2026-05-05", "어린이날 (대체)", "2026-05-05"],
    ["", "(점심)", "2026-05-25", "부처님 오신 날", "2026-05-25"],
    ["", "12:50", "2026-06-06", "현충일", "2026-06-06"],
    ["", "14:00", "2026-08-15", "광복절", "2026-08-15"],
    ["", "", "2026-09-24", "추석", "2026-09-24"],
    ["", "", "2026-09-25", "추석", "2026-09-25"],
    ["", "", "2026-09-26", "추석", "2026-09-26"],
    ["", "", "2026-10-03", "개천절", "2026-10-03"],
    ["", "", "2026-10-05", "추석 대체", "2026-10-05"],
    ["", "", "2026-10-09", "한글날", "2026-10-09"],
    ["", "", "2026-12-25", "크리스마스", "2026-12-25"],
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'★설정'!A4:E15",
    valueInputOption="USER_ENTERED",
    body={"values": sheet_names_data},
).execute()

# F-L 매니저 매핑 (15명)
managers = [
    ["492537", "492537", "김진향(기술)", "", "", "", "492537", "김진향(기술)", "", ""],
    ["540982", "540982", "윤준규(기술)", "", "", "", "540982", "윤준규(기술)", "", ""],
    ["557415", "557415", "최종수(CS)", "", "557415", "최종수(CS)", "", "", "", ""],
    ["620022", "620022", "김지은(CS)", "", "620022", "김지은(CS)", "", "", "", ""],
    ["623467", "623467", "한송희(기술)", "", "", "", "623467", "한송희(기술)", "", ""],
    ["629462", "629462", "정현호(CS)", "", "629462", "정현호(CS)", "", "", "", ""],
    ["631540", "631540", "지상호(CS)", "", "631540", "지상호(CS)", "", "", "", ""],
    ["631655", "631655", "박슬기(CS)", "", "631655", "박슬기(CS)", "", "", "", ""],
    ["631668", "631668", "한승연(CS)", "", "631668", "한승연(CS)", "", "", "", ""],
    ["633677", "633677", "이윤애(CS)", "", "633677", "이윤애(CS)", "", "", "", ""],
    ["631394", "631394", "CS쉐어링_안준모", "", "", "", "", "", "631394", "CS쉐어링_안준모"],
    ["589223", "589223", "CS쉐어링_김혜림", "", "", "", "", "", "589223", "CS쉐어링_김혜림"],
    ["601163", "601163", "CS쉐어링_이혜미", "", "", "", "", "", "601163", "CS쉐어링_이혜미"],
    ["617407", "617407", "CS쉐어링_신화영", "", "", "", "", "", "617407", "CS쉐어링_신화영"],
    ["621571", "621571", "CS쉐어링_천승현", "", "", "", "", "", "621571", "CS쉐어링_천승현"],
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'★설정'!F4:O18",
    valueInputOption="USER_ENTERED",
    body={"values": managers},
).execute()

# T 운영시간 1분 시계열 (사용자가 별도 채울 수 있음)
print("✅ ★설정 구조 재정렬 완료 (A1 라벨 / A2 URL / A3 헤더 / A4+ 데이터)")

print("\n🎉 모든 텍스트/구조 정리 완료")
