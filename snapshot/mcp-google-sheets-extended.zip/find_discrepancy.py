"""4/30 차이 3건 원인 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 4/30 운영시간 내 IB_포기호 (알림 제외) 모두
print("=" * 80)
print("4/30 운영시간 내 IB_포기호 (알림제외) — 시간대 분포")
print("=" * 80)
from collections import Counter
ib_aban_by_hour = Counter()
ob_succ_by_hour = Counter()
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        AD = row[29] if len(row) > 29 else ""
        AC = row[28] if len(row) > 28 else ""
        time_band = row[15] if len(row) > 15 else ""  # P 컬럼 인덱스 = 15
        if N == "2026-04-30" and AD == "내":
            if Q == "IB_포기호" and Y != "알림톡발송":
                ib_aban_by_hour[time_band] += 1
            elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
                ob_succ_by_hour[time_band] += 1

# 시간대 09-10 ~ 18-19에 안 들어가는 시간대 식별
hourly_range = ["09-10", "10-11", "11-12", "12-13", "13-14", "14-15", "15-16", "16-17", "17-18", "18-19"]

print("\n[IB_포기호 (알림제외) 시간대 분포]")
total_in_range = 0
total_out_range = 0
for tb in sorted(ib_aban_by_hour.keys()):
    cnt = ib_aban_by_hour[tb]
    in_hourly = tb in hourly_range
    print(f"  {tb}: {cnt}건 {'✅' if in_hourly else '❌ 시간대별 외!'}")
    if in_hourly:
        total_in_range += cnt
    else:
        total_out_range += cnt
print(f"\n  → 시간대별 (09-19) 내: {total_in_range}건")
print(f"  → 시간대별 외 (운영시간 내 분류이지만 09 미만 또는 19 이상): {total_out_range}건")
print(f"  → 합계: {total_in_range + total_out_range}건 (직접 카운트와 일치)")
print(f"  → 1.일별은 시간대별 (09-19) 합 = {total_in_range}건 (3건 차이 원인)")

print("\n[OB_성공 시간대 분포]")
total_in_range_ob = 0
total_out_range_ob = 0
for tb in sorted(ob_succ_by_hour.keys()):
    cnt = ob_succ_by_hour[tb]
    in_hourly = tb in hourly_range
    print(f"  {tb}: {cnt}건 {'✅' if in_hourly else '❌ 시간대별 외!'}")
    if in_hourly:
        total_in_range_ob += cnt
    else:
        total_out_range_ob += cnt
print(f"\n  → 시간대별 합: {total_in_range_ob}건 / 직접 합: {total_in_range_ob + total_out_range_ob}건")
