"""5.콜 / 6.채팅에 운영시간 분류 컬럼 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 AD 컬럼 = 운영시간 분류
# X = tags 원본, "운영시간아님" 포함 시 "외", 아니면 "내"
print("=" * 70)
print("1️⃣ 5.콜 AD 컬럼 추가 — 운영시간 분류")
print("=" * 70)

# AD1 헤더
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD1",
    valueInputOption="USER_ENTERED",
    body={"values": [["운영시간 분류"]]},
).execute()

# AD2 ARRAYFORMULA
ad_formula = (
    '=ARRAYFORMULA(IF(N2:N="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",X2:X)),"외","내")))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2",
    valueInputOption="USER_ENTERED",
    body={"values": [[ad_formula]]},
).execute()
print("✅ 5.콜 AD2: 운영시간 분류 (내/외)")

# 6.채팅 Z 컬럼 추가
print("\n" + "=" * 70)
print("2️⃣ 6.채팅 Z 컬럼 추가 — 운영시간 분류")
print("=" * 70)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z1",
    valueInputOption="USER_ENTERED",
    body={"values": [["운영시간 분류"]]},
).execute()
chat_op_formula = (
    '=ARRAYFORMULA(IF(O2:O="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",K2:K)),"외","내")))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z2",
    valueInputOption="USER_ENTERED",
    body={"values": [[chat_op_formula]]},
).execute()
print("✅ 6.채팅 Z2: 운영시간 분류 (내/외)")

time.sleep(3)

# 검증
print("\n" + "=" * 70)
print("3️⃣ 결과 검증")
print("=" * 70)

# 5.콜 AD 분포
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
counts = Counter(r[0] for r in res if r and r[0])
print(f"\n[5.콜 AD 분포]")
for k, v in counts.most_common():
    print(f"  {k}: {v}건")

# 6.채팅 Z 분포
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
counts2 = Counter(r[0] for r in res2 if r and r[0])
print(f"\n[6.채팅 Z 분포]")
for k, v in counts2.most_common():
    print(f"  {k}: {v}건")

# 5/8 운영시간외 IB_포기호 카운트 (참고용)
print("\n[5.콜 5/8 운영시간 분류 × IB_포기호 (알림톡 제외)]")
all_5col = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
in_aban = out_aban = 0
for row in all_5col:
    if len(row) > 16 and row[0] == "2026-05-08" and row[3] == "IB_포기호":
        Y = row[11] if len(row) > 11 else ""
        if Y == "알림톡발송": continue
        AD = row[16] if len(row) > 16 else ""
        if AD == "내": in_aban += 1
        elif AD == "외": out_aban += 1
print(f"  운영시간 내 IB_포기호 (알림톡제외): {in_aban}")
print(f"  운영시간 외 IB_포기호 (알림톡제외): {out_aban}")
print(f"  합계: {in_aban + out_aban}")
