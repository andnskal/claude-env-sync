"""더 깊은 종합 점검."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

issues = []

# ============================================================
# 1. 모든 BYROW/MAP 수식의 범위 점검 (A:A vs A:A100 vs A:A1000)
# ============================================================
print("=" * 100)
print("[1] BYROW/MAP 범위 점검 (자동 확장 vs 한정)")
print("=" * 100)

# 1.일별 모든 행 6 수식 다 가져오기
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])

if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(ci)
            # 범위 패턴 찾기
            import re
            # A6:A100 또는 A6:A 식별
            patterns_limited = re.findall(r"A6:A(\d+)", v)
            patterns_open = re.findall(r"A6:A(?!\d)", v)
            if patterns_limited:
                issues.append(f"[1] 1.일별 {col}6: A6:A{patterns_limited[0]} (한정)")
                print(f"  ⚠️ {col}6: A6:A{patterns_limited[0]} (한정)")

# 2.시간대별
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:AL4",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])

if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(ci)
            import re
            patterns_limited = re.findall(r"B4:B(\d+)", v)
            if patterns_limited:
                issues.append(f"[1] 2.시간대별 {col}4: B4:B{patterns_limited[0]} (한정)")
                print(f"  ⚠️ 2.시간대별 {col}4: B4:B{patterns_limited[0]}")

# ============================================================
# 2. 모든 비율 셀의 분모 0 처리
# ============================================================
print("\n[2] 분모 0 처리 (DIV/0 안전)")
# 1.일별 비율 컬럼들
ratio_cells = [
    ("1.일별 전체 통계", "K6", "K (답변율)"),
    ("1.일별 전체 통계", "R6", "R (응대율)"),
    ("1.일별 전체 통계", "V6", "V (응대율2)"),
    ("1.일별 전체 통계", "AJ6", "AJ (콜백처리율)"),
    ("1.일별 전체 통계", "AK6", "AK (서비스레벨)"),
    ("1.일별 전체 통계", "AL6", "AL (응답속도)"),
    ("1.일별 전체 통계", "X6", "X (IB ATT)"),
    ("1.일별 전체 통계", "AG6", "AG (OB ATT)"),
    ("1.일별 전체 통계", "AM6", "AM (평균통화)"),
    ("2.시간대별 전체통계", "I4", "I 응대율"),
    ("2.시간대별 전체통계", "M4", "M 응대율"),
    ("2.시간대별 전체통계", "S4", "S 응대율"),
    ("2.시간대별 전체통계", "AA4", "AA OB ATT"),
    ("2.시간대별 전체통계", "AD4", "AD 응답률"),
    ("2.시간대별 전체통계", "AF4", "AF 기여도"),
    ("2.시간대별 전체통계", "U4", "U IB ATT"),
]
for sheet, cell, label in ratio_cells:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{cell}",
        valueRenderOption="FORMULA",
    ).execute().get("values", [[]])
    if res and res[0]:
        f = res[0][0]
        # IFERROR 또는 IF(...=0,,...) 패턴 확인
        has_safety = "IFERROR" in f or "=0,," in f or "=0,," in f or "/IF(" in f
        if not has_safety:
            issues.append(f"[2] {sheet}!{cell} ({label}): 분모 0 보호 없음")
            print(f"  ⚠️ {sheet}!{cell} ({label}): 분모 0 보호 없음")
        else:
            print(f"  ✅ {sheet}!{cell} ({label})")

# ============================================================
# 3. 5.콜 / 6.채팅 데이터 행 수와 _RAW 일관성
# ============================================================
print("\n[3] 5.콜/6.채팅 vs _RAW 데이터 일관성")
for src, raw in [("5.콜 상담내역", "_RAW_NewMeet_33"), ("6.채팅 상담내역", "_RAW_UserChat_p1")]:
    src_data = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{src}'!A:A",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    raw_data = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{raw}'!A:A",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    src_count = sum(1 for r in src_data if r and r[0])
    raw_count = sum(1 for r in raw_data if r and r[0])
    print(f"  {src}: {src_count}행, {raw}: {raw_count}행")
    if abs(src_count - raw_count) > 10:
        issues.append(f"[3] {src} ({src_count}) vs {raw} ({raw_count}) 차이 큼")

# ============================================================
# 4. ★설정 V/W (appkakao/카카오), X/Y (appnavertalk/네이버) 매핑 활용
# ============================================================
print("\n[4] ★설정 V-Y 채널 매핑 활용")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!V1:Y10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if res:
    print(f"  매핑 데이터: {res[1] if len(res) > 1 else '없음'}")
# 6.채팅 M (채널 한글) 수식이 ★설정 매핑 사용?
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!M2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
if res and res[0]:
    m_formula = res[0][0]
    if "★설정" not in str(m_formula):
        print(f"  ⚠️ 6.채팅 M (채널 한글) 수식이 ★설정 매핑 미참조")
        print(f"     M2: {str(m_formula)[:200]}")

# ============================================================
# 5. 모든 시트 헤더 정렬 + 폰트 일관성
# ============================================================
print("\n[5] 헤더 정렬 + 폰트 일관성")
for sheet, header_rows in [
    ("1.일별 전체 통계", [(0, 50)]),
    ("2.시간대별 전체통계", [(0, 38)]),
    ("3.상담사별 채팅 실적", [(0, 56)]),
    ("4.상담사별 콜 실적", [(0, 39)]),
    ("5.콜 상담내역", [(0, 32)]),
    ("6.채팅 상담내역", [(0, 26)]),
    ("★설정", [(0, 25)]),
    ("1분 단위 포기호, 통화상세", [(0, 22)]),
    ("5분 단위 포기호, 통화상세", [(0, 22)]),
    ("RAW시간대별 포기호, 통화상세", [(0, 32)]),
]:
    fmt = _sheets.spreadsheets().get(
        spreadsheetId=NEW, ranges=[f"'{sheet}'!A1:{col_letter(header_rows[0][1]-1)}1"],
        includeGridData=True,
        fields="sheets(data(rowData(values(userEnteredFormat))))"
    ).execute()
    rows = fmt["sheets"][0]["data"][0].get("rowData", [])
    if rows and "values" in rows[0]:
        bg_colors = set()
        for cell in rows[0]["values"]:
            bg = cell.get("userEnteredFormat", {}).get("backgroundColor", {})
            if bg:
                bg_colors.add(f"rgb({bg.get('red',0):.2f},{bg.get('green',0):.2f},{bg.get('blue',0):.2f})")
        if not bg_colors:
            issues.append(f"[5] {sheet}: 헤더 배경색 없음")
            print(f"  ⚠️ {sheet}: 헤더 배경색 미적용")
        else:
            print(f"  ✅ {sheet}: 배경색 {len(bg_colors)}종류")

# ============================================================
# 6. 모든 시트 행 1 freeze
# ============================================================
print("\n[6] 헤더 행 freeze")
for s in meta if False else _sheets.spreadsheets().get(spreadsheetId=NEW).execute().get("sheets", []):
    p = s["properties"]
    name = p["title"]
    fr = p.get("gridProperties", {}).get("frozenRowCount", 0)
    fc = p.get("gridProperties", {}).get("frozenColumnCount", 0)
    if fr == 0 and name not in ["★설정"]:
        issues.append(f"[6] {name}: 행 freeze 없음")
        print(f"  ⚠️ {name}: 행 freeze 0")
    else:
        print(f"  ✅ {name}: 행 freeze {fr}, 컬럼 freeze {fc}")

# ============================================================
# 결과 종합
# ============================================================
print("\n" + "=" * 100)
print(f"이번 점검 발견 이슈: {len(issues)}개")
print("=" * 100)
for i, iss in enumerate(issues, 1):
    print(f"  {i}. {iss}")
