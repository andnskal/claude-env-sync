"""가이드 시트 서식 적용."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"
sid = _get_sheet_id_by_name(RAW, "📌 사용 가이드")

reqs = []

# 큰 제목 병합 + 진한 배경
reqs.append({
    "mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 1, "endColumnIndex": 6},
        "mergeType": "MERGE_ALL"
    }
})
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 1, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.13, "green": 0.27, "blue": 0.45},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 18},
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
    }
})
reqs.append({
    "updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 0, "endIndex": 1},
        "properties": {"pixelSize": 50}, "fields": "pixelSize"
    }
})

# 섹션 헤더 (1-indexed: 3, 6, 19, 26, 33, 40, 48, 53)
section_rows_0 = [2, 5, 18, 25, 32, 39, 47, 52]
for sr in section_rows_0:
    reqs.append({
        "mergeCells": {
            "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 6},
            "mergeType": "MERGE_ALL"
        }
    })
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 6},
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 0.20, "green": 0.45, "blue": 0.65},
                "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 13},
                "horizontalAlignment": "LEFT",
                "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
        }
    })
    reqs.append({
        "updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": sr, "endIndex": sr+1},
            "properties": {"pixelSize": 35}, "fields": "pixelSize"
        }
    })

# 표 헤더 행 (1-indexed: 7, 21, 28, 42, 50)
table_header_0 = [6, 20, 27, 41, 49]
for sr in table_header_0:
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 6},
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 0.85, "green": 0.85, "blue": 0.85},
                "textFormat": {"bold": True, "fontSize": 10},
                "horizontalAlignment": "CENTER",
                "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
        }
    })

# 일반 데이터 영역 폰트
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 60, "startColumnIndex": 1, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "textFormat": {"fontSize": 10},
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(textFormat,verticalAlignment,wrapStrategy)"
    }
})

# 한 줄 요약 박스 (행 4 = index 3)
reqs.append({
    "mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 4, "startColumnIndex": 4, "endColumnIndex": 6},
        "mergeType": "MERGE_ALL"
    }
})
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 4, "startColumnIndex": 4, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 1.0, "green": 0.95, "blue": 0.7},
            "textFormat": {"bold": True, "fontSize": 11},
            "horizontalAlignment": "LEFT",
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }
})
reqs.append({
    "updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 3, "endIndex": 4},
        "properties": {"pixelSize": 70}, "fields": "pixelSize"
    }
})

# 데이터 표 영역들
data_ranges = [
    (7, 14),   # 시트 구성 (행 8-15)
    (21, 24),  # 단계 (행 22-25)
    (28, 30),  # 연결 (행 29-31)
    (33, 37),  # 주의사항 (행 34-38)
    (42, 45),  # 문제 (행 43-46)
    (50, 51),  # 변경이력 (행 51-52)
]
for sr, er in data_ranges:
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": er+1, "startColumnIndex": 1, "endColumnIndex": 6},
            "cell": {"userEnteredFormat": {
                "borders": {
                    "top": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                    "bottom": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                    "left": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                    "right": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                }
            }},
            "fields": "userEnteredFormat.borders"
        }
    })
    reqs.append({
        "updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": sr, "endIndex": er+1},
            "properties": {"pixelSize": 40}, "fields": "pixelSize"
        }
    })

# 임원 보고 한 줄 (행 49 = index 48)
reqs.append({
    "mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": 48, "endRowIndex": 49, "startColumnIndex": 4, "endColumnIndex": 6},
        "mergeType": "MERGE_ALL"
    }
})
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 48, "endRowIndex": 49, "startColumnIndex": 4, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
            "textFormat": {"bold": True, "fontSize": 11},
            "horizontalAlignment": "LEFT",
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }
})
reqs.append({
    "updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 48, "endIndex": 49},
        "properties": {"pixelSize": 80}, "fields": "pixelSize"
    }
})

# 시트 freeze + 격자 숨기기 + 첫 번째 위치 이동
reqs.append({
    "updateSheetProperties": {
        "properties": {"sheetId": sid,
                       "gridProperties": {"hideGridlines": True, "frozenRowCount": 1},
                       "index": 0},
        "fields": "gridProperties.hideGridlines,gridProperties.frozenRowCount,index"
    }
})

_batch_update(RAW, reqs)
print("OK 서식 적용 완료")
