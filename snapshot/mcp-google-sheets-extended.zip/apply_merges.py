"""누락된 병합 적용 + 3,4 시트 일자 그룹 시각적 구분."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 1.일별 AI1:AJ1 병합 (콜백 처리 그룹)
sid_daily = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")
reqs = []
reqs.append({
    "mergeCells": {
        "range": {"sheetId": sid_daily, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 34, "endColumnIndex": 36},
        "mergeType": "MERGE_ALL"
    }
})
# AH1:AH2 (상담톡 발송) 병합 - 상위 그룹 없으니 상위행 빈 값
# 근데 AH는 어느 그룹인가? 검토 필요. 일단 패스.

# 2) 1.일별 행 1-3 의 비어있는 셀들을 깔끔하게 처리
# 레거시 패턴: 그룹 헤더 (행 1), 세부 헤더 (행 2-3)
# 빈 셀은 위 셀 상속 (이미 병합으로 처리됨)

# A1:A3 병합 (날짜 헤더)
reqs.append({
    "mergeCells": {
        "range": {"sheetId": sid_daily, "startRowIndex": 0, "endRowIndex": 3, "startColumnIndex": 0, "endColumnIndex": 1},
        "mergeType": "MERGE_ALL"
    }
})

# B1:B2 병합 (구분 헤더)는 이미 B2:B3 병합됨. B1만 비어있으면 그대로 둠.

_batch_update(NEW, reqs)
print("✅ 1.일별: AI1:AJ1, A1:A3 병합")

# 검증
import time; time.sleep(2)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A1:AT3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 그룹 헤더만 출력
print("\n[1.일별 헤더 상태]")
print("Row 1 그룹 헤더:", [v for v in res[0] if v] if res else [])
print("Row 2 세부:", [v[:15] for v in res[1] if v] if len(res) > 1 else [])
