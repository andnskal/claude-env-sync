"""V열 구조 정리 - V3 클리어 (사용자 입력 셀)."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1분단위: V2 = 헤더, V3 = 사용자 입력 (비움)
# V3 클리어
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V3",
).execute()

# V2에 안내 텍스트 (헤더)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V2",
    valueInputOption="USER_ENTERED",
    body={"values": [["통화 외 시간(h) — 상담사 선택 ↓"]]},
).execute()
print("✅ 1분단위 V2 안내, V3 비움")

# 5분단위 동일
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!V3",
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!V2",
    valueInputOption="USER_ENTERED",
    body={"values": [["통화 외 시간(h) — 상담사 선택 ↓"]]},
).execute()
print("✅ 5분단위 V2 안내, V3 비움")

# V3에 테스트 값 입력하여 검증
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V3",
    valueInputOption="USER_ENTERED",
    body={"values": [["기술_김진향"]]},
).execute()
time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V1:V4",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[1분단위 V1:V4 (V3=기술_김진향 테스트)]: {res}")

# V3 비움
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V3",
).execute()
print("✅ V3 비워 사용자 입력 대기 상태")
