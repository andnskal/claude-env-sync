"""최종 그룹화 - depth 차별화로 분리 시도."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 기존 그룹 모두 삭제 (반복적)
print("[기존 그룹 모두 삭제]")
for attempt in range(15):
    meta = _sheets.spreadsheets().get(
        spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
    ).execute()
    found_groups = []
    for s in meta.get("sheets", []):
        if s["properties"]["sheetId"] == sid:
            found_groups = s.get("columnGroups", [])
            break
    if not found_groups:
        print(f"  완료 ({attempt}회)")
        break
    g = sorted(found_groups, key=lambda x: -x.get("depth", 1))[0]
    r = g["range"]
    try:
        _batch_update(NEW, [{
            "deleteDimensionGroup": {
                "range": {
                    "sheetId": sid, "dimension": "COLUMNS",
                    "startIndex": r.get("startIndex", 0),
                    "endIndex": r.get("endIndex", 0),
                }
            }
        }])
        time.sleep(1)
    except Exception as e:
        print(f"  ⚠️ {e}")
        break
time.sleep(3)

# 핵심 트릭: 외부 그룹 만든 후 내부 그룹 추가하면 depth 자동 증가
# C-AW (depth 1) → 내부: 카테고리별 (depth 2) — 같은 depth라도 분리 유지될지 확인
# 다른 시도: outer 없이 같은 범위 두번 추가하여 depth 증가시키기
print("\n[새 그룹 적용 - 트릭 사용]")

# 시도: 큰 그룹부터 → 카테고리별 (이미 큰 그룹 안에 nested되면 분리 유지)
# Step 1: C-AW (외부)
_batch_update(NEW, [{
    "addDimensionGroup": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 49}
    }
}])
time.sleep(1)
print("  외부 그룹 C-AW (depth 1) 추가")

# Step 2: 각 카테고리를 외부 그룹 안에 → depth 2가 되고 별도 control point
groups = [
    (2, 14, "채팅"),       # C-N
    (14, 26, "IB"),        # O-Z
    (26, 34, "OB"),        # AA-AH
    (34, 36, "콜백"),       # AI-AJ
    (36, 39, "KPI"),       # AK-AM
    (39, 46, "부재중"),     # AN-AT
    (46, 49, "참고"),       # AU-AW
]
for start, end, label in groups:
    _batch_update(NEW, [{
        "addDimensionGroup": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": start, "endIndex": end}
        }
    }])
    time.sleep(0.8)
    print(f"  {label} ({start}-{end-1}) 추가")

time.sleep(3)

# 결과 확인
print("\n[최종]")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
).execute()
def cl(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        groups_now = s.get("columnGroups", [])
        print(f"  그룹 {len(groups_now)}개:")
        for g in sorted(groups_now, key=lambda x: (x.get("depth", 0), x["range"].get("startIndex", 0))):
            r = g["range"]
            print(f"    depth {g.get('depth',0)}: {cl(r['startIndex'])}-{cl(r['endIndex']-1)}")
        break
