"""R 분류 수식 정확하게 수정."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# REGEXMATCH 사용 - 더 정확하고 가독성 좋음
new_r = (
    '=ARRAYFORMULA(IF(ISBLANK(C2:C),,'
    'IF(LEFT(J2:J,2)="@@", "미매핑",'
    'IF(REGEXMATCH(J2:J,"^(TCK|CS쉐어링)_"),'
    'IF(H2:H="채팅","외주_채팅","외주_비채팅"),'
    'IF(H2:H="채팅","본사_채팅","본사_비채팅")))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!R2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_r]]},
).execute()
print("OK R2 수식 정정 (REGEXMATCH)")
time.sleep(8)

# 재검증
raw55 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:R10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

mismatch = 0
from collections import Counter
r_actual = Counter()
for row in raw55:
    if len(row) < 11: continue
    H = row[0]
    J = row[2] if len(row) > 2 else ""
    R = row[10] if len(row) > 10 else ""
    r_actual[R] += 1

    if J.startswith("@@"):
        expected = "미매핑"
    elif J.startswith("TCK_") or J.startswith("CS쉐어링"):
        expected = "외주_채팅" if H == "채팅" else "외주_비채팅"
    else:
        expected = "본사_채팅" if H == "채팅" else "본사_비채팅"

    if R != expected:
        mismatch += 1

print(f"\n불일치: {mismatch}건")
print(f"\n새 분포:")
for k, v in r_actual.most_common():
    print(f"  {k}: {v}건")

# 1.일별 M 재검증
print("\n[1.일별 M 재검증]")
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:M30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        date = row[0]
        H = row[7] if len(row) > 7 else "?"
        L = row[11] if len(row) > 11 else "?"
        M = row[12] if len(row) > 12 else "?"
        print(f"  {date}: H={H}, L={L}, M={M}")
