"""보조 시트 3개 이름 변경 + 수식 자동 업데이트 확인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 변경 전 — 어디서 참조되는지 확인
print("=" * 80)
print("[참조 검색] 변경 전 어떤 시트에서 참조 중?")
print("=" * 80)

# 모든 시트의 모든 셀에서 _RAW_ 참조 찾기
import re
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
ref_count = {"_RAW_UserChat_p1": 0, "_RAW_UserChat_p2": 0, "_RAW_NewMeet_33": 0}
ref_sheets = {"_RAW_UserChat_p1": [], "_RAW_UserChat_p2": [], "_RAW_NewMeet_33": []}

for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    if name.startswith("_RAW_") or name == "📌 사용 가이드":
        continue
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0: continue
    
    def cl(idx):
        s, n = "", idx + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(ord("A") + r) + s
        return s
    
    rng = f"'{name}'!A1:{cl(cols-1)}{rows}"
    try:
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        for ri, row in enumerate(formulas):
            for ci, v in enumerate(row):
                if v and isinstance(v, str):
                    for old in ref_count.keys():
                        if old in v:
                            ref_count[old] += 1
                            if len(ref_sheets[old]) < 3:
                                ref_sheets[old].append(f"{name}!{cl(ci)}{ri+1}")
    except: continue

for old, cnt in ref_count.items():
    print(f"  {old}: {cnt}회 참조 (예: {ref_sheets[old][:3]})")

# 2) 시트 이름 변경
print("\n" + "=" * 80)
print("[이름 변경]")
print("=" * 80)

renames = [
    ("_RAW_UserChat_p1", "_보조 채팅 A"),
    ("_RAW_UserChat_p2", "_보조 채팅 B"),
    ("_RAW_NewMeet_33", "_보조 콜"),
]

reqs = []
for old, new in renames:
    sid = _get_sheet_id_by_name(NEW, old)
    reqs.append({
        "updateSheetProperties": {
            "properties": {"sheetId": sid, "title": new},
            "fields": "title"
        }
    })
    print(f"  {old} → {new}")

_batch_update(NEW, reqs)
time.sleep(3)

# 3) 변경 후 자동 수식 업데이트 확인
print("\n" + "=" * 80)
print("[수식 자동 업데이트 확인]")
print("=" * 80)

# 다시 검색
new_names = [n for _, n in renames]
old_names = [o for o, _ in renames]
new_count = {n: 0 for n in new_names}
remain_old = {o: 0 for o in old_names}

meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    if name.startswith("_보조") or name == "📌 사용 가이드":
        continue
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0: continue
    def cl(idx):
        s, n = "", idx + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(ord("A") + r) + s
        return s
    rng = f"'{name}'!A1:{cl(cols-1)}{rows}"
    try:
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        for row in formulas:
            for v in row:
                if v and isinstance(v, str):
                    for new in new_names:
                        if new in v:
                            new_count[new] += 1
                    for old in old_names:
                        if old in v:
                            remain_old[old] += 1
    except: continue

print("\n새 이름으로 자동 변경된 참조:")
for n, c in new_count.items():
    print(f"  {n}: {c}회")
print("\n옛 이름이 남아있는 참조 (수동 수정 필요):")
for o, c in remain_old.items():
    if c > 0:
        print(f"  ⚠️ {o}: {c}회 (수동 수정 필요)")
    else:
        print(f"  ✅ {o}: 0회 (정상)")
