"""이윤애 16건 vs 채널톡 15건 차이 원인 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 5/8 CS_이윤애 IB_성공 모든 컬럼 가져오기
all_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("=" * 100)
print("이윤애 5/8 IB_성공 16건 — 상세 분석 (각 콜의 분류 정보)")
print("=" * 100)
print(f"{'시작시각':>20} | {'X (tags)':>30} | {'Y (콜백/알림)':>10} | {'Z (기술)':>15} | {'AC':>15} | {'AD':>5}")
print("-" * 100)

cnt = 0
for row in all_data:
    if len(row) < 30: continue
    N = row[13]
    Q = row[16]
    W = row[22]
    if N != "2026-05-08" or W != "CS_이윤애" or Q != "IB_성공": continue
    
    C = row[2]   # startedAt
    X = row[23]  # tags
    Y = row[24]  # 콜백/알림톡
    Z = row[25]  # 기술IVR
    AC = row[28] # 인하우스
    AD = row[29] # 운영시간
    
    cnt += 1
    print(f"{C:>20} | {str(X)[:30]:>30} | {str(Y):>10} | {str(Z)[:15]:>15} | {str(AC)[:15]:>15} | {AD:>5}")

print(f"\n총 {cnt}건")

# 가능한 차이 원인 카운트
print("\n" + "=" * 100)
print("가능한 차이 원인 분석")
print("=" * 100)

# 시나리오 1: 채널톡이 X 태그 "운영시간아님" 포함을 제외
exclude_off = 0
# 시나리오 2: 채널톡이 알림톡발송 포함을 제외
exclude_alert = 0
# 시나리오 3: 채널톡이 콜백 인입을 별도 분류
exclude_callback = 0
# 시나리오 4: 채널톡이 기술포기호 제외 (이윤애와 무관)
exclude_tech = 0

for row in all_data:
    if len(row) < 30: continue
    N = row[13]; Q = row[16]; W = row[22]
    if N != "2026-05-08" or W != "CS_이윤애" or Q != "IB_성공": continue
    
    X = row[23] if len(row) > 23 else ""
    Y = row[24] if len(row) > 24 else ""
    Z = row[25] if len(row) > 25 else ""
    
    if "운영시간아님" in str(X): exclude_off += 1
    if Y == "알림톡발송": exclude_alert += 1
    if Y == "콜백": exclude_callback += 1
    if Z == "기술부재포기호": exclude_tech += 1

print(f"  운영시간아님 태그: {exclude_off}건")
print(f"  알림톡발송: {exclude_alert}건")
print(f"  콜백 분류: {exclude_callback}건")
print(f"  기술부재포기호: {exclude_tech}건")

# 추가: 채널톡의 매니저 ID 매핑 확인
print("\n" + "=" * 100)
print("채널톡 매니저 ID 매핑 확인 (★설정)")
print("=" * 100)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!F4:H50",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for row in res:
    if row and len(row) > 2 and "이윤애" in str(row[2]):
        print(f"  매니저 ID: {row[0]}, 담당자: {row[2]}")

# 5.콜의 L 컬럼 (callAssigneeId) 분포
print("\n" + "=" * 100)
print("5/8 이윤애 callAssigneeId 분포")
print("=" * 100)
for row in all_data:
    if len(row) < 23: continue
    N = row[13]; Q = row[16]; W = row[22]
    if N != "2026-05-08" or W != "CS_이윤애" or Q != "IB_성공": continue
    L = row[11] if len(row) > 11 else ""
    M = row[12] if len(row) > 12 else ""
    print(f"  L (callAssigneeId): {L}, M (정제): {M}")
