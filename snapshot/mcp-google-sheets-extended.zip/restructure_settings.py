"""★설정 시트 이전 시트 구조처럼 깔끔하게 재정렬."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _hex_to_rgb_dict, _get_sheet_id_by_name, _batch_update

NEW = '1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU'

# ============================================================
# Step 1: ★설정 클리어 + 재정렬
# ============================================================
_sheets.spreadsheets().values().clear(spreadsheetId=NEW, range="'★설정'!A1:Z200", body={}).execute()

# 행1 헤더 (이전 시트 패턴 + 신 시스템 추가)
header = [
    "RAW 시트 주소",                # A
    "업무시간",                       # B
    "공휴일 (입력)",                  # C
    "비고",                           # D
    "날짜 텍스트변환",                # E
    "매니저 아이디텍스트변환",         # F
    "매니저 아이디",                   # G
    "담당자",                         # H
    "",                              # I (구분)
    "분류",                           # J
    "",                              # K (구분)
    "본사 명단",                       # L
    "외주 고객센터 명단",              # M
    "기타 명단",                       # N
    "",                              # O (구분)
    "팀 ID",                          # P
    "팀명",                           # Q
    "구분",                           # R
    "",                              # S (구분)
    "phoneNumber",                    # T
    "전화",                           # U
    "appkakao",                       # V
    "카카오",                         # W
    "appnavertalk",                   # X
    "네이버"                          # Y
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!A1:Y1",
    valueInputOption='RAW', body={'values': [header]}
).execute()

# A: RAW URL
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!A2",
    valueInputOption='USER_ENTERED',
    body={'values': [['https://docs.google.com/spreadsheets/d/10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8/edit']]}
).execute()

# B: 업무시간 1분 시계열
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!B2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440)']]}
).execute()

# C-E: 공휴일/비고/날짜텍스트
holidays = [
    ['2026-05-01', '근로자의 날'],
    ['2026-05-05', '어린이날 (대체)'],
    ['2026-05-25', '부처님 오신 날'],
    ['2026-06-06', '현충일'],
    ['2026-08-15', '광복절'],
    ['2026-09-24', '추석'],
    ['2026-09-25', '추석'],
    ['2026-09-26', '추석'],
    ['2026-10-03', '개천절'],
    ['2026-10-05', '추석 대체'],
    ['2026-10-09', '한글날'],
    ['2026-12-25', '크리스마스'],
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range=f"'★설정'!C2:D{1+len(holidays)}",
    valueInputOption='USER_ENTERED', body={'values': holidays}
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!E2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF(C2:C="",,TEXT(C2:C,"yyyy-mm-dd")))']]}
).execute()

# F-J: 매니저 매핑
with open('legacy_managers.json', 'r', encoding='utf-8') as f:
    legacy = json.load(f)

active = {
    '492537': '김진향(기술)', '540982': '윤준규(기술)', '557415': '최종수(CS)',
    '620022': '김지은(CS)', '623467': '한송희(기술)', '629462': '정현호(CS)',
    '631540': '지상호(CS)', '631655': '박슬기(CS)', '631668': '한승연(CS)',
    '633677': '이윤애(CS)',
    '631394': 'CS쉐어링_안준모', '589223': 'CS쉐어링_김혜림', '601163': 'CS쉐어링_이혜미',
    '617407': 'CS쉐어링_신화영', '621571': 'CS쉐어링_천승현',
}

unified = list(legacy['all'])
existing_ids = set(m['id'] for m in unified)
for mid, mname in active.items():
    if mid not in existing_ids:
        unified.append({'id': mid, 'name': mname})
unified.sort(key=lambda x: int(x['id']))

def classify(name):
    if name.startswith('CS쉐어링_') or name.startswith('TCK_'):
        return '외주 고객센터'
    if name.startswith(('CS_', 'CX_', '기술_')) or '(CS)' in name or '(기술)' in name:
        return '본사'
    return '기타'

manager_rows = []
for m in unified:
    mid, mname = m['id'], m['name']
    manager_rows.append([mid, mid, mname, '', classify(mname)])

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range=f"'★설정'!F2:J{1+len(manager_rows)}",
    valueInputOption='USER_ENTERED', body={'values': manager_rows}
).execute()

# L-N: 본사/외주/기타 명단 (자동)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!L2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF((H2:H200<>"")*(J2:J200="본사"),H2:H200,""))']]}
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!M2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF((H2:H200<>"")*(J2:J200="외주 고객센터"),H2:H200,""))']]}
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!N2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF((H2:H200<>"")*(J2:J200="기타"),H2:H200,""))']]}
).execute()

# P-R: 팀 매핑
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!P2:R5",
    valueInputOption='RAW', body={'values': [
        ['10268', '고객센터', '본사'],
        ['10308', '기술CS', '본사'],
        ['10367', '채팅담당자', '본사'],
        ['', '도급사', '외주 고객센터'],
    ]}
).execute()

# T-Y: 채널 매핑
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!T2:Y2",
    valueInputOption='RAW', body={'values': [['phoneNumber', '전화', 'appkakao', '카카오', 'appnavertalk', '네이버']]}
).execute()

print(f'✅ ★설정 재정렬 완료 ({len(unified)}명 매니저)')

# ============================================================
# Step 2: 5.콜/6.채팅 매핑 수식 — F열(텍스트 ID) 매칭으로 단순화
# ============================================================
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!W2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF(M2:M="",,IFNA(VLOOKUP(M2:M,\'★설정\'!F$2:H$200,3,FALSE),"기타")))']]}
).execute()

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AC2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF(M2:M="",,IFNA(VLOOKUP(M2:M,\'★설정\'!F$2:J$200,5,FALSE),"기타")))']]}
).execute()

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!N2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF(G2:G="",,IFNA(VLOOKUP(G2:G,\'★설정\'!F$2:H$200,3,FALSE),"기타")))']]}
).execute()

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!W2",
    valueInputOption='USER_ENTERED',
    body={'values': [['=ARRAYFORMULA(IF(G2:G="",,IFNA(VLOOKUP(G2:G,\'★설정\'!F$2:J$200,5,FALSE),"기타")))']]}
).execute()

print('✅ 5.콜/6.채팅 매핑 수식 단순화')

# ============================================================
# Step 3: ★설정 시각적 서식
# ============================================================
sids = _get_sheet_id_by_name(NEW, '★설정')
reqs = []

# 행1 헤더 짙은 청록
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 0, "endColumnIndex": 25},
        "cell": {"userEnteredFormat": {
            "backgroundColor": _hex_to_rgb_dict("134F5C"),
            "textFormat": {"bold": True, "fontSize": 11, "foregroundColor": _hex_to_rgb_dict("FFFFFF")},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
        }},
        "fields": "userEnteredFormat.backgroundColor,userEnteredFormat.textFormat,userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
    }
})

# 행 고정 1행
reqs.append({
    "updateSheetProperties": {
        "properties": {"sheetId": sids, "gridProperties": {"frozenRowCount": 1}},
        "fields": "gridProperties.frozenRowCount",
    }
})

# 열 너비
widths = [
    (0,1,250),   # A
    (1,2,80),    # B
    (2,3,110),   # C
    (3,4,140),   # D
    (4,5,110),   # E
    (5,6,130),   # F
    (6,7,110),   # G
    (7,8,180),   # H
    (8,9,30),    # I (구분 좁게)
    (9,10,160),  # J
    (10,11,30),  # K (구분 좁게)
    (11,14,160), # L,M,N
    (14,15,30),  # O (구분 좁게)
    (15,18,90),  # P,Q,R
    (18,19,30),  # S (구분 좁게)
    (19,25,110), # T-Y
]
for sc, ec, px in widths:
    reqs.append({
        "updateDimensionProperties": {
            "range": {"sheetId": sids, "dimension": "COLUMNS", "startIndex": sc, "endIndex": ec},
            "properties": {"pixelSize": px}, "fields": "pixelSize",
        }
    })

# B (업무시간) TIME 형식
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 511, "startColumnIndex": 1, "endColumnIndex": 2},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "TIME", "pattern": "hh:mm"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# C, E (날짜) DATE 형식
for sc, ec in [(2,3), (4,5)]:
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 30, "startColumnIndex": sc, "endColumnIndex": ec},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": "DATE", "pattern": "yyyy\"-\"mm\"-\"dd"}}},
            "fields": "userEnteredFormat.numberFormat",
        }
    })

# F, G (매니저 ID) 텍스트 강제
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 200, "startColumnIndex": 5, "endColumnIndex": 7},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "TEXT"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# I, K, O, S (구분 빈 컬럼) 옅은 회색 — 시각적 구분
for sc, ec in [(8,9), (10,11), (14,15), (18,19)]:
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sids, "startRowIndex": 0, "endRowIndex": 200, "startColumnIndex": sc, "endColumnIndex": ec},
            "cell": {"userEnteredFormat": {"backgroundColor": _hex_to_rgb_dict("EFEFEF")}},
            "fields": "userEnteredFormat.backgroundColor",
        }
    })

# 그룹별 데이터 영역 음영 (얕은 색)
# F-J 매니저 그룹: 살구
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 200, "startColumnIndex": 5, "endColumnIndex": 10},
        "cell": {"userEnteredFormat": {"backgroundColor": _hex_to_rgb_dict("FFF2F0")}},
        "fields": "userEnteredFormat.backgroundColor",
    }
})
# L-N 명단 그룹: 연두
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 200, "startColumnIndex": 11, "endColumnIndex": 14},
        "cell": {"userEnteredFormat": {"backgroundColor": _hex_to_rgb_dict("F0FFF0")}},
        "fields": "userEnteredFormat.backgroundColor",
    }
})
# P-R 팀: 하늘
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 6, "startColumnIndex": 15, "endColumnIndex": 18},
        "cell": {"userEnteredFormat": {"backgroundColor": _hex_to_rgb_dict("F0F8FF")}},
        "fields": "userEnteredFormat.backgroundColor",
    }
})
# T-Y 채널: 노랑
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 3, "startColumnIndex": 19, "endColumnIndex": 25},
        "cell": {"userEnteredFormat": {"backgroundColor": _hex_to_rgb_dict("FFFCE0")}},
        "fields": "userEnteredFormat.backgroundColor",
    }
})

# H, J, L, M, N (이름/명단) 정렬
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 200, "startColumnIndex": 7, "endColumnIndex": 8},
        "cell": {"userEnteredFormat": {"horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
    }
})
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 200, "startColumnIndex": 9, "endColumnIndex": 14},
        "cell": {"userEnteredFormat": {"horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
    }
})

# B, C, E, F, G (시간/날짜/ID) 가운데 정렬
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sids, "startRowIndex": 1, "endRowIndex": 511, "startColumnIndex": 1, "endColumnIndex": 7},
        "cell": {"userEnteredFormat": {"horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat.horizontalAlignment,userEnteredFormat.verticalAlignment",
    }
})

_batch_update(NEW, reqs)
print(f'✅ ★설정 시각적 서식 ({len(reqs)}개)')

# 검증
import time; time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!L2:N100",
    valueRenderOption='FORMATTED_VALUE'
).execute().get('values', [])
l_list = [r[0] for r in res if r and len(r)>0 and r[0]]
m_list = [r[1] for r in res if r and len(r)>1 and r[1]]
n_list = [r[2] for r in res if r and len(r)>2 and r[2]]
print(f'\n=== L (본사) {len(l_list)}명 / M (외주: CS쉐어링+TCK) {len(m_list)}명 / N (기타) {len(n_list)}명 ===')
print(f'  본사 샘플: {l_list[:3]}')
print(f'  외주 샘플: {m_list[:3]}')
print(f'  기타 샘플: {n_list[:3]}')

res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AJ13",
    valueRenderOption='UNFORMATTED_VALUE'
).execute().get('values', [])
print(f'\n=== 1.일별 검증 (TCK_ 외주 반영) ===')
print(f'{"날짜":12} {"AC":6} {"AD":6} {"AE":6} {"AI":6}')
for row in res2:
    if not row: continue
    d = str(row[0])[:10]
    print(f'{d:12} {str(row[28] if len(row)>28 else 0):6} {str(row[29] if len(row)>29 else 0):6} {str(row[30] if len(row)>30 else 0):6} {str(row[34] if len(row)>34 else 0):6}')
