"""RAW 55 매핑 컬럼 추가 + 1.일별 기술이관 수식 통합."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

print("[1] RAW 55에 매핑 + 가공 컬럼 추가")

# 헤더 (M-Q): 신 형식 날짜, 운영시간 분류, 팀 분리, 이름 분리, 비고
headers = [["날짜 텍스트변환", "운영시간 분류", "팀(★설정 분리)", "이름(★설정 분리)", "비고"]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!M1:Q1",
    valueInputOption="USER_ENTERED",
    body={"values": headers},
).execute()
print("  헤더 M-Q 입력")

# M2: 신 형식 날짜 (yyyy-mm-dd) — A 컬럼 "2025.06.23" 형식 → "2025-06-23"
m2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,SUBSTITUTE(A2:A,".","-")))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!M2",
    valueInputOption="USER_ENTERED",
    body={"values": [[m2]]},
).execute()

# N2: 운영시간 분류 — 외부 데이터에는 운영시간 정보 없으므로 "내" 가정
n2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,"내"))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!N2",
    valueInputOption="USER_ENTERED",
    body={"values": [[n2]]},
).execute()

# O2: 팀 — ★설정 H에서 SPLIT
o2 = '=ARRAYFORMULA(IF(ISBLANK(\'★설정\'!H4:H),,SPLIT(\'★설정\'!H4:H,"_",TRUE,TRUE)))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!O2",
    valueInputOption="USER_ENTERED",
    body={"values": [[o2]]},
).execute()
# O는 SPLIT의 첫 컬럼 (팀), P는 두 번째 컬럼 (이름) 자동 spillover

# Q2: 비고 — 도급사 운영 안내
q2 = '=ARRAYFORMULA(IF(ISBLANK(C2:C),,"외주 도급사 데이터"))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!Q2",
    valueInputOption="USER_ENTERED",
    body={"values": [[q2]]},
).execute()
print("  M-Q 가공 수식 입력")

# J2 정정 — XLOOKUP P 컬럼 사용
j2 = ('=ARRAYFORMULA(IF(ISBLANK(C2:C),,'
      'IFNA(XLOOKUP(C2:C&"",P2:P&"",O2:O&"_"&P2:P,"@@"),"@@")&'
      'IF(ISNUMBER(SEARCH("@@",IFNA(XLOOKUP(C2:C&"",P2:P&"","",""),""))),"_"&TRIM(C2:C),"")))')
# 위 수식은 복잡 - 단순화
j2 = ('=ARRAYFORMULA(IF(ISBLANK(C2:C),,'
      'IFERROR(XLOOKUP(C2:C&"",P2:P&"",O2:O&"_"&P2:P),'
      '"@@"&TRIM(C2:C)&"_미매핑")))')
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2",
    valueInputOption="USER_ENTERED",
    body={"values": [[j2]]},
).execute()
print("  J2 정정 (XLOOKUP P 컬럼 사용)")

time.sleep(8)

# 검증
print("\n[검증]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A2:Q5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
labels = "ABCDEFGHIJKLMNOPQ"
for ri, row in enumerate(res):
    if row:
        non_empty = [(labels[ci], str(c)[:25]) for ci, c in enumerate(row) if c and ci < len(labels)]
        print(f"  Row {ri+2}: {non_empty}")

# J 매핑 분포 (수정 후)
print("\n[J 매핑 분포 - 수정 후]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2:J10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
j_dist = Counter(r[0][:30] for r in res if r and r[0])
print("상위 10개:")
for k, v in j_dist.most_common(10):
    print(f"  {k}: {v}건")

# 매핑 성공 vs 실패
matched = sum(v for k, v in j_dist.items() if not k.startswith("@@"))
unmatched = sum(v for k, v in j_dist.items() if k.startswith("@@"))
print(f"\n  매핑 성공: {matched}건")
print(f"  매핑 실패 (★설정 H에 미등록): {unmatched}건")
