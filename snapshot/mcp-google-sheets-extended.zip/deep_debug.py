"""5.콜 5/4 IB_포기호 정밀 분석 + RAW시간대별 작동 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 5/4 모든 행 분석
print("=" * 70)
print("5.콜 5/4 모든 IB_포기호 정밀 분석")
print("=" * 70)
all_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AC3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"총 데이터: {len(all_data)}행")
total_5_4_ib_abandon = 0
matching_filter = 0
not_matching_alert = 0
not_matching_techfail = 0
for row in all_data:
    if len(row) > 16:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        Z = row[25] if len(row) > 25 else ""
        if N == "2026-05-04" and Q == "IB_포기호":
            total_5_4_ib_abandon += 1
            if Y == "알림톡발송":
                not_matching_alert += 1
            elif Z == "기술부재포기호":
                not_matching_techfail += 1
            else:
                matching_filter += 1

print(f"5/4 IB_포기호 전체: {total_5_4_ib_abandon}")
print(f"  알림톡발송 제외: {not_matching_alert}")
print(f"  기술부재포기호 제외: {not_matching_techfail}")
print(f"  매칭 (실제 응대 가능 포기호): {matching_filter}")

# 1.일별 5/4 IB 포기호 값
print("\n" + "=" * 70)
print("1.일별 5/4 IB 포기호 값 비교")
print("=" * 70)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AJ50",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for row in res:
    if row and row[0] == "2026-05-04":
        print(f"  5/4: O={row[14] if len(row)>14 else ''} P={row[15] if len(row)>15 else ''} Q={row[16] if len(row)>16 else ''}")
        # O=접수호, P=응대호, Q=포기호
        break

# 4/30 IB_포기호 (백필 데이터 검증)
print("\n" + "=" * 70)
print("5.콜 4/30 IB_포기호 정밀 분석")
print("=" * 70)
total_4_30 = 0
matching_4_30 = 0
for row in all_data:
    if len(row) > 16:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        Z = row[25] if len(row) > 25 else ""
        if N == "2026-04-30" and Q == "IB_포기호":
            total_4_30 += 1
            if Y != "알림톡발송" and Z != "기술부재포기호":
                matching_4_30 += 1
print(f"4/30 IB_포기호 전체: {total_4_30}, 매칭: {matching_4_30}")

# 1분단위 E2 현재 설정값
print("\n" + "=" * 70)
print("1분단위 E2 (날짜 설정) 현재 값")
print("=" * 70)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print(f"  E2 = {res[0][0] if res and res[0] else 'None'}")
