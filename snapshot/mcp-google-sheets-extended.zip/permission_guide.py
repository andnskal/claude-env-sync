"""IMPORTRANGE 권한 부여 안내 셀 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
EXTERNAL = "1-6uipG0sTwxFW30T1-rfXmcxiBsfiEYQMlmv_CFe8xk"

# A2 IMPORTRANGE 그대로 두고, M1에 안내 추가
sid = _get_sheet_id_by_name(NEW, "RAW 55번 기술 이관")

# N2:Q2에 안내 + 권한 부여 셀
guide_data = [
    ["", "권한 부여 안내", "", ""],
    ["A2가 #REF! 표시이면 →", "A2 클릭", "→ '액세스 허용' 버튼", "1회만 부여하면 자동 작동"],
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!N1:Q2",
    valueInputOption="USER_ENTERED",
    body={"values": guide_data},
).execute()

# 안내 박스 서식
reqs = [
    {"mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 13, "endColumnIndex": 17},
        "mergeType": "MERGE_ALL"}},
    {"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 13, "endColumnIndex": 17},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.95, "green": 0.6, "blue": 0.2},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 11},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}},
    {"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 13, "endColumnIndex": 17},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 1.0, "green": 0.95, "blue": 0.7},
            "textFormat": {"bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"}},
]
_batch_update(NEW, reqs)
print("OK 권한 부여 안내 추가 (N1:Q2)")

# 향후 권한 부여 후 자동 작동을 위한 IMPORTRANGE 미리 1회 호출
# 빈 셀에 임시 시도 후 제거 - 권한 dialog 트리거
print("\n[현재 A2 상태]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])
print(f"  A2: {res[0][0] if res and res[0] else '?'}")

print("\n📌 사용자 행동 필요:")
print("   1. https://docs.google.com/spreadsheets/d/1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU 열기")
print("   2. 'RAW 55번 기술 이관' 시트 클릭")
print("   3. A2 셀 클릭 (#REF! 표시되어 있음)")
print("   4. 팝업 또는 셀 위 '액세스 허용' 버튼 클릭")
print("   5. 자동으로 모든 데이터 로드됨")
