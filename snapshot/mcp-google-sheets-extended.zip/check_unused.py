"""두 시트의 신/구 비교."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

for sheet_name in ["RAW 55번 기술 이관", "RAW_현시간 전화 모니터링"]:
    print("=" * 80)
    print(f"📋 {sheet_name}")
    print("=" * 80)
    
    # 신 시스템
    print("\n[신 시스템]")
    try:
        f = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=f"'{sheet_name}'!A1:M5",
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        print(f"  수식 + 헤더 (행 1-5):")
        for ri, row in enumerate(f[:5]):
            for ci, v in enumerate(row[:13]):
                if v:
                    col = chr(ord('A') + ci)
                    print(f"    {col}{ri+1}: {str(v)[:120]}")
    except Exception as e:
        print(f"  ⚠️ {e}")
    
    # 이전 시트
    print("\n[이전 시트]")
    try:
        f = _sheets.spreadsheets().values().get(
            spreadsheetId=OLD, range=f"'{sheet_name}'!A1:M5",
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        print(f"  수식 + 헤더 (행 1-5):")
        for ri, row in enumerate(f[:5]):
            for ci, v in enumerate(row[:13]):
                if v:
                    col = chr(ord('A') + ci)
                    print(f"    {col}{ri+1}: {str(v)[:120]}")
        
        # 데이터 행 수 (얼마나 사용했는지)
        v = _sheets.spreadsheets().values().get(
            spreadsheetId=OLD, range=f"'{sheet_name}'!A:A",
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        non_empty = sum(1 for r in v if r and r[0])
        print(f"\n  이전 시트 데이터 행 수: {non_empty}")
    except Exception as e:
        print(f"  ⚠️ {e}")

# 다른 시트가 이 두 시트를 참조하는지
print("\n" + "=" * 80)
print("[참조 확인 - 다른 시트가 이 두 시트를 가리키는가?]")
print("=" * 80)

import re
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
targets = ["RAW 55번 기술 이관", "RAW_현시간 전화 모니터링"]
ref_count = {t: 0 for t in targets}
ref_locations = {t: [] for t in targets}

for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    if name in targets or name == "📌 사용 가이드":
        continue
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0: continue
    
    def cl(idx):
        s, n = "", idx + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(ord("A") + r) + s
        return s
    
    rng = f"'{name}'!A1:{cl(cols-1)}{rows}"
    try:
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        for ri, row in enumerate(formulas):
            for ci, v in enumerate(row):
                if v and isinstance(v, str):
                    for t in targets:
                        if t in v:
                            ref_count[t] += 1
                            if len(ref_locations[t]) < 3:
                                ref_locations[t].append(f"{name}!{cl(ci)}{ri+1}")
    except: continue

for t, cnt in ref_count.items():
    print(f"  {t}: {cnt}회 참조 {ref_locations[t][:3]}")
