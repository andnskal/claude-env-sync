"""2.시간대별 모든 수식에 운영시간 필터 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 운영시간 필터: 'AD:AD = "내"'
# 6.채팅 운영시간 필터: 'Z:Z = "내"'

formulas = {}

# D4: IB 투입인원
formulas["D4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,IFERROR(COUNTA(UNIQUE(FILTER('
    "'5.콜 상담내역'!$W:$W,"
    "'5.콜 상담내역'!$N:$N=d,"
    "'5.콜 상담내역'!$P:$P=t,"
    "'5.콜 상담내역'!$Q:$Q=" + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD=" + '"내"' + ","
    "'5.콜 상담내역'!$W:$W<>" + '"기타"' + ","
    "'5.콜 상담내역'!$W:$W<>" + '""' + "))),0)))))"
)

# E4: OB 투입인원
formulas["E4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,IFERROR(COUNTA(UNIQUE(FILTER('
    "'5.콜 상담내역'!$W:$W,"
    "'5.콜 상담내역'!$N:$N=d,"
    "'5.콜 상담내역'!$P:$P=t,"
    "'5.콜 상담내역'!$Q:$Q=" + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD=" + '"내"' + ","
    "'5.콜 상담내역'!$W:$W<>" + '"기타"' + ","
    "'5.콜 상담내역'!$W:$W<>" + '""' + "))),0)))))"
)

# F4: 채팅 투입인원
formulas["F4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,IFERROR(COUNTA(UNIQUE(FILTER('
    "'6.채팅 상담내역'!$N:$N,"
    "'6.채팅 상담내역'!$O:$O=d,"
    "'6.채팅 상담내역'!$Q:$Q=t,"
    "'6.채팅 상담내역'!$X:$X=" + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z=" + '"내"' + ","
    "'6.채팅 상담내역'!$N:$N<>" + '"기타"' + ","
    "'6.채팅 상담내역'!$N:$N<>" + '""' + "))),0)))))"
)

# H4: 포기호 (콜백+알림톡 제외) — 운영시간 필터 추가
formulas["H4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$Y:$Y," + '"<>콜백"' + ","
    "'5.콜 상담내역'!$Y:$Y," + '"<>알림톡발송"' + ","
    "'5.콜 상담내역'!$Z:$Z," + '"<>기술부재포기호"' + ")))))"
)

# K4: 포기호 (기술포기호 제외)
formulas["K4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$Y:$Y," + '"<>알림톡발송"' + ","
    "'5.콜 상담내역'!$Z:$Z," + '"<>기술부재포기호"' + ")))))"
)

# L4: IB_성공
formulas["L4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")))))"
)

# N4: 기술부재포기호
formulas["N4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Z:$Z," + '"기술부재포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")))))"
)

# O4: 기술부재 unique 고객
formulas["O4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,IFERROR(COUNTA(UNIQUE(FILTER('
    "'5.콜 상담내역'!$A:$A,"
    "'5.콜 상담내역'!$N:$N=d,"
    "'5.콜 상담내역'!$P:$P=t,"
    "'5.콜 상담내역'!$Z:$Z=" + '"기술부재포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD=" + '"내"' + "))),0)))))"
)

# Q4: 포기호 (알림톡만 제외)
formulas["Q4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$Y:$Y," + '"<>알림톡발송"' + ")))))"
)

# R4: IB_성공 (P 그룹용)
formulas["R4"] = formulas["L4"]  # 동일

# T4: IB 통화시간
formulas["T4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "SUMIFS('5.콜 상담내역'!$S:$S,"
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")))))"
)

# V4: 콜백
formulas["V4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Y:$Y," + '"콜백"' + ","
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")))))"
)

# W4: 알림톡발송
formulas["W4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Y:$Y," + '"알림톡발송"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")))))"
)

# X4: OB 성공 (본사+외주)
formulas["X4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"본사"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"외주 고객센터"' + ")))))"
)

# Y4: OB 실패
formulas["Y4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_실패"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"본사"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_실패"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"외주 고객센터"' + ")))))"
)

# Z4: OB 통화시간
formulas["Z4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "SUMIFS('5.콜 상담내역'!$S:$S,'5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"본사"' + ")"
    "+SUMIFS('5.콜 상담내역'!$S:$S,'5.콜 상담내역'!$N:$N,d,'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"외주 고객센터"' + ")))))"
)

# AE4: 채팅 매니저 답변
formulas["AE4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$Y:$Y," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ","
    "'6.채팅 상담내역'!$N:$N," + '"<>기타"' + ","
    "'6.채팅 상담내역'!$N:$N," + '"<>"' + ")))))"
)

# AG4: 카카오 인입
formulas["AG4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$M:$M," + '"카카오"' + ","
    "'6.채팅 상담내역'!$X:$X," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")))))"
)

# AH4: 카카오 답변
formulas["AH4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$M:$M," + '"카카오"' + ","
    "'6.채팅 상담내역'!$Y:$Y," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")))))"
)

# AI4: 네이버 인입
formulas["AI4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$M:$M," + '"네이버"' + ","
    "'6.채팅 상담내역'!$X:$X," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")))))"
)

# AJ4: 네이버 답변
formulas["AJ4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$M:$M," + '"네이버"' + ","
    "'6.채팅 상담내역'!$Y:$Y," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")))))"
)

# AK4: 채널톡 인입
formulas["AK4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$M:$M," + '"채널톡"' + ","
    "'6.채팅 상담내역'!$X:$X," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")))))"
)

# AL4: 채널톡 답변
formulas["AL4"] = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    "COUNTIFS('6.채팅 상담내역'!$O:$O,d,'6.채팅 상담내역'!$Q:$Q,t,"
    "'6.채팅 상담내역'!$M:$M," + '"채널톡"' + ","
    "'6.채팅 상담내역'!$Y:$Y," + '"Y"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")))))"
)

print("=" * 80)
print("2.시간대별 수식 일괄 업데이트 (운영시간 필터 추가)")
print("=" * 80)
for cell, f in formulas.items():
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'2.시간대별 전체통계'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[f]]},
    ).execute()
    print(f"  OK {cell}")
print(f"\n총 {len(formulas)}개 수식 업데이트")

time.sleep(8)

# 검증
print("\n[2.시간대별 5/8 검증 (운영시간 필터 적용 후)]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_p = sum_q = sum_l = sum_g = sum_h = sum_k = 0
for row in res:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == "2026-05-08":
        if isinstance(row[6], (int, float)): sum_g += row[6]
        if isinstance(row[7], (int, float)): sum_h += row[7]
        if isinstance(row[10], (int, float)): sum_k += row[10]
        if isinstance(row[11], (int, float)): sum_l += row[11]
        if isinstance(row[15], (int, float)): sum_p += row[15]
        if isinstance(row[16], (int, float)): sum_q += row[16]

print(f"  G (총 접수호 콜백+알림톡 제외): {sum_g}")
print(f"  H (포기호 콜백+알림톡 제외): {sum_h}")
print(f"  K (포기호 기술포기호 제외): {sum_k}")
print(f"  L (IB_성공): {sum_l}")
print(f"  P (총 접수호 알림톡 제외): {sum_p}")
print(f"  Q (포기호 알림톡 제외): {sum_q}")
