"""
google-sheets-extended MCP server
서식(배경색, 글꼴, 병합, 테두리, 행 고정, 조건부 서식 등) 작업을 지원.
기본 값/수식 도구도 포함하여 단일 MCP로 통합 사용.
"""

import os
import json
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP
from google.oauth2 import service_account
from googleapiclient.discovery import build

CREDS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".credentials", "sa-key.json")
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

_creds = service_account.Credentials.from_service_account_file(CREDS_PATH, scopes=SCOPES)
_sheets = build("sheets", "v4", credentials=_creds, cache_discovery=False)
_drive = build("drive", "v3", credentials=_creds, cache_discovery=False)

mcp = FastMCP("google-sheets-extended")


# ---------- 헬퍼 ----------

def _hex_to_rgb_dict(hex_color: str) -> dict:
    """'#RRGGBB' 또는 'RRGGBB' → {red, green, blue} (0~1)"""
    h = hex_color.lstrip("#")
    if len(h) != 6:
        raise ValueError(f"hex_color must be RRGGBB: {hex_color}")
    r = int(h[0:2], 16) / 255.0
    g = int(h[2:4], 16) / 255.0
    b = int(h[4:6], 16) / 255.0
    return {"red": r, "green": g, "blue": b}


def _get_sheet_id_by_name(spreadsheet_id: str, sheet_name: str) -> int:
    meta = _sheets.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    for s in meta.get("sheets", []):
        if s["properties"]["title"] == sheet_name:
            return s["properties"]["sheetId"]
    raise ValueError(f"Sheet not found: {sheet_name}")


def _a1_to_grid_range(spreadsheet_id: str, a1_range: str) -> dict:
    """'시트명!A1:C5' → GridRange. ':없으면 전체 컬럼/행."""
    if "!" in a1_range:
        sheet_part, cell_part = a1_range.split("!", 1)
    else:
        # 시트명만 → 첫 시트
        meta = _sheets.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
        sheet_part = meta["sheets"][0]["properties"]["title"]
        cell_part = a1_range
    sheet_part = sheet_part.strip("'")
    sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_part)

    # 셀 부분 파싱
    def col_to_idx(col: str) -> int:
        col = col.upper()
        idx = 0
        for c in col:
            idx = idx * 26 + (ord(c) - ord("A") + 1)
        return idx - 1

    import re
    m = re.match(r"^([A-Z]*)(\d*):?([A-Z]*)(\d*)$", cell_part.upper())
    if not m:
        raise ValueError(f"Invalid range: {cell_part}")
    c1, r1, c2, r2 = m.groups()
    grid: dict[str, Any] = {"sheetId": sheet_id}
    if c1:
        grid["startColumnIndex"] = col_to_idx(c1)
    if c2:
        grid["endColumnIndex"] = col_to_idx(c2) + 1
    if r1:
        grid["startRowIndex"] = int(r1) - 1
    if r2:
        grid["endRowIndex"] = int(r2)
    return grid


def _batch_update(spreadsheet_id: str, requests: list[dict]) -> dict:
    body = {"requests": requests}
    return _sheets.spreadsheets().batchUpdate(spreadsheetId=spreadsheet_id, body=body).execute()


# ============================================================
# 기본 값/수식 도구 (호환성)
# ============================================================

@mcp.tool()
def sheets_list_spreadsheets(max_results: int = 10) -> str:
    """접근 가능한 스프레드시트 목록."""
    try:
        result = _drive.files().list(
            q="mimeType='application/vnd.google-apps.spreadsheet'",
            pageSize=max_results,
            fields="files(id, name, modifiedTime)",
        ).execute()
        files = result.get("files", [])
        if not files:
            return "📭 접근 가능한 스프레드시트가 없습니다."
        lines = ["📋 스프레드시트 목록:"]
        for f in files:
            lines.append(f"• {f['name']}\n  ID: {f['id']}\n  수정: {f.get('modifiedTime','')}")
        return "\n\n".join(lines)
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_get_sheet_info(spreadsheet_id: str) -> str:
    """스프레드시트 메타데이터(시트 목록, 크기)."""
    try:
        meta = _sheets.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
        title = meta.get("properties", {}).get("title", "")
        url = f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}/edit"
        lines = [f"📊 스프레드시트: {title}", f"🔗 URL: {url}", "", f"📑 시트 목록 ({len(meta.get('sheets',[]))}개):"]
        for s in meta.get("sheets", []):
            p = s["properties"]
            grid = p.get("gridProperties", {})
            lines.append(f"\n• {p['title']}\n  ID: {p['sheetId']}\n  크기: {grid.get('rowCount',0)}행 x {grid.get('columnCount',0)}열")
        return "\n".join(lines)
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_get_values(spreadsheet_id: str, range: str, value_render_option: str = "FORMATTED_VALUE") -> str:
    """범위 데이터 읽기. value_render_option: FORMATTED_VALUE / UNFORMATTED_VALUE / FORMULA"""
    try:
        result = _sheets.spreadsheets().values().get(
            spreadsheetId=spreadsheet_id, range=range, valueRenderOption=value_render_option
        ).execute()
        values = result.get("values", [])
        return f"📖 범위: {range}\n📊 렌더 옵션: {value_render_option}\n\n데이터:\n{json.dumps(values, ensure_ascii=False, indent=2)}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_batch_get_values(spreadsheet_id: str, ranges: list[str]) -> str:
    """여러 범위 동시 읽기."""
    try:
        result = _sheets.spreadsheets().values().batchGet(
            spreadsheetId=spreadsheet_id, ranges=ranges
        ).execute()
        out = [f"📖 {len(ranges)}개 범위 데이터:"]
        for vr in result.get("valueRanges", []):
            out.append(f"\n범위: {vr.get('range','')}\n{json.dumps(vr.get('values',[]), ensure_ascii=False, indent=2)}")
        return "\n".join(out)
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_update_values(spreadsheet_id: str, range: str, values: list[list[Any]], value_input_option: str = "USER_ENTERED") -> str:
    """범위에 데이터 쓰기. value_input_option: USER_ENTERED(수식 해석) / RAW"""
    try:
        body = {"values": values}
        result = _sheets.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id, range=range, valueInputOption=value_input_option, body=body
        ).execute()
        return f"✅ 업데이트 완료\n📍 범위: {result.get('updatedRange','')}\n📊 셀: {result.get('updatedCells',0)}개"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_append_values(spreadsheet_id: str, range: str, values: list[list[Any]], value_input_option: str = "USER_ENTERED") -> str:
    """마지막 행 다음에 데이터 추가."""
    try:
        body = {"values": values}
        result = _sheets.spreadsheets().values().append(
            spreadsheetId=spreadsheet_id, range=range, valueInputOption=value_input_option, body=body
        ).execute()
        return f"✅ 추가 완료\n📍 범위: {result.get('updates',{}).get('updatedRange','')}\n📊 셀: {result.get('updates',{}).get('updatedCells',0)}개"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_clear_values(spreadsheet_id: str, range: str) -> str:
    """범위 데이터 삭제 (서식 유지)."""
    try:
        _sheets.spreadsheets().values().clear(spreadsheetId=spreadsheet_id, range=range, body={}).execute()
        return f"✅ 삭제 완료\n📍 범위: {range}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_add_sheet(spreadsheet_id: str, sheet_name: str) -> str:
    """새 탭 추가."""
    try:
        result = _batch_update(spreadsheet_id, [{"addSheet": {"properties": {"title": sheet_name}}}])
        sheet_id = result["replies"][0]["addSheet"]["properties"]["sheetId"]
        return f"✅ 시트 추가 완료\n📑 이름: {sheet_name}\n🆔 ID: {sheet_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_create_spreadsheet(title: str, sheet_names: Optional[list[str]] = None) -> str:
    """새 스프레드시트 생성."""
    try:
        body: dict[str, Any] = {"properties": {"title": title}}
        if sheet_names:
            body["sheets"] = [{"properties": {"title": n}} for n in sheet_names]
        result = _sheets.spreadsheets().create(body=body, fields="spreadsheetId,spreadsheetUrl").execute()
        return f"✅ 생성 완료\n🆔 ID: {result['spreadsheetId']}\n🔗 URL: {result['spreadsheetUrl']}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_delete_sheet(spreadsheet_id: str, sheet_name: str) -> str:
    """시트 삭제."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        _batch_update(spreadsheet_id, [{"deleteSheet": {"sheetId": sheet_id}}])
        return f"✅ 시트 삭제: {sheet_name}"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 서식 조회/적용 도구
# ============================================================

@mcp.tool()
def sheets_get_format(spreadsheet_id: str, range: str) -> str:
    """범위의 서식 정보 조회 (배경색, 글꼴, 병합, 테두리 등)."""
    try:
        result = _sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id, ranges=[range], includeGridData=True,
            fields="sheets(properties(title,sheetId,gridProperties),merges,data(rowData(values(userEnteredFormat,effectiveFormat,note))))"
        ).execute()
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_background(spreadsheet_id: str, range: str, hex_color: str) -> str:
    """배경색 설정. hex_color: '#RRGGBB' 또는 'RRGGBB'."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        rgb = _hex_to_rgb_dict(hex_color)
        req = {
            "repeatCell": {
                "range": grid,
                "cell": {"userEnteredFormat": {"backgroundColor": rgb}},
                "fields": "userEnteredFormat.backgroundColor",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 배경색 적용\n📍 {range} → {hex_color}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_text_format(
    spreadsheet_id: str,
    range: str,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    strikethrough: Optional[bool] = None,
    font_size: Optional[int] = None,
    font_family: Optional[str] = None,
    foreground_hex: Optional[str] = None,
) -> str:
    """글꼴 서식 (굵기/기울임/밑줄/취소선/크기/글꼴/색)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        text_fmt: dict[str, Any] = {}
        fields = []
        if bold is not None:
            text_fmt["bold"] = bold; fields.append("bold")
        if italic is not None:
            text_fmt["italic"] = italic; fields.append("italic")
        if underline is not None:
            text_fmt["underline"] = underline; fields.append("underline")
        if strikethrough is not None:
            text_fmt["strikethrough"] = strikethrough; fields.append("strikethrough")
        if font_size is not None:
            text_fmt["fontSize"] = font_size; fields.append("fontSize")
        if font_family is not None:
            text_fmt["fontFamily"] = font_family; fields.append("fontFamily")
        if foreground_hex is not None:
            text_fmt["foregroundColor"] = _hex_to_rgb_dict(foreground_hex); fields.append("foregroundColor")
        if not fields:
            return "❌ 변경할 속성이 없습니다."
        field_str = ",".join(f"userEnteredFormat.textFormat.{f}" for f in fields)
        req = {
            "repeatCell": {
                "range": grid,
                "cell": {"userEnteredFormat": {"textFormat": text_fmt}},
                "fields": field_str,
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 글꼴 서식 적용\n📍 {range}\n⚙️  {', '.join(fields)}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_alignment(
    spreadsheet_id: str,
    range: str,
    horizontal: Optional[str] = None,  # LEFT, CENTER, RIGHT
    vertical: Optional[str] = None,    # TOP, MIDDLE, BOTTOM
    wrap: Optional[str] = None,         # OVERFLOW_CELL, LEGACY_WRAP, CLIP, WRAP
) -> str:
    """정렬 (가로/세로/줄바꿈)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        fmt: dict[str, Any] = {}
        fields = []
        if horizontal is not None:
            fmt["horizontalAlignment"] = horizontal; fields.append("horizontalAlignment")
        if vertical is not None:
            fmt["verticalAlignment"] = vertical; fields.append("verticalAlignment")
        if wrap is not None:
            fmt["wrapStrategy"] = wrap; fields.append("wrapStrategy")
        if not fields:
            return "❌ 변경할 속성이 없습니다."
        field_str = ",".join(f"userEnteredFormat.{f}" for f in fields)
        req = {
            "repeatCell": {"range": grid, "cell": {"userEnteredFormat": fmt}, "fields": field_str}
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 정렬 적용\n📍 {range}\n⚙️  {', '.join(fields)}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_borders(
    spreadsheet_id: str,
    range: str,
    style: str = "SOLID",  # DOTTED, DASHED, SOLID, SOLID_MEDIUM, SOLID_THICK, DOUBLE, NONE
    color_hex: str = "000000",
    sides: str = "all",  # all, outer, top, bottom, left, right, inner_h, inner_v
) -> str:
    """테두리 (위/아래/왼쪽/오른쪽/내부 가로/내부 세로/외곽/모두)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        border = {"style": style, "color": _hex_to_rgb_dict(color_hex)}
        req: dict[str, Any] = {"updateBorders": {"range": grid}}
        if sides == "all":
            for k in ("top", "bottom", "left", "right", "innerHorizontal", "innerVertical"):
                req["updateBorders"][k] = border
        elif sides == "outer":
            for k in ("top", "bottom", "left", "right"):
                req["updateBorders"][k] = border
        elif sides == "inner_h":
            req["updateBorders"]["innerHorizontal"] = border
        elif sides == "inner_v":
            req["updateBorders"]["innerVertical"] = border
        else:
            req["updateBorders"][sides] = border
        _batch_update(spreadsheet_id, [req])
        return f"✅ 테두리 적용\n📍 {range} ({sides}, {style}, #{color_hex})"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_merge_cells(spreadsheet_id: str, range: str, merge_type: str = "MERGE_ALL") -> str:
    """셀 병합. merge_type: MERGE_ALL / MERGE_COLUMNS / MERGE_ROWS"""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        _batch_update(spreadsheet_id, [{"mergeCells": {"range": grid, "mergeType": merge_type}}])
        return f"✅ 병합 완료\n📍 {range} ({merge_type})"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_unmerge_cells(spreadsheet_id: str, range: str) -> str:
    """병합 해제."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        _batch_update(spreadsheet_id, [{"unmergeCells": {"range": grid}}])
        return f"✅ 병합 해제\n📍 {range}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_column_width(spreadsheet_id: str, sheet_name: str, start_column: int, end_column: int, pixel_size: int) -> str:
    """열 너비 (픽셀). column 인덱스는 0부터 시작."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateDimensionProperties": {
                "range": {"sheetId": sheet_id, "dimension": "COLUMNS", "startIndex": start_column, "endIndex": end_column},
                "properties": {"pixelSize": pixel_size},
                "fields": "pixelSize",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 열 너비 설정\n📍 {sheet_name} 열 {start_column}~{end_column-1} → {pixel_size}px"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_row_height(spreadsheet_id: str, sheet_name: str, start_row: int, end_row: int, pixel_size: int) -> str:
    """행 높이 (픽셀). row 인덱스는 0부터 시작."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateDimensionProperties": {
                "range": {"sheetId": sheet_id, "dimension": "ROWS", "startIndex": start_row, "endIndex": end_row},
                "properties": {"pixelSize": pixel_size},
                "fields": "pixelSize",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 행 높이 설정\n📍 {sheet_name} 행 {start_row}~{end_row-1} → {pixel_size}px"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_freeze(spreadsheet_id: str, sheet_name: str, frozen_rows: int = 0, frozen_columns: int = 0) -> str:
    """행/열 고정."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateSheetProperties": {
                "properties": {
                    "sheetId": sheet_id,
                    "gridProperties": {"frozenRowCount": frozen_rows, "frozenColumnCount": frozen_columns},
                },
                "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 고정 적용\n📍 {sheet_name} 행 {frozen_rows}, 열 {frozen_columns}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_number_format(spreadsheet_id: str, range: str, format_type: str, pattern: Optional[str] = None) -> str:
    """숫자 형식. format_type: TEXT, NUMBER, PERCENT, CURRENCY, DATE, TIME, DATE_TIME, SCIENTIFIC."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        nf: dict[str, Any] = {"type": format_type}
        if pattern:
            nf["pattern"] = pattern
        req = {
            "repeatCell": {
                "range": grid,
                "cell": {"userEnteredFormat": {"numberFormat": nf}},
                "fields": "userEnteredFormat.numberFormat",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 숫자 형식 적용\n📍 {range} ({format_type}{', '+pattern if pattern else ''})"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_clear_format(spreadsheet_id: str, range: str) -> str:
    """범위의 모든 서식 지우기 (값 유지)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        req = {
            "updateCells": {"range": grid, "fields": "userEnteredFormat"}
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 서식 삭제\n📍 {range}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_copy_format(spreadsheet_id: str, source_range: str, dest_range: str) -> str:
    """서식만 복사·붙여넣기 (값/수식 보존)."""
    try:
        src = _a1_to_grid_range(spreadsheet_id, source_range)
        dst = _a1_to_grid_range(spreadsheet_id, dest_range)
        req = {"copyPaste": {"source": src, "destination": dst, "pasteType": "PASTE_FORMAT", "pasteOrientation": "NORMAL"}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 서식 복사\n📍 {source_range} → {dest_range}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_add_conditional_format(
    spreadsheet_id: str,
    range: str,
    condition_type: str,  # NUMBER_GREATER, NUMBER_LESS, NUMBER_EQ, TEXT_CONTAINS, BLANK, NOT_BLANK 등
    condition_value: Optional[str] = None,
    background_hex: Optional[str] = None,
    foreground_hex: Optional[str] = None,
    bold: Optional[bool] = None,
) -> str:
    """조건부 서식 추가."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        cond: dict[str, Any] = {"type": condition_type}
        if condition_value is not None:
            cond["values"] = [{"userEnteredValue": condition_value}]
        fmt: dict[str, Any] = {}
        if background_hex:
            fmt["backgroundColor"] = _hex_to_rgb_dict(background_hex)
        text_fmt: dict[str, Any] = {}
        if foreground_hex:
            text_fmt["foregroundColor"] = _hex_to_rgb_dict(foreground_hex)
        if bold is not None:
            text_fmt["bold"] = bold
        if text_fmt:
            fmt["textFormat"] = text_fmt
        rule = {"ranges": [grid], "booleanRule": {"condition": cond, "format": fmt}}
        req = {"addConditionalFormatRule": {"rule": rule, "index": 0}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 조건부 서식 추가\n📍 {range} ({condition_type})"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_get_full_format_summary(spreadsheet_id: str, sheet_name: str) -> str:
    """시트 전체 서식 요약 — 셀별 배경색/글꼴/병합/테두리/숫자형식 추출."""
    try:
        result = _sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            ranges=[sheet_name],
            includeGridData=True,
            fields="sheets(properties(title,sheetId,gridProperties(frozenRowCount,frozenColumnCount)),merges,data(rowData(values(userEnteredFormat))),conditionalFormats)"
        ).execute()
        sheet = result["sheets"][0]
        out: dict[str, Any] = {
            "title": sheet["properties"]["title"],
            "frozen": {
                "rows": sheet["properties"]["gridProperties"].get("frozenRowCount", 0),
                "cols": sheet["properties"]["gridProperties"].get("frozenColumnCount", 0),
            },
            "merges": sheet.get("merges", []),
            "conditionalFormats": sheet.get("conditionalFormats", []),
            "cells": [],
        }
        # 셀별 서식 압축
        for row_idx, row in enumerate(sheet.get("data", [{}])[0].get("rowData", [])):
            for col_idx, cell in enumerate(row.get("values", [])):
                fmt = cell.get("userEnteredFormat")
                if fmt:
                    out["cells"].append({"row": row_idx, "col": col_idx, "format": fmt})
        return json.dumps(out, ensure_ascii=False, indent=2)
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 데이터 검증 / 드롭다운
# ============================================================

@mcp.tool()
def sheets_set_data_validation(
    spreadsheet_id: str,
    range: str,
    condition_type: str,
    values: Optional[list[str]] = None,
    strict: bool = True,
    show_dropdown: bool = True,
    input_message: Optional[str] = None,
) -> str:
    """데이터 검증 / 드롭다운 설정.
    condition_type: ONE_OF_LIST(드롭다운), ONE_OF_RANGE, BOOLEAN(체크박스),
                    NUMBER_BETWEEN, NUMBER_GREATER, NUMBER_LESS, NUMBER_EQ,
                    DATE_BETWEEN, DATE_AFTER, DATE_BEFORE, DATE_EQ,
                    TEXT_CONTAINS, TEXT_EQ, TEXT_IS_EMAIL, TEXT_IS_URL,
                    BLANK, NOT_BLANK, CUSTOM_FORMULA.
    values: ONE_OF_LIST일 때 항목 리스트, NUMBER/DATE_BETWEEN일 때 [min,max], CUSTOM_FORMULA일 때 ['=수식']."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        condition: dict[str, Any] = {"type": condition_type}
        if values:
            condition["values"] = [{"userEnteredValue": v} for v in values]
        rule: dict[str, Any] = {"condition": condition, "strict": strict, "showCustomUi": show_dropdown}
        if input_message:
            rule["inputMessage"] = input_message
        req = {"setDataValidation": {"range": grid, "rule": rule}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 데이터 검증 적용\n📍 {range} ({condition_type})"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_clear_data_validation(spreadsheet_id: str, range: str) -> str:
    """데이터 검증 / 드롭다운 제거."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        req = {"setDataValidation": {"range": grid}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 데이터 검증 제거\n📍 {range}"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 보호 (시트 / 범위)
# ============================================================

@mcp.tool()
def sheets_protect_range(
    spreadsheet_id: str,
    range: str,
    description: str = "",
    warning_only: bool = True,
    editor_emails: Optional[list[str]] = None,
) -> str:
    """범위 보호. warning_only=True이면 경고만(편집은 가능),
    False이면 editor_emails 외에는 편집 차단."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        protected: dict[str, Any] = {"range": grid, "description": description, "warningOnly": warning_only}
        if not warning_only and editor_emails:
            protected["editors"] = {"users": editor_emails}
        req = {"addProtectedRange": {"protectedRange": protected}}
        result = _batch_update(spreadsheet_id, [req])
        prot_id = result["replies"][0]["addProtectedRange"]["protectedRange"]["protectedRangeId"]
        return f"✅ 범위 보호 추가\n📍 {range}\n🆔 보호ID: {prot_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_protect_sheet(
    spreadsheet_id: str,
    sheet_name: str,
    description: str = "",
    warning_only: bool = True,
    unprotected_ranges: Optional[list[str]] = None,
    editor_emails: Optional[list[str]] = None,
) -> str:
    """시트 전체 보호. unprotected_ranges로 일부 영역만 편집 가능하게 예외 지정."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        protected: dict[str, Any] = {
            "range": {"sheetId": sheet_id},
            "description": description,
            "warningOnly": warning_only,
        }
        if unprotected_ranges:
            protected["unprotectedRanges"] = [_a1_to_grid_range(spreadsheet_id, r) for r in unprotected_ranges]
        if not warning_only and editor_emails:
            protected["editors"] = {"users": editor_emails}
        req = {"addProtectedRange": {"protectedRange": protected}}
        result = _batch_update(spreadsheet_id, [req])
        prot_id = result["replies"][0]["addProtectedRange"]["protectedRange"]["protectedRangeId"]
        return f"✅ 시트 보호\n📍 {sheet_name}\n🆔 보호ID: {prot_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_unprotect(spreadsheet_id: str, protected_range_id: int) -> str:
    """보호 해제 (보호ID 필요)."""
    try:
        req = {"deleteProtectedRange": {"protectedRangeId": protected_range_id}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 보호 해제: {protected_range_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_list_protected_ranges(spreadsheet_id: str) -> str:
    """모든 보호 범위 목록."""
    try:
        meta = _sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            fields="sheets(properties(title,sheetId),protectedRanges)"
        ).execute()
        out = []
        for s in meta.get("sheets", []):
            for p in s.get("protectedRanges", []):
                out.append({
                    "sheetTitle": s["properties"]["title"],
                    "protectedRangeId": p.get("protectedRangeId"),
                    "description": p.get("description", ""),
                    "warningOnly": p.get("warningOnly", False),
                    "range": p.get("range", {}),
                })
        return json.dumps(out, ensure_ascii=False, indent=2) if out else "📭 보호 범위 없음"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 시트 속성 (이름변경 / 숨기기 / 색상)
# ============================================================

@mcp.tool()
def sheets_rename_sheet(spreadsheet_id: str, old_name: str, new_name: str) -> str:
    """시트 이름 변경."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, old_name)
        req = {
            "updateSheetProperties": {
                "properties": {"sheetId": sheet_id, "title": new_name},
                "fields": "title",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 이름 변경: {old_name} → {new_name}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_set_tab_color(spreadsheet_id: str, sheet_name: str, hex_color: str) -> str:
    """시트 탭 색상 설정 ('#RRGGBB')."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateSheetProperties": {
                "properties": {"sheetId": sheet_id, "tabColor": _hex_to_rgb_dict(hex_color)},
                "fields": "tabColor",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 탭 색상 적용: {sheet_name} → #{hex_color}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_hide_sheet(spreadsheet_id: str, sheet_name: str, hidden: bool = True) -> str:
    """시트 숨기기 / 표시."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateSheetProperties": {
                "properties": {"sheetId": sheet_id, "hidden": hidden},
                "fields": "hidden",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 시트 {'숨김' if hidden else '표시'}: {sheet_name}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_duplicate_sheet(spreadsheet_id: str, source_sheet_name: str, new_sheet_name: str, insert_index: Optional[int] = None) -> str:
    """시트 복제."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, source_sheet_name)
        dup: dict[str, Any] = {"sourceSheetId": sheet_id, "newSheetName": new_sheet_name}
        if insert_index is not None:
            dup["insertSheetIndex"] = insert_index
        result = _batch_update(spreadsheet_id, [{"duplicateSheet": dup}])
        new_id = result["replies"][0]["duplicateSheet"]["properties"]["sheetId"]
        return f"✅ 시트 복제\n📑 {source_sheet_name} → {new_sheet_name}\n🆔 ID: {new_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_reorder_sheet(spreadsheet_id: str, sheet_name: str, new_index: int) -> str:
    """시트 순서 변경 (0부터)."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateSheetProperties": {
                "properties": {"sheetId": sheet_id, "index": new_index},
                "fields": "index",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 순서 변경: {sheet_name} → 인덱스 {new_index}"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 행/열 숨기기 + 자동 크기
# ============================================================

@mcp.tool()
def sheets_hide_columns(spreadsheet_id: str, sheet_name: str, start_column: int, end_column: int, hidden: bool = True) -> str:
    """열 숨기기 / 표시 (인덱스 0부터)."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateDimensionProperties": {
                "range": {"sheetId": sheet_id, "dimension": "COLUMNS", "startIndex": start_column, "endIndex": end_column},
                "properties": {"hiddenByUser": hidden},
                "fields": "hiddenByUser",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 열 {'숨김' if hidden else '표시'}: {sheet_name} {start_column}~{end_column-1}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_hide_rows(spreadsheet_id: str, sheet_name: str, start_row: int, end_row: int, hidden: bool = True) -> str:
    """행 숨기기 / 표시 (인덱스 0부터)."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "updateDimensionProperties": {
                "range": {"sheetId": sheet_id, "dimension": "ROWS", "startIndex": start_row, "endIndex": end_row},
                "properties": {"hiddenByUser": hidden},
                "fields": "hiddenByUser",
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 행 {'숨김' if hidden else '표시'}: {sheet_name} {start_row}~{end_row-1}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_auto_resize(spreadsheet_id: str, sheet_name: str, dimension: str, start_index: int, end_index: int) -> str:
    """자동 크기 조정. dimension: COLUMNS / ROWS"""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {
            "autoResizeDimensions": {
                "dimensions": {"sheetId": sheet_id, "dimension": dimension, "startIndex": start_index, "endIndex": end_index}
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 자동 크기 조정\n📍 {sheet_name} {dimension} {start_index}~{end_index-1}"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 차트
# ============================================================

@mcp.tool()
def sheets_add_chart(
    spreadsheet_id: str,
    chart_type: str,
    title: str,
    source_range: str,
    anchor_cell: str,
    legend_position: str = "RIGHT_LEGEND",
    has_header: bool = True,
) -> str:
    """차트 추가.
    chart_type: COLUMN, BAR, LINE, AREA, PIE, SCATTER, COMBO, STEPPED_AREA.
    source_range: 'Sheet1!A1:C10'. 첫 컬럼=도메인(x축), 나머지 컬럼=시리즈.
    anchor_cell: 차트 좌상단 셀."""
    try:
        src_grid = _a1_to_grid_range(spreadsheet_id, source_range)
        anchor_grid = _a1_to_grid_range(spreadsheet_id, anchor_cell)
        spec: dict[str, Any] = {
            "title": title,
            "basicChart": {
                "chartType": chart_type,
                "legendPosition": legend_position,
                "axis": [{"position": "BOTTOM_AXIS"}, {"position": "LEFT_AXIS"}],
                "domains": [{
                    "domain": {"sourceRange": {"sources": [{
                        "sheetId": src_grid["sheetId"],
                        "startRowIndex": src_grid.get("startRowIndex", 0),
                        "endRowIndex": src_grid.get("endRowIndex"),
                        "startColumnIndex": src_grid.get("startColumnIndex", 0),
                        "endColumnIndex": src_grid.get("startColumnIndex", 0) + 1,
                    }]}}
                }],
                "series": [{
                    "series": {"sourceRange": {"sources": [{
                        "sheetId": src_grid["sheetId"],
                        "startRowIndex": src_grid.get("startRowIndex", 0),
                        "endRowIndex": src_grid.get("endRowIndex"),
                        "startColumnIndex": src_grid.get("startColumnIndex", 0) + 1,
                        "endColumnIndex": src_grid.get("endColumnIndex"),
                    }]}},
                    "targetAxis": "LEFT_AXIS",
                }],
                "headerCount": 1 if has_header else 0,
            }
        }
        if chart_type == "PIE":
            spec.pop("basicChart", None)
            spec["pieChart"] = {
                "legendPosition": legend_position,
                "domain": {"sourceRange": {"sources": [{
                    "sheetId": src_grid["sheetId"],
                    "startRowIndex": src_grid.get("startRowIndex", 0),
                    "endRowIndex": src_grid.get("endRowIndex"),
                    "startColumnIndex": src_grid.get("startColumnIndex", 0),
                    "endColumnIndex": src_grid.get("startColumnIndex", 0) + 1,
                }]}},
                "series": {"sourceRange": {"sources": [{
                    "sheetId": src_grid["sheetId"],
                    "startRowIndex": src_grid.get("startRowIndex", 0),
                    "endRowIndex": src_grid.get("endRowIndex"),
                    "startColumnIndex": src_grid.get("startColumnIndex", 0) + 1,
                    "endColumnIndex": src_grid.get("startColumnIndex", 0) + 2,
                }]}},
            }
        position = {
            "overlayPosition": {
                "anchorCell": {
                    "sheetId": anchor_grid["sheetId"],
                    "rowIndex": anchor_grid.get("startRowIndex", 0),
                    "columnIndex": anchor_grid.get("startColumnIndex", 0),
                }
            }
        }
        req = {"addChart": {"chart": {"spec": spec, "position": position}}}
        result = _batch_update(spreadsheet_id, [req])
        chart_id = result["replies"][0]["addChart"]["chart"]["chartId"]
        return f"✅ 차트 추가\n📊 {title} ({chart_type})\n🆔 ChartID: {chart_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_delete_chart(spreadsheet_id: str, chart_id: int) -> str:
    """차트 삭제."""
    try:
        req = {"deleteEmbeddedObject": {"objectId": chart_id}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 차트 삭제: {chart_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 이름 있는 범위 (Named Range)
# ============================================================

@mcp.tool()
def sheets_add_named_range(spreadsheet_id: str, name: str, range: str) -> str:
    """이름 있는 범위 생성 (수식에서 명칭으로 참조)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        req = {"addNamedRange": {"namedRange": {"name": name, "range": grid}}}
        result = _batch_update(spreadsheet_id, [req])
        nr_id = result["replies"][0]["addNamedRange"]["namedRange"]["namedRangeId"]
        return f"✅ 이름 있는 범위 추가: {name}\n📍 {range}\n🆔 ID: {nr_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_delete_named_range(spreadsheet_id: str, named_range_id: str) -> str:
    """이름 있는 범위 삭제."""
    try:
        req = {"deleteNamedRange": {"namedRangeId": named_range_id}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 이름 있는 범위 삭제: {named_range_id}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_list_named_ranges(spreadsheet_id: str) -> str:
    """이름 있는 범위 목록."""
    try:
        meta = _sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id, fields="namedRanges"
        ).execute()
        ranges = meta.get("namedRanges", [])
        return json.dumps(ranges, ensure_ascii=False, indent=2) if ranges else "📭 이름 있는 범위 없음"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 조건부 서식 (목록 / 삭제 / 그라데이션)
# ============================================================

@mcp.tool()
def sheets_list_conditional_formats(spreadsheet_id: str, sheet_name: str) -> str:
    """시트의 조건부 서식 규칙 목록."""
    try:
        meta = _sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id, ranges=[sheet_name],
            fields="sheets(conditionalFormats)"
        ).execute()
        rules = meta["sheets"][0].get("conditionalFormats", [])
        return json.dumps(rules, ensure_ascii=False, indent=2) if rules else "📭 조건부 서식 없음"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_clear_conditional_formats(spreadsheet_id: str, sheet_name: str) -> str:
    """시트의 모든 조건부 서식 일괄 삭제."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        meta = _sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id, ranges=[sheet_name],
            fields="sheets(conditionalFormats)"
        ).execute()
        rules = meta["sheets"][0].get("conditionalFormats", [])
        # 인덱스 변경 방지를 위해 뒤에서부터 삭제
        requests = [{"deleteConditionalFormatRule": {"sheetId": sheet_id, "index": i}} for i in range(len(rules) - 1, -1, -1)]
        if requests:
            _batch_update(spreadsheet_id, requests)
        return f"✅ 조건부 서식 {len(rules)}개 삭제\n📍 {sheet_name}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_add_gradient_format(
    spreadsheet_id: str,
    range: str,
    min_hex: str = "F4CCCC",
    mid_hex: Optional[str] = "FFE599",
    max_hex: str = "B6D7A8",
    min_type: str = "MIN",
    max_type: str = "MAX",
    mid_value: Optional[str] = None,
) -> str:
    """그라데이션 조건부 서식 (값에 따라 색 변화).
    min_type/max_type: MIN/MAX/NUMBER/PERCENT/PERCENTILE.
    mid_hex가 None이면 2색 그라데이션, 있으면 3색."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        gradient: dict[str, Any] = {
            "minpoint": {"color": _hex_to_rgb_dict(min_hex), "type": min_type},
            "maxpoint": {"color": _hex_to_rgb_dict(max_hex), "type": max_type},
        }
        if mid_hex:
            mid: dict[str, Any] = {"color": _hex_to_rgb_dict(mid_hex), "type": "PERCENTILE"}
            if mid_value:
                mid["type"] = "NUMBER"; mid["value"] = mid_value
            else:
                mid["value"] = "50"
            gradient["midpoint"] = mid
        rule = {"ranges": [grid], "gradientRule": gradient}
        req = {"addConditionalFormatRule": {"rule": rule, "index": 0}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 그라데이션 조건부 서식 추가\n📍 {range}"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 필터 / 정렬
# ============================================================

@mcp.tool()
def sheets_set_basic_filter(spreadsheet_id: str, range: str) -> str:
    """기본 필터 적용 (헤더 행에 깔때기 표시)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        req = {"setBasicFilter": {"filter": {"range": grid}}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 기본 필터 적용\n📍 {range}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_clear_basic_filter(spreadsheet_id: str, sheet_name: str) -> str:
    """기본 필터 제거."""
    try:
        sheet_id = _get_sheet_id_by_name(spreadsheet_id, sheet_name)
        req = {"clearBasicFilter": {"sheetId": sheet_id}}
        _batch_update(spreadsheet_id, [req])
        return f"✅ 기본 필터 제거\n📍 {sheet_name}"
    except Exception as e:
        return f"❌ 오류: {e}"


@mcp.tool()
def sheets_sort_range(
    spreadsheet_id: str,
    range: str,
    sort_column_index: int,
    ascending: bool = True,
) -> str:
    """범위 정렬 (sort_column_index는 범위 내 0부터)."""
    try:
        grid = _a1_to_grid_range(spreadsheet_id, range)
        req = {
            "sortRange": {
                "range": grid,
                "sortSpecs": [{"dimensionIndex": grid.get("startColumnIndex", 0) + sort_column_index, "sortOrder": "ASCENDING" if ascending else "DESCENDING"}],
            }
        }
        _batch_update(spreadsheet_id, [req])
        return f"✅ 정렬 완료\n📍 {range} (col {sort_column_index}, {'오름차순' if ascending else '내림차순'})"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 일괄 batchUpdate (전문가용 — Raw API 요청 직접 전달)
# ============================================================

@mcp.tool()
def sheets_batch_update_raw(spreadsheet_id: str, requests_json: str) -> str:
    """Google Sheets API의 requests 배열을 JSON 문자열로 받아 일괄 실행.
    여러 서식·구조 변경을 한 번에 처리. 공식 문서:
    https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request"""
    try:
        requests = json.loads(requests_json)
        if not isinstance(requests, list):
            return "❌ requests_json은 list[dict] 형식이어야 합니다."
        result = _batch_update(spreadsheet_id, requests)
        return f"✅ {len(requests)}개 요청 일괄 적용\n응답: {len(result.get('replies', []))}개"
    except Exception as e:
        return f"❌ 오류: {e}"


# ============================================================
# 시작
# ============================================================

if __name__ == "__main__":
    mcp.run()
