"""V열 (통화 외 시간) 수식 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# V3, V4 수식 + 표시값
formulas = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V1:V20",
    valueRenderOption="FORMULA",
).execute().get("values", [])
values = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V1:V20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("V열 수식 + 표시값:")
for ri in range(min(20, len(formulas))):
    f = formulas[ri][0] if ri < len(formulas) and formulas[ri] else ""
    v = values[ri][0] if ri < len(values) and values[ri] else ""
    if f or v:
        print(f"  V{ri+1}: 수식={f[:100]} / 값={v}")

# 1분단위 전체 V열 검사 (행 4-15)
print("\n[V4 ~ V20 표시값]")
for ri in range(3, 20):
    v = values[ri][0] if ri < len(values) and values[ri] else ""
    print(f"  V{ri+1}: {v}")
