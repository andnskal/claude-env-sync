"""1분단위 작동 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW시간대별 — A:B 모든 데이터 (포기호 영역) 확인
print("=" * 70)
print("RAW시간대별 — A3:B30 (포기호 시도/종료 시간) 5/4")
print("=" * 70)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:B30",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    print(f"  Row {ri+3}: {row}")

# Also check raw value (date serial)
print("\n[원시 시리얼값]")
res_raw = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:B30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res_raw):
    print(f"  Row {ri+3}: {row}")

# C-D (김진향 기술) 통화시작/종료
print("\n[C3:D30 — 김진향(기술) 통화시작/종료]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!C3:D30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    print(f"  Row {ri+3}: {row}")

# 5.콜에서 5/4 IB_포기호 데이터 확인
print("\n" + "=" * 70)
print("5.콜 5/4 IB_포기호 (필터 조건 매칭 확인)")
print("=" * 70)
all_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AC2000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# Q='IB_포기호', N='2026-05-04', Y<>'알림톡발송', Z<>'기술부재포기호'
matched = []
for row in all_data:
    if len(row) > 25 and row[13] == "2026-05-04" and row[16] == "IB_포기호":
        Y = row[24] if len(row) > 24 else ""
        Z = row[25] if len(row) > 25 else ""
        if Y != "알림톡발송" and Z != "기술부재포기호":
            matched.append({
                'A': row[0], 'C': row[2], 'D': row[3], 'E': row[4], 
                'F': row[5], 'W': row[22] if len(row)>22 else '',
                'Y': Y, 'Z': Z
            })
print(f"매칭 건수: {len(matched)}")
for m in matched[:10]:
    print(f"  C(시작)={m['C']}, D(연결)={m['D']}, E(종료)={m['E']}, F={m['F']}, W={m['W']}, Z={m['Z']}")
