"""체인 최종 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 5/8
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("[1.일별 5/8]")
for row in res:
    if row and isinstance(row[0], str) and "2026-05-08" in row[0]:
        print(f"  P (응대호): {row[15]}")
        print(f"  Q (포기호): {row[16]}")
        print(f"  H (채널톡 답변): {row[7]}")
        print(f"  M (기술이관): {row[12]}")
        print(f"  AC (OB 성공): {row[28]}")
        print(f"  AE (콜백 신청): {row[30]}")
        print(f"  AI (콜백 처리): {row[34]}")
        break

# 직접 카운트 비교
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_p = defaultdict(int)
date_h = defaultdict(int)
date_m = defaultdict(int)
date_ac = defaultdict(int)
for row in all_calls:
    if len(row) > 29:
        N, Q, AC, AD = row[13], row[16], row[28], row[29]
        if N and AD == "내":
            if Q == "IB_성공": date_p[N] += 1
            elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
                date_ac[N] += 1

for row in all_chats:
    if len(row) > 25:
        O, M, Y, Z = row[14], row[12], row[24], row[25]
        if O and Z == "내" and Y == "Y":
            if M == "채널톡": date_h[O] += 1
            elif M == "기술이관": date_m[O] += 1

print("\n[직접 카운트 vs 시트]")
mismatches = 0
for row in res:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        date = row[0]
        for ci, key, val in [(15, "P", date_p), (7, "H", date_h), (12, "M", date_m), (28, "AC", date_ac)]:
            actual = row[ci] if len(row) > ci else 0
            expected = val[date]
            if actual != expected:
                mismatches += 1
                print(f"  ❌ {date} {key}={actual} vs {expected}")
if mismatches == 0:
    print("  ✅ 모든 KPI 일치")

# 시트 목록
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
print(f"\n[총 시트: {len(meta.get('sheets',[]))}개]")
for s in meta.get("sheets", []):
    print(f"  - {s['properties']['title']}")
