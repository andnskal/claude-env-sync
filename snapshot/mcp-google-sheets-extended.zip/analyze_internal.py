"""본사 직원 RAW 55 입력 분석 - 인입 경로별, 운영시간별."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW 55 모든 데이터 (H, J, K, M)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:M10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
# H (인입경로) × J (담당자 카테고리) 매트릭스
matrix = defaultdict(lambda: defaultdict(int))
for row in res:
    if len(row) > 5:
        H = row[0]  # 인입 경로
        J = row[2] if len(row) > 2 else ""  # 요청자한글
        K = row[3] if len(row) > 3 else ""  # 기술이관
        M = row[5] if len(row) > 5 else ""  # 신 날짜
        if K != "기술이관": continue
        # 직원 분류
        if J.startswith("TCK_") or J.startswith("CS쉐어링_"):
            cat = "외주 (TCK/CS쉐어링)"
        elif J.startswith("CS_"):
            cat = "본사 CS"
        elif J.startswith("CX_"):
            cat = "본사 CX"
        elif J.startswith("기술_"):
            cat = "본사 기술"
        elif J.startswith("@@"):
            cat = "미매핑"
        else:
            cat = "기타 매핑"
        matrix[H][cat] += 1

print("[H 인입경로 × J 직원분류 매트릭스 (전체 7528건)]")
print(f"\n{'인입경로':>10} | {'외주':>10} | {'본사 CS':>8} | {'본사 CX':>8} | {'본사 기술':>8} | {'기타':>8} | {'미매핑':>10} | {'총':>8}")
print("-" * 100)
hh_total = defaultdict(int)
for h in sorted(matrix.keys()):
    row_total = sum(matrix[h].values())
    print(f"{h:>10} | {matrix[h]['외주 (TCK/CS쉐어링)']:>10} | {matrix[h]['본사 CS']:>8} | {matrix[h]['본사 CX']:>8} | {matrix[h]['본사 기술']:>8} | {matrix[h]['기타 매핑']:>8} | {matrix[h]['미매핑']:>10} | {row_total:>8}")
    for k, v in matrix[h].items():
        hh_total[k] += v

print(f"\n{'합계':>10} | {hh_total['외주 (TCK/CS쉐어링)']:>10} | {hh_total['본사 CS']:>8} | {hh_total['본사 CX']:>8} | {hh_total['본사 기술']:>8} | {hh_total['기타 매핑']:>8} | {hh_total['미매핑']:>10} | {sum(hh_total.values()):>8}")

# 4/30 이후 (신 시스템 운영 기간)
print("\n\n[4/30 이후 (신 시스템 백필 기간) 매트릭스]")
matrix_new = defaultdict(lambda: defaultdict(int))
for row in res:
    if len(row) > 5:
        H = row[0]
        J = row[2] if len(row) > 2 else ""
        K = row[3] if len(row) > 3 else ""
        M = row[5] if len(row) > 5 else ""
        if K != "기술이관" or not M or "2026" not in M: continue
        if M < "2026-04-30": continue
        if J.startswith("TCK_") or J.startswith("CS쉐어링_"):
            cat = "외주"
        elif J.startswith("CS_") or J.startswith("CX_") or J.startswith("기술_"):
            cat = "본사"
        elif J.startswith("@@"):
            cat = "미매핑"
        else:
            cat = "기타"
        matrix_new[H][cat] += 1

print(f"\n{'인입경로':>10} | {'외주':>8} | {'본사':>8} | {'기타':>8} | {'미매핑':>10} | {'총':>8}")
print("-" * 70)
for h in sorted(matrix_new.keys()):
    row_total = sum(matrix_new[h].values())
    print(f"{h:>10} | {matrix_new[h]['외주']:>8} | {matrix_new[h]['본사']:>8} | {matrix_new[h]['기타']:>8} | {matrix_new[h]['미매핑']:>10} | {row_total:>8}")
