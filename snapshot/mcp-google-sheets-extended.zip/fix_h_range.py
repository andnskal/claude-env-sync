"""H 컬럼 시작 행 H4 → H2 정정."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# O2: H4:H → H2:H
o2 = '=ARRAYFORMULA(IF(ISBLANK(\'★설정\'!H2:H),,SPLIT(\'★설정\'!H2:H,"_",TRUE,TRUE)))'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!O2",
    valueInputOption="USER_ENTERED",
    body={"values": [[o2]]},
).execute()
print("OK O2: H2:H로 정정")

time.sleep(5)

# J2도 동일 정정 — P 컬럼 매칭 (이름)
j2 = ('=ARRAYFORMULA(IF(ISBLANK(C2:C),,'
      'IFERROR(XLOOKUP(C2:C&"",P2:P&"",O2:O&"_"&P2:P),'
      '"@@"&TRIM(C2:C)&"_미매핑")))')
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2",
    valueInputOption="USER_ENTERED",
    body={"values": [[j2]]},
).execute()
print("OK J2: 동일 유지 (P 컬럼 매칭)")

time.sleep(8)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!I1:Q8",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
labels_idx = {0:'I', 1:'J', 2:'K', 3:'L', 4:'M', 5:'N', 6:'O', 7:'P', 8:'Q'}
print("\n[I-Q 결과]")
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+1}: {row[:9]}")

# J 매핑 분포
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2:J10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
j_dist = Counter(r[0][:30] for r in res if r and r[0])
matched = sum(v for k, v in j_dist.items() if not k.startswith("@@"))
unmatched = sum(v for k, v in j_dist.items() if k.startswith("@@"))
print(f"\n[J 매핑 결과]")
print(f"  매핑 성공: {matched}건")
print(f"  매핑 실패: {unmatched}건")
print(f"\n매핑 성공 상위 10:")
for k, v in j_dist.most_common(20):
    if not k.startswith("@@"):
        print(f"  {k}: {v}건")
print(f"\n매핑 실패 상위 5 (★설정 H에 추가 필요):")
fail_count = 0
for k, v in j_dist.most_common():
    if k.startswith("@@") and fail_count < 5:
        print(f"  {k}: {v}건")
        fail_count += 1
