"""5분단위 — MAP 안에서 작동하는 형식으로 재작성."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 단순한 형식: ('RAW!$A<>"") * (LEFT...) * (HOUR/MINUTE 비교)
# IFERROR을 SUMPRODUCT 외부에 추가하여 안정성 확보
def make_5min_formula(raw_a, raw_b):
    """5분 bucket. SUMPRODUCT-friendly 형식."""
    return (
        f'=MAP($C$4:$C$135, LAMBDA(일시, '
        f'IF(일시="",, '
        f'IFERROR('
        f'IF(SUMPRODUCT('
        f'(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300<>"")*'
        f'(LEFT(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300,10)=LEFT(일시,10))*'
        f'((HOUR(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300))<HOUR(일시)*60+MINUTE(일시)+5)*'
        f'((HOUR(\'RAW시간대별 포기호, 통화상세\'!${raw_b}$3:${raw_b}$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!${raw_b}$3:${raw_b}$300))>=HOUR(일시)*60+MINUTE(일시))'
        f')>0,"********",""), "")))'
    )

# E4
e4 = make_5min_formula("A", "B")
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E4",
    valueInputOption="USER_ENTERED",
    body={"values": [[e4]]},
).execute()

# F4:T4
agent_starts = ['C', 'E', 'G', 'I', 'K', 'M', 'O', 'Q', 'S', 'U', 'W', 'Y', 'AA', 'AC', 'AE']
agent_ends   = ['D', 'F', 'H', 'J', 'L', 'N', 'P', 'R', 'T', 'V', 'X', 'Z', 'AB', 'AD', 'AF']
oneminute_letters = ['F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T']

for letter, raw_a, raw_b in zip(oneminute_letters, agent_starts, agent_ends):
    formula = make_5min_formula(raw_a, raw_b)
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'5분 단위 포기호, 통화상세'!{letter}4",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
print(f"✅ E4 + F4:T4 재작성 (IFERROR 보호)")

time.sleep(8)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A4:V25",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[5분단위 9:00~12:00 (수정 후)]")
print(f"{'행':>4} | {'시간':>6} | {'통화중':>4} | {'포기호':>10} | {'F':>10} | {'G':>10} | {'H':>10} | {'I':>10}")
for ri, row in enumerate(res):
    if not row: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    e = row[4] if len(row) > 4 else ""
    f = row[5] if len(row) > 5 else ""
    g = row[6] if len(row) > 6 else ""
    h = row[7] if len(row) > 7 else ""
    i = row[8] if len(row) > 8 else ""
    print(f"{ri+4:>4} | {time_str:>6} | {counta:>4} | {e:>10} | {f:>10} | {g:>10} | {h:>10} | {i:>10}")
