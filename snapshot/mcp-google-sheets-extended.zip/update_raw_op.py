"""RAW시간대별 + 1분단위/5분단위 — 포기호 데이터에 운영시간 필터 적용."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW시간대별 A3 수식: IB_포기호 데이터에서 운영시간 외 제외
new_a3 = (
    "=IFERROR(FILTER({"
    "'5.콜 상담내역'!C2:C,"
    "'5.콜 상담내역'!E2:E},"
    "'5.콜 상담내역'!Q2:Q=" + '"IB_포기호"' + ","
    "'5.콜 상담내역'!Z2:Z<>" + '"기술부재포기호"' + ","
    "'5.콜 상담내역'!Y2:Y<>" + '"알림톡발송"' + ","
    "'5.콜 상담내역'!AD2:AD=" + '"내"' + ","
    "'5.콜 상담내역'!N2:N=TEXT('1분 단위 포기호, 통화상세'!$E$2," + '"YYYY-MM-DD"' + ")),)"
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_a3]]},
).execute()
print("OK RAW시간대별 A3 (포기호) 운영시간 필터 추가")

# RAW시간대별 C3 ~ AE3 (각 상담사 통화시작/종료) - 모든 통화는 운영시간 무관 (그대로)
# 통화 자체는 운영시간 외에도 발생할 수 있으나, 상담사가 응답한 콜 기준이므로
# IB_성공/OB_성공만 표시. 운영시간 필터를 추가해야 1분단위와 일관됨.
agent_starts = ['C', 'E', 'G', 'I', 'K', 'M', 'O', 'Q', 'S', 'U', 'W', 'Y', 'AA', 'AC', 'AE']

for raw_start in agent_starts:
    formula = (
        "=IFERROR(IF(ISBLANK(" + raw_start + "1),,"
        "FILTER({"
        "'5.콜 상담내역'!D2:D,"
        "'5.콜 상담내역'!E2:E},"
        "'5.콜 상담내역'!W2:W=" + raw_start + "1,"
        "('5.콜 상담내역'!Q2:Q=" + '"IB_성공"' + ")+('5.콜 상담내역'!Q2:Q=" + '"OB_성공"' + "),"
        "'5.콜 상담내역'!AD2:AD=" + '"내"' + ","
        "'5.콜 상담내역'!N2:N=TEXT('1분 단위 포기호, 통화상세'!$E$2," + '"YYYY-MM-DD"' + "))),)"
    )
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'RAW시간대별 포기호, 통화상세'!{raw_start}3",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
print(f"OK RAW시간대별 15명 상담사 컬럼 운영시간 필터 추가")

# 1분단위 F3 (동적 상담사 헤더) — 운영시간 내 상담사만
new_f3 = (
    "=IFERROR(TRANSPOSE(SORT(UNIQUE(FILTER("
    "'5.콜 상담내역'!W2:W,"
    "'5.콜 상담내역'!W2:W<>" + '""' + ","
    "'5.콜 상담내역'!W2:W<>" + '"기타"' + ","
    "'5.콜 상담내역'!N2:N=TEXT($E$2," + '"YYYY-MM-DD"' + "),"
    "('5.콜 상담내역'!Q2:Q=" + '"IB_성공"' + ")+('5.콜 상담내역'!Q2:Q=" + '"OB_성공"' + "),"
    "'5.콜 상담내역'!AD2:AD=" + '"내"' + ")),1,TRUE)),)"
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!F3",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_f3]]},
).execute()
print("OK 1분단위 F3 동적 상담사 헤더 운영시간 필터 추가")

# 5분단위 F3 동일
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!F3",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_f3]]},
).execute()
print("OK 5분단위 F3 동적 헤더 운영시간 필터 추가")

time.sleep(8)

# 검증
print("\n[5/8 검증]")
# 1분단위 E2 = 5/8
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
    valueInputOption="USER_ENTERED",
    body={"values": [["46150"]]},
).execute()
time.sleep(8)

raw_a = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
cnt = sum(1 for r in raw_a if r and r[0])
print(f"  RAW시간대별 5/8 포기호 (운영시간 내, 알림톡/기술 제외): {cnt}건")

one_min = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E4:E513",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
one_cnt = sum(1 for r in one_min if r and "*" in (r[0] if r else ""))
print(f"  1분단위 5/8 포기호 매칭 분: {one_cnt}분")

agents = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!F3:T3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if agents and agents[0]:
    active = [a for a in agents[0] if a]
    print(f"  활동 상담사 (운영시간 내): {len(active)}명: {active[:5]}...")
