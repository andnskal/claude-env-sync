"""삭제된 수식 재적용 + ★설정 H 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ★설정 H 컬럼 전체 (4행부터)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!H1:H50",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[★설정 H 컬럼 (담당자)]")
for ri, r in enumerate(res):
    if r and r[0]:
        print(f"  H{ri+1}: {r[0]}")

# RAW 55 N, O, P 수식 다시 입력
print("\n[N, O, P 수식 재입력]")

# N2: 운영시간 분류
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!N2",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(ISBLANK(C2:C),,"내"))']]},
).execute()

# O2: 팀 + P (이름) — SPLIT
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!O2",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(ISBLANK(\'★설정\'!H4:H),,SPLIT(\'★설정\'!H4:H,"_",TRUE,TRUE)))']]},
).execute()

print("  OK")
time.sleep(5)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!M1:Q10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[M-Q 결과]")
for ri, row in enumerate(res):
    print(f"  Row {ri+1}: {row}")

# J 매핑 재확인
time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!I1:L10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[I-L 결과]")
for ri, row in enumerate(res):
    print(f"  Row {ri+1}: {row}")
