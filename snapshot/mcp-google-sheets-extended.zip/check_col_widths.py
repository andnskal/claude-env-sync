"""모든 시트 열 너비 점검."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# 모든 시트 메타 (column metadata 포함)
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties,data(columnMetadata))"
).execute()

for s in meta.get("sheets", []):
    name = s["properties"]["title"]
    if name == "시트1":
        continue
    
    data = s.get("data", [])
    if data and "columnMetadata" in data[0]:
        cols = data[0]["columnMetadata"]
        # 사용 중인 컬럼 (값이 있는 컬럼)만 표시
        max_col = s["properties"]["gridProperties"].get("columnCount", 0)
        widths = [c.get("pixelSize", 100) for c in cols[:max_col]]
        
        # 100 (default), 또는 다른 값들
        unique_widths = {}
        for ci, w in enumerate(widths):
            if w in unique_widths:
                unique_widths[w].append(col_letter(ci))
            else:
                unique_widths[w] = [col_letter(ci)]
        
        print(f"\n📋 {name} ({len(widths)}열)")
        for w, cols_list in sorted(unique_widths.items()):
            cols_str = ', '.join(cols_list[:8])
            if len(cols_list) > 8:
                cols_str += f"... 총 {len(cols_list)}개"
            print(f"  {w}px: {cols_str}")
