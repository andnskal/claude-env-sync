"""XLOOKUP에 DATEVALUE 추가하여 텍스트 날짜 ↔ DATE 시리얼 매칭."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 AD 수식 — DATEVALUE 추가
new_ad = (
    '=ARRAYFORMULA(IF(N2:N="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",X2:X)),"외",'
    'IF('
    '(HOUR(C2:C)*60+MINUTE(C2:C)>=540)*(HOUR(C2:C)*60+MINUTE(C2:C)<1050)*'
    '((HOUR(C2:C)*60+MINUTE(C2:C)<'
    '(HOUR(IFNA(XLOOKUP(DATEVALUE(N2:N),\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))*60+'
    'MINUTE(IFNA(XLOOKUP(DATEVALUE(N2:N),\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))))+'
    '(HOUR(C2:C)*60+MINUTE(C2:C)>='
    '(HOUR(IFNA(XLOOKUP(DATEVALUE(N2:N),\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2))*60+'
    'MINUTE(IFNA(XLOOKUP(DATEVALUE(N2:N),\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2)))))'
    ',"내","외"))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_ad]]},
).execute()
print("OK 5.콜 AD2 수정 (DATEVALUE 추가)")

# 6.채팅 Z 동일
new_z = (
    '=ARRAYFORMULA(IF(O2:O="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",K2:K)),"외",'
    'IF('
    '(HOUR(B2:B)*60+MINUTE(B2:B)>=540)*(HOUR(B2:B)*60+MINUTE(B2:B)<1050)*'
    '((HOUR(B2:B)*60+MINUTE(B2:B)<'
    '(HOUR(IFNA(XLOOKUP(DATEVALUE(O2:O),\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))*60+'
    'MINUTE(IFNA(XLOOKUP(DATEVALUE(O2:O),\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))))+'
    '(HOUR(B2:B)*60+MINUTE(B2:B)>='
    '(HOUR(IFNA(XLOOKUP(DATEVALUE(O2:O),\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2))*60+'
    'MINUTE(IFNA(XLOOKUP(DATEVALUE(O2:O),\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2)))))'
    ',"내","외"))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_z]]},
).execute()
print("OK 6.채팅 Z2 수정")

time.sleep(8)

# 검증
print("\n[5/11 11:50-13:00 시간대 콜 재검증]")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

count_in = 0
count_out = 0
mismatches = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h*60+m
    except:
        continue
    if 710 <= tm < 780:  # 11:50-13:00 (예외 점심)
        ad = row[29]
        if ad == "외": count_out += 1
        else: 
            count_in += 1
            mismatches += 1

print(f"  5/11 11:50-13:00 콜 분류:")
print(f"    '외' (점심으로 정상 분류): {count_out}건")
print(f"    '내' (잘못 분류): {count_in}건 {'❌' if count_in > 0 else '✅'}")

# 5/11 12:50-14:00 시간대 (기본 점심이지만 예외 적용일 → '내'여야)
print(f"\n[5/11 13:00-14:00 (기본 점심 시간이지만 예외 적용일) 콜 분류]")
print(f"  → 5/11은 예외(11:50-13:00) 적용이므로 13:00-14:00은 '내'여야 정상")
post_lunch_in = 0
post_lunch_out = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h*60+m
    except:
        continue
    if 780 <= tm < 840:  # 13:00-14:00
        if row[29] == "외": post_lunch_out += 1
        else: post_lunch_in += 1
print(f"  '내' (정상): {post_lunch_in}건")
print(f"  '외' (잘못): {post_lunch_out}건")

# 5/8 이윤애 재검증 (기본 점심 12:50-14:00)
print(f"\n[5/8 이윤애 IB_성공 재검증 (점심 12:50-14:00 기본)]")
in_5_8 = 0
out_5_8 = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08" or row[22] != "CS_이윤애" or row[16] != "IB_성공": continue
    if row[29] == "내": in_5_8 += 1
    elif row[29] == "외": out_5_8 += 1
print(f"  운영시간 내: {in_5_8}건 (채널톡 = 15건)")
print(f"  운영시간 외: {out_5_8}건")
print(f"  → {'✅ 일치' if in_5_8 == 15 else '❌ 불일치'}")
