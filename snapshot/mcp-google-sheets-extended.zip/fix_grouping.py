"""기존 그룹 모두 삭제 후 nested 구조로 재적용 (depth 1 + depth 2)."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 1) 기존 모든 그룹 삭제
print("[1] 기존 그룹 조회 + 삭제")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties,columnGroups)"
).execute()
existing_groups = []
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        existing_groups = s.get("columnGroups", [])
        break

print(f"  기존 그룹: {len(existing_groups)}개")
delete_reqs = []
# 깊은 그룹부터 삭제 (depth 큰 것부터)
for g in sorted(existing_groups, key=lambda x: -x.get("depth", 1)):
    r = g["range"]
    delete_reqs.append({
        "deleteDimensionGroup": {
            "range": {
                "sheetId": sid,
                "dimension": "COLUMNS",
                "startIndex": r.get("startIndex", 0),
                "endIndex": r.get("endIndex", 0),
            }
        }
    })
if delete_reqs:
    _batch_update(NEW, delete_reqs)
    print(f"  OK {len(delete_reqs)}개 삭제")
time.sleep(2)

# 2) 새 그룹 적용 - 7개 동급 그룹 (각 카테고리)
# 인접한 그룹은 자동 병합되므로, 각 그룹을 nested 또는 분리 처리해야
# 방법: 카테고리 그룹 끝에 collapse 표시. 하지만 단일 depth는 인접 시 합쳐짐.
# 차선: depth 1로 7개 별도 그룹화 - 인접해도 별도 그룹으로 인식되도록 시도
print("\n[2] 새 그룹 적용 - 7개 카테고리")
groups = [
    (2, 14, "채팅"),       # C-N
    (14, 26, "IB"),        # O-Z
    (26, 34, "OB"),        # AA-AH
    (34, 36, "콜백"),       # AI-AJ
    (36, 39, "KPI"),       # AK-AM
    (39, 46, "부재중사유"),  # AN-AT
    (46, 49, "참고"),       # AU-AW
]
add_reqs = []
for start, end, label in groups:
    add_reqs.append({
        "addDimensionGroup": {
            "range": {
                "sheetId": sid,
                "dimension": "COLUMNS",
                "startIndex": start,
                "endIndex": end,
            }
        }
    })
_batch_update(NEW, add_reqs)
time.sleep(3)

# 3) 결과 확인
print("\n[3] 결과 확인")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties,columnGroups)"
).execute()
def cl(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        groups_now = s.get("columnGroups", [])
        print(f"  적용된 그룹: {len(groups_now)}개")
        for g in groups_now:
            r = g["range"]
            si = r.get("startIndex", 0)
            ei = r.get("endIndex", 0)
            depth = g.get("depth", 0)
            print(f"  - {cl(si)}-{cl(ei-1)} depth={depth}")
        break
