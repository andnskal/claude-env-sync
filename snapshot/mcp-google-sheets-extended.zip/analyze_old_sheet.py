"""이전 시트의 5.콜 데이터로 정확한 시간대 분포 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 이전 시트 5.콜 데이터 전체
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'5.콜 상담내역'!A2:U10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"이전 시트 5.콜 총 행수: {len(all_calls)}")

# 날짜 분포 확인
from collections import Counter, defaultdict
date_counter = Counter()
for row in all_calls:
    if len(row) > 12 and row[12]:
        date_counter[row[12]] += 1
print(f"\n날짜별 분포:")
for d in sorted(date_counter.keys())[:15]:
    print(f"  {d}: {date_counter[d]}건")
print(f"  ... 등 총 {len(date_counter)}개 일자")
print(f"  최초: {min(date_counter.keys())}")
print(f"  최종: {max(date_counter.keys())}")

# 모든 IB_포기호의 시간대 분포
section_aban = defaultdict(int)
section_succ = defaultdict(int)

def get_section(hour):
    if hour < 6: return "🌙 새벽 (00-06)"
    elif hour < 9: return "🌅 이른 아침 (06-09)"
    elif hour < 12: return "☀️ 오전 (09-12)"
    elif hour < 14: return "🍱 점심대 (12-14)"
    elif hour < 17: return "📞 오후 (14-17)"
    elif hour < 19: return "🌆 17시 이후 (17-19)"
    else: return "🌙 야간 (19-24)"

# 이전 시트 컬럼: B=direction, C=startedAt, M=날짜, Q=구분
total_inbound = 0
for row in all_calls:
    if len(row) < 17: continue
    B = row[1] if len(row) > 1 else ""
    C = row[2] if len(row) > 2 else ""
    Q = row[16] if len(row) > 16 else ""
    
    if B not in ("inbound", "missed"): continue
    total_inbound += 1
    
    # 시간 파싱
    hour = None
    if isinstance(C, str) and " " in C:
        try:
            hour = int(C.split(" ")[1].split(":")[0])
        except:
            pass
    
    if hour is None: continue
    
    sec = get_section(hour)
    if Q == "IB_성공":
        section_succ[sec] += 1
    elif Q == "IB_포기호":
        section_aban[sec] += 1

# 전체 IB 시간대 분포
print(f"\n전체 IB 콜 수: {total_inbound}")
print(f"IB_성공 분류: {sum(section_succ.values())}")
print(f"IB_포기호 분류: {sum(section_aban.values())}")

# 분포 출력
print("\n" + "=" * 100)
print("이전 시트 전체 데이터 — IB_포기호 시간대 분포")
print("=" * 100)
print(f"{'구간':>35} | {'IB_성공':>8} | {'IB_포기호':>10} | {'비중':>8}")
print("-" * 100)

total_aban = sum(section_aban.values())
total_succ = sum(section_succ.values())

for sec in ["🌙 새벽 (00-06)", "🌅 이른 아침 (06-09)", "☀️ 오전 (09-12)",
            "🍱 점심대 (12-14)", "📞 오후 (14-17)", "🌆 17시 이후 (17-19)", "🌙 야간 (19-24)"]:
    s = section_succ[sec]
    a = section_aban[sec]
    pct = a / total_aban * 100 if total_aban else 0
    indicator = ""
    if "새벽" in sec or "야간" in sec or "이른 아침" in sec:
        indicator = "← 운영시간 명백히 외"
    elif "17시 이후" in sec:
        indicator = "← 17:30 이후 일부"
    elif "점심" in sec:
        indicator = "← ★설정상 운영시간"
    print(f"  {sec:>32} | {s:>8} | {a:>10} | {pct:>6.1f}% | {indicator}")

print("-" * 100)
print(f"  {'합계':>32} | {total_succ:>8} | {total_aban:>10}")

# 구간별 핵심
print("\n[객관적 사실]")
night = section_aban["🌙 새벽 (00-06)"] + section_aban["🌅 이른 아침 (06-09)"] + section_aban["🌙 야간 (19-24)"]
lunch = section_aban["🍱 점심대 (12-14)"]
evening = section_aban["🌆 17시 이후 (17-19)"]
operating = section_aban["☀️ 오전 (09-12)"] + section_aban["📞 오후 (14-17)"]

print(f"  새벽/이른아침/야간 IB_포기호: {night}건 ({night/total_aban*100:.1f}%) — '야간/새벽' 정당성")
print(f"  점심대 IB_포기호: {lunch}건 ({lunch/total_aban*100:.1f}%) — ★설정상 운영시간")
print(f"  17시 이후 IB_포기호: {evening}건 ({evening/total_aban*100:.1f}%) — 17:30 이후만 운영 외")
print(f"  운영시간 명백 내: {operating}건 ({operating/total_aban*100:.1f}%)")
