"""2.시간대별 AE 수식 수정 - 채널 제한 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 새 AE: 채널 = 카카오 + 네이버 + 채널톡 만 카운트
new_ae = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    '(COUNTIFS(\'6.채팅 상담내역\'!$O:$O,d,\'6.채팅 상담내역\'!$Q:$Q,t,'
    '\'6.채팅 상담내역\'!$M:$M,"카카오",'
    '\'6.채팅 상담내역\'!$Y:$Y,"Y",'
    '\'6.채팅 상담내역\'!$Z:$Z,"내",'
    '\'6.채팅 상담내역\'!$N:$N,"<>기타",'
    '\'6.채팅 상담내역\'!$N:$N,"<>")'
    '+COUNTIFS(\'6.채팅 상담내역\'!$O:$O,d,\'6.채팅 상담내역\'!$Q:$Q,t,'
    '\'6.채팅 상담내역\'!$M:$M,"네이버",'
    '\'6.채팅 상담내역\'!$Y:$Y,"Y",'
    '\'6.채팅 상담내역\'!$Z:$Z,"내",'
    '\'6.채팅 상담내역\'!$N:$N,"<>기타",'
    '\'6.채팅 상담내역\'!$N:$N,"<>")'
    '+COUNTIFS(\'6.채팅 상담내역\'!$O:$O,d,\'6.채팅 상담내역\'!$Q:$Q,t,'
    '\'6.채팅 상담내역\'!$M:$M,"채널톡",'
    '\'6.채팅 상담내역\'!$Y:$Y,"Y",'
    '\'6.채팅 상담내역\'!$Z:$Z,"내",'
    '\'6.채팅 상담내역\'!$N:$N,"<>기타",'
    '\'6.채팅 상담내역\'!$N:$N,"<>")'
    ')))))'
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!AE4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_ae]]},
).execute()
print("OK 2.시간대별 AE4 수정 (채널 카카오+네이버+채널톡 제한)")

time.sleep(8)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:AL14",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[2.시간대별 4/30 시간대별 채팅 검증]")
print(f"{'시간':>6} | {'AB 인입':>6} | {'AC 답변':>6} | {'AD 답변율':>8} | {'AE 답변(본+외)':>10} | {'AF 기여도':>8}")
for row in res:
    if not row or len(row) < 32: continue
    if row[1] != "2026-04-30": continue
    time_str = row[2]
    AB = row[27] if len(row) > 27 else "?"
    AC = row[28] if len(row) > 28 else "?"
    AD = row[29] if len(row) > 29 else "?"
    AE = row[30] if len(row) > 30 else "?"
    AF = row[31] if len(row) > 31 else "?"
    print(f"{time_str:>6} | {AB:>6} | {AC:>6} | {AD:>8} | {AE:>10} | {AF:>8}")
