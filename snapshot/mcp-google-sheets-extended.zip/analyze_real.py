"""실제 데이터 (5/4-5/8)로 시간대 분포 객관 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict

# 5/4-5/8 모든 IB 콜 시간대 분포
section_aban = defaultdict(int)
section_succ = defaultdict(int)
section_aban_op = defaultdict(int)
section_aban_alert = defaultdict(int)

def get_section(hour):
    if hour < 6: return "🌙 새벽 (00-06)"
    elif hour < 9: return "🌅 이른 아침 (06-09)"
    elif hour < 12: return "☀️ 오전 (09-12)"
    elif hour < 14: return "🍱 점심대 (12-14)"
    elif hour < 17: return "📞 오후 (14-17)"
    elif hour < 19: return "🌆 17시 이후 (17-19)"
    else: return "🌙 야간 (19-24)"

dates = ["2026-05-04", "2026-05-06", "2026-05-07", "2026-05-08"]

for row in all_calls:
    if len(row) < 30: continue
    if row[13] not in dates: continue
    B = row[1] if len(row) > 1 else ""
    if B != "inbound": continue
    
    Q = row[16] if len(row) > 16 else ""
    C = row[2] if len(row) > 2 else ""
    X = row[23] if len(row) > 23 else ""
    Y = row[24] if len(row) > 24 else ""
    
    try:
        hour = int(C.split(" ")[1].split(":")[0])
    except:
        continue
    
    sec = get_section(hour)
    if Q == "IB_성공":
        section_succ[sec] += 1
    elif Q == "IB_포기호":
        section_aban[sec] += 1
        if "운영시간아님" in X: section_aban_op[sec] += 1
        if Y == "알림톡발송": section_aban_alert[sec] += 1

# 출력
print("=" * 100)
print(f"5/4-5/8 (4일치) IB 콜 시간대별 분포")
print("=" * 100)
print(f"{'구간':>35} | {'성공':>5} | {'포기호':>6} | {'운영외태그':>10} | {'알림톡':>6} | 의미")
print("-" * 100)

total_aban = sum(section_aban.values())
total_succ = sum(section_succ.values())
total_op = sum(section_aban_op.values())
total_alert = sum(section_aban_alert.values())

for sec in ["🌙 새벽 (00-06)", "🌅 이른 아침 (06-09)", "☀️ 오전 (09-12)",
            "🍱 점심대 (12-14)", "📞 오후 (14-17)", "🌆 17시 이후 (17-19)", "🌙 야간 (19-24)"]:
    s = section_succ[sec]
    a = section_aban[sec]
    ao = section_aban_op[sec]
    al = section_aban_alert[sec]
    pct = a / total_aban * 100 if total_aban else 0
    print(f"  {sec:>32} | {s:>5} | {a:>6} | {ao:>10} | {al:>6} | {pct:>5.1f}% 차지")

print("-" * 100)
print(f"  {'합계':>32} | {total_succ:>5} | {total_aban:>6} | {total_op:>10} | {total_alert:>6}")

print("\n" + "=" * 100)
print("🎯 객관적 분석 결과")
print("=" * 100)

# 운영시간 외 = 우리 정의로 09:00 미만 + 17:30 이후 + X태그
true_off_hour = (
    section_aban["🌙 새벽 (00-06)"] +
    section_aban["🌅 이른 아침 (06-09)"] +
    section_aban["🌆 17시 이후 (17-19)"] +
    section_aban["🌙 야간 (19-24)"]
)
during_lunch = section_aban["🍱 점심대 (12-14)"]
during_operating = section_aban["☀️ 오전 (09-12)"] + section_aban["📞 오후 (14-17)"]

print(f"\n전체 IB_포기호: {total_aban}건")
print(f"\n구간별 비중:")
print(f"  운영시간 명백 외 (새벽+이른아침+저녁+야간): {true_off_hour}건 ({true_off_hour/total_aban*100:.1f}%)")
print(f"  점심대 (12-14): {during_lunch}건 ({during_lunch/total_aban*100:.1f}%)")
print(f"  운영시간 명백 내 (09-12, 14-17): {during_operating}건 ({during_operating/total_aban*100:.1f}%)")
print(f"  채널톡 X태그 '운영시간아님': {total_op}건 ({total_op/total_aban*100:.1f}%)")

print(f"\n구간 비율로 본 핵심:")
night_dawn = section_aban["🌙 새벽 (00-06)"] + section_aban["🌅 이른 아침 (06-09)"] + section_aban["🌙 야간 (19-24)"]
print(f"  '야간/새벽' 표현 정당성: {night_dawn}건 ({night_dawn/total_aban*100:.1f}%)")
print(f"  '점심' 표현 정당성: {during_lunch}건 ({during_lunch/total_aban*100:.1f}%) — ★설정 정의상 점심도 운영시간")
print(f"  '17:30 이후' 영향: {section_aban['🌆 17시 이후 (17-19)']}건 ({section_aban['🌆 17시 이후 (17-19)']/total_aban*100:.1f}%)")
