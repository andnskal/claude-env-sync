"""신 시스템 전체 시트 종합 진단 — 1단계: 메타정보 + 오류 셀 탐지."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# 모든 시트 정보
meta = _sheets.spreadsheets().get(spreadsheetId=NEW, includeGridData=False).execute()

print("=" * 80)
print("📋 1. 시트 목록 및 메타정보")
print("=" * 80)

sheets_info = []
for s in meta.get("sheets", []):
    p = s["properties"]
    g = p["gridProperties"]
    info = {
        "name": p["title"],
        "id": p["sheetId"],
        "rows": g.get("rowCount", 0),
        "cols": g.get("columnCount", 0),
        "frozenRows": g.get("frozenRowCount", 0),
        "frozenCols": g.get("frozenColumnCount", 0),
        "hidden": p.get("hidden", False),
    }
    sheets_info.append(info)
    print(f"  📄 {info['name']:<30} | {info['rows']}행×{info['cols']}열 | 동결: {info['frozenRows']}r/{info['frozenCols']}c | {'(숨김)' if info['hidden'] else ''}")

# 오류 셀 탐지
print("\n" + "=" * 80)
print("🔍 2. 오류 셀 탐지 (모든 시트)")
print("=" * 80)

ERROR_PATTERNS = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")

total_errors = 0
errors_by_sheet = {}

for info in sheets_info:
    name = info["name"]
    if name == "시트1":
        continue
    
    rows = min(info["rows"], 600)
    cols = min(info["cols"], 75)
    
    if rows == 0 or cols == 0:
        continue
    
    rng = f"'{name}'!A1:{col_letter(cols-1)}{rows}"
    try:
        result = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute()
    except Exception as e:
        print(f"  ❌ {name}: 읽기 실패 - {str(e)[:100]}")
        continue
    
    values = result.get("values", [])
    sheet_errs = []
    for ri, row in enumerate(values):
        for ci, cell in enumerate(row):
            if isinstance(cell, str):
                for pattern in ERROR_PATTERNS:
                    if pattern in cell:
                        sheet_errs.append((col_letter(ci), ri+1, cell[:60], pattern))
                        break
    
    if sheet_errs:
        errors_by_sheet[name] = sheet_errs
        total_errors += len(sheet_errs)
        print(f"\n  ❌ {name}: {len(sheet_errs)}개 오류")
        # 처음 8개만 표시
        for col, row_num, val, ptn in sheet_errs[:8]:
            print(f"    {col}{row_num} [{ptn}]: {val}")
        if len(sheet_errs) > 8:
            print(f"    ... 그 외 {len(sheet_errs) - 8}개")
    else:
        # 비어있지 않은 행 카운트
        non_empty_rows = sum(1 for r in values if r and any(c for c in r))
        max_data_col = 0
        for r in values:
            if r:
                # 마지막으로 비어있지 않은 셀의 인덱스
                for ci in range(len(r)-1, -1, -1):
                    if r[ci]:
                        max_data_col = max(max_data_col, ci)
                        break
        if non_empty_rows > 0:
            print(f"  ✅ {name}: 오류 없음 ({non_empty_rows}행 데이터, 최대 {col_letter(max_data_col)}열)")

print("\n" + "=" * 80)
print(f"종합: 발견된 오류 {total_errors}개")
print("=" * 80)
