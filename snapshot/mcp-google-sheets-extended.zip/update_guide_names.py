"""가이드 시트의 보조 시트 이름 업데이트."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 통계 시트 가이드 데이터 가져오기 + 옛 이름 새 이름 치환
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'📌 사용 가이드'!A1:C60",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

renames = {
    "_RAW_NewMeet_33": "_보조 콜",
    "_RAW_UserChat_p1": "_보조 채팅 A",
    "_RAW_UserChat_p2": "_보조 채팅 B",
}

new_data = []
changes = 0
for row in res:
    new_row = list(row) if row else []
    for ci, cell in enumerate(new_row):
        if isinstance(cell, str):
            for old, new in renames.items():
                if old in cell:
                    new_row[ci] = cell.replace(old, new)
                    changes += 1
    new_data.append(new_row)

print(f"치환된 셀: {changes}개")

# 다시 입력
if changes > 0:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range="'📌 사용 가이드'!A1",
        valueInputOption="USER_ENTERED",
        body={"values": new_data},
    ).execute()
    print("OK 가이드 업데이트")

# RAW 시트 가이드도 동일
RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"
res = _sheets.spreadsheets().values().get(
    spreadsheetId=RAW, range="'📌 사용 가이드'!A1:C60",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

new_data = []
changes = 0
for row in res:
    new_row = list(row) if row else []
    for ci, cell in enumerate(new_row):
        if isinstance(cell, str):
            for old, new in renames.items():
                if old in cell:
                    new_row[ci] = cell.replace(old, new)
                    changes += 1
    new_data.append(new_row)

print(f"\nRAW 가이드 치환: {changes}개")
if changes > 0:
    _sheets.spreadsheets().values().update(
        spreadsheetId=RAW, range="'📌 사용 가이드'!A1",
        valueInputOption="USER_ENTERED",
        body={"values": new_data},
    ).execute()
    print("OK RAW 가이드 업데이트")

# 최종 검증 - 5/8 데이터 정상 작동 확인
print("\n" + "=" * 80)
print("[수식 자동 업데이트 후 데이터 검증]")
print("=" * 80)
time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in res:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  5/8 P (응대호): {row[15]}")
        print(f"  5/8 Q (포기호 알림제외): {row[16]}")
        print(f"  5/8 H (채널톡 답변): {row[7]}")
        print(f"  5/8 AC (OB 성공): {row[28]}")
        break
