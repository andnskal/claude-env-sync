"""이전 시트 데이터에 정말 야간/점심/새벽 콜이 포함됐는지 객관적 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 신 시스템 5.콜 데이터 (= 이전 시트와 동일 RAW 데이터)
# 채널톡 RAW는 동일하므로 이전 시트의 통계도 같은 RAW 기반
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 4/30 모든 IB_포기호의 시간대 분포 (이전 시트의 Q=146 분석)
from collections import defaultdict

# 시간대별 IB_포기호 분포 (4/30)
ib_aban_by_hour = defaultdict(int)
ib_succ_by_hour = defaultdict(int)
ib_aban_with_op_tag = defaultdict(int)  # 채널톡이 X 태그 "운영시간아님" 부여
ib_aban_alert = defaultdict(int)  # 알림톡발송

for row in all_calls:
    if len(row) < 30: continue
    N = row[13]
    Q = row[16]
    B = row[1]
    if N != "2026-04-30" or B != "inbound": continue
    
    C = row[2]   # startedAt
    X = row[23]  # tags
    Y = row[24]  # 콜백/알림톡
    AD = row[29]  # 운영시간 (우리 정의)
    
    # 시작 시각의 시간 추출
    try:
        time_part = C.split(" ")[1]
        hour = int(time_part.split(":")[0])
    except:
        continue
    
    if Q == "IB_성공":
        ib_succ_by_hour[hour] += 1
    elif Q == "IB_포기호":
        ib_aban_by_hour[hour] += 1
        if "운영시간아님" in str(X):
            ib_aban_with_op_tag[hour] += 1
        if Y == "알림톡발송":
            ib_aban_alert[hour] += 1

print("=" * 100)
print("4/30 IB (inbound) 시간대별 분포 — 이전 시트와 신 시스템 비교")
print("=" * 100)
print(f"{'시간':>6} | {'IB 성공':>8} | {'IB 포기호 (전체)':>15} | {'중 X태그 운영시간외':>15} | {'중 알림톡발송':>13}")
print("-" * 100)

total_succ = 0
total_aban = 0
total_aban_op = 0
total_aban_alert = 0
for h in sorted(set(list(ib_aban_by_hour.keys()) + list(ib_succ_by_hour.keys()))):
    s = ib_succ_by_hour[h]
    a = ib_aban_by_hour[h]
    ao = ib_aban_with_op_tag[h]
    al = ib_aban_alert[h]
    total_succ += s
    total_aban += a
    total_aban_op += ao
    total_aban_alert += al
    indicator = ""
    if h < 9:
        indicator = " ← 새벽/오전"
    elif 12 <= h < 14:
        indicator = " ← 점심시간 가능"
    elif h >= 18:
        indicator = " ← 야간"
    elif h == 17:
        indicator = " ← 17:30 이후 일부"
    print(f"  {h:>4}시 | {s:>8} | {a:>15} | {ao:>15} | {al:>13}{indicator}")

print("-" * 100)
print(f"  {'합계':>4} | {total_succ:>8} | {total_aban:>15} | {total_aban_op:>15} | {total_aban_alert:>13}")

# 구간별 분류
print("\n" + "=" * 100)
print("구간별 4/30 IB_포기호 분류")
print("=" * 100)
sections = {
    "🌙 새벽 (00-06)": 0,
    "☀️ 오전 (07-09)": 0,
    "📞 운영시간 (09-12)": 0,
    "🍱 점심 (12-14)": 0,
    "📞 운영시간 (14-17)": 0,
    "🌆 저녁 (17-19)": 0,
    "🌙 야간 (19-24)": 0,
}
for h, cnt in ib_aban_by_hour.items():
    if h < 7: sections["🌙 새벽 (00-06)"] += cnt
    elif h < 9: sections["☀️ 오전 (07-09)"] += cnt
    elif h < 12: sections["📞 운영시간 (09-12)"] += cnt
    elif h < 14: sections["🍱 점심 (12-14)"] += cnt
    elif h < 17: sections["📞 운영시간 (14-17)"] += cnt
    elif h < 19: sections["🌆 저녁 (17-19)"] += cnt
    else: sections["🌙 야간 (19-24)"] += cnt

for s, c in sections.items():
    pct = c / total_aban * 100 if total_aban else 0
    print(f"  {s:>20}: {c}건 ({pct:.1f}%)")

# 핵심 분석
print("\n" + "=" * 100)
print("핵심 분석")
print("=" * 100)
print(f"이전 시트 Q (4/30) = 146건 (전체 IB_포기호, 알림톡 포함)")
print(f"신 시스템 Q (4/30) = 95건 (운영시간 내 + 알림제외)")
print(f"차이 = 51건")
print(f"\n51건의 구성:")
print(f"  - X태그 '운영시간아님' 콜: {total_aban_op}건")
print(f"  - 알림톡발송 콜: {total_aban_alert}건")
print(f"  - 새벽/야간 콜 (00-09 + 19-24): {sections['🌙 새벽 (00-06)'] + sections['☀️ 오전 (07-09)'] + sections['🌙 야간 (19-24)']}건")
print(f"  - 점심 (12-14): {sections['🍱 점심 (12-14)']}건")
print(f"  - 저녁 (17-19, 17:30 이후): {sections['🌆 저녁 (17-19)']}건")
