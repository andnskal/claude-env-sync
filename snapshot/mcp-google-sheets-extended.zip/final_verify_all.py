"""모든 수식 갱신 후 최종 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

print("최종 갱신 대기...")
time.sleep(15)

# 1.일별 모든 일자
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("\n[1.일별 모든 일자 KPI]")
print(f"{'날짜':>12} | {'P':>6} | {'Q':>6} | {'H':>6} | {'M':>6} | {'AC':>6} | {'AE':>6} | {'AI':>6}")
print("-" * 70)
for row in daily:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        date = row[0]
        P = row[15] if len(row) > 15 else "?"
        Q = row[16] if len(row) > 16 else "?"
        H = row[7] if len(row) > 7 else "?"
        M = row[12] if len(row) > 12 else "?"
        AC = row[28] if len(row) > 28 else "?"
        AE = row[30] if len(row) > 30 else "?"
        AI = row[34] if len(row) > 34 else "?"
        print(f"{date:>12} | {P:>6} | {Q:>6} | {H:>6} | {M:>6} | {AC:>6} | {AE:>6} | {AI:>6}")

# 직접 카운트와 비교
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_p = defaultdict(int)
date_h = defaultdict(int)
date_m = defaultdict(int)
for row in all_calls:
    if len(row) > 29:
        N, Q, AD = row[13], row[16], row[29]
        if N and AD == "내" and Q == "IB_성공":
            date_p[N] += 1

for row in all_chats:
    if len(row) > 25:
        O, M, Y, Z = row[14], row[12], row[24], row[25]
        if O and Z == "내" and Y == "Y":
            if M == "채널톡": date_h[O] += 1
            elif M == "기술이관": date_m[O] += 1

print("\n[직접 카운트 vs 시트 비교]")
mismatches = 0
for row in daily:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        date = row[0]
        P = row[15] if len(row) > 15 else 0
        H = row[7] if len(row) > 7 else 0
        M = row[12] if len(row) > 12 else 0
        if P != date_p[date]: mismatches += 1; print(f"  ❌ {date} P={P} vs {date_p[date]}")
        if H != date_h[date]: mismatches += 1; print(f"  ❌ {date} H={H} vs {date_h[date]}")
        if M != date_m[date]: mismatches += 1; print(f"  ❌ {date} M={M} vs {date_m[date]}")
if mismatches == 0:
    print("  ✅ 모든 KPI 일치")

print("\n[최종 시트 목록]")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    print(f"  - {s['properties']['title']}")
