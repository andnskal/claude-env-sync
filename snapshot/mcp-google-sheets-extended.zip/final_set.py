"""기본 날짜 설정 + 최종 검증 출력."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5/8 (가장 최근 데이터) 기본 날짜
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
    valueInputOption="USER_ENTERED",
    body={"values": [["46150"]]},  # 5/8
).execute()
time.sleep(8)

# 최종 검증 출력
print("=" * 80)
print("📊 1분단위/5분단위 포기호 시트 최종 상태 (2026-05-08 기준)")
print("=" * 80)

# 1분단위 9시-9시 50분 영역 출력
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A4:V60",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[1분단위 9:00~10:00 시간대] (5/8)")
print(f"{'행':>3} {'시간':>6} {'통화중':>4} {'포기호':>8} {'F':>6} {'G':>6} {'H':>6} {'I':>6} {'J':>6} {'K':>6}")
for ri, row in enumerate(res[:60]):
    if not row: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    e = "★" if row[4:5] and "*" in row[4] else ""
    f = "★" if len(row)>5 and row[5] and "*" in row[5] else ""
    g = "★" if len(row)>6 and row[6] and "*" in row[6] else ""
    h = "★" if len(row)>7 and row[7] and "*" in row[7] else ""
    i = "★" if len(row)>8 and row[8] and "*" in row[8] else ""
    j = "★" if len(row)>9 and row[9] and "*" in row[9] else ""
    k = "★" if len(row)>10 and row[10] and "*" in row[10] else ""
    if e or f or g or h or i or j or k:
        print(f"{ri+4:>3} {time_str:>6} {counta:>4} {e:>8} {f:>6} {g:>6} {h:>6} {i:>6} {j:>6} {k:>6}")

# 동적 헤더 출력
hdr = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!F3:T3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[활동 상담사 (5/8)] (열 F~T):")
if hdr and hdr[0]:
    for i, name in enumerate(hdr[0]):
        if name:
            col = chr(ord('F') + i)
            print(f"  {col}: {name}")

# 통계
ones = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E4:E513",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
fives = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E4:E135",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
raw_a = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"\n📊 5/8 통계:")
print(f"  - 1분단위 포기호 발생 분 수: {sum(1 for r in ones if r and '*' in (r[0] if r else ''))}")
print(f"  - 5분단위 포기호 발생 5분 buckets: {sum(1 for r in fives if r and '*' in (r[0] if r else ''))}")
print(f"  - RAW시간대별 포기호 건수: {sum(1 for r in raw_a if r and r[0])}")

# 제외할 상담사 컬럼 도움말
print(f"\n💡 사용법:")
print(f"  - 1분단위!E2 또는 5분단위!E2에 날짜 입력 → 자동 필터링")
print(f"    (예: 46142 = 4/30, 46146 = 5/4, 46150 = 5/8)")
print(f"  - 1분단위!V3 또는 5분단위!V3에 상담사 선택 → 통화 외 시간 계산")
print(f"  - 1분단위!C3 (제외할 상담사) — 미구현 (필요시 추후 추가)")
