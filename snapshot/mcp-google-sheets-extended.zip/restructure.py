"""대대적 재구조: 헤더 변경 + 운영시간 확장 + 동적 날짜 + 평균/합계 + 가로 펼침."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ============================================================
# Step 1: ★설정 J 분류명 변경 (인하우스 → 본사, 도급사 → 외주 고객센터)
# ============================================================
mgr_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!J2:J16",
).execute().get("values", [])
new_j = []
for row in mgr_data:
    if not row:
        new_j.append([""])
        continue
    v = row[0] if row else ""
    if v == "인하우스":
        new_j.append(["본사"])
    elif v == "도급사":
        new_j.append(["외주 고객센터"])
    else:
        new_j.append([v])
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!J2:J16",
    valueInputOption="USER_ENTERED", body={"values": new_j},
).execute()
# 헤더 J1 변경
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!J1",
    valueInputOption="RAW", body={"values": [["팀 (본사/외주 고객센터)"]]},
).execute()
# X1, Y1 헤더 변경
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!X1:Y1",
    valueInputOption="RAW",
    body={"values": [["본사 명단 (CS+기술)", "외주 고객센터 명단"]]},
).execute()
# X, Y 수식 분류명 변경
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!X2",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF((I2:I16<>"")*((J2:J16="본사")+(J2:J16="기술"))>0,I2:I16,""))']]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!Y2",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF((I2:I16<>"")*(J2:J16="외주 고객센터"),I2:I16,""))']]},
).execute()
print("✅ ★설정 J/X/Y 변경 (본사/외주 고객센터)")

# ============================================================
# Step 2: 1.일별 헤더 텍스트 변경 (행1, 행2, 행3 일부)
# ============================================================
# 행1
daily_row1 = [["", "",
               "채팅 전체 (ALF 제외)", "", "", "", "", "", "", "", "",
               "채팅 (본사+외주 고객센터)", "", "",
               "유선 현황 (본사+외주 고객센터)", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A1:AH1",
    valueInputOption="RAW", body={"values": daily_row1},
).execute()
# 행2
daily_row2 = [["", "구분", "카카오", "", "네이버", "", "채널톡", "", "본사 + 외주 고객센터 합계\n(카카오+네이버+채널톡)",
               "", "", "", "", "", "IB", "", "", "", "", "", "", "", "", "", "", "", "", "", "OB",
               "", "", "", "", ""]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A2:AH2",
    valueInputOption="RAW", body={"values": daily_row2},
).execute()
# 행3 L 헤더만 갱신
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!L3",
    valueInputOption="RAW", body={"values": [["카카오+네이버+채널톡"]]},
).execute()
print("✅ 1.일별 행1·2·L3 헤더 변경")

# ============================================================
# Step 3: 2.시간대별 헤더 + 운영시간 10시간 확장
# ============================================================
hourly_row1 = [["", "", "", "투입인원 (본사+외주 고객센터)", "", "", "IB (본사+외주 고객센터)",
                "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                "OB (본사+외주 고객센터)", "", "", "", "채팅 (ALF 제외)", "", "", "", "", "카카오", "", "네이버", "", "채널톡", ""]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A1:AL1",
    valueInputOption="RAW", body={"values": hourly_row1},
).execute()
# 행3 AE/AF 변경
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!AE3:AF3",
    valueInputOption="RAW",
    body={"values": [["답변(본사+외주 고객센터)", "기여도(본사+외주 고객센터)"]]},
).execute()
print("✅ 2.시간대별 행1·AE/AF 헤더 변경")

# 운영시간 10시간 확장 (09-10 ~ 18-19) + 동적 날짜
# A4: 5.콜 unique 날짜 × 10 반복
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IFERROR(FLATTEN(SPLIT(TEXTJOIN(";",TRUE,REPT(SORT(UNIQUE(FILTER(\'5.콜 상담내역\'!N2:N,\'5.콜 상담내역\'!N2:N<>"")))&";",10)),";"))))']]},
).execute()
# C4: 시간대 10개 cycle
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!C4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(A4:A="",,CHOOSE(MOD(SEQUENCE(ROWS(A4:A),1,0,1),10)+1,"09-10","10-11","11-12","12-13","13-14","14-15","15-16","16-17","17-18","18-19")))']]},
).execute()
print("✅ 2.시간대별 운영시간 10시간 + 동적 날짜")

# ============================================================
# Step 4: 1.일별 행4-5 평균/합계 + 데이터 행 6+로 이동
# ============================================================
# 1.일별 모든 BYROW 수식이 A4:A 기반 → A6:A로 이동 필요
# 우선 A,B 수식 변경
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4",
    valueInputOption="RAW", body={"values": [[""]]},  # 행4 비움 (평균 라벨로)
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A5:B5",
    valueInputOption="RAW", body={"values": [["", "합계"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:B4",
    valueInputOption="RAW", body={"values": [["", "일 평균"]]},
).execute()

# A6: 동적 날짜 (시간대별 unique B 컬럼)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IFERROR(UNIQUE(FILTER(\'2.시간대별 전체통계\'!B4:B,\'2.시간대별 전체통계\'!B4:B<>"")))']]},
).execute()

# B6: 요일/공휴일
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!B6",
    valueInputOption="USER_ENTERED",
    body={"values": [[
        '=ARRAYFORMULA(IF(A6:A="",,IFERROR(IF(IFERROR(MATCH(DATEVALUE(A6:A),DATEVALUE(\'★설정\'!D$2:D$15),0),0)>0,"공휴일",CHOOSE(WEEKDAY(DATEVALUE(A6:A)),"일","월","화","수","목","금","토")),"")))'
    ]]},
).execute()
print("✅ 1.일별 A4-A5 라벨, A6 동적 날짜 시작")

# 모든 BYROW 수식 가져와서 A4:A → A6:A 변경
existing = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!C4:AH4",
    valueRenderOption="FORMULA"
).execute().get("values", [[]])
if existing:
    formulas = existing[0]
    cols = []
    for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
        cols.append(letter)
    cols.extend(["AA","AB","AC","AD","AE","AF","AG","AH"])
    new_formulas_row6 = []
    for col, f in zip(cols, formulas):
        if isinstance(f, str) and f.startswith("="):
            # A4:A → A6:A
            new_f = f.replace("A4:A,", "A6:A,").replace("A4:A,LAMBDA", "A6:A,LAMBDA").replace("A4:A=\"\"", "A6:A=\"\"").replace("BYROW(A4:A,", "BYROW(A6:A,").replace("ARRAYFORMULA(IF(A4:A", "ARRAYFORMULA(IF(A6:A").replace("(R4:R", "(R6:R").replace("(P4:P", "(P6:P").replace("(O4:O", "(O6:O").replace("(K4:K", "(K6:K").replace("(L4:L", "(L6:L").replace("(M4:M", "(M6:M").replace("(N4:N", "(N6:N").replace("(D4:D", "(D6:D").replace("(F4:F", "(F6:F").replace("(H4:H", "(H6:H").replace("(J4:J", "(J6:J").replace("(C4:C", "(C6:C").replace("(E4:E", "(E6:E").replace("(G4:G", "(G6:G").replace("(I4:I", "(I6:I").replace("(S4:S", "(S6:S").replace("(T4:T", "(T6:T").replace("(W4:W", "(W6:W").replace("(AA4:AA", "(AA6:AA").replace("(AB4:AB", "(AB6:AB").replace("(AC4:AC", "(AC6:AC").replace("(AD4:AD", "(AD6:AD").replace("(AE4:AE", "(AE6:AE").replace("(AF4:AF", "(AF6:AF")
            # 행4의 셀을 행6로 옮기기
            try:
                _sheets.spreadsheets().values().update(
                    spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{col}6",
                    valueInputOption="USER_ENTERED", body={"values": [[new_f]]},
                ).execute()
                new_formulas_row6.append(col)
            except Exception as e:
                print(f"  ⚠️ {col}: {e}")
    print(f"✅ 1.일별 BYROW 수식 {len(new_formulas_row6)}개 → 행6으로 이동")

# 행4-5 평균/합계 수식 (각 컬럼 AVERAGE/SUM)
avg_row = [""]*2  # A,B
sum_row = [""]*2  # A,B
for col in cols:
    avg_row.append(f"=IFERROR(AVERAGE({col}6:{col}100),)")
    sum_row.append(f"=IFERROR(SUM({col}6:{col}100),)")
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AH4",
    valueInputOption="USER_ENTERED",
    body={"values": [["", "일 평균"] + avg_row[2:]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A5:AH5",
    valueInputOption="USER_ENTERED",
    body={"values": [["", "합계"] + sum_row[2:]]},
).execute()
print("✅ 1.일별 행4 일평균, 행5 합계 수식")

# 1.일별 C4:AH4 (이전 수식 위치) 클리어 → 위에서 평균 수식으로 덮음

print("\n🎉 재구조 완료")
