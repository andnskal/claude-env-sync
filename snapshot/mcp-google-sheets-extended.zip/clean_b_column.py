"""B 컬럼 점심시간 제거 + 헤더 명확화."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# B1 헤더 명확화
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!B1",
    valueInputOption="USER_ENTERED",
    body={"values": [["업무시간\n(점심 제외)"]]},
).execute()
print("OK B1: 업무시간 (점심 제외)")

# B2 수식: 점심시간 (12:30 ~ 13:29) 빈 셀로 처리
new_b2 = (
    '=ARRAYFORMULA(IF('
    '(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440>=TIME(12,30,0))*'
    '(TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440<TIME(13,30,0)),'
    ',TIME(9,0,0)+SEQUENCE(510,1,0,1)/1440))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!B2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_b2]]},
).execute()
print("OK B2 수식 변경 (점심 60셀 비우기)")

time.sleep(5)

# B 컬럼 점심 영역에 조건부 서식 (회색 배경)
sid = _get_sheet_id_by_name(NEW, "★설정")

# 기존 조건부 서식 확인
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties(sheetId),conditionalFormats(ranges,booleanRule))"
).execute()
existing_rules = 0
for s in meta.get("sheets", []):
    if s["properties"].get("sheetId") == sid:
        existing_rules = len(s.get("conditionalFormats", []))
        break

# 점심 영역 (행 212-271)에 회색 배경 조건부 서식
# ARRAYFORMULA로 빈 셀이 되는 영역
reqs = []
reqs.append({
    "addConditionalFormatRule": {
        "rule": {
            "ranges": [{
                "sheetId": sid,
                "startRowIndex": 211,  # B212 (0-indexed)
                "endRowIndex": 271,    # B271 (0-indexed, exclusive 272)
                "startColumnIndex": 1,  # B
                "endColumnIndex": 2
            }],
            "booleanRule": {
                "condition": {"type": "BLANK"},
                "format": {
                    "backgroundColor": {"red": 0.95, "green": 0.85, "blue": 0.55},
                }
            }
        },
        "index": existing_rules
    }
})

_batch_update(NEW, reqs)
print(f"OK B212:B271 조건부 서식 (점심 영역 강조)")

time.sleep(3)

# 검증
print("\n[B 컬럼 점심 시간대 확인]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B210:B273",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    actual_row = 210 + ri
    val = r[0] if r and r[0] else "(빈)"
    note = ""
    if 212 <= actual_row <= 271:
        note = "  ← 점심 영역 (회색 배경)"
    print(f"  B{actual_row}: {val}{note}")

# 전체 B 컬럼 유효 행 카운트
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B600",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
non_empty = sum(1 for r in res if r and r[0])
print(f"\nB 컬럼 비어있지 않은 셀: {non_empty}개")
print(f"  → 09:00-12:29 (210셀) + 13:30-17:29 (240셀) + 헤더 1 = 451개")
