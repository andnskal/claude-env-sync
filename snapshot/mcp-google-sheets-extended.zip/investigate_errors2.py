"""오류 셀의 풀 수식 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Get full formulas
def get_formula(sheet, cell):
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{cell}",
        valueRenderOption="FORMULA",
    ).execute().get("values", [[]])
    return res[0][0] if res and res[0] else ""

# 1.일별 Y6
print("=" * 70)
print("1.일별 Y6 (IB 투입인원 - 단순 인원 수)")
print("=" * 70)
y6 = get_formula("1.일별 전체 통계", "Y6")
print(y6)

# 3.상담사별 채팅 C2
print("\n" + "=" * 70)
print("3.상담사별 채팅 C2")
print("=" * 70)
print(get_formula("3.상담사별 채팅 실적", "C2"))

# 3.상담사별 채팅 J2 (또한 J1, J3)
print("\n" + "=" * 70)
print("3.상담사별 채팅 J 컬럼")
print("=" * 70)
print(f"  J1: {get_formula('3.상담사별 채팅 실적', 'J1')}")
print(f"  J2: {get_formula('3.상담사별 채팅 실적', 'J2')}")
print(f"  J3: {get_formula('3.상담사별 채팅 실적', 'J3')}")
print(f"  J4: {get_formula('3.상담사별 채팅 실적', 'J4')}")
print(f"  J5: {get_formula('3.상담사별 채팅 실적', 'J5')}")

# C1 어디까지 들어가는지 확인
print("\n" + "=" * 70)
print("C1 expand (얼마나 spillover)?")
print("=" * 70)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:BD2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if res:
    row1 = res[0]
    row2 = res[1] if len(res) > 1 else []
    # 비어있지 않은 C1 이후 셀 카운트
    non_empty_c1 = sum(1 for c in row1[2:] if c)
    print(f"  C1+ 비어있지 않은 셀: {non_empty_c1}개")
    print(f"  마지막 일부: {row1[-5:] if len(row1) >= 5 else row1}")
    print(f"  C2 row 첫 값: {row2[:10]}")

# 4.상담사별 콜 동일
print("\n" + "=" * 70)
print("4.상담사별 콜 J 컬럼")
print("=" * 70)
print(f"  J1: {get_formula('4.상담사별 콜 실적', 'J1')}")
print(f"  J2: {get_formula('4.상담사별 콜 실적', 'J2')}")
print(f"  J3: {get_formula('4.상담사별 콜 실적', 'J3')}")
