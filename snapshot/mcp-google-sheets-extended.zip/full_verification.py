"""실무 적용 가능 수준 종합 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 100)
print("실무 적용 검증")
print("=" * 100)
issues = []

# 1.일별 데이터 로드
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AW60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# ============================================================
# A. 3.상담사별 채팅 실적 합계 vs 1.일별
# ============================================================
print("\n[A] 3.상담사별 채팅 실적 vs 1.일별 H/F/D")
res3 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

if res3 and len(res3) >= 3:
    headers_dates = res3[0]
    headers_chans = res3[1]

    sum_by_date = {}
    for ci, (d, ch) in enumerate(zip(headers_dates, headers_chans)):
        if isinstance(d, str) and d:
            if d not in sum_by_date:
                sum_by_date[d] = {"카카오": 0, "네이버": 0, "채널톡": 0, "기술이관": 0}
            for ri in range(2, len(res3)):
                if ci < len(res3[ri]) and isinstance(res3[ri][ci], (int, float)):
                    if ch in sum_by_date[d]:
                        sum_by_date[d][ch] += res3[ri][ci]

# 1.일별 D, F, H, M과 비교
for row in daily[2:]:  # 행 6+ 데이터
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in sum_by_date: continue

    D = row[3] if len(row) > 3 else 0      # 카카오 답변
    F = row[5] if len(row) > 5 else 0      # 네이버 답변
    H = row[7] if len(row) > 7 else 0      # 채널톡 답변
    M = row[12] if len(row) > 12 else 0    # 기술이관

    s_kakao = sum_by_date[date]["카카오"]
    s_naver = sum_by_date[date]["네이버"]
    s_chan = sum_by_date[date]["채널톡"]
    s_tech = sum_by_date[date]["기술이관"]

    msg = []
    if D != s_kakao: msg.append(f"D 카카오={D}/3합={s_kakao}")
    if F != s_naver: msg.append(f"F 네이버={F}/3합={s_naver}")
    if H != s_chan: msg.append(f"H 채널톡={H}/3합={s_chan}")
    # M은 RAW 55 추가로 인해 3.상담사별과 다를 수 있음 (3은 6.채팅만, M은 6.채팅+RAW55)
    if msg:
        issues.append(f"3vs1.일별 {date}: {', '.join(msg)}")
        print(f"  ❌ {date}: {', '.join(msg)}")

if not any(i.startswith("3vs") for i in issues):
    print(f"  ✅ 3.상담사별 채팅 ↔ 1.일별 D/F/H 모든 일자 일치")

# ============================================================
# B. 4.상담사별 콜 실적 합계 vs 1.일별
# ============================================================
print("\n[B] 4.상담사별 콜 실적 vs 1.일별 P, AC")
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

sum4_by_date = {}
if res4 and len(res4) >= 3:
    headers_dates = res4[0]
    headers_types = res4[1]

    for ci, (d, t) in enumerate(zip(headers_dates, headers_types)):
        if isinstance(d, str) and d:
            if d not in sum4_by_date:
                sum4_by_date[d] = {"IB_성공": 0, "OB_성공": 0, "OB_실패": 0}
            for ri in range(2, len(res4)):
                if ci < len(res4[ri]) and isinstance(res4[ri][ci], (int, float)):
                    if t in sum4_by_date[d]:
                        sum4_by_date[d][t] += res4[ri][ci]

for row in daily[2:]:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in sum4_by_date: continue
    P = row[15] if len(row) > 15 else 0
    AC = row[28] if len(row) > 28 else 0

    s_ib = sum4_by_date[date]["IB_성공"]
    s_ob = sum4_by_date[date]["OB_성공"]

    msg = []
    if P != s_ib: msg.append(f"P 응대호={P}/4합={s_ib}")
    if AC != s_ob: msg.append(f"AC OB성공={AC}/4합={s_ob}")
    if msg:
        issues.append(f"4vs1.일별 {date}: {', '.join(msg)}")
        print(f"  ❌ {date}: {', '.join(msg)}")

if not any(i.startswith("4vs") for i in issues):
    print(f"  ✅ 4.상담사별 콜 ↔ 1.일별 P/AC 모든 일자 일치")

# ============================================================
# C. 2.시간대별 합계 vs 1.일별
# ============================================================
print("\n[C] 2.시간대별 vs 1.일별")
hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:AL700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 시간대별 컬럼 매핑 (A=일자, B=날짜텍스트, C=시간, D=IB투입, E=OB투입, F=채팅투입,
#                    G=총접수호, H=포기호, ..., L=IB_성공, P=총접수호(알림제외), Q=포기호, R=응대호, ...)
sum_h_by_date = {}
for row in hourly:
    if len(row) > 16 and isinstance(row[1], str) and "2026" in row[1]:
        d = row[1]
        if d not in sum_h_by_date:
            sum_h_by_date[d] = {"L_IB": 0, "P_접수": 0, "Q_포기": 0, "X_OB": 0, "AL_채널톡": 0}
        for ci, key in [(11, "L_IB"), (15, "P_접수"), (16, "Q_포기"), (23, "X_OB"), (37, "AL_채널톡")]:
            if isinstance(row[ci], (int, float)) if ci < len(row) else False:
                sum_h_by_date[d][key] += row[ci]

for row in daily[2:]:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in sum_h_by_date: continue
    P = row[15] if len(row) > 15 else 0  # 1.일별 P (응대호) ← 시간대별 L
    O = row[14] if len(row) > 14 else 0  # 1.일별 O (접수호) ← 시간대별 P
    Q = row[16] if len(row) > 16 else 0  # 1.일별 Q (포기호) ← 시간대별 Q
    AC = row[28] if len(row) > 28 else 0 # 1.일별 AC (OB 성공) ← 시간대별 X
    H = row[7] if len(row) > 7 else 0    # 1.일별 H (채널톡 답변) ← 시간대별 AL

    s_l = sum_h_by_date[date]["L_IB"]
    s_p = sum_h_by_date[date]["P_접수"]
    s_q = sum_h_by_date[date]["Q_포기"]
    s_x = sum_h_by_date[date]["X_OB"]
    s_al = sum_h_by_date[date]["AL_채널톡"]

    msg = []
    if P != s_l: msg.append(f"P={P}/2합={s_l}")
    if O != s_p: msg.append(f"O={O}/2합={s_p}")
    if Q != s_q: msg.append(f"Q={Q}/2합={s_q}")
    if AC != s_x: msg.append(f"AC={AC}/2합={s_x}")
    if H != s_al: msg.append(f"H={H}/2합={s_al}")
    if msg:
        issues.append(f"2vs1.일별 {date}: {', '.join(msg)}")
        print(f"  ❌ {date}: {', '.join(msg)}")

if not any(i.startswith("2vs") for i in issues):
    print(f"  ✅ 2.시간대별 ↔ 1.일별 모든 KPI 모든 일자 일치")

# ============================================================
# D. 합계/평균 행 (행 4, 5) 검증
# ============================================================
print("\n[D] 1.일별 합계/평균 행 (행 4, 5) 재검증")
# 1.일별 행 4 = 평균, 행 5 = 합계
# 데이터 행 6-12 의 카운트 합산해서 비교
data_rows = []
for row in daily[2:]:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        data_rows.append(row)

avg_row = daily[0]  # 행 4 (평균)
sum_row = daily[1]  # 행 5 (합계)

count_cols = [3, 5, 7, 12, 15, 16, 20, 27, 28, 30, 33, 34, 39, 40, 41, 42, 43, 44, 45]
sum_mismatch = 0
for ci in count_cols:
    manual_sum = sum(r[ci] for r in data_rows if ci < len(r) and isinstance(r[ci], (int, float)))
    sheet_sum = sum_row[ci] if ci < len(sum_row) and isinstance(sum_row[ci], (int, float)) else 0
    if abs(sheet_sum - manual_sum) > 0.01:
        sum_mismatch += 1
        issues.append(f"행5합계 {col_letter(ci)}: 시트={sheet_sum} 수동={manual_sum}")

if sum_mismatch == 0:
    print(f"  ✅ 합계 행 모든 컬럼 정확 ({len(count_cols)}개)")
else:
    print(f"  ❌ 합계 행 불일치: {sum_mismatch}개")

# ============================================================
# E. AU/AV/AW 모든 일자 검증
# ============================================================
print("\n[E] AU/AV/AW (전체시간 응대율 / 운영외 IB / 운영외 OB)")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_au_data = defaultdict(lambda: {"ib_total": 0, "ib_succ": 0, "off_aban": 0, "off_ob": 0})
for row in all_calls:
    if len(row) > 29:
        N, B, Q, AC, AD = row[13], row[1], row[16], row[28], row[29]
        if not N: continue
        if B == "inbound":
            date_au_data[N]["ib_total"] += 1
            if Q == "IB_성공": date_au_data[N]["ib_succ"] += 1
        if B == "inbound" and AD == "외" and Q == "IB_포기호":
            date_au_data[N]["off_aban"] += 1
        if Q == "OB_성공" and AD == "외" and AC in ("본사", "외주 고객센터"):
            date_au_data[N]["off_ob"] += 1

au_match = 0
au_total = 0
for row in daily[2:]:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_au_data: continue
    AU = row[46] if len(row) > 46 else 0
    AV = row[47] if len(row) > 47 else 0
    AW = row[48] if len(row) > 48 else 0

    d = date_au_data[date]
    exp_au = d["ib_succ"] / d["ib_total"] if d["ib_total"] else 0
    exp_av = d["off_aban"]
    exp_aw = d["off_ob"]

    if isinstance(AU, (int, float)) and abs(AU - exp_au) < 0.001: au_match += 1
    elif AU == "" and exp_au == 0: au_match += 1
    else:
        issues.append(f"AU {date}: 시트={AU} 수동={exp_au:.4f}")
    au_total += 1

    if AV == exp_av: au_match += 1
    else:
        issues.append(f"AV {date}: 시트={AV} 수동={exp_av}")
    au_total += 1

    if AW == exp_aw: au_match += 1
    else:
        issues.append(f"AW {date}: 시트={AW} 수동={exp_aw}")
    au_total += 1

print(f"  → AU/AV/AW 일치: {au_match}/{au_total}")

# ============================================================
# F. R 분류 자동 작동 검증
# ============================================================
print("\n[F] RAW 55 R 분류 자동 분류")
raw55 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:R10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
verify_r = {"본사_채팅": 0, "본사_비채팅": 0, "외주_채팅": 0, "외주_비채팅": 0, "미매핑": 0}
r_actual = {"본사_채팅": 0, "본사_비채팅": 0, "외주_채팅": 0, "외주_비채팅": 0, "미매핑": 0}
mismatch_r = 0
for row in raw55:
    if len(row) < 11: continue
    H = row[0]
    J = row[2] if len(row) > 2 else ""
    R = row[10] if len(row) > 10 else ""

    # 직접 분류
    if J.startswith("@@"):
        expected = "미매핑"
    elif J.startswith("TCK_") or J.startswith("CS쉐어링"):
        expected = "외주_채팅" if H == "채팅" else "외주_비채팅"
    else:
        expected = "본사_채팅" if H == "채팅" else "본사_비채팅"

    verify_r[expected] = verify_r.get(expected, 0) + 1
    if R in r_actual:
        r_actual[R] += 1

    if R != expected:
        mismatch_r += 1

print(f"  R 분류 일치: {sum(verify_r.values()) - mismatch_r}/{sum(verify_r.values())}")
print(f"  실제 분포: {dict(r_actual)}")

# ============================================================
# 종합
# ============================================================
print("\n" + "=" * 100)
if not issues:
    print("✅ 모든 영역 검증 통과 — 실무 적용 가능")
else:
    print(f"⚠️ 발견된 이슈: {len(issues)}건")
    for i in issues[:25]:
        print(f"  - {i}")
print("=" * 100)
