"""6.채팅 #VALUE! 진단."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 6.채팅 B2 수식 확인
f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!B2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print(f"B2 수식: {f[0][0] if f and f[0] else '?'}")

# B2 결과 + 에러 메시지
res = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'6.채팅 상담내역'!B2"],
    includeGridData=True,
    fields="sheets(data(rowData(values(formattedValue,effectiveValue))))"
).execute()
cell = res["sheets"][0]["data"][0]["rowData"][0]["values"][0]
print(f"  formattedValue: {cell.get('formattedValue', '?')}")
print(f"  effectiveValue: {cell.get('effectiveValue', {})}")

# 단순 테스트 - 인접 셀에 직접 참조
test_formula = "='RAW_UserChat'!AH2"
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!AC2",
    valueInputOption="USER_ENTERED",
    body={"values": [[test_formula]]},
).execute()
time.sleep(2)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!AC2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])
print(f"\n테스트 ='RAW_UserChat'!AH2 = {res[0][0] if res and res[0] else '?'}")

# 정리
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!AC2"
).execute()

# 시간 더 기다림
print("\n추가 대기 (20초)...")
time.sleep(20)

# 다시 6.채팅 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:G5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[6.채팅 A2:G5 (대기 후)]")
for ri, row in enumerate(res):
    print(f"  Row {ri+2}: {row}")
