"""5/8 직접 카운트 vs 1.일별 시트 정합성."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 5/8 직접 카운트
from collections import defaultdict
direct = defaultdict(int)
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    Q = row[16]
    Y = row[24]
    AD = row[29]
    
    if Q == "IB_성공" and AD == "내":
        direct["IB_성공_운영내"] += 1
    elif Q == "IB_성공" and AD == "외":
        direct["IB_성공_운영외"] += 1
    elif Q == "IB_포기호" and AD == "내" and Y != "알림톡발송":
        direct["IB_포기호_운영내_알림제외"] += 1
    elif Q == "IB_포기호" and AD == "외":
        direct["IB_포기호_운영외"] += 1

print("[5/8 5.콜 직접 카운트]")
for k, v in direct.items():
    print(f"  {k}: {v}")

# 1.일별 5/8 KPI
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AW60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 5/8 KPI]")
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  P (응대호): {row[15]}")
        print(f"  Q (포기호 알림제외): {row[16]}")
        print(f"  R (응대율): {row[17]*100:.2f}%" if isinstance(row[17], (int,float)) else f"  R: {row[17]}")
        break

# 2.시간대별 5/8 합산
hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
sum_l = sum_q = 0
for row in hourly:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == "2026-05-08":
        if isinstance(row[11], (int, float)): sum_l += row[11]
        if isinstance(row[16], (int, float)): sum_q += row[16]
print(f"\n[2.시간대별 5/8 합]")
print(f"  L (IB_성공) 합: {sum_l}")
print(f"  Q (포기호 알림제외) 합: {sum_q}")

# 매칭
print(f"\n[정합성 확인]")
print(f"  5.콜 직접 IB_성공 운영내: {direct['IB_성공_운영내']} vs 시트 P, 2.시간대별 L")
print(f"  5.콜 직접 IB_포기호 운영내(알림제외): {direct['IB_포기호_운영내_알림제외']} vs 시트 Q")
