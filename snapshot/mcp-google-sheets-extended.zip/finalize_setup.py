"""RAW_현시간 전화 모니터링 헤더 + 안내 작성."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW_현시간 전화 모니터링 헤더 정리
sid = _get_sheet_id_by_name(NEW, "RAW_현시간 전화 모니터링")

# 헤더 (이전 시트와 동일)
headers = [["id", "userChatId", "startedAt", "endedAt", "engagedAt", "from", "to",
            "direction", "missedReason", "duration", "type", "primaryNumber", "representativeNumber"]]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_현시간 전화 모니터링'!A1:M1",
    valueInputOption="USER_ENTERED",
    body={"values": headers},
).execute()

# 안내문 (P1 부터)
guide = [
    ["", "📌 사용 안내"],
    ["", "이 시트는 실시간 콜 모니터링용입니다."],
    ["", "신 시스템에서는 5.콜 시트가 채널톡 RAW를 자동 동기하므로"],
    ["", "이 시트는 향후 외부 시스템(전화 PBX 등) 연동 시 활용을 위해 보존."],
    ["", ""],
    ["", "📋 활용 방법"],
    ["", "옵션 A: 운영팀이 모니터링 데이터 수동 입력 (특정 일자 분석용)"],
    ["", "옵션 B: 외부 시스템에서 IMPORTRANGE로 자동 연결"],
    ["", "옵션 C: 5.콜 시트의 특정 일자 데이터 추출용 보조"],
]
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_현시간 전화 모니터링'!P1",
    valueInputOption="USER_ENTERED",
    body={"values": guide},
).execute()

# 헤더 서식
_batch_update(NEW, [
    {"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 0, "endColumnIndex": 13},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.2, "green": 0.4, "blue": 0.6},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}},
    # 안내문 영역
    {"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 9, "startColumnIndex": 15, "endColumnIndex": 17},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.97, "green": 0.97, "blue": 0.85},
            "textFormat": {"fontSize": 10},
            "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 15, "endIndex": 17},
        "properties": {"pixelSize": 350}, "fields": "pixelSize"}},
])
print("OK RAW_현시간 전화 모니터링 헤더 + 안내")

print("\n[전체 작업 요약]")
print("=" * 80)
print("1. RAW 55번 기술 이관:")
print("   - 외부 IMPORTRANGE 복원 (1-6uipG0...)")
print("   - 7,528건 데이터 자동 동기")
print("   - 매핑 컬럼: I(날짜), J(요청자한글), K(기술이관), L(-), M(신날짜), N(운영시간), O(팀), P(이름)")
print("   - 1494건 외주 직원(TCK_xxx) 매핑 성공")
print()
print("2. 1.일별 M (기술이관) 통합:")
print("   = 본사 채팅 기술이관 + RAW 55(TCK_xxx OR CS쉐어링_xxx, 채팅, 운영시간 내)")
print("   - 5/9 시점 도급사 미운영 → M=0 (정상)")
print("   - 향후 도급사 운영 시작 → 자동 카운트")
print()
print("3. RAW_현시간 전화 모니터링:")
print("   - 헤더 13컬럼 정리 (id ~ representativeNumber)")
print("   - 사용 안내 추가 (P1:Q9)")
print("   - 향후 외부 시스템 연결용 보존")
print()
print("4. 향후 도급사 추가 가이드:")
print("   - ★설정 H 컬럼에 'TCK_홍길동' 또는 'CS쉐어링_김철수' 형식으로 추가")
print("   - 자동으로 RAW 55 J 매핑 + 1.일별 M 카운트")
