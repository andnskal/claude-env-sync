"""2.시간대별 시트를 10시간대(09-19) → 24시간대(00-24)로 확장.
- A4 (날짜): REPT 10 → 24
- C4 (시간대): CHOOSE에 0~9시, 19~24시 추가
"""
import os, sys, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 백업
print("[백업] 기존 A4, C4 수식")
backup = {}
for col, r in [("A", 4), ("C", 4)]:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'2.시간대별 전체통계'!{col}{r}",
        valueRenderOption='FORMULA',
    ).execute().get('values', [])
    if res and res[0]:
        backup[f"{col}{r}"] = res[0][0]
        print(f"  {col}{r}: {res[0][0][:200]}")

with open("D:/claude/mcp-google-sheets-extended/backup_24h_extension.json", "w", encoding="utf-8") as f:
    json.dump(backup, f, ensure_ascii=False, indent=2)
print("  → backup_24h_extension.json 저장됨")

time.sleep(2)

# Step 1: A4 — REPT 10 → 24
print("\n[1] A4 (날짜 반복) — 10 → 24로 변경")
new_a4 = (
    '=ARRAYFORMULA(IFERROR(TEXT(FLATTEN(SPLIT(TEXTJOIN(";",TRUE,'
    'REPT(SORT(UNIQUE(FILTER(\'5.콜 상담내역\'!N2:N,\'5.콜 상담내역\'!N2:N<>"")))&";",24)),'
    '";")),"yyyy-mm-dd")))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_a4]]},
).execute()
print(f"  {new_a4}")

# Step 2: C4 — 24개 시간대로 확장 (00-01 ~ 23-24)
print("\n[2] C4 (시간대) — 24개 슬롯으로 확장")
# CHOOSE에 24개 슬롯
slots = [f'"{h:02d}-{h+1:02d}"' for h in range(24)]  # "00-01", "01-02", ..., "23-24"
slots_str = ",".join(slots)
new_c4 = (
    f'=ARRAYFORMULA(IF(A4:A="",,'
    f'CHOOSE(MOD(SEQUENCE(ROWS(A4:A),1,0,1),24)+1,{slots_str})))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!C4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_c4]]},
).execute()
print(f"  {new_c4[:200]}...")

time.sleep(15)

# 검증
print("\n" + "=" * 80)
print("[검증] 2.시간대별 시트 5/11 확장 결과")
print("=" * 80)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:X1000",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])

slots_5_11 = []
ob_total_5_11 = 0
for row in res:
    if len(row) >= 3 and str(row[1]) == '2026-05-11':
        slot = row[2]
        ob = row[23] if len(row) > 23 else 0
        try:
            ob = int(ob)
        except:
            ob = 0
        slots_5_11.append((slot, ob))
        ob_total_5_11 += ob

print(f"\n5/11 시간대 슬롯 ({len(slots_5_11)}개):")
for s, ob in slots_5_11:
    marker = "  ← 신규" if s in ("19-20","20-21","21-22","22-23","23-24") or s.startswith("0") or s in ("00-01","01-02","02-03","03-04","04-05","05-06","06-07","07-08","08-09") else ""
    if ob or marker:
        print(f"  {s} | OB성공={ob}{marker}")
print(f"\n  → 5/11 OB 성공 시간대별 합: {ob_total_5_11}건  (예상: 61건)")

# 1.일별 5/11 확인
print()
print("[1.일별 5/11 — OB 수치 재확인]")
vals = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AL30",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])
for r in vals:
    if r and r[0] == '2026-05-11':
        print(f"  AA (OB부재): {r[26] if len(r) > 26 else ''}")
        print(f"  AB (OB 시도): {r[27] if len(r) > 27 else ''}")
        print(f"  AC (OB 성공): {r[28] if len(r) > 28 else ''}  (예상: 61)")
        print(f"  AD (OB 콜백제외): {r[29] if len(r) > 29 else ''}")
        print(f"  AF (OB 통화시간): {r[31] if len(r) > 31 else ''}")
        break

# 4.상담사별 합계 vs 1.일별 일치 확인
print()
print("[4.상담사별 5/11 OB_성공 vs 1.일별 — 일치 검증]")
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption='UNFORMATTED_VALUE',
).execute().get('values', [])
if res4 and len(res4) >= 3:
    dates, types = res4[0], res4[1]
    tgt = None
    for ci, (d, t) in enumerate(zip(dates, types)):
        if isinstance(d, str) and d == '2026-05-11' and t == 'OB_성공':
            tgt = ci
            break
    if tgt:
        total = 0
        for ri in range(2, len(res4)):
            v = res4[ri][tgt] if tgt < len(res4[ri]) and isinstance(res4[ri][tgt], (int, float)) else 0
            total += v
        print(f"  4.상담사별 OB_성공 합계: {total}건")

# IB 확인 - 변화 없어야
print()
print("[IB 변화 없음 검증]")
vals = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AL30",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])
for r in vals:
    if r and r[0] == '2026-05-11':
        print(f"  O (IB 접수호): {r[14]}  (이전: 376)")
        print(f"  P (IB 응대호): {r[15]}  (이전: 126)")
        break
