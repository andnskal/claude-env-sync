"""09:08을 포함하는 케이스만 찾기."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:B300",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

from datetime import datetime

print("[09:00 ~ 09:30 의 모든 포기호]")
for ri, row in enumerate(res):
    if not row or len(row) < 2:
        continue
    try:
        a_dt = datetime.fromisoformat(row[0].replace(' ', 'T'))
        b_dt = datetime.fromisoformat(row[1].replace(' ', 'T'))
        a_min = a_dt.hour * 60 + a_dt.minute
        b_min = b_dt.hour * 60 + b_dt.minute
        if 540 <= a_min <= 570 or (a_min <= 570 and b_min >= 540):
            print(f"  Row {ri+3}: {row[0]} - {row[1]} (분: {a_min}-{b_min})")
    except:
        continue

# 매칭 안되는 듯한데 SUMPRODUCT가 1을 반환했음. 다시 검증
print("\n[09:08 (548분) 포함 여부 정밀 검색]")
for ri, row in enumerate(res):
    if not row or len(row) < 2:
        continue
    try:
        a_dt = datetime.fromisoformat(row[0].replace(' ', 'T'))
        b_dt = datetime.fromisoformat(row[1].replace(' ', 'T'))
        a_min = a_dt.hour * 60 + a_dt.minute
        b_min = b_dt.hour * 60 + b_dt.minute
        # INT(value*1440) 대신 hour*60 + minute (반올림 다르게)
        if a_min <= 548 <= b_min:
            print(f"  ★ Row {ri+3}: {row[0]} - {row[1]} (분: {a_min}-{b_min})")
    except:
        pass
