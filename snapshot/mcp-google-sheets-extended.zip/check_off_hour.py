"""5/8 운영시간 외 콜 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5/8 운영시간 외 (09 이전, 19 이후) IB_포기호 카운트
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# N=날짜, P=시간대 (09-10), Q=구분, Y=콜백/알림톡, Z=기술
off_hour_aban = []
in_hour_aban = []
for row in all_calls:
    if len(row) > 11 and row[0] == "2026-05-08" and row[3] == "IB_포기호":
        time_band = row[2] if len(row) > 2 else ""
        Y = row[11] if len(row) > 11 else ""
        Z = row[12] if len(row) > 12 else ""
        if Y == "알림톡발송":
            continue
        if time_band:
            try:
                start_hour = int(time_band.split('-')[0])
                if start_hour < 9 or start_hour >= 19:
                    off_hour_aban.append((time_band, Y, Z))
                else:
                    in_hour_aban.append((time_band, Y, Z))
            except:
                pass

print(f"5/8 IB_포기호 (알림톡 제외):")
print(f"  운영시간 내 (09-19): {len(in_hour_aban)}건")
print(f"  운영시간 외 (00-09, 19-24): {len(off_hour_aban)}건")
print(f"  합계: {len(in_hour_aban) + len(off_hour_aban)}건")

# 운영시간 외 시간대 분포
from collections import Counter
print("\n[운영시간 외 시간대 분포]")
counts = Counter(b[0] for b in off_hour_aban)
for tb, c in sorted(counts.items()):
    print(f"  {tb}: {c}건")
