"""3·4 상담사별 가로 펼침 (날짜×채널) 재작성."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"


# ============================================================
# 3.상담사별 채팅 실적 — 가로 펼침
# ============================================================
# 기존 시트 클리어
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:LG1000", body={}
).execute()

# A1: 정렬 방향 (TRUE/FALSE)
# B1: 토글 (날짜-내림차순)
# C1+: 날짜 (각 4번 반복: 카카오/네이버/채널톡/기술이관)
# B2: 토글 (전체/본사/외주 고객센터/기술)
# C2+: "카카오","네이버","채널톡","기술이관" 4반복
# B3+: 상담사 명단 (B2 필터)
# C3+: COUNTIFS (답변)

a1_formula = '=IF(B1="날짜-오름차순","TRUE",IF(B1="날짜-내림차순","FALSE"))'
c1_formula = '=ARRAYFORMULA(IFERROR(TRANSPOSE(FLATTEN(SPLIT(TEXTJOIN(";",TRUE,REPT(SORT(UNIQUE(FILTER(\'6.채팅 상담내역\'!O2:O,\'6.채팅 상담내역\'!O2:O<>"")),1,A1)&";",4)),";")))))'
c2_formula = '=ARRAYFORMULA(SPLIT(REPT("카카오,네이버,채널톡,기술이관,",COUNTA(C1:LG1)/4),","))'

b3_formula = '''=IF(B2="본사",
SORT(UNIQUE(FILTER('6.채팅 상담내역'!N2:N,'6.채팅 상담내역'!N2:N<>"",(ISNUMBER(SEARCH("(CS)",'6.채팅 상담내역'!N2:N))+ISNUMBER(SEARCH("(기술)",'6.채팅 상담내역'!N2:N)))>0)),1,TRUE),
IF(B2="외주 고객센터",
SORT(UNIQUE(FILTER('6.채팅 상담내역'!N2:N,'6.채팅 상담내역'!N2:N<>"",ISNUMBER(SEARCH("쉐어링",'6.채팅 상담내역'!N2:N)))),1,TRUE),
IF(B2="기술",
SORT(UNIQUE(FILTER('6.채팅 상담내역'!N2:N,'6.채팅 상담내역'!N2:N<>"",ISNUMBER(SEARCH("(기술)",'6.채팅 상담내역'!N2:N)))),1,TRUE),
SORT(UNIQUE(FILTER('6.채팅 상담내역'!N2:N,'6.채팅 상담내역'!N2:N<>"")),1,TRUE)
)))'''

c3_formula = '''=ARRAYFORMULA(IF(ISBLANK(B3:B50),,IF(ISBLANK($C$2:$LG$2),,
MAP(B3:B50,LAMBDA(상담사,
COUNTIFS('6.채팅 상담내역'!$N:$N,상담사,
'6.채팅 상담내역'!$O:$O,$C$1:$LG$1,
'6.채팅 상담내역'!$M:$M,$C$2:$LG$2,
'6.채팅 상담내역'!$Y:$Y,"Y"))))))'''

# 작성
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1",
    valueInputOption="USER_ENTERED", body={"values": [[a1_formula]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!B1",
    valueInputOption="RAW", body={"values": [["날짜-내림차순"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!C1",
    valueInputOption="USER_ENTERED", body={"values": [[c1_formula]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!B2",
    valueInputOption="RAW", body={"values": [["전체"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!C2",
    valueInputOption="USER_ENTERED", body={"values": [[c2_formula]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!B3",
    valueInputOption="USER_ENTERED", body={"values": [[b3_formula]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!C3",
    valueInputOption="USER_ENTERED", body={"values": [[c3_formula]]},
).execute()
print("✅ 3.상담사별 채팅 가로 펼침 완성")

# ============================================================
# 4.상담사별 콜 실적 — 가로 펼침 (IB_성공/OB_성공/OB_실패)
# ============================================================
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:LG1000", body={}
).execute()

a1_call = '=IF(B1="날짜-오름차순","TRUE",IF(B1="날짜-내림차순","FALSE"))'
c1_call = '=ARRAYFORMULA(IFERROR(TRANSPOSE(FLATTEN(SPLIT(TEXTJOIN(";",TRUE,REPT(SORT(UNIQUE(FILTER(\'5.콜 상담내역\'!N2:N,\'5.콜 상담내역\'!N2:N<>"")),1,A1)&";",3)),";")))))'
c2_call = '=ARRAYFORMULA(SPLIT(REPT("IB_성공,OB_성공,OB_실패,",COUNTA(C1:LG1)/3),","))'

b3_call = '''=IF(B2="본사",
SORT(UNIQUE(FILTER('5.콜 상담내역'!W2:W,'5.콜 상담내역'!W2:W<>"",(ISNUMBER(SEARCH("(CS)",'5.콜 상담내역'!W2:W))+ISNUMBER(SEARCH("(기술)",'5.콜 상담내역'!W2:W)))>0)),1,TRUE),
IF(B2="외주 고객센터",
SORT(UNIQUE(FILTER('5.콜 상담내역'!W2:W,'5.콜 상담내역'!W2:W<>"",ISNUMBER(SEARCH("쉐어링",'5.콜 상담내역'!W2:W)))),1,TRUE),
IF(B2="기술",
SORT(UNIQUE(FILTER('5.콜 상담내역'!W2:W,'5.콜 상담내역'!W2:W<>"",ISNUMBER(SEARCH("(기술)",'5.콜 상담내역'!W2:W)))),1,TRUE),
SORT(UNIQUE(FILTER('5.콜 상담내역'!W2:W,'5.콜 상담내역'!W2:W<>"")),1,TRUE)
)))'''

c3_call = '''=ARRAYFORMULA(IF(ISBLANK(B3:B50),,IF(ISBLANK($C$2:$LG$2),,
MAP(B3:B50,LAMBDA(상담사,
COUNTIFS('5.콜 상담내역'!$W:$W,상담사,
'5.콜 상담내역'!$N:$N,$C$1:$LG$1,
'5.콜 상담내역'!$Q:$Q,$C$2:$LG$2))))))'''

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1",
    valueInputOption="USER_ENTERED", body={"values": [[a1_call]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!B1",
    valueInputOption="RAW", body={"values": [["날짜-내림차순"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!C1",
    valueInputOption="USER_ENTERED", body={"values": [[c1_call]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!B2",
    valueInputOption="RAW", body={"values": [["전체"]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!C2",
    valueInputOption="USER_ENTERED", body={"values": [[c2_call]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!B3",
    valueInputOption="USER_ENTERED", body={"values": [[b3_call]]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!C3",
    valueInputOption="USER_ENTERED", body={"values": [[c3_call]]},
).execute()
print("✅ 4.상담사별 콜 가로 펼침 완성")

# 행 고정 + 열 고정 + 헤더 색상
sid3 = _get_sheet_id_by_name(NEW, "3.상담사별 채팅 실적")
sid4 = _get_sheet_id_by_name(NEW, "4.상담사별 콜 실적")
reqs = []
for sid in [sid3, sid4]:
    reqs.append({
        "updateSheetProperties": {
            "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": 2, "frozenColumnCount": 2}},
            "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount",
        }
    })
_batch_update(NEW, reqs)
print("✅ 3·4 행 고정 2, 열 고정 2")
print("\n🎉 3·4 상담사별 가로 펼침 완료")
