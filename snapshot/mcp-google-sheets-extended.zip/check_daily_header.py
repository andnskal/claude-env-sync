"""1.일별, 2.시간대별 헤더 행 자세히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

for sheet_name, max_col in [("1.일별 전체 통계", 50), ("2.시간대별 전체통계", 38)]:
    print(f"\n{'='*100}")
    print(f"📋 {sheet_name} 헤더 (행 1, 2, 3)")
    print("=" * 100)
    
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A1:{col_letter(max_col-1)}5",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    
    print("\n[Row 1 - 그룹 헤더]")
    for ci in range(max_col):
        v = res[0][ci] if len(res) > 0 and ci < len(res[0]) else ""
        if v:
            print(f"  {col_letter(ci)}1: {v}")
    
    print("\n[Row 2 - 세부 헤더]")
    for ci in range(max_col):
        v = res[1][ci] if len(res) > 1 and ci < len(res[1]) else ""
        if v:
            print(f"  {col_letter(ci)}2: {v}")
    
    print("\n[Row 3 - 상세]")
    for ci in range(max_col):
        v = res[2][ci] if len(res) > 2 and ci < len(res[2]) else ""
        if v:
            print(f"  {col_letter(ci)}3: {v}")
