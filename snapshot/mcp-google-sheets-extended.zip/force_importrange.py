"""IMPORTRANGE 권한 재부여 + 데이터 강제 로드."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) RAW_NewMeet A1 수식 재입력
print("[RAW_NewMeet A1 재입력]")
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","\'UserChat meet data\'!A1:AG")']]},
).execute()
print("  OK")

# 2) RAW_UserChat A1, W1 재입력
print("\n[RAW_UserChat 재입력]")
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat!A1:V")']]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_UserChat'!W1",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat!W1:CS")']]},
).execute()
print("  OK")

print("\n로딩 대기 (30초)...")
time.sleep(30)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_NewMeet'!A1:E3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[RAW_NewMeet]")
for r in res[:3]:
    print(f"  {r}")

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1:E3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[RAW_UserChat]")
for r in res[:3]:
    print(f"  {r}")

# 5.콜 + 1.일별
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:Q3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[5.콜]")
for r in res[:3]:
    print(f"  {r[:5] if r else 'empty'}")

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:H10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별]")
for r in res[:5]:
    print(f"  {r}")
