"""★설정 시트 자세히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ★설정 헤더 + 첫 5행
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!A1:Y10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

def col_letter(idx):
    return chr(ord('A') + idx) if idx < 26 else 'A' + chr(ord('A') + idx - 26)

print("=" * 90)
print("★설정 시트 헤더 + 데이터")
print("=" * 90)
for ri, row in enumerate(res):
    print(f"\nRow {ri+1}:")
    for ci, v in enumerate(row):
        if v:
            print(f"  {col_letter(ci)}: {v}")
