"""1.일별 행 4 AC~AT 범위 확장."""
import os, sys, time, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# 행 4 AC~AT 수식 가져오기
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AC4:AT4",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])

if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(28 + ci)  # AC = 28
            # 모든 100, 200, 300 등 패턴을 1000으로
            new_v = re.sub(r":([A-Z]+)(\d{1,3})\b", lambda m: f":{m.group(1)}1000" if int(m.group(2)) < 1000 else f":{m.group(1)}{m.group(2)}", v)
            if new_v != v:
                _sheets.spreadsheets().values().update(
                    spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{col}4",
                    valueInputOption="USER_ENTERED",
                    body={"values": [[new_v]]},
                ).execute()
                print(f"  OK {col}4: 범위 1000으로 확장")

# 행 5 동일 검사 (AC~AT)
print("\n[행 5 AC~AT 검사]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AC5:AT5",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])

if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(28 + ci)
            new_v = re.sub(r":([A-Z]+)(\d{1,3})\b", lambda m: f":{m.group(1)}1000" if int(m.group(2)) < 1000 else f":{m.group(1)}{m.group(2)}", v)
            if new_v != v:
                _sheets.spreadsheets().values().update(
                    spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{col}5",
                    valueInputOption="USER_ENTERED",
                    body={"values": [[new_v]]},
                ).execute()
                print(f"  OK {col}5: 범위 확장")

time.sleep(3)

# 재점검
print("\n[재점검]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AT5",
    valueRenderOption="FORMULA",
).execute().get("values", [])
remaining = 0
for ri, row in enumerate(res):
    for ci, v in enumerate(row):
        if v and isinstance(v, str):
            patterns = re.findall(r":([A-Z]+)(\d+)", v)
            for p_col, p_num in patterns:
                if int(p_num) < 1000:
                    col = col_letter(ci)
                    print(f"  {col}{ri+4}: 여전히 :{p_col}{p_num}")
                    remaining += 1
                    break
print(f"\n남은 한정 범위: {remaining}개")
