"""2.시간대별 시트 수식 분석 - 운영시간 외 데이터가 어떻게 들어가는지."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 2.시간대별 행 4 수식
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:AL4",
    valueRenderOption="FORMULA",
).execute().get("values", [])

if res and res[0]:
    labels_h = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL"]
    print("[2.시간대별 행 4 수식 (시간대 09-10)]")
    for ci, lbl in enumerate(labels_h):
        v = res[0][ci] if ci < len(res[0]) else ""
        if v:
            print(f"\n  {lbl}4: {str(v)[:300]}")
