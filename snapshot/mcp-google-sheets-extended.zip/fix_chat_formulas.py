"""6.채팅 시트 RAW_UserChat 참조 수식 직접 수정."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 정확한 매핑 — 원래 _보조 채팅 B의 컬럼이 RAW_UserChat의 어디에 있는지
# _보조 채팅 B!X = UserChat의 AH+(X-1) → RAW_UserChat에서 X+33 컬럼
# A→AH, D→AK, K→AR, Q→AX, U→BB, V→BC, X→BE, AF→BM, AP→BW
fixes = {
    "B2": "AH",  # 원래 _보조 채팅 B!A
    "C2": "AK",  # !D
    "D2": "AR",  # !K
    "E2": "AX",  # !Q
    "F2": "BB",  # !U
    "S2": "BC",  # !V
    "T2": "BE",  # !X
    "U2": "BM",  # !AF
    "V2": "BW",  # !AP
}

print("[6.채팅 수식 직접 수정]")
for cell, raw_col in fixes.items():
    formula = f"=ARRAYFORMULA(IF('RAW_UserChat'!{raw_col}2:{raw_col}=\"\",,'RAW_UserChat'!{raw_col}2:{raw_col}))"
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'6.채팅 상담내역'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
    print(f"  {cell}: → 'RAW_UserChat'!{raw_col}")

time.sleep(8)

# 검증
print("\n[6.채팅 5/8 데이터]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res[:3]):
    if row:
        print(f"  Row {ri+2}: A={row[0] if len(row)>0 else ''}, B={row[1] if len(row)>1 else ''}, C={row[2] if len(row)>2 else ''}, D={row[3] if len(row)>3 else ''}, M={row[12] if len(row)>12 else ''}")

# 1.일별 5/8
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 5/8 KPI]")
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  H 채널톡 답변: {row[7]}")
        print(f"  M 기술이관: {row[12]}")
        print(f"  P 응대호: {row[15]}")
        print(f"  Q 포기호: {row[16]}")
        print(f"  AC OB 성공: {row[28]}")
        break
