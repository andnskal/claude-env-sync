"""권한 부여 후 데이터 확인 + ★설정 구조 + 통합 준비."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) RAW 55번 데이터 로드 확인
print("=" * 80)
print("[1] RAW 55번 기술 이관 데이터 확인")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A1:L8",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        non_empty = [(chr(ord('A')+ci), str(c)[:25]) for ci, c in enumerate(row) if c]
        print(f"  Row {ri+1}: {non_empty[:8]}")

# 데이터 행 수
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A:A",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n총 데이터 행 수: {sum(1 for r in res if r and r[0])}")

# H 컬럼 (인입 경로) 분포
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:H10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
h_dist = Counter(r[0] for r in res if r and r[0])
print(f"\nH (인입 경로) 분포:")
for k, v in h_dist.most_common():
    print(f"  {k}: {v}건")

# J 컬럼 (요청자 한글) 분포 — 외주 직원 매핑
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!J2:J10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
j_dist = Counter(r[0][:30] for r in res if r and r[0])
print(f"\nJ (요청자 한글) 상위 15개:")
for k, v in j_dist.most_common(15):
    print(f"  {k}: {v}건")

# 2) 신 시스템 ★설정 H 컬럼 (담당자 매핑) 확인
print("\n" + "=" * 80)
print("[2] 신 시스템 ★설정 H 컬럼 (담당자 매핑)")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!F1:J20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+1}: {row}")

# 3) 4/30 이후 RAW 55 데이터 (관심 있는 부분)
print("\n" + "=" * 80)
print("[3] RAW 55에서 4/30 이후 데이터 카운트")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!A2:H10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

cnt_after_430 = 0
sample = []
for row in res:
    if row and row[0]:
        a = row[0]  # 접수날짜
        # "2026.04.30" 같은 형식 파싱
        if "2026" in a:
            try:
                date_str = a.replace(".", "-")
                if date_str >= "2026-04-30":
                    cnt_after_430 += 1
                    if len(sample) < 5:
                        sample.append(row[:8])
            except:
                pass

print(f"  4/30 이후 RAW 55 데이터: {cnt_after_430}건")
print(f"  샘플:")
for s in sample:
    print(f"    {s}")
