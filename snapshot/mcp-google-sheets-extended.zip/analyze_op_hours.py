"""운영시간 외 콜의 시간대 분포 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 P (시간대) + X (tags) + N (날짜)
all_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:X3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 운영시간외 태그 시간대 분포
from collections import defaultdict
ops_outside_by_hour = defaultdict(int)
ops_inside_by_hour = defaultdict(int)
for row in all_data:
    if len(row) > 10:
        time_band = row[2] if len(row) > 2 else ""
        X_val = row[10] if len(row) > 10 else ""
        is_outside = "운영시간아님" in X_val
        if is_outside:
            ops_outside_by_hour[time_band] += 1
        else:
            ops_inside_by_hour[time_band] += 1

print("[X 컬럼 운영시간아님 vs 시간대 매트릭스]")
print(f"{'시간대':>10} | {'운영시간내':>10} | {'운영시간외':>10}")
all_hours = sorted(set(list(ops_inside_by_hour.keys()) + list(ops_outside_by_hour.keys())))
for tb in all_hours:
    inside = ops_inside_by_hour.get(tb, 0)
    outside = ops_outside_by_hour.get(tb, 0)
    print(f"{tb:>10} | {inside:>10} | {outside:>10}")

# 5.콜 첫 다이얼 시간 (C) HOUR/MINUTE 분석 - 운영시간 정확한 cutoff 찾기
print("\n[운영시간외 태그 콜의 startedAt 시간 (C 컬럼)]")
all_c = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!C2:X3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter
late_morning = []
late_evening = []
for row in all_c:
    if len(row) > 21 and "운영시간아님" in (row[21] if len(row) > 21 else ""):
        c_val = row[0] if row else ""
        if " " in c_val:
            time_part = c_val.split(" ")[1]
            if time_part >= "09:00:00" and time_part < "12:00:00":
                late_morning.append(time_part[:5])
            elif time_part >= "12:00:00":
                late_evening.append(time_part[:5])

morning_counts = Counter(late_morning)
evening_counts = Counter(late_evening)
print(f"\n  [09시 이후 운영시간외 태그 (오전 시작)]")
for t in sorted(morning_counts.keys())[:10]:
    print(f"    {t}: {morning_counts[t]}건")
print(f"\n  [12시 이후 운영시간외 태그 (오후 시작)] - 종료시간 추정")
for t in sorted(evening_counts.keys())[:30]:
    print(f"    {t}: {evening_counts[t]}건")
