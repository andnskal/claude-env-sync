"""4/30 운영시간 외 시간대 (06, 08, 19시) 콜의 X 태그 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("[4/30 시간대별 외 콜 — X 태그 확인]")
for row in all_calls:
    if len(row) > 29:
        A = row[0] if len(row) > 0 else ""
        C = row[2] if len(row) > 2 else ""  # startedAt
        B = row[1] if len(row) > 1 else ""  # direction
        Q = row[16] if len(row) > 16 else ""  # 구분
        N = row[13] if len(row) > 13 else ""  # 날짜
        P = row[15] if len(row) > 15 else ""  # 시간대
        X = row[23] if len(row) > 23 else ""  # tags(원본)
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        if N == "2026-04-30" and P in ("06-07", "07-08", "08-09", "19-20", "20-21", "21-22", "22-23", "23-24", "00-01", "01-02", "02-03", "03-04", "04-05", "05-06"):
            if AD == "내" and Q in ("IB_포기호", "OB_성공", "IB_성공"):
                print(f"  {C} | {B} | {Q} | P={P} | X='{X[:50]}' | AC={AC} | AD={AD}")
