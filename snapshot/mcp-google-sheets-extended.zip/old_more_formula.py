"""이전 시트 W:AH 수식 + Z 정의."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

formulas = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!W6:AH6",
    valueRenderOption="FORMULA",
).execute().get("values", [])

if formulas and formulas[0]:
    labels = ["W","X","Y","Z","AA","AB","AC","AD","AE","AF","AG","AH"]
    for ci, v in enumerate(formulas[0]):
        if v and isinstance(v, str):
            print(f"\n{labels[ci]}: {v[:400]}")
