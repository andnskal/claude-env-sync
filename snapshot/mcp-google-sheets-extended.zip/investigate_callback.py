"""콜백 정의 명확화 — OB 중 '콜백대상' 태그 가진 콜 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 5.콜 X 컬럼 (tags 원본)에 "콜백" 또는 "콜백대상" 포함된 행
print("=" * 80)
print("X 태그에 '콜백' 키워드 포함 — 분포")
print("=" * 80)
from collections import Counter
callback_x = Counter()
for row in all_calls:
    if len(row) > 23:
        X = row[23] if len(row) > 23 else ""
        if "콜백" in X:
            callback_x[X[:80]] += 1
for k, v in callback_x.most_common(15):
    print(f"  '{k}': {v}건")

# X 태그에 "콜백대상" 포함된 콜 - direction 별
print("\n[X에 '콜백' 포함된 콜 — direction 별]")
ib_callback = ob_callback = 0
ib_succ_cb = ib_aban_cb = ob_succ_cb = ob_fail_cb = 0
for row in all_calls:
    if len(row) > 23:
        B = row[1] if len(row) > 1 else ""
        Q = row[16] if len(row) > 16 else ""
        X = row[23] if len(row) > 23 else ""
        if "콜백" in X:
            if B == "inbound": ib_callback += 1
            elif B == "outbound": ob_callback += 1
            if Q == "IB_성공": ib_succ_cb += 1
            elif Q == "IB_포기호": ib_aban_cb += 1
            elif Q == "OB_성공": ob_succ_cb += 1
            elif Q == "OB_실패": ob_fail_cb += 1

print(f"  IB (모든): {ib_callback}건")
print(f"  OB (모든): {ob_callback}건")
print(f"  IB_성공 + 콜백: {ib_succ_cb}")
print(f"  IB_포기호 + 콜백: {ib_aban_cb}")
print(f"  OB_성공 + 콜백: {ob_succ_cb}")
print(f"  OB_실패 + 콜백: {ob_fail_cb}")

# 5/8 OB_성공 + 콜백 + 본사/외주
print("\n[5/8 OB_성공 + X에 '콜백' + AC=본사/외주, 운영시간 내]")
ob_callback_in = 0
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        X = row[23] if len(row) > 23 else ""
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        if N == "2026-05-08" and Q == "OB_성공" and "콜백" in X and AC in ("본사", "외주 고객센터") and AD == "내":
            ob_callback_in += 1
print(f"  카운트: {ob_callback_in}건")

# 모든 일자 OB_성공 + 콜백 + 본사/외주, 운영시간 내
print("\n[모든 일자 OB_성공 + 콜백 + 본사/외주, 운영시간 내]")
from collections import defaultdict
date_ob_cb = defaultdict(int)
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        X = row[23] if len(row) > 23 else ""
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        if N and Q == "OB_성공" and "콜백" in X and AC in ("본사", "외주 고객센터") and AD == "내":
            date_ob_cb[N] += 1
for d in sorted(date_ob_cb.keys()):
    print(f"  {d}: {date_ob_cb[d]}건")
