"""★설정 운영시간 정확한 범위 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ★설정 B 컬럼 (운영시간) 첫 ~ 끝
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B700",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 비어있지 않은 셀 카운트
non_empty = [(i+1, r[0]) for i, r in enumerate(res) if r and r[0]]
print(f"★설정 B 컬럼 (운영시간 시계열):")
print(f"  총 {len(non_empty)}개 셀")
print(f"  첫 5개: {non_empty[:5]}")
print(f"  마지막 5개: {non_empty[-5:]}")

# 점심시간 C 컬럼? 
print("\n[★설정 C 컬럼 (운영시간)]")
res_c = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!A1:E5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res_c):
    if row:
        print(f"  Row {ri+1}: {row}")

# 5.콜의 X 컬럼 (tags) 보면 운영시간 외 콜 표시
print("\n[5.콜 X 컬럼 'tags(원본)' 운영시간외 분류]")
all_x = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:X3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

ops_outside = 0
ops_inside = 0
ops_categories = {}
for row in all_x:
    if len(row) > 10:
        X_val = row[10] if len(row) > 10 else ""
        if "운영시간아님" in X_val:
            ops_outside += 1
        else:
            ops_inside += 1
        ops_categories[X_val[:30]] = ops_categories.get(X_val[:30], 0) + 1
print(f"  운영시간외 (X = '운영시간아님'): {ops_outside}건")
print(f"  운영시간 내: {ops_inside}건")

# 5.콜 P 시간대 unique
all_p = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!P2:P3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
hours = Counter(r[0] for r in all_p if r and r[0])
print(f"\n[5.콜 P (시간대) 분포]")
for tb in sorted(hours.keys()):
    print(f"  {tb}: {hours[tb]}건")
