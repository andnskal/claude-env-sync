"""★설정 시트 빈 컬럼 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ★설정 모든 컬럼 헤더 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!A1:AE1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])

if res and res[0]:
    for ci, h in enumerate(res[0]):
        col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
        if h:
            print(f"  {col}: '{h}'")
        else:
            print(f"  {col}: (빈)")
