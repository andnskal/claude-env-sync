"""각 카테고리를 다른 depth로 적용 - 분리 시도."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 기존 그룹 모두 삭제
print("[기존 그룹 삭제]")
for _ in range(10):
    meta = _sheets.spreadsheets().get(
        spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
    ).execute()
    del_reqs = []
    for s in meta.get("sheets", []):
        if s["properties"]["sheetId"] == sid:
            groups = s.get("columnGroups", [])
            if not groups: break
            # depth 큰 것부터
            for g in sorted(groups, key=lambda x: -x.get("depth", 1)):
                r = g["range"]
                del_reqs.append({
                    "deleteDimensionGroup": {
                        "range": {
                            "sheetId": sid,
                            "dimension": "COLUMNS",
                            "startIndex": r.get("startIndex", 0),
                            "endIndex": r.get("endIndex", 0),
                        }
                    }
                })
                break  # 한번에 하나씩
            break
    if not del_reqs:
        break
    _batch_update(NEW, del_reqs)
    time.sleep(1)
print("  OK 모두 삭제")

# 각 그룹을 nested 구조로 만들기
# Outer 그룹 (전체 데이터) → Inner 그룹들
# 핵심 트릭: Outer 그룹을 먼저 만들고, 그 안에 각 카테고리 Inner 그룹
# Inner 그룹은 같은 depth(2)지만 별도 토글 control 가짐

print("\n[중첩 구조 시도]")
print("  1) Outer: C-AW depth 1 (전체 그룹)")
_batch_update(NEW, [{
    "addDimensionGroup": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 49}
    }
}])
time.sleep(2)

print("  2) Inner (depth 2): 각 카테고리")
groups = [
    (2, 14, "채팅"),       # C-N
    (14, 26, "IB"),        # O-Z
    (26, 34, "OB"),        # AA-AH
    (34, 36, "콜백"),       # AI-AJ
    (36, 39, "KPI"),       # AK-AM
    (39, 46, "부재중"),     # AN-AT
    (46, 49, "참고"),       # AU-AW
]
for start, end, label in groups:
    try:
        _batch_update(NEW, [{
            "addDimensionGroup": {
                "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": start, "endIndex": end}
            }
        }])
        time.sleep(0.8)
    except Exception as e:
        print(f"    ⚠️ {label}: {e}")

time.sleep(3)

# 결과
print("\n[최종]")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
).execute()
def cl(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        groups_now = s.get("columnGroups", [])
        print(f"  그룹 {len(groups_now)}개:")
        for g in sorted(groups_now, key=lambda x: (x.get("depth", 0), x["range"].get("startIndex", 0))):
            r = g["range"]
            print(f"    depth {g.get('depth',0)}: {cl(r['startIndex'])}-{cl(r['endIndex']-1)}")
        break
