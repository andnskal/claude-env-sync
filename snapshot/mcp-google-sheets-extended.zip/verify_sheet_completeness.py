"""시트 전체 정합성 점검:
1. 1.일별 ↔ 2.시간대별 ↔ 4.상담사별 합계 일치 여부
2. 모든 일자에서 OB 룰 변경 효과 (운영시간 외 포함이 어디서 어떻게 잡혔는지)
3. 다른 일자에도 점심시간 경계 IB_성공 케이스가 있는지
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets
from collections import Counter, defaultdict

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

print("="*80)
print("[1] 5.콜에서 모든 일자 OB_성공 / IB_성공 직접 카운트")
print("="*80)

calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD11112",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])

date_stats = defaultdict(lambda: {
    "IB성공_내": 0, "IB성공_외": 0,
    "IB포기_내": 0, "IB포기_외": 0,
    "OB성공_내": 0, "OB성공_외": 0,
    "OB실패_내": 0, "OB실패_외": 0,
})

for r in calls:
    if len(r) < 30: continue
    d = r[13]
    q = r[16]
    ad = r[29]
    if not d or not q: continue
    k = q.replace("_성공","성공_").replace("_포기호","포기_").replace("_실패","실패_")
    key = f"{k}{ad}"
    if key in date_stats[d]:
        date_stats[d][key] += 1

print(f"\n{'날짜':>12} | {'IB성공내':>5} {'IB성공외':>5} | {'OB성공내':>5} {'OB성공외':>5} | OB성공합")
print("-"*80)
for d in sorted(date_stats.keys()):
    if d.startswith("2026-05"):
        s = date_stats[d]
        ob_total = s['OB성공_내'] + s['OB성공_외']
        print(f"  {d} | {s['IB성공_내']:>5} {s['IB성공_외']:>5} | "
              f"{s['OB성공_내']:>5} {s['OB성공_외']:>5} | {ob_total:>5}")

# ─────────── 1.일별 vs 5.콜 직접 카운트 매칭 ───────────
print("\n" + "="*80)
print("[2] 1.일별 시트값 vs 5.콜 직접카운트 매칭 검증")
print("="*80)

vals = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AL30",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])

print(f"\n{'날짜':>12} | {'시트 IB응대':>10} {'직접 IB내':>10} | "
      f"{'시트 OB성공':>10} {'직접 OB(내+외)':>13} | 일치?")
print("-"*100)
mismatches = []
for r in vals:
    if not r or not r[0] or "2026-05" not in r[0]: continue
    d = r[0]
    ib_sheet = int(r[19]) if len(r) > 19 and r[19] else 0  # T column index 19 = 1.일별 응대호
    ob_sheet = int(r[28]) if len(r) > 28 and r[28] else 0  # AC column
    s = date_stats[d]
    ib_in = s['IB성공_내']
    ob_all = s['OB성공_내'] + s['OB성공_외']
    ok_ib = (ib_sheet == ib_in)
    ok_ob = (ob_sheet == ob_all)
    ok = ok_ib and ok_ob
    flag = "✅" if ok else "❌"
    print(f"  {d} | {ib_sheet:>10} {ib_in:>10} | {ob_sheet:>10} {ob_all:>13} | {flag}")
    if not ok:
        mismatches.append((d, ib_sheet, ib_in, ob_sheet, ob_all))

if mismatches:
    print(f"\n  ⚠️ 불일치 {len(mismatches)}건")
else:
    print(f"\n  ✅ 모든 일자 일치 — 1.일별 = 5.콜 직접카운트")

# ─────────── 4.상담사별 합계 vs 1.일별 매칭 ───────────
print("\n" + "="*80)
print("[3] 4.상담사별 OB_성공 합계 = 1.일별 OB성공 일치 검증")
print("="*80)

res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:CV50",
    valueRenderOption='UNFORMATTED_VALUE',
).execute().get('values', [])

if res4 and len(res4) >= 3:
    dates_row = res4[0]
    types_row = res4[1]
    # 각 (날짜, OB_성공) 컬럼 인덱스 모으기
    cols_by_date = defaultdict(dict)
    for ci, (d, t) in enumerate(zip(dates_row, types_row)):
        if isinstance(d, str) and d.startswith("2026-05") and t in ("IB_성공","OB_성공"):
            cols_by_date[d][t] = ci

    # 1.일별 데이터 dict
    daily_sheet = {}
    for r in vals:
        if not r or not r[0]: continue
        if not r[0].startswith("2026-05"): continue
        daily_sheet[r[0]] = {
            "IB": int(r[19]) if len(r)>19 and r[19] else 0,
            "OB": int(r[28]) if len(r)>28 and r[28] else 0,
        }

    print(f"\n{'날짜':>12} | {'1.일별 IB':>10} {'4.상담 IB':>10} | "
          f"{'1.일별 OB':>10} {'4.상담 OB':>10} | 일치?")
    print("-"*80)
    for d in sorted(cols_by_date.keys()):
        ib_col = cols_by_date[d].get("IB_성공")
        ob_col = cols_by_date[d].get("OB_성공")
        ib_sum = 0
        ob_sum = 0
        for ri in range(2, len(res4)):
            row = res4[ri]
            if ib_col is not None and ib_col < len(row):
                v = row[ib_col]
                if isinstance(v, (int, float)): ib_sum += int(v)
            if ob_col is not None and ob_col < len(row):
                v = row[ob_col]
                if isinstance(v, (int, float)): ob_sum += int(v)
        ib_daily = daily_sheet.get(d, {}).get("IB", 0)
        ob_daily = daily_sheet.get(d, {}).get("OB", 0)
        ok_ib = (ib_sum == ib_daily)
        ok_ob = (ob_sum == ob_daily)
        flag = "✅" if ok_ib and ok_ob else "❌"
        print(f"  {d} | {ib_daily:>10} {ib_sum:>10} | {ob_daily:>10} {ob_sum:>10} | {flag}")

# ─────────── 2.시간대별 합계 vs 1.일별 매칭 ───────────
print("\n" + "="*80)
print("[4] 2.시간대별 일자별 합계 vs 1.일별 매칭")
print("="*80)

slot_vals = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:Z1000",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])

slot_sum = defaultdict(lambda: {"IB응대": 0, "OB성공": 0, "OB실패": 0})
for r in slot_vals:
    if not r or len(r) < 26: continue
    d = r[1]  # B = 날짜 텍스트
    if not d or not d.startswith("2026-05"): continue
    try:
        # L = index 11 = 응대호 (기술 제외)
        l_val = int(r[11]) if r[11] and r[11] != "" else 0
    except:
        l_val = 0
    try:
        x_val = int(r[23]) if r[23] and r[23] != "" else 0  # X = OB 성공
    except:
        x_val = 0
    try:
        y_val = int(r[24]) if r[24] and r[24] != "" else 0  # Y = OB 실패
    except:
        y_val = 0
    slot_sum[d]["IB응대"] += l_val
    slot_sum[d]["OB성공"] += x_val
    slot_sum[d]["OB실패"] += y_val

print(f"\n{'날짜':>12} | {'1.일별 IB응대':>13} {'2.시간대별 합':>14} | "
      f"{'1.일별 OB성공':>13} {'2.시간대별 합':>14} | 일치?")
print("-"*100)
for d in sorted(daily_sheet.keys()):
    daily = daily_sheet[d]
    slot = slot_sum[d]
    ok_ib = (daily["IB"] == slot["IB응대"])
    ok_ob = (daily["OB"] == slot["OB성공"])
    flag = "✅" if ok_ib and ok_ob else "❌"
    print(f"  {d} | {daily['IB']:>13} {slot['IB응대']:>14} | "
          f"{daily['OB']:>13} {slot['OB성공']:>14} | {flag}")

# ─────────── 점심시간 경계 케이스 ───────────
print("\n" + "="*80)
print("[5] 점심시간 경계 (12:59:59 / 13:59:59 / 14:00:00) IB_성공 케이스")
print("="*80)
lunch_cases = []
for r in calls:
    if len(r) < 30: continue
    if r[16] != "IB_성공": continue
    if not r[2]: continue
    try:
        t = r[2].split(" ")[1]
        h, m, s = int(t.split(":")[0]), int(t.split(":")[1]), int(t.split(":")[2])
        # 점심 직전(12:55~12:59) or 점심 중(13:00~13:59) or 점심 직후(14:00~14:05)
        if (h == 12 and m >= 55) or h == 13 or (h == 14 and m <= 5):
            lunch_cases.append(r)
    except: continue

for r in lunch_cases:
    print(f"  {r[13]} {r[2]} | engaged={r[3] if len(r)>3 else '-'} | AD={r[29]} | {r[22] if len(r)>22 else ''}")

# ─────────── 17:30 경계 케이스 (전 일자) ───────────
print("\n" + "="*80)
print("[6] 17:25 ~ 17:35 IB_성공 (전 일자) — 운영시간 경계")
print("="*80)
boundary = []
for r in calls:
    if len(r) < 30: continue
    if r[16] != "IB_성공": continue
    if not r[2]: continue
    try:
        t = r[2].split(" ")[1]
        h, m = int(t.split(":")[0]), int(t.split(":")[1])
        if h == 17 and 25 <= m <= 59:
            boundary.append(r)
    except: continue

for r in boundary:
    print(f"  {r[13]} {r[2]} | engaged={r[3] if len(r)>3 else '-'} | AD={r[29]} | {r[22] if len(r)>22 else ''}")
