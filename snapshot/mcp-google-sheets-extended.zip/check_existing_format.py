"""1.일별, 2.시간대별 기존 헤더 색상 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 행 1-3 색상 확인
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'1.일별 전체 통계'!A1:AT3"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat(backgroundColor,textFormat)))))"
).execute()

def color_to_hex(c):
    if not c:
        return "default"
    r = int(c.get("red", 0) * 255)
    g = int(c.get("green", 0) * 255)
    b = int(c.get("blue", 0) * 255)
    return f"#{r:02X}{g:02X}{b:02X}"

rows = fmt["sheets"][0]["data"][0]["rowData"]
for ri, r in enumerate(rows[:3]):
    if "values" not in r:
        continue
    print(f"\n[1.일별 Row {ri+1} 색상]")
    prev_color = None
    start_col = 0
    for ci, cell in enumerate(r.get("values", [])):
        bg = cell.get("userEnteredFormat", {}).get("backgroundColor", {})
        color = color_to_hex(bg)
        if color != prev_color:
            if prev_color is not None:
                col_l = chr(ord('A') + start_col) if start_col < 26 else 'A' + chr(ord('A') + start_col - 26)
                col_e = chr(ord('A') + ci - 1) if (ci-1) < 26 else 'A' + chr(ord('A') + ci - 1 - 26)
                print(f"  {col_l}-{col_e}: {prev_color}")
            prev_color = color
            start_col = ci
    # 마지막
    if prev_color:
        col_l = chr(ord('A') + start_col) if start_col < 26 else 'A' + chr(ord('A') + start_col - 26)
        print(f"  {col_l}-끝: {prev_color}")
