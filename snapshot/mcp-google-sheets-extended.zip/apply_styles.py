"""신 시스템에 기존 시각적 서식을 일괄 적용."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _hex_to_rgb_dict, _get_sheet_id_by_name, _a1_to_grid_range, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"


def make_bg_request(sheet_id, start_row, end_row, start_col, end_col, hex_color):
    return {
        "repeatCell": {
            "range": {"sheetId": sheet_id, "startRowIndex": start_row, "endRowIndex": end_row,
                      "startColumnIndex": start_col, "endColumnIndex": end_col},
            "cell": {"userEnteredFormat": {"backgroundColor": _hex_to_rgb_dict(hex_color)}},
            "fields": "userEnteredFormat.backgroundColor",
        }
    }


def make_text_request(sheet_id, start_row, end_row, start_col, end_col, *, bold=None, font_size=None, fg_hex=None, halign="CENTER", valign="MIDDLE"):
    text_fmt = {}
    fields = []
    fmt = {}
    fmt_fields = []
    if bold is not None:
        text_fmt["bold"] = bold
        fields.append("bold")
    if font_size is not None:
        text_fmt["fontSize"] = font_size
        fields.append("fontSize")
    if fg_hex is not None:
        text_fmt["foregroundColor"] = _hex_to_rgb_dict(fg_hex)
        fields.append("foregroundColor")
    cell = {"userEnteredFormat": {}}
    if text_fmt:
        cell["userEnteredFormat"]["textFormat"] = text_fmt
        fmt_fields.extend([f"userEnteredFormat.textFormat.{f}" for f in fields])
    if halign:
        cell["userEnteredFormat"]["horizontalAlignment"] = halign
        fmt_fields.append("userEnteredFormat.horizontalAlignment")
    if valign:
        cell["userEnteredFormat"]["verticalAlignment"] = valign
        fmt_fields.append("userEnteredFormat.verticalAlignment")
    return {
        "repeatCell": {
            "range": {"sheetId": sheet_id, "startRowIndex": start_row, "endRowIndex": end_row,
                      "startColumnIndex": start_col, "endColumnIndex": end_col},
            "cell": cell,
            "fields": ",".join(fmt_fields),
        }
    }


def make_merge_request(sheet_id, start_row, end_row, start_col, end_col):
    return {
        "mergeCells": {
            "range": {"sheetId": sheet_id, "startRowIndex": start_row, "endRowIndex": end_row,
                      "startColumnIndex": start_col, "endColumnIndex": end_col},
            "mergeType": "MERGE_ALL",
        }
    }


def make_freeze_request(sheet_id, frozen_rows, frozen_cols):
    return {
        "updateSheetProperties": {
            "properties": {"sheetId": sheet_id,
                           "gridProperties": {"frozenRowCount": frozen_rows, "frozenColumnCount": frozen_cols}},
            "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount",
        }
    }


def make_number_format_request(sheet_id, start_row, end_row, start_col, end_col, fmt_type, pattern):
    return {
        "repeatCell": {
            "range": {"sheetId": sheet_id, "startRowIndex": start_row, "endRowIndex": end_row,
                      "startColumnIndex": start_col, "endColumnIndex": end_col},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": fmt_type, "pattern": pattern}}},
            "fields": "userEnteredFormat.numberFormat",
        }
    }


def make_column_width_request(sheet_id, start_col, end_col, pixel):
    return {
        "updateDimensionProperties": {
            "range": {"sheetId": sheet_id, "dimension": "COLUMNS", "startIndex": start_col, "endIndex": end_col},
            "properties": {"pixelSize": pixel},
            "fields": "pixelSize",
        }
    }


def make_borders_request(sheet_id, start_row, end_row, start_col, end_col, style="SOLID", color_hex="000000"):
    border = {"style": style, "color": _hex_to_rgb_dict(color_hex)}
    return {
        "updateBorders": {
            "range": {"sheetId": sheet_id, "startRowIndex": start_row, "endRowIndex": end_row,
                      "startColumnIndex": start_col, "endColumnIndex": end_col},
            "top": border, "bottom": border, "left": border, "right": border,
            "innerHorizontal": border, "innerVertical": border,
        }
    }


# =====================================================
# 1.일별 전체 통계 — 가장 정교한 시각적 정리
# =====================================================
def style_1_daily():
    sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")
    reqs = []

    # 행 고정 + 열 고정
    reqs.append(make_freeze_request(sid, 3, 1))

    # === 병합 ===
    # 행1: 대분류
    reqs.append(make_merge_request(sid, 0, 1, 2, 11))   # C1:K1 = "채팅 전체 (ALF 제외)"
    reqs.append(make_merge_request(sid, 0, 2, 11, 14))  # L1:N2 = "채팅(인하우스+도급사)"
    reqs.append(make_merge_request(sid, 0, 1, 14, 33))  # O1:AG1 = "유선 현황 (인하우스+도급사)"
    # 행2: 중분류
    reqs.append(make_merge_request(sid, 1, 3, 1, 2))    # B2:B3 = "구분"
    reqs.append(make_merge_request(sid, 1, 2, 2, 4))    # C2:D2 = "카카오"
    reqs.append(make_merge_request(sid, 1, 2, 4, 6))    # E2:F2 = "네이버"
    reqs.append(make_merge_request(sid, 1, 2, 6, 8))    # G2:H2 = "채널톡"
    reqs.append(make_merge_request(sid, 1, 2, 8, 11))   # I2:K2 = "본사+도급사 합계"
    reqs.append(make_merge_request(sid, 1, 2, 14, 26))  # O2:Z2 = "IB"
    reqs.append(make_merge_request(sid, 1, 2, 28, 33))  # AC2:AG2 = "OB 그룹"

    # === 헤더 행1 (대분류) — 짙은 청록·짙은 파랑, 흰 글자, bold, 11pt ===
    # C-K (채팅 전체) 청록 #134F5C
    reqs.append(make_bg_request(sid, 0, 1, 2, 11, "134F5C"))
    reqs.append(make_text_request(sid, 0, 1, 2, 11, bold=True, font_size=11, fg_hex="FFFFFF"))
    # L-N (채팅 인하우스+도급사) 청록
    reqs.append(make_bg_request(sid, 0, 2, 11, 14, "134F5C"))
    reqs.append(make_text_request(sid, 0, 2, 11, 14, bold=True, font_size=11, fg_hex="FFFFFF"))
    # O-AG (유선) 짙은 파랑 #1B325B
    reqs.append(make_bg_request(sid, 0, 1, 14, 33, "1B325B"))
    reqs.append(make_text_request(sid, 0, 1, 14, 33, bold=True, font_size=11, fg_hex="FFFFFF"))
    # AH (알림톡) 짙은 파랑
    reqs.append(make_bg_request(sid, 0, 1, 33, 34, "1B325B"))
    reqs.append(make_text_request(sid, 0, 1, 33, 34, bold=True, font_size=11, fg_hex="FFFFFF"))

    # === 헤더 행2 (중분류) ===
    reqs.append(make_bg_request(sid, 1, 2, 1, 14, "134F5C"))
    reqs.append(make_text_request(sid, 1, 2, 1, 14, bold=True, font_size=11, fg_hex="FFFFFF"))
    reqs.append(make_bg_request(sid, 1, 2, 14, 34, "1B325B"))
    reqs.append(make_text_request(sid, 1, 2, 14, 34, bold=True, font_size=11, fg_hex="FFFFFF"))

    # === 헤더 행3 (컬럼명) — 그룹별 파스텔 색상 ===
    # A,B (날짜/요일): 흰 + bold
    reqs.append(make_text_request(sid, 2, 3, 0, 2, bold=True, font_size=10))
    # C-K (채팅 전체) #9BBB59 연두
    reqs.append(make_bg_request(sid, 2, 3, 2, 11, "9BBB59"))
    reqs.append(make_text_request(sid, 2, 3, 2, 11, bold=True, font_size=10))
    # L-N (채팅 인하우스) #FCE5CD 살구
    reqs.append(make_bg_request(sid, 2, 3, 11, 14, "FCE5CD"))
    reqs.append(make_text_request(sid, 2, 3, 11, 14, bold=True, font_size=10))
    # O-R (IB 알림톡 제외) #D9EAD3 밝은 초록
    reqs.append(make_bg_request(sid, 2, 3, 14, 18, "D9EAD3"))
    reqs.append(make_text_request(sid, 2, 3, 14, 18, bold=True, font_size=10))
    # S-V (IB 기술포기호 제외) #FFF2CC 밝은 노랑
    reqs.append(make_bg_request(sid, 2, 3, 18, 22, "FFF2CC"))
    reqs.append(make_text_request(sid, 2, 3, 18, 22, bold=True, font_size=10))
    # W-X (IB 통화시간/ATT) #D9EAD3
    reqs.append(make_bg_request(sid, 2, 3, 22, 24, "D9EAD3"))
    reqs.append(make_text_request(sid, 2, 3, 22, 24, bold=True, font_size=10))
    # Y-Z (IB 투입인원) #EFEFEF 회색
    reqs.append(make_bg_request(sid, 2, 3, 24, 26, "EFEFEF"))
    reqs.append(make_text_request(sid, 2, 3, 24, 26, bold=True, font_size=10))
    # AA-AG (OB) #BDD7EE 밝은 파랑
    reqs.append(make_bg_request(sid, 2, 3, 26, 33, "BDD7EE"))
    reqs.append(make_text_request(sid, 2, 3, 26, 33, bold=True, font_size=10))
    # AH (알림톡) #EFEFEF
    reqs.append(make_bg_request(sid, 2, 3, 33, 34, "EFEFEF"))
    reqs.append(make_text_request(sid, 2, 3, 33, 34, bold=True, font_size=10))

    # === 데이터 행 숫자 형식 ===
    # A,B 날짜
    reqs.append(make_number_format_request(sid, 3, 100, 0, 2, "DATE", "yyyy\"-\"mm\"-\"dd"))
    # C-J (채팅 인입/답변) NUMBER 0
    reqs.append(make_number_format_request(sid, 3, 100, 2, 10, "NUMBER", "0"))
    # K (답변율) PERCENT 0.0%
    reqs.append(make_number_format_request(sid, 3, 100, 10, 11, "PERCENT", "0.0%"))
    # L,M,N NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 11, 14, "NUMBER", "0"))
    # O-Q NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 14, 17, "NUMBER", "0"))
    # R 응대율 PERCENT 0.00%
    reqs.append(make_number_format_request(sid, 3, 100, 17, 18, "PERCENT", "0.00%"))
    # S-U NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 18, 21, "NUMBER", "0"))
    # V 응대율 PERCENT 0.00%
    reqs.append(make_number_format_request(sid, 3, 100, 21, 22, "PERCENT", "0.00%"))
    # W-X 통화시간 (초) → TIME [hh]:mm:ss는 Google에서 시간대로 자동 처리됨. 우리는 초 데이터라 단순 숫자로 둠
    reqs.append(make_number_format_request(sid, 3, 100, 22, 24, "NUMBER", "#,##0"))
    # Y-Z 투입인원 NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 24, 26, "NUMBER", "0.0"))
    # AA-AC NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 26, 29, "NUMBER", "0"))
    # AD OB응답률 PERCENT
    reqs.append(make_number_format_request(sid, 3, 100, 29, 30, "PERCENT", "0.00%"))
    # AE NUMBER (콜백)
    reqs.append(make_number_format_request(sid, 3, 100, 30, 31, "NUMBER", "0"))
    # AF OB통화시간 (초) NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 31, 32, "NUMBER", "#,##0"))
    # AG OB평균통화 NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 32, 33, "NUMBER", "0.0"))
    # AH 알림톡발송 NUMBER
    reqs.append(make_number_format_request(sid, 3, 100, 33, 34, "NUMBER", "0"))

    # 열 너비 — A,B 좁게, KPI 열 보통
    reqs.append(make_column_width_request(sid, 0, 1, 90))   # A 날짜
    reqs.append(make_column_width_request(sid, 1, 2, 60))   # B 요일
    reqs.append(make_column_width_request(sid, 2, 34, 75))  # 나머지 75px

    # 헤더 테두리
    reqs.append(make_borders_request(sid, 0, 3, 0, 34))

    return reqs


# =====================================================
# 2.시간대별 전체통계
# =====================================================
def style_2_hourly():
    sid = _get_sheet_id_by_name(NEW, "2.시간대별 전체통계")
    reqs = []

    reqs.append(make_freeze_request(sid, 3, 3))

    # 병합
    reqs.append(make_merge_request(sid, 0, 2, 3, 6))    # D1:F2 = "투입인원"
    reqs.append(make_merge_request(sid, 0, 1, 6, 23))   # G1:W1 = "IB"
    reqs.append(make_merge_request(sid, 0, 2, 23, 27))  # X1:AA2 = "OB"
    reqs.append(make_merge_request(sid, 0, 1, 27, 38))  # AB1:AL1 = "채팅"
    reqs.append(make_merge_request(sid, 1, 2, 6, 9))    # G2:I2 (콜백+알림톡 제외)
    reqs.append(make_merge_request(sid, 1, 2, 9, 14))   # J2:N2 (기술포기호+알림톡 제외)
    reqs.append(make_merge_request(sid, 1, 2, 15, 23))  # P2:W2 (알림톡만 제외)
    reqs.append(make_merge_request(sid, 1, 2, 27, 32))  # AB2:AF2 (채팅 합계)
    reqs.append(make_merge_request(sid, 1, 2, 32, 34))  # AG2:AH2 카카오
    reqs.append(make_merge_request(sid, 1, 2, 34, 36))  # AI2:AJ2 네이버
    reqs.append(make_merge_request(sid, 1, 2, 36, 38))  # AK2:AL2 채널톡

    # 색상
    # 행1
    reqs.append(make_bg_request(sid, 0, 1, 0, 3, "FFFFFF"))
    reqs.append(make_text_request(sid, 0, 1, 0, 3, bold=True, font_size=14))
    reqs.append(make_bg_request(sid, 0, 2, 3, 6, "D0E0E3"))
    reqs.append(make_text_request(sid, 0, 2, 3, 6, bold=True, font_size=12))
    reqs.append(make_bg_request(sid, 0, 1, 6, 23, "D9EAD3"))
    reqs.append(make_text_request(sid, 0, 1, 6, 23, bold=True, font_size=14))
    reqs.append(make_bg_request(sid, 0, 2, 23, 27, "FCE5CD"))
    reqs.append(make_text_request(sid, 0, 2, 23, 27, bold=True, font_size=12))
    reqs.append(make_bg_request(sid, 0, 1, 27, 38, "FFF2CC"))
    reqs.append(make_text_request(sid, 0, 1, 27, 38, bold=True, font_size=14))

    # 행2 IB 그룹 색
    reqs.append(make_bg_request(sid, 1, 2, 6, 9, "FF9900"))   # 콜백+알림톡 제외 주황
    reqs.append(make_text_request(sid, 1, 2, 6, 9, bold=True, font_size=10, fg_hex="FFFFFF"))
    reqs.append(make_bg_request(sid, 1, 2, 9, 14, "FFF2CC"))  # 기술포기호+알림톡 제외
    reqs.append(make_text_request(sid, 1, 2, 9, 14, bold=True, font_size=10))
    reqs.append(make_bg_request(sid, 1, 2, 15, 23, "D9EAD3")) # 알림톡만 제외
    reqs.append(make_text_request(sid, 1, 2, 15, 23, bold=True, font_size=10))
    # 행2 채팅
    reqs.append(make_bg_request(sid, 1, 2, 27, 38, "FFF2CC"))
    reqs.append(make_text_request(sid, 1, 2, 27, 38, bold=True, font_size=10))

    # 행3 컬럼명
    reqs.append(make_text_request(sid, 2, 3, 0, 3, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 3, 6, "D0E0E3"))
    reqs.append(make_text_request(sid, 2, 3, 3, 6, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 6, 9, "FF9900"))
    reqs.append(make_text_request(sid, 2, 3, 6, 9, bold=True, font_size=9, fg_hex="FFFFFF"))
    # 행3 J-N (기술 인입 제외) — K(응대율), N(기술포기호) = 빨강 강조
    reqs.append(make_bg_request(sid, 2, 3, 9, 10, "D9EAD3"))   # J 총접수호
    reqs.append(make_text_request(sid, 2, 3, 9, 10, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 10, 11, "FF0000"))  # K 포기호 빨강
    reqs.append(make_text_request(sid, 2, 3, 10, 11, bold=True, font_size=9, fg_hex="FFFFFF"))
    reqs.append(make_bg_request(sid, 2, 3, 11, 12, "D9EAD3"))  # L 응대호
    reqs.append(make_text_request(sid, 2, 3, 11, 12, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 12, 13, "D9EAD3"))  # M 응대율
    reqs.append(make_text_request(sid, 2, 3, 12, 13, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 13, 15, "FF0000"))  # N,O 기술포기호 빨강
    reqs.append(make_text_request(sid, 2, 3, 13, 15, bold=True, font_size=9, fg_hex="FFFFFF"))
    reqs.append(make_bg_request(sid, 2, 3, 15, 17, "FF0000"))  # P,Q 알림톡만 제외 — 포기호 강조
    reqs.append(make_text_request(sid, 2, 3, 15, 17, bold=True, font_size=9, fg_hex="FFFFFF"))
    reqs.append(make_bg_request(sid, 2, 3, 17, 23, "D9EAD3"))  # R-W 응대 관련
    reqs.append(make_text_request(sid, 2, 3, 17, 23, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 23, 27, "FCE5CD"))  # OB
    reqs.append(make_text_request(sid, 2, 3, 23, 27, bold=True, font_size=9))
    reqs.append(make_bg_request(sid, 2, 3, 27, 38, "FFF2CC"))  # 채팅
    reqs.append(make_text_request(sid, 2, 3, 27, 38, bold=True, font_size=9))

    # 데이터 숫자 형식
    reqs.append(make_number_format_request(sid, 3, 600, 8, 9, "PERCENT", "0.0%"))     # I 응대율
    reqs.append(make_number_format_request(sid, 3, 600, 12, 13, "PERCENT", "0.00%"))  # M 응대율
    reqs.append(make_number_format_request(sid, 3, 600, 18, 19, "PERCENT", "0.0%"))   # S 응대율
    reqs.append(make_number_format_request(sid, 3, 600, 19, 21, "NUMBER", "#,##0"))   # T,U 통화/평균(초)
    reqs.append(make_number_format_request(sid, 3, 600, 25, 27, "NUMBER", "#,##0"))   # Z,AA OB
    reqs.append(make_number_format_request(sid, 3, 600, 29, 30, "PERCENT", "0.00%"))  # AD 답변율
    reqs.append(make_number_format_request(sid, 3, 600, 31, 32, "PERCENT", "0.00%"))  # AF 기여도

    # 열 너비
    reqs.append(make_column_width_request(sid, 0, 3, 80))
    reqs.append(make_column_width_request(sid, 3, 38, 65))

    return reqs


# =====================================================
# 5.콜 상담내역
# =====================================================
def style_5_call():
    sid = _get_sheet_id_by_name(NEW, "5.콜 상담내역")
    reqs = []
    reqs.append(make_freeze_request(sid, 1, 0))
    # 헤더 색상
    reqs.append(make_bg_request(sid, 0, 1, 0, 12, "D9D9D9"))    # A-L 회색
    reqs.append(make_bg_request(sid, 0, 1, 12, 16, "FFFF00"))   # M-P 노랑 (가공)
    reqs.append(make_bg_request(sid, 0, 1, 16, 23, "FFF2CC"))   # Q-W 밝은 노랑
    reqs.append(make_bg_request(sid, 0, 1, 23, 26, "FCE5CD"))   # X-Z (신규 추가) 살구
    reqs.append(make_text_request(sid, 0, 1, 0, 26, bold=True, font_size=10))
    # 행 높이
    reqs.append(make_column_width_request(sid, 0, 1, 200))   # userChatId
    reqs.append(make_column_width_request(sid, 1, 26, 110))  # 나머지
    return reqs


# =====================================================
# 6.채팅 상담내역
# =====================================================
def style_6_chat():
    sid = _get_sheet_id_by_name(NEW, "6.채팅 상담내역")
    reqs = []
    reqs.append(make_freeze_request(sid, 1, 0))
    # A-L: 흰색 + bold
    reqs.append(make_text_request(sid, 0, 1, 0, 12, bold=True, font_size=10))
    # M-V (가공 컬럼) 노랑
    reqs.append(make_bg_request(sid, 0, 1, 12, 22, "FFFF00"))
    reqs.append(make_text_request(sid, 0, 1, 12, 22, bold=True, font_size=11))
    # W-Y (신규 추가 인하우스/사람처리/매니저답변) 살구
    reqs.append(make_bg_request(sid, 0, 1, 22, 25, "FCE5CD"))
    reqs.append(make_text_request(sid, 0, 1, 22, 25, bold=True, font_size=10))
    # 열 너비
    reqs.append(make_column_width_request(sid, 0, 1, 200))
    reqs.append(make_column_width_request(sid, 1, 25, 100))
    return reqs


# =====================================================
# 3.상담사별 채팅 / 4.상담사별 콜
# =====================================================
def style_3_4_agent():
    out = []
    for name, cols in [("3.상담사별 채팅 실적", 10), ("4.상담사별 콜 실적", 10)]:
        sid = _get_sheet_id_by_name(NEW, name)
        out.append(make_freeze_request(sid, 1, 1))
        # 헤더 짙은 청록 + 흰 글자
        out.append(make_bg_request(sid, 0, 1, 0, cols, "134F5C"))
        out.append(make_text_request(sid, 0, 1, 0, cols, bold=True, font_size=11, fg_hex="FFFFFF"))
        out.append(make_column_width_request(sid, 0, 1, 150))
        out.append(make_column_width_request(sid, 1, cols, 100))
    return out


# =====================================================
# ★설정
# =====================================================
def style_settings():
    sid = _get_sheet_id_by_name(NEW, "★설정")
    reqs = []
    reqs.append(make_freeze_request(sid, 1, 0))
    # 행1 헤더 진한 색 + 흰 글자
    reqs.append(make_bg_request(sid, 0, 1, 0, 25, "134F5C"))
    reqs.append(make_text_request(sid, 0, 1, 0, 25, bold=True, font_size=11, fg_hex="FFFFFF"))
    # 열 너비
    reqs.append(make_column_width_request(sid, 0, 1, 320))    # A RAW URL
    reqs.append(make_column_width_request(sid, 1, 5, 100))    # B-E 운영시간/공휴일
    reqs.append(make_column_width_request(sid, 5, 12, 130))   # F-L 매핑
    reqs.append(make_column_width_request(sid, 12, 25, 110))
    return reqs


# =====================================================
# 실행
# =====================================================
ALL_REQS = []
print("📋 1.일별 전체 통계 서식 생성 중...")
ALL_REQS.extend(style_1_daily())
print("📋 2.시간대별 전체통계 서식 생성 중...")
ALL_REQS.extend(style_2_hourly())
print("📋 5.콜 상담내역 서식 생성 중...")
ALL_REQS.extend(style_5_call())
print("📋 6.채팅 상담내역 서식 생성 중...")
ALL_REQS.extend(style_6_chat())
print("📋 3·4 상담사별 서식 생성 중...")
ALL_REQS.extend(style_3_4_agent())
print("📋 ★설정 서식 생성 중...")
ALL_REQS.extend(style_settings())

print(f"\n총 {len(ALL_REQS)}개 요청 → batchUpdate 실행")

# 배치 분할 (한 번에 너무 많으면 실패)
BATCH_SIZE = 100
for i in range(0, len(ALL_REQS), BATCH_SIZE):
    batch = ALL_REQS[i:i+BATCH_SIZE]
    try:
        _batch_update(NEW, batch)
        print(f"  ✅ 배치 {i//BATCH_SIZE + 1}: {len(batch)}개 적용")
    except Exception as e:
        print(f"  ❌ 배치 {i//BATCH_SIZE + 1} 실패: {e}")

print("\n🎉 시각적 정리 완료")
