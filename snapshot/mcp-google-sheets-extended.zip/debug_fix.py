"""데이터 정확성 디버깅 + 수정."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ============================================================
# Fix 1: 시간대별 A4 — 텍스트로 강제 (DATE 시리얼 변환 방지)
# ============================================================
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4",
    valueInputOption="USER_ENTERED",
    body={"values": [[
        '=ARRAYFORMULA(IFERROR(TEXT(FLATTEN(SPLIT(TEXTJOIN(";",TRUE,REPT(SORT(UNIQUE(FILTER(\'5.콜 상담내역\'!N2:N,\'5.콜 상담내역\'!N2:N<>"")))&";",10)),";")),"yyyy-mm-dd")))'
    ]]},
).execute()
print("✅ 2.시간대별 A4 텍스트 강제 (DATE 시리얼 방지)")

# ============================================================
# Fix 2: 1.일별 ARRAYFORMULA 산술 수식 행4:C → 행6:C
# 산술 수식들: I, J, K, N, R, T, V, X, AB, AD, AG, AJ
# ============================================================
fixes = [
    # I (본사+TCK 인입): C+E+G
    ("I6", '=ARRAYFORMULA(IF(A6:A="",,C6:C+E6:E+G6:G))'),
    # J (본사+TCK 답변): D+F+H
    ("J6", '=ARRAYFORMULA(IF(A6:A="",,D6:D+F6:F+H6:H))'),
    # K (답변율): J/I
    ("K6", '=ARRAYFORMULA(IF(I6:I=0,,J6:J/I6:I))'),
    # N (Total): L+M
    ("N6", '=ARRAYFORMULA(IF(A6:A="",,L6:L+M6:M))'),
    # R (응대율 알림톡 제외): P/O
    ("R6", '=ARRAYFORMULA(IF(O6:O=0,,P6:P/O6:O))'),
    # T (응대호) = P
    ("T6", '=ARRAYFORMULA(IF(A6:A="",,P6:P))'),
    # V (응대율 기술포기호 제외): T/S = P/S
    ("V6", '=ARRAYFORMULA(IF(S6:S=0,,T6:T/S6:S))'),
    # X (ATT): W/P
    ("X6", '=ARRAYFORMULA(IF(P6:P=0,,W6:W/P6:P))'),
    # AB (OB 시도 전체): AA + AC
    ("AB6", '=ARRAYFORMULA(IF(A6:A="",,AA6:AA+AC6:AC))'),
    # AD (OB 콜백 제외): AC - AE
    ("AD6", '=ARRAYFORMULA(IF(A6:A="",,AC6:AC-AE6:AE))'),
    # AG (OB 평균통화): AF/AD
    ("AG6", '=ARRAYFORMULA(IF(AD6:AD=0,,AF6:AF/AD6:AD))'),
]

for cell, formula in fixes:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{cell}",
        valueInputOption="USER_ENTERED", body={"values": [[formula]]},
    ).execute()
print(f"✅ 1.일별 산술 수식 {len(fixes)}개 수정 (행4:C → 행6:C)")

# ============================================================
# Fix 3: 1.일별 BYROW의 LEFT(d,10) 매칭 검증
# d = "2026-04-30 (목)" 형태이므로 LEFT(d,10) = "2026-04-30" — OK
# 시간대별 B = TEXT 텍스트 (Fix 1 후) — OK
# 매칭 정상화 예상
# ============================================================

# Z 헤더 변경 ÷ 9 → ÷ 10 (운영 10시간으로 변경)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!Z3",
    valueInputOption="RAW",
    body={"values": [["IB\n투입인원\n- 시간대별합 ÷ 10"]]},
).execute()

# Z 수식: SUMIFS 시간대별 D / 10
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!Z6",
    valueInputOption="USER_ENTERED",
    body={"values": [[
        '=BYROW(A6:A,LAMBDA(d,IF(d="",,SUMIFS(\'2.시간대별 전체통계\'!$D:$D,\'2.시간대별 전체통계\'!$B:$B,LEFT(d,10))/10)))'
    ]]},
).execute()
print("✅ Z 헤더/수식 ÷ 10 (운영시간 10시간 반영)")

print("\n🎉 디버깅 수정 완료")
