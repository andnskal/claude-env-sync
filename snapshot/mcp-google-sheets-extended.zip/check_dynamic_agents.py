"""1분단위 F3:T3 동적 상담사 헤더 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1분단위 F3:Z3 (헤더 행)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!F3:Z3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("1분단위 F3:Z3 (동적 상담사 헤더):")
print(res)

# 헤더 (행 2)도 확인
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2:Z3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n1분단위 E2:Z3 (전체):")
for row in res2:
    print(row)
