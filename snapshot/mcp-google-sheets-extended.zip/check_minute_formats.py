"""1분단위 + 5분단위 시트 모든 셀 서식 점검."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

for sheet_name in ["1분 단위 포기호, 통화상세", "5분 단위 포기호, 통화상세"]:
    print(f"\n{'='*80}")
    print(f"📋 {sheet_name}")
    print("=" * 80)
    
    # 헤더 + 데이터 첫 5행 서식 + 표시값
    fmt = _sheets.spreadsheets().get(
        spreadsheetId=NEW, ranges=[f"'{sheet_name}'!A1:V8"],
        includeGridData=True,
        fields="sheets(data(rowData(values(userEnteredFormat,formattedValue,userEnteredValue))))"
    ).execute()
    rows = fmt["sheets"][0]["data"][0]["rowData"]
    
    for ri, r in enumerate(rows[:8]):
        for ci, cell in enumerate(r.get("values", [])):
            fmt_obj = cell.get("userEnteredFormat", {}).get("numberFormat", {})
            val = cell.get("formattedValue", "")
            raw = cell.get("userEnteredValue", {})
            if val or raw:
                col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
                fmt_type = fmt_obj.get("type", "AUTO")
                fmt_pat = fmt_obj.get("pattern", "")
                # 중요한 셀만
                if ci < 7 or (ri == 0 and ci < 22) or (ri == 1 and ci < 22) or (ri == 2 and ci < 22):
                    print(f"  {col}{ri+1}: val='{val}' / type={fmt_type} pat='{fmt_pat}'")
