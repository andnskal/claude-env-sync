"""1분단위 E4 + F4:T4 수식 — 부동소수점 오류 회피 위해 텍스트 비교로 재작성."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Helper: build SUMPRODUCT formula with text comparison
def make_sumproduct(raw_a, raw_b, range_n=300):
    """LEFT 16자 비교로 분 단위 매칭. 부동소수점 오류 회피."""
    return (
        f'(LEFT(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300,16)<>"")*'
        f'(LEFT(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300,16)<=LEFT(일시,16))*'
        f'(LEFT(\'RAW시간대별 포기호, 통화상세\'!${raw_b}$3:${raw_b}$300,16)>=LEFT(일시,16))'
    )

# E4: 포기호 (A:B 범위)
e4_formula = (
    f'=MAP(C4:C513, LAMBDA(일시, '
    f'IF(ISBLANK(일시),, '
    f'IF(SUMPRODUCT({make_sumproduct("A", "B")})>0,"********",))))'
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E4",
    valueInputOption="USER_ENTERED",
    body={"values": [[e4_formula]]},
).execute()
print(f"✅ E4 (포기호) 재작성 — LEFT 16자 비교")

# F4:T4 (15명) → 각각 RAW의 C/D, E/F, G/H, ... 페어 참조
agent_starts = ['C', 'E', 'G', 'I', 'K', 'M', 'O', 'Q', 'S', 'U', 'W', 'Y', 'AA', 'AC', 'AE']
agent_ends   = ['D', 'F', 'H', 'J', 'L', 'N', 'P', 'R', 'T', 'V', 'X', 'Z', 'AB', 'AD', 'AF']
oneminute_letters = ['F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T']

for letter, raw_a, raw_b in zip(oneminute_letters, agent_starts, agent_ends):
    formula = (
        f'=MAP($C$4:$C$513, LAMBDA(일시, '
        f'IF(ISBLANK(일시),, '
        f'IF(SUMPRODUCT({make_sumproduct(raw_a, raw_b)})>0,"********",))))'
    )
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1분 단위 포기호, 통화상세'!{letter}4",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
print(f"✅ F4:T4 (15명) 재작성")

# 검증
import time; time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A30:V42",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[1분단위 9:25~9:38 영역 (수정 후)]")
print(f"{'행':>4} | {'시간':>6} | {'통화중':>4} | {'포기호':>10} | {'F(기술_김진향)':>15}")
for ri, row in enumerate(res):
    if not row: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    e = row[4] if len(row) > 4 else ""
    f = row[5] if len(row) > 5 else ""
    print(f"{ri+30:>4} | {time_str:>6} | {counta:>4} | {e:>10} | {f:>15}")

print("\n[검증] 9:32:25-9:33:51 통화는 9:32, 9:33 모두 매칭되어야 함")
print("[검증] 9:50:49-9:52:55 통화는 9:50, 9:51, 9:52 매칭되어야 함")
