"""Q 컬럼 수식 - 첫 데이터 행."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 행 6 (4/30) 수식 - 첫 데이터 행
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:U6",
    valueRenderOption="FORMULA",
).execute().get("values", [])

labels_full = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U"]
print("[1.일별 행 6 (4/30) 수식]")
if res and res[0]:
    for ci, lbl in enumerate(labels_full):
        v = res[0][ci] if ci < len(res[0]) else ""
        if v:
            print(f"\n  {lbl}6: {str(v)[:200]}")

# 또한 ARRAY 수식이 있는지 행 5 (합계) 확인
print("\n\n[행 5 (합계) 수식]")
res5 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A5:U5",
    valueRenderOption="FORMULA",
).execute().get("values", [])
if res5 and res5[0]:
    for ci, lbl in enumerate(labels_full):
        v = res5[0][ci] if ci < len(res5[0]) else ""
        if v:
            print(f"  {lbl}5: {str(v)[:150]}")
