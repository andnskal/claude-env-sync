"""모든 시트의 병합 영역 + 헤더 구조 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# 모든 시트의 merges 정보 가져오기
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties,merges)"
).execute()

for s in meta.get("sheets", []):
    name = s["properties"]["title"]
    if name == "시트1":
        continue
    merges = s.get("merges", [])
    print(f"\n{'='*70}")
    print(f"📋 {name} — 병합: {len(merges)}개")
    print("=" * 70)
    if merges:
        # 행별로 정렬
        merges_sorted = sorted(merges, key=lambda m: (m.get("startRowIndex", 0), m.get("startColumnIndex", 0)))
        for m in merges_sorted[:30]:
            sr, er = m.get("startRowIndex", 0), m.get("endRowIndex", 0)
            sc, ec = m.get("startColumnIndex", 0), m.get("endColumnIndex", 0)
            range_str = f"{col_letter(sc)}{sr+1}:{col_letter(ec-1)}{er}"
            print(f"  {range_str}")
        if len(merges) > 30:
            print(f"  ... 외 {len(merges)-30}개")
