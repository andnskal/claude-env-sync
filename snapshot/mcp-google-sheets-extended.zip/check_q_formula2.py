"""Q 컬럼 수식 정확히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5/8은 데이터 행 12. 수식 직접 가져오기
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!O12:U12",
    valueRenderOption="FORMULA",
).execute().get("values", [])

labels = ["O", "P", "Q", "R", "S", "T", "U"]
print("[1.일별 5/8 (행 12) 수식]")
if res and res[0]:
    for ci, lbl in enumerate(labels):
        v = res[0][ci] if ci < len(res[0]) else ""
        print(f"\n  {lbl}12: {v}")
