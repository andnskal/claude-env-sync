"""모든 시트의 시간/날짜 형식 전수 점검."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"


def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


# 점검 대상: 각 시트 + 시간/날짜 가능성 컬럼 + 적절한 형식
TARGETS = {
    "1.일별 전체 통계": {
        "expected_data_row": 6,
        "checks": [
            ("A", "DATE", "yyyy-mm-dd (ddd)", "날짜"),
            ("B", "DATE", "yyyy-mm-dd (ddd)", "구분(요일)"),
            ("W", "TIME", "[h]:mm:ss", "IB 통화시간(총)"),
            ("X", "TIME", "[h]:mm:ss", "IB 평균통화(ATT)"),
            ("AF", "TIME", "[h]:mm:ss", "OB 통화시간(총)"),
            ("AG", "TIME", "[h]:mm:ss", "OB 평균통화"),
        ],
    },
    "2.시간대별 전체통계": {
        "expected_data_row": 4,
        "checks": [
            ("A", "DATE", "yyyy-mm-dd", "일자"),
            ("B", "TEXT_OR_DATE", None, "날짜 텍스트변환"),
            ("C", None, None, "시간(텍스트 09-10)"),
            ("T", "TIME", "[h]:mm:ss", "IB 통화시간"),
            ("U", "TIME", "[h]:mm:ss", "IB 평균통화"),
            ("Z", "TIME", "[h]:mm:ss", "OB 통화시간"),
            ("AA", "TIME", "[h]:mm:ss", "OB 평균통화"),
        ],
    },
    "5.콜 상담내역": {
        "expected_data_row": 2,
        "checks": [
            ("C", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "startedAt"),
            ("D", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "firstEngagedAt"),
            ("E", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "endedAt"),
            ("J", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "firstPostCallStartedAt"),
            ("K", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "firstPostCallEndedAt"),
            ("S", "TIME", "[h]:mm:ss", "통화시간"),
            ("T", "TIME", "[h]:mm:ss", "후처리시간"),
            ("U", "TIME", "[h]:mm:ss", "대기시간"),
            ("V", "TIME", "[h]:mm:ss", "보류시간"),
            ("N", None, None, "날짜(텍스트 yyyy-mm-dd)"),
        ],
    },
    "6.채팅 상담내역": {
        "expected_data_row": 2,
        "checks": [
            ("B", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "createdAt"),
            ("C", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "firstAskedAt"),
            ("D", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "firstOpenedAt"),
            ("E", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "firstAnsweredAt"),
            ("F", "DATE_TIME", "yyyy-mm-dd hh:mm:ss", "closedAt"),
            ("O", None, None, "날짜(텍스트)"),
        ],
    },
    "★설정": {
        "expected_data_row": 2,
        "checks": [
            ("B", "TIME_OR_TEXT", None, "운영시간"),
            ("C", "TIME_OR_TEXT", None, "점심시간"),
            ("D", "DATE", "yyyy-mm-dd", "공휴일"),
            ("F", "DATE", "yyyy-mm-dd", "날짜 텍스트변환"),
        ],
    },
    "3.상담사별 채팅 실적": {
        "expected_data_row": 3,
        "checks": [
            ("C", "DATE", "yyyy-mm-dd", "행1 날짜"),
        ],
    },
    "4.상담사별 콜 실적": {
        "expected_data_row": 3,
        "checks": [
            ("C", "DATE", "yyyy-mm-dd", "행1 날짜"),
        ],
    },
}


def col_to_idx(col):
    idx = 0
    for c in col:
        idx = idx * 26 + (ord(c) - ord("A") + 1)
    return idx - 1


def check_format(sheet_name, col, row, expected_type, expected_pattern, description):
    col_idx = col_to_idx(col)
    rng = f"'{sheet_name}'!{col}{row}:{col}{row}"
    res = _sheets.spreadsheets().get(
        spreadsheetId=NEW, ranges=[rng], includeGridData=True,
        fields="sheets(data(rowData(values(userEnteredValue,formattedValue,userEnteredFormat))))"
    ).execute()
    rows = res["sheets"][0].get("data", [{}])[0].get("rowData", [])
    if not rows or "values" not in rows[0] or not rows[0]["values"]:
        return f"  ❓ {col}{row} ({description}) — 데이터 없음"
    cell = rows[0]["values"][0]
    fmt = cell.get("userEnteredFormat", {}).get("numberFormat", {})
    actual_type = fmt.get("type")
    actual_pattern = fmt.get("pattern")
    formatted = cell.get("formattedValue", "")
    raw = cell.get("userEnteredValue", {})

    status = "✅"
    msg_parts = []
    if expected_type:
        if expected_type == "TEXT_OR_DATE":
            if actual_type not in (None, "DATE", "TEXT"):
                status = "⚠️"
                msg_parts.append(f"형식={actual_type} (TEXT 또는 DATE 기대)")
        elif expected_type == "TIME_OR_TEXT":
            if actual_type not in (None, "TIME", "TEXT"):
                status = "⚠️"
                msg_parts.append(f"형식={actual_type} (TIME 또는 TEXT 기대)")
        elif actual_type != expected_type:
            status = "❌"
            msg_parts.append(f"형식={actual_type} (기대: {expected_type})")
    if expected_pattern:
        if actual_pattern and expected_pattern.replace('"', '').replace(' ', '') not in actual_pattern.replace('"', '').replace(' ', ''):
            if status != "❌":
                status = "⚠️"
            msg_parts.append(f"패턴={actual_pattern[:30]}")

    extras = " | ".join(msg_parts) if msg_parts else f"형식={actual_type}"
    return f"  {status} {col}{row} ({description}): 표시='{formatted[:25]}' / {extras}"


for sheet_name, info in TARGETS.items():
    print(f"\n📋 {sheet_name}")
    print("-" * 70)
    row = info["expected_data_row"]
    for col, etype, epattern, desc in info["checks"]:
        try:
            print(check_format(sheet_name, col, row, etype, epattern, desc))
        except Exception as e:
            print(f"  ⚠️ {col}{row} ({desc}): 오류 - {e}")
