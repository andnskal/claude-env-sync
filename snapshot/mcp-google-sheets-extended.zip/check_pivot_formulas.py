"""3,4 시트의 모든 수식 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 3.상담사별 채팅 - C3 수식 (모든 데이터 행에 적용)
for sheet_name in ["3.상담사별 채팅 실적", "4.상담사별 콜 실적"]:
    print(f"\n=== {sheet_name} ===")
    # 행 3 수식
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A3:E5",
        valueRenderOption="FORMULA",
    ).execute().get("values", [])
    for ri, row in enumerate(res):
        for ci, v in enumerate(row):
            if v and isinstance(v, str) and v.startswith("="):
                col = chr(ord('A') + ci)
                print(f"\n  {col}{ri+3}: {str(v)[:300]}")
