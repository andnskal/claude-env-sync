"""3,4 시트 A:B 컬럼 자세히."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

for sheet_name in ["3.상담사별 채팅 실적", "4.상담사별 콜 실적"]:
    print("\n" + "=" * 80)
    print(f"📋 {sheet_name}")
    print("=" * 80)
    
    # A:B 컬럼 (행 1-30)
    formulas = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A1:B30",
        valueRenderOption="FORMULA",
    ).execute().get("values", [])
    values = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A1:B30",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    
    print("\n[A:B 컬럼 (행 1-30)]")
    for ri in range(min(30, len(formulas))):
        for ci in range(2):
            f = formulas[ri][ci] if ri < len(formulas) and ci < len(formulas[ri]) else ""
            v = values[ri][ci] if ri < len(values) and ci < len(values[ri]) else ""
            if f or v:
                col = chr(ord('A') + ci)
                print(f"  {col}{ri+1}: F='{str(f)[:80]}' / V='{str(v)[:30]}'")
