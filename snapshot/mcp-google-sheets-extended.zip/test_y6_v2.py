"""1.일별 Y6 진단 - AX 컬럼 사용."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

test_formulas = [
    ("AX1", '=COUNTIFS(\'5.콜 상담내역\'!N:N, "2026-04-30", \'5.콜 상담내역\'!Q:Q, "IB_성공")'),
    ("AX2", '=COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!W:W, \'5.콜 상담내역\'!N:N="2026-04-30", \'5.콜 상담내역\'!Q:Q="IB_성공", \'5.콜 상담내역\'!W:W<>"기타", \'5.콜 상담내역\'!W:W<>"")))'),
    ("AX3", '=A6'),  # A6 값
    ("AX4", '=LEFT(A6, 10)'),
    ("AX5", '=BYROW(A6:A20, LAMBDA(d, IF(d="",,COUNTIFS(\'5.콜 상담내역\'!$N:$N,LEFT(d,10),\'5.콜 상담내역\'!$Q:$Q,"IB_성공"))))'),
]

for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(3)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1:AX20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

labels = [
    "4/30 IB_성공 카운트",
    "4/30 unique 상담사 카운트",
    "A6 값",
    "LEFT(A6, 10)",
    "BYROW spillover (시작)"
]
for i, label in enumerate(labels):
    val = res[i][0] if i < len(res) and res[i] else 'N/A'
    print(f"  {label}: {val}")

print("\n[AX5 BYROW spillover]")
for i in range(4, 20):
    val = res[i][0] if i < len(res) and res[i] else ''
    if val:
        print(f"  AX{i+1}: {val}")

# AX 정리
import time
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AX1:AX25"
).execute()
