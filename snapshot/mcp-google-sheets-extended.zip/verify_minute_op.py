"""1분/5분단위 운영시간 적용 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 4/30, 5/4, 5/8 모두 검증
for serial, date in [("46142", "4/30"), ("46146", "5/4"), ("46150", "5/8")]:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
        valueInputOption="USER_ENTERED",
        body={"values": [[serial]]},
    ).execute()
    time.sleep(8)
    
    raw_a = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    raw_count = sum(1 for r in raw_a if r and r[0])
    
    one_min = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E4:E513",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    one_cnt = sum(1 for r in one_min if r and "*" in (r[0] if r else ""))
    
    five_min = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E4:E135",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    five_cnt = sum(1 for r in five_min if r and "*" in (r[0] if r else ""))
    
    # 1.일별 U (포기호 기술제외)와 비교 - 운영시간 내
    daily = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:U60",
        valueRenderOption="UNFORMATTED_VALUE",
    ).execute().get("values", [])
    daily_u = "?"
    target_date = f"2026-0{date.replace('/', '-0')}".replace("4-04", "4-30").replace("5-04", "5-04").replace("5-08", "5-08")
    target_date = "2026-04-30" if date == "4/30" else f"2026-05-0{date.split('/')[1]}"
    for row in daily:
        if row and isinstance(row[0], str) and row[0] == target_date:
            daily_u = row[20] if len(row) > 20 else "?"
            break
    
    print(f"\n📅 {date} ({target_date}):")
    print(f"  RAW시간대별 (포기호 알림+기술 제외 운영시간 내): {raw_count}건")
    print(f"  1분단위 매칭 분: {one_cnt}분")
    print(f"  5분단위 buckets: {five_cnt}")
    print(f"  1.일별 U (포기호 기술제외): {daily_u}")
    match = "✅" if raw_count == daily_u else "❌"
    print(f"  RAW vs 1.일별 U: {match}")
