"""디버깅 잔재 정리 + E2 서식 재적용."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 1분단위 + 5분단위 X, Y, AA, AB 등 모든 비공식 컬럼 클리어
for sheet in ["1분 단위 포기호, 통화상세", "5분 단위 포기호, 통화상세"]:
    # W~Z 컬럼 (V는 통화 외 시간 공식 사용)
    _sheets.spreadsheets().values().clear(
        spreadsheetId=NEW, range=f"'{sheet}'!W1:Z1000"
    ).execute()
    # 또한 데이터 검증 잔재
    print(f"OK {sheet} W~Z 컬럼 클리어")

# 2) 1.일별 시트 AU~AX 등 디버깅 잔재 클리어
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AU1:AX200"
).execute()
print("OK 1.일별 AU~AX 클리어")

# 3) 1분단위 + 5분단위 E2 서식 재적용
sid_1m = _get_sheet_id_by_name(NEW, "1분 단위 포기호, 통화상세")
sid_5m = _get_sheet_id_by_name(NEW, "5분 단위 포기호, 통화상세")
reqs = [
    {
        "repeatCell": {
            "range": {"sheetId": sid_1m, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 4, "endColumnIndex": 5},
            "cell": {"userEnteredFormat": {
                "numberFormat": {"type": "DATE", "pattern": "yyyy-mm-dd"},
                "backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
                "textFormat": {"bold": True, "fontSize": 11, "foregroundColor": {"red": 0.6, "green": 0.0, "blue": 0.0}},
                "horizontalAlignment": "CENTER",
            }},
            "fields": "userEnteredFormat(numberFormat,backgroundColor,textFormat,horizontalAlignment)",
        }
    },
    {
        "repeatCell": {
            "range": {"sheetId": sid_5m, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 4, "endColumnIndex": 5},
            "cell": {"userEnteredFormat": {
                "numberFormat": {"type": "DATE", "pattern": "yyyy-mm-dd"},
                "backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
                "textFormat": {"bold": True, "fontSize": 11, "foregroundColor": {"red": 0.6, "green": 0.0, "blue": 0.0}},
                "horizontalAlignment": "CENTER",
            }},
            "fields": "userEnteredFormat(numberFormat,backgroundColor,textFormat,horizontalAlignment)",
        }
    }
]
_batch_update(NEW, reqs)
print("OK 1분/5분단위 E2 DATE 서식 재적용")

time.sleep(3)

# 4) 다른 시트도 디버깅 잔재 검사
print("\n[다른 시트 비어있어야 할 영역 검사]")
sheets_to_check = [
    ("★설정", "Z1:Z200"),
    ("1.일별 전체 통계", "AY1:AX200"),
    ("2.시간대별 전체통계", "AM1:AM200"),
    ("3.상담사별 채팅 실적", "BE1:BE200"),
    ("4.상담사별 콜 실적", "BE1:BE200"),
    ("5.콜 상담내역", "AE1:AE200"),
    ("6.채팅 상담내역", "AA1:AA200"),
    ("RAW시간대별 포기호, 통화상세", "AG1:AG200"),
]
for sheet, rng in sheets_to_check:
    try:
        res = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=f"'{sheet}'!{rng}",
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        non_empty = [r for r in res if r and any(c for c in r)]
        if non_empty:
            print(f"  ⚠️ {sheet} {rng}: {len(non_empty)}개 비어있지 않은 셀")
        else:
            print(f"  ✅ {sheet} {rng}: 비어있음")
    except Exception as e:
        print(f"  ⚠️ {sheet}: {str(e)[:50]}")

# 5) 1분단위 E2 검증
res = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'1분 단위 포기호, 통화상세'!E2"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue))))"
).execute()
e2 = res["sheets"][0]["data"][0]["rowData"][0]["values"][0]
fmt_t = e2.get("userEnteredFormat", {}).get("numberFormat", {}).get("type", "?")
fmt_p = e2.get("userEnteredFormat", {}).get("numberFormat", {}).get("pattern", "?")
val = e2.get("formattedValue", "?")
print(f"\n[E2 최종 상태] 표시='{val}' / 서식={fmt_t} '{fmt_p}'")
