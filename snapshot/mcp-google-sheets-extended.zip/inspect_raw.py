"""RAW 업로드 시트 구조 조사."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW 업로드 시트 시트 목록
print("=" * 80)
print("[RAW 업로드 시트 구조]")
print("=" * 80)
meta = _sheets.spreadsheets().get(spreadsheetId=RAW).execute()
for s in meta.get("sheets", []):
    p = s["properties"]
    g = p["gridProperties"]
    print(f"\n📄 {p['title']}")
    print(f"  - 행: {g.get('rowCount', 0)} / 열: {g.get('columnCount', 0)}")
    
    # 헤더 가져오기 (첫 1-2행)
    try:
        h = _sheets.spreadsheets().values().get(
            spreadsheetId=RAW, range=f"'{p['title']}'!A1:AZ2",
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        if h:
            for ri, row in enumerate(h):
                non_empty = sum(1 for c in row if c)
                if non_empty > 0:
                    print(f"  Row {ri+1}: {non_empty}개 비어있지 않은 셀")
                    if ri == 0 and non_empty > 0:
                        # 첫 5개 헤더
                        first_5 = [c for c in row[:8] if c]
                        print(f"    샘플: {first_5}")
    except Exception as e:
        print(f"  ⚠️ 읽기 오류: {e}")

# 신 시스템에서 IMPORTRANGE 연결 확인
print("\n" + "=" * 80)
print("[신 시스템의 IMPORTRANGE 보조 시트]")
print("=" * 80)
for sheet in ["_RAW_NewMeet_33", "_RAW_UserChat_p1", "_RAW_UserChat_p2"]:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!A1",
        valueRenderOption="FORMULA",
    ).execute().get("values", [[]])
    print(f"\n{sheet}!A1 수식:")
    if res and res[0]:
        print(f"  {res[0][0][:200]}")
