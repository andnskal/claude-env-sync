"""신 시스템 4/30 데이터 + 비교."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 신 시스템 4/30
new_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

new_4_30 = None
for row in new_data:
    if row and isinstance(row[0], str) and "2026-04-30" in row[0]:
        new_4_30 = row
        break

# 이전 시트 4/30
old_data = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
old_4_30 = None
for row in old_data:
    if row and isinstance(row[0], str) and "2026-04-30" in row[0]:
        old_4_30 = row
        break

# 비교
print("=" * 100)
print("[4/30 이전 vs 신 시스템 KPI 비교]")
print("=" * 100)

# 헤더 매핑
labels = {
    3: "D 카카오 답변",
    5: "F 네이버 답변",
    7: "H 채널톡 답변",
    12: "M 기술이관",
    14: "O 접수호 (알림제외)",
    15: "P 응대호",
    16: "Q 포기호 (알림제외)",
    17: "R 응대율",
    18: "S 접수호 (기술제외)",
    19: "T 응대호 (기술제외)",
    20: "U 포기호 (기술제외)",
    21: "V 응대율 (기술제외)",
    22: "W IB 통화시간 총",
    23: "X IB ATT",
    24: "Y IB 투입인원",
    25: "Z IB 투입(시간대÷N)",
    26: "AA OB부재",
    27: "AB OB 시도",
    28: "AC OB 성공",
    29: "AD OB(콜백제외)",
    30: "AE 콜백",
    31: "AF OB 통화시간",
    32: "AG OB ATT",
    33: "AH 상담톡 발송",
}

print(f"\n{'KPI':>30} | {'이전':>15} | {'신':>15} | {'차이':>10}")
print("-" * 100)
diffs = []
for idx, lbl in labels.items():
    old_v = old_4_30[idx] if old_4_30 and idx < len(old_4_30) else "-"
    new_v = new_4_30[idx] if new_4_30 and idx < len(new_4_30) else "-"
    
    # 비교
    diff = ""
    if isinstance(old_v, (int, float)) and isinstance(new_v, (int, float)):
        d = new_v - old_v
        if abs(d) > 0.001:
            diff = f"{d:+.2f}"
            diffs.append((lbl, old_v, new_v, d))
    
    # 출력 포맷
    def fmt(v):
        if isinstance(v, (int, float)):
            if 0 < abs(v) < 1: return f"{v:.4f}"
            return f"{v:.0f}" if v == int(v) else f"{v:.2f}"
        return str(v)
    
    print(f"{lbl:>30} | {fmt(old_v):>15} | {fmt(new_v):>15} | {diff:>10}")

print(f"\n[차이 발생 항목: {len(diffs)}개]")
