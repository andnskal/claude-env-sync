"""AT 수식 수정 + 알림톡 분류 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# AT6: ARRAYFORMULA로 모든 행 = 모든 IB_포기호 (알림톡 포함, 운영시간 내) - (AN+AO+AP+AQ+AR+AS)
at_formula = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"IB_포기호"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$F:$F," + '"notInOperation"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$F:$F," + '"userLeftInIvrWithoutInput"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$F:$F," + '"userLeftInIvr"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$F:$F," + '"userLeftInQueued"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$F:$F," + '"ringTimeOver"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "-COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),'5.콜 상담내역'!$B:$B," + '"inbound"' + ","
    "'5.콜 상담내역'!$F:$F," + '"wfEndCall"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + "))))"
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AT6",
    valueInputOption="USER_ENTERED",
    body={"values": [[at_formula]]},
).execute()
print("✅ AT6 BYROW 직접 IB_포기호 - 분류 합")
time.sleep(5)

# 검증 - 5/8 알림톡발송 운영시간 내 카운트 + 모든 missedReason 분류
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import Counter
miss_reasons = Counter()
total_aban_in = 0
alert_in = 0
for row in all_calls:
    if len(row) > 16 and row[0] == "2026-05-08":
        Q_val = row[3] if len(row) > 3 else ""
        F_val = row[5] if len(row) > 5 else ""  # 사실 F는 5번째 인덱스 (N=14, F=5: N2:AD3500의 첫 컬럼 = N, 5번째 = R)
        # range가 N:AD라 0=N, 1=O, 2=P, 3=Q, 4=R(callDuration), 5=S(통화시간)... 다시
        # N=0, O=1, P=2, Q=3, R=4, S=5, T=6, U=7, V=8, W=9, X=10, Y=11, Z=12, AA=13, AB=14, AC=15, AD=16
        # F (missedReason)는 5.콜 시트의 F 컬럼인데 우리 range는 N2부터. F는 따로 가져와야 함.
        AD_val = row[16] if len(row) > 16 else ""  # AD = 운영시간 분류
        Y_val = row[11] if len(row) > 11 else ""
        if Q_val == "IB_포기호" and AD_val == "내":
            total_aban_in += 1
            if Y_val == "알림톡발송":
                alert_in += 1

# 다시 F 컬럼 별도로 가져오기
res_F = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!F2:F3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"\n[5/8 운영시간 내 IB_포기호 (알림톡 포함): {total_aban_in}건]")
print(f"  중 알림톡발송: {alert_in}건")
print(f"  실제 응대 가능 포기호 (알림톡 제외): {total_aban_in - alert_in}건")

# 모든 missedReason 분포 (5/8 운영시간 내 IB_포기호)
miss_dist = Counter()
for ri, row in enumerate(all_calls):
    if len(row) > 16 and row[0] == "2026-05-08":
        Q_val = row[3] if len(row) > 3 else ""
        AD_val = row[16] if len(row) > 16 else ""
        if Q_val == "IB_포기호" and AD_val == "내":
            # F 별도 lookup
            F_val = res_F[ri][0] if ri < len(res_F) and res_F[ri] else ""
            miss_dist[F_val] += 1

print("\n[5/8 운영시간 내 IB_포기호 missedReason 분포]")
for r, c in miss_dist.most_common():
    print(f"  {r}: {c}건")

# AT 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AN6:AT15",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in res:
    if row:
        date_check = ""  # B 컬럼 따로 읽어야 함
        print(f"  AN-AT: {row}")
