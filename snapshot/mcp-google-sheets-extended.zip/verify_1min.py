"""1분단위 시트 검증 - 5/4."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

time.sleep(2)

# 1분단위 — 9시 ~ 10시 데이터 (550분~600분 = 9:10~10:00)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!A4:V100",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("=" * 100)
print("1분단위 검증 — 9시~9시 50분")
print("=" * 100)
# 9:08 (행 12), 9:09 (행 13), 9:10 (행 14), 9:30~ 등 매칭 행만
print(f"{'시간':>8} | {'통화중':>6} | {'포기호':>6} | {'F(상담사1)':>15} | {'G':>15} | {'H':>15} | {'I':>15}")
for ri, row in enumerate(res):
    if ri >= 50: break
    if not row or len(row) < 4: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    e = row[4] if len(row) > 4 else ""
    f = row[5] if len(row) > 5 else ""
    g = row[6] if len(row) > 6 else ""
    h = row[7] if len(row) > 7 else ""
    i = row[8] if len(row) > 8 else ""
    if e or f or g or h or i:  # 매칭된 행만 출력
        print(f"{time_str:>8} | {counta:>6} | {e:>6} | {f:>15} | {g:>15} | {h:>15} | {i:>15}")

# 9:32 ~ 9:54 (기술_김진향 통화 시간) 영역도 확인
print("\n[9:30 ~ 09:55 — 기술_김진향 통화 영역]")
for ri, row in enumerate(res):
    if ri < 30 or ri > 55: continue
    if not row or len(row) < 6: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    f = row[5] if len(row) > 5 else ""
    print(f"  {time_str}: F(첫상담사)={f}, 통화중인원={counta}")
