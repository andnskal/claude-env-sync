"""4/30 KPI 직접 비교."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 이전 시트 1.일별 헤더 + 4/30 행
print("=" * 100)
print("[이전 시트 1.일별 — 헤더 + 4/30 행]")
print("=" * 100)

old_h = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!A1:AT5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 4/30 행 찾기
old_data = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 헤더 출력 (행 1, 2, 3)
def cl(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("\n[행 1-3 헤더 (이전)]")
for ri in range(min(3, len(old_h))):
    for ci, v in enumerate(old_h[ri]):
        if v:
            print(f"  {cl(ci)}{ri+1}: {v[:50]}")

# 4/30 행 찾기
print("\n[이전 시트 4/30 데이터]")
old_4_30 = None
for row in old_data:
    if row and isinstance(row[0], str) and "2026-04-30" in row[0]:
        old_4_30 = row
        break
if old_4_30:
    for ci, v in enumerate(old_4_30):
        if v != "":
            print(f"  {cl(ci)}: {v}")
else:
    print("  4/30 행 없음")
