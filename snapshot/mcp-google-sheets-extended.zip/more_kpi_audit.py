"""더 많은 KPI 검증 - AT 기타, AI 콜백, AB OB 시도, 기타이관 등."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# F 컬럼 (missedReason) 별도 가져오기
all_f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!F2:F3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict, Counter

# 일자별 missedReason 분포 + AT 검증
date_missed = defaultdict(lambda: defaultdict(int))
date_aban_total = defaultdict(int)
date_callback = defaultdict(int)
date_ob_attempt = defaultdict(int)
date_alert_send = defaultdict(int)
date_tech_fail = defaultdict(int)

for ri, row in enumerate(all_calls):
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        Z = row[25] if len(row) > 25 else ""
        X = row[23] if len(row) > 23 else ""
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        F = all_f[ri][0] if ri < len(all_f) and all_f[ri] else ""
        if not N or AD != "내": continue
        # IB_포기호 missed reason
        if Q == "IB_포기호":
            date_aban_total[N] += 1
            date_missed[N][F] += 1
        # 콜백 OB (OB_성공 + 콜백 태그) + (IB_포기호 + 콜백)
        if Q == "OB_성공" and "콜백" in X and AC in ("본사", "외주 고객센터"):
            date_callback[N] += 1
        if Q == "IB_포기호" and Y == "콜백":
            date_callback[N] += 1
        # OB 시도 (모든 outbound = OB_성공 + OB_실패)
        if row[1] == "outbound":
            date_ob_attempt[N] += 1
        # 알림톡발송
        if Y == "알림톡발송":
            date_alert_send[N] += 1
        # 기술부재포기호
        if Q == "IB_포기호" and Z == "기술부재포기호":
            date_tech_fail[N] += 1

# 채팅 기술이관
date_tech_chat = defaultdict(int)
for row in all_chats:
    if len(row) > 25:
        O = row[14] if len(row) > 14 else ""
        M = row[12] if len(row) > 12 else ""
        Z_chat = row[25] if len(row) > 25 else ""
        if not O or Z_chat != "내": continue
        if M == "기술이관":
            date_tech_chat[O] += 1

# 1.일별
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 100)
print("추가 KPI 검증 - 모든 일자")
print("=" * 100)
all_match = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_aban_total: continue
    
    # AT (기타) = 미분류 missedReason
    miss_classified = (
        date_missed[date].get("notInOperation", 0) +
        date_missed[date].get("userLeftInIvrWithoutInput", 0) +
        date_missed[date].get("userLeftInIvr", 0) +
        date_missed[date].get("userLeftInQueued", 0) +
        date_missed[date].get("ringTimeOver", 0) +
        date_missed[date].get("wfEndCall", 0)
    )
    expected_at = date_aban_total[date] - miss_classified
    
    daily_vals = {
        "M (기술이관)": row[12] if len(row) > 12 else "",
        "AB (OB 시도)": row[27] if len(row) > 27 else "",
        "AE (콜백 등록)": row[30] if len(row) > 30 else "",  # 30 = AE
        "AH (상담톡 발송)": row[33] if len(row) > 33 else "",  # AH
        "AI (콜백 OB)": row[34] if len(row) > 34 else "",  # AI
        "N (기술부재 포기호)": row[20] if len(row) > 20 else "",  # U = 포기호 기술제외, N (기술 포기호)는 다른 셀
        "AT (기타)": row[45] if len(row) > 45 else "",
    }
    expected = {
        "M (기술이관)": date_tech_chat[date],
        "AB (OB 시도)": date_ob_attempt[date],
        "AE (콜백 등록)": date_callback[date],
        "AH (상담톡 발송)": date_alert_send[date],
        "AI (콜백 OB)": date_callback[date],  # AI = OB_성공 콜백 + IB_포기호 콜백
        "N (기술부재 포기호)": date_tech_fail[date],  
        "AT (기타)": expected_at,
    }
    
    date_match = True
    msgs = []
    for kpi, exp in expected.items():
        actual = daily_vals[kpi]
        if actual != exp:
            msgs.append(f"❌ {kpi}: {actual} vs {exp}")
            all_match = False
            date_match = False
        else:
            msgs.append(f"✅ {kpi}: {actual}")
    
    print(f"\n📅 {date}:")
    for m in msgs:
        print(f"  {m}")

print("\n" + "=" * 100)
if all_match:
    print("🎉 모든 추가 KPI 100% 일치!")
else:
    print("⚠️ 불일치 발견")
print("=" * 100)
