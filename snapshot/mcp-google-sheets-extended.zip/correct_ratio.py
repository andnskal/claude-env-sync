"""비율 KPI 정확한 검증 (R, V만 - AD는 절대값)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 비율: R, V만 (AD는 절대값)
print("[R, V 비율 KPI 검증]")
all_ok = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    O = row[14] if len(row) > 14 else 0
    P = row[15] if len(row) > 15 else 0
    R = row[17] if len(row) > 17 else 0
    S = row[18] if len(row) > 18 else 0
    T = row[19] if len(row) > 19 else 0
    V = row[21] if len(row) > 21 else 0
    AB = row[27] if len(row) > 27 else 0
    AC = row[28] if len(row) > 28 else 0
    AD = row[29] if len(row) > 29 else 0
    AI = row[34] if len(row) > 34 else 0
    
    exp_R = P/O if O else 0
    exp_V = T/S if S else 0
    exp_AD = AC - AI  # 절대값
    
    R_ok = (not isinstance(R, (int, float)) and R == "") or abs(R - exp_R) < 0.001
    V_ok = (not isinstance(V, (int, float)) and V == "") or abs(V - exp_V) < 0.001
    AD_ok = AD == exp_AD
    
    print(f"  {date}: R={R} (={exp_R:.4f}) {'✅' if R_ok else '❌'} | V={V} (={exp_V:.4f}) {'✅' if V_ok else '❌'} | AD={AD} (=AC-AI={exp_AD}) {'✅' if AD_ok else '❌'}")
    if not (R_ok and V_ok and AD_ok):
        all_ok = False

# OB 응답률 = AC/AB
print("\n[OB 응답률 (AC/AB)]")
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    AB = row[27] if len(row) > 27 else 0
    AC = row[28] if len(row) > 28 else 0
    rate = AC/AB if AB else 0
    print(f"  {date}: AC={AC}/AB={AB} = {rate*100:.1f}%")
