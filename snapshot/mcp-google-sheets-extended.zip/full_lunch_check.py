"""모든 일자 + 모든 상담사 점심 분리 후 영향."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 모든 일자 KPI
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AW60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 80)
print("1.일별 모든 일자 KPI (점심 분리 적용)")
print("=" * 80)
print(f"{'날짜':>12} | {'P':>5} | {'Q':>5} | {'U':>5} | {'R응대율':>8} | {'V':>8} | {'AC':>5} | {'AE':>5}")
print("-" * 80)
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    P = row[15] if len(row) > 15 else "?"
    Q = row[16] if len(row) > 16 else "?"
    U = row[20] if len(row) > 20 else "?"
    R = row[17] if len(row) > 17 else 0
    V = row[21] if len(row) > 21 else 0
    AC = row[28] if len(row) > 28 else "?"
    AE = row[30] if len(row) > 30 else "?"
    r_str = f"{R*100:.1f}%" if isinstance(R, (int, float)) else str(R)
    v_str = f"{V*100:.1f}%" if isinstance(V, (int, float)) else str(V)
    print(f"  {date} | {P:>5} | {Q:>5} | {U:>5} | {r_str:>8} | {v_str:>8} | {AC:>5} | {AE:>5}")

# 4.상담사별 시트에서 5/8 IB_성공 상위
print("\n" + "=" * 80)
print("4.상담사별 5/8 IB_성공 (점심 분리 후, 채널톡 비교용)")
print("=" * 80)
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

if res4 and len(res4) >= 3:
    dates = res4[0]
    types = res4[1]
    target_col = None
    for ci, (d, t) in enumerate(zip(dates, types)):
        if isinstance(d, str) and d == "2026-05-08" and t == "IB_성공":
            target_col = ci
            break
    
    if target_col:
        rows_data = []
        for ri in range(2, len(res4)):
            row = res4[ri]
            if row and len(row) > target_col:
                name = row[1] if len(row) > 1 else ""
                val = row[target_col] if target_col < len(row) and isinstance(row[target_col], (int, float)) else 0
                if name and val > 0:
                    rows_data.append((name, val))
        
        rows_data.sort(key=lambda x: -x[1])
        print(f"{'상담사':>20} | {'5/8 IB_성공':>12}")
        for name, val in rows_data:
            print(f"  {name:>18} | {val:>12}")

# 5/11 데이터 확인
print("\n" + "=" * 80)
print("5/11 데이터 존재 여부")
print("=" * 80)
res5_11 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N:N",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
has_5_11 = any(r and r[0] == "2026-05-11" for r in res5_11)
print(f"  5/11 데이터 5.콜에 존재: {'있음' if has_5_11 else '❌ 없음 (RAW 갱신 안 됨)'}")

# ★설정의 점심 마스터 검증
print("\n" + "=" * 80)
print("★설정 점심시간 마스터 상태")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!Z1:AB10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+1}: {row}")
