"""진정한 종합 점검 - 발견되는 모든 이슈 숨기지 않고 보고."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

issues = []  # 모든 발견 이슈 누적

# ============================================================
# 1. 모든 시트 모든 셀 오류 (전체 범위)
# ============================================================
print("=" * 100)
print("[A] 셀 단위 오류 전수조사")
print("=" * 100)
ERR = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = p["gridProperties"].get("rowCount", 0)
    cols = p["gridProperties"].get("columnCount", 0)
    if rows == 0 or cols == 0: continue

    rng = f"'{name}'!A1:{col_letter(cols-1)}{min(rows, 600)}"
    try:
        v = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue

    err_locs = []
    for ri, row in enumerate(v):
        for ci, c in enumerate(row):
            if isinstance(c, str):
                for ptn in ERR:
                    if ptn in c:
                        err_locs.append(f"{col_letter(ci)}{ri+1}:{ptn}")
                        break
    if err_locs:
        issues.append(f"[A] {name}: {len(err_locs)}개 오류 - {err_locs[:5]}")
        print(f"  ❌ {name}: {len(err_locs)}개 오류 - {err_locs[:5]}")

# ============================================================
# 2. 비어있어야 할 영역에 잔재 셀
# ============================================================
print("\n[B] 디버깅/임시 셀 잔재 검사")
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    cols = p["gridProperties"].get("columnCount", 0)
    if cols == 0: continue

    # 각 시트의 데이터 끝 컬럼 식별 (행 1-3 헤더 기준)
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{name}'!A1:{col_letter(cols-1)}5",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    if not res: continue

    # 1-3행에서 마지막 비어있지 않은 컬럼
    max_data_col = 0
    for r in res[:3]:
        for ci, v in enumerate(r):
            if v: max_data_col = max(max_data_col, ci)

    # max_data_col + 1 부터 cols 까지가 빈 영역이어야
    if max_data_col + 1 >= cols: continue

    rng = f"'{name}'!{col_letter(max_data_col + 1)}1:{col_letter(cols-1)}600"
    try:
        v = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        non_empty = [(ri, ci, c) for ri, row in enumerate(v) for ci, c in enumerate(row) if c]
        if non_empty:
            sample = [(col_letter(max_data_col + 1 + ci), ri+1, str(c)[:20]) for ri, ci, c in non_empty[:5]]
            issues.append(f"[B] {name}: 빈 영역에 {len(non_empty)}개 잔재 - {sample}")
            print(f"  ⚠️ {name} {col_letter(max_data_col + 1)}+: {len(non_empty)}개 잔재 - {sample}")
    except: continue

# ============================================================
# 3. ★설정 시트 일관성 (D 컬럼 D2 값 = "근로자의 날" 비고만 - 다른 데이터 정합성)
# ============================================================
print("\n[C] ★설정 시트 모든 컬럼 일관성")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!A1:Y20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 헤더 + 데이터
print(f"  ★설정 헤더 (행 1):")
if res:
    for ci, h in enumerate(res[0]):
        if h:
            print(f"    {col_letter(ci)}: '{h}'")

# E 컬럼 = 텍스트변환 - 수식이 아닌 정적 값이라면 문제
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'★설정'!E2:E15"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue,userEnteredValue))))"
).execute()
e_rows = fmt["sheets"][0]["data"][0]["rowData"]
e_static_count = 0
for ri, r in enumerate(e_rows):
    if "values" in r and r["values"]:
        cell = r["values"][0]
        raw = cell.get("userEnteredValue", {})
        if "formulaValue" not in raw and "stringValue" in raw:
            e_static_count += 1
if e_static_count > 1:  # E2는 수식, 그 외 정적이면 ARRAYFORMULA 안 작동
    issues.append(f"[C] ★설정 E 컬럼: {e_static_count}개 정적 값 (E2 ARRAYFORMULA 작동 안 할 수도)")
    print(f"  ⚠️ ★설정 E 컬럼: {e_static_count}개 정적 값 (ARRAYFORMULA 미적용 가능성)")

# ============================================================
# 4. 1.일별 합계/평균 행 vs 데이터 행 일관성
# ============================================================
print("\n[D] 1.일별 행 4 (평균), 행 5 (합계) 자동 계산 vs 데이터 합")
daily_full = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AT15",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
# 행 4 = 평균, 행 5 = 합계
if len(daily_full) >= 7:
    avg_row = daily_full[0]
    sum_row = daily_full[1]
    data_rows = daily_full[2:]

    # 모든 카운트 컬럼 (D-AT 일부)
    count_cols = [3, 5, 7, 12, 15, 16, 20, 27, 28, 30, 33, 34, 39, 40, 41, 42, 43, 44, 45]
    for ci in count_cols:
        manual_sum = sum(r[ci] for r in data_rows if ci < len(r) and isinstance(r[ci], (int, float)))
        manual_cnt = sum(1 for r in data_rows if ci < len(r) and isinstance(r[ci], (int, float)))
        manual_avg = manual_sum / manual_cnt if manual_cnt else 0
        sheet_sum = sum_row[ci] if ci < len(sum_row) else 0
        sheet_avg = avg_row[ci] if ci < len(avg_row) else 0
        if isinstance(sheet_sum, (int, float)) and abs(sheet_sum - manual_sum) > 0.01:
            issues.append(f"[D] 1.일별 행5 {col_letter(ci)} 합계: 시트={sheet_sum} 수동={manual_sum}")
            print(f"  ⚠️ 1.일별 행5 {col_letter(ci)} 합계: 시트={sheet_sum} 수동={manual_sum}")
        if isinstance(sheet_avg, (int, float)) and abs(sheet_avg - manual_avg) > 0.5:
            issues.append(f"[D] 1.일별 행4 {col_letter(ci)} 평균: 시트={sheet_avg:.1f} 수동={manual_avg:.1f}")
            print(f"  ⚠️ 1.일별 행4 {col_letter(ci)} 평균: 시트={sheet_avg:.1f} 수동={manual_avg:.1f}")

# ============================================================
# 5. 모든 ARRAYFORMULA 범위 확인 (자동 확장 vs 정적 길이)
# ============================================================
print("\n[E] ARRAYFORMULA 범위 - 미래 데이터 대응성")
# 1.일별 BYROW(A6:A100) vs A6:A 비교
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!Y6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
y6 = res[0][0] if res and res[0] else ""
if "A6:A100" in y6:
    issues.append(f"[E] 1.일별 Y6: BYROW(A6:A100) - 100행 한정. 5월 ~ 7월 데이터 추가 시 한계")
    print(f"  ⚠️ 1.일별 Y6: A6:A100 (100행 한정)")

# AT6
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AT6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
at6 = res[0][0] if res and res[0] else ""

# ============================================================
# 6. 5.콜 / 6.채팅의 운영시간 분류 컬럼 (AD/Z) 자동 확장
# ============================================================
print("\n[F] 5.콜/6.채팅 ARRAYFORMULA 자동 확장")
# 5.콜 AD2 수식 - N2:N 사용?
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
ad2 = res[0][0] if res and res[0] else ""
if "N2:N" not in ad2 and "N2:N3500" in ad2:
    issues.append(f"[F] 5.콜 AD2: 범위 한정 - 새 데이터 자동 확장 미보장")
    print(f"  ⚠️ 5.콜 AD2 범위 확인: {ad2[:100]}")
else:
    print(f"  ✅ 5.콜 AD2 N2:N 사용 (자동 확장)")

# 6.채팅 Z2
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
z2 = res[0][0] if res and res[0] else ""
if "O2:O" in z2:
    print(f"  ✅ 6.채팅 Z2 O2:O 사용 (자동 확장)")

# ============================================================
# 7. 데이터 검증 (드롭다운) 누락
# ============================================================
print("\n[G] 데이터 검증 (드롭다운) 적용 여부")
# 1분단위 V3 드롭다운 (이미 적용)
# 1.일별 어느 셀에 드롭다운이 있어야 하나?
# 3,4번 시트 B2 (전체/본사/외주/기술/기타)
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW,
    fields="sheets(properties,data(rowData(values(dataValidation))))"
).execute()
dv_count = 0
for s in fmt.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    for d in s.get("data", []):
        for ri, row_data in enumerate(d.get("rowData", [])):
            for ci, v in enumerate(row_data.get("values", [])):
                if "dataValidation" in v:
                    dv_count += 1
print(f"  데이터 검증 (드롭다운) 셀: {dv_count}개")

# ============================================================
# 8. 동기화 (1분 ↔ 5분 E2)
# ============================================================
print("\n[H] 1분 ↔ 5분단위 E2 동기화")
res5 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
e2_5 = res5[0][0] if res5 and res5[0] else ""
if "1분 단위 포기호" in str(e2_5):
    print(f"  ✅ 5분단위 E2 = 1분단위!E2 동기화")
else:
    issues.append(f"[H] 5분단위 E2 동기화 안됨: {e2_5}")
    print(f"  ❌ 5분단위 E2: {e2_5}")

# ============================================================
# 9. 시각적 일관성 - 헤더 폰트, 컬럼 너비 등
# ============================================================
print("\n[I] 시각적 일관성")
# (간단 검사만)

# ============================================================
# 종합
# ============================================================
print("\n" + "=" * 100)
print(f"발견된 이슈: {len(issues)}개")
print("=" * 100)
for i, iss in enumerate(issues, 1):
    print(f"  {i}. {iss}")
