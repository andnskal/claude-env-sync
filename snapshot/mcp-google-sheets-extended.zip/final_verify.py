"""점심시간 표시 + 운영시간 분류 최종 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) ★설정 B + Z-AB 마스터
print("=" * 80)
print("[1] ★설정 점심시간 관련 마스터")
print("=" * 80)

# B 컬럼 헤더
print("B 컬럼 (업무시간 시계열):")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    if r:
        print(f"  B{ri+1}: {r[0]}")
print("  ... (점심: 🍱 점심 60셀) ...")
print("  ... (오후 13:30 ~ 17:29)")

# Z-AB 점심 마스터
print("\nZ-AB 컬럼 (점심시간 정의):")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!Z1:AB5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res):
    if r:
        print(f"  Row {ri+1}: {r}")

# 2) 5/8 KPI 확인
print("\n" + "=" * 80)
print("[2] 5/8 KPI (점심 분리 적용 상태)")
print("=" * 80)
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AW20",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  P (응대호): {row[15]}")
        print(f"  Q (포기호): {row[16]}")
        print(f"  R (응대율): {row[17]*100:.2f}%" if isinstance(row[17], (int,float)) else f"  R: {row[17]}")
        break

# 3) 이윤애 검증
print("\n" + "=" * 80)
print("[3] 이윤애 5/8 (채널톡 = 15건)")
print("=" * 80)
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for ri in range(2, len(res4)):
    row = res4[ri]
    if row and len(row) > 1 and row[1] == "CS_이윤애":
        # 5/8 IB_성공 컬럼 찾기
        dates = res4[0]
        types = res4[1]
        for ci, (d, t) in enumerate(zip(dates, types)):
            if isinstance(d, str) and d == "2026-05-08" and t == "IB_성공":
                val = row[ci] if ci < len(row) and isinstance(row[ci], (int, float)) else 0
                print(f"  CS_이윤애 5/8 IB_성공: {val}건")
                print(f"  채널톡 대시보드: 15건")
                print(f"  → {'✅ 정확히 일치' if val == 15 else '❌ 불일치 (' + str(val) + ')'}")
                break
        break
