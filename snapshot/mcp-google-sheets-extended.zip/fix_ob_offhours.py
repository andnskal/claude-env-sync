"""OB를 운영시간 외에도 모두 집계하도록 수식 수정.
- IB는 기존 운영시간 내 룰 유지
- OB 성공/실패/통화시간/알림톡/콜백처리는 운영시간 외 포함
"""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 백업
print("[백업] 수정 전 수식 저장")
backup = {}
targets = [
    ("'2.시간대별 전체통계'!W4", "2_W4_알림톡"),
    ("'2.시간대별 전체통계'!X4", "2_X4_OB성공"),
    ("'2.시간대별 전체통계'!Y4", "2_Y4_OB실패"),
    ("'2.시간대별 전체통계'!Z4", "2_Z4_OB통화시간"),
    ("'1.일별 전체 통계'!AI6", "1_AI6_콜백OB처리"),
    ("'4.상담사별 콜 실적'!C3", "4_C3_상담사별"),
]
for rng, name in targets:
    r = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=rng,
        valueRenderOption='FORMULA',
    ).execute().get('values', [])
    if r and r[0]:
        backup[name] = r[0][0]
        print(f"  {name}: {r[0][0][:120]}...")

# 백업 파일로 저장
import json
with open("D:/claude/mcp-google-sheets-extended/backup_ob_formulas.json", "w", encoding="utf-8") as f:
    json.dump(backup, f, ensure_ascii=False, indent=2)
print(f"\n  → backup_ob_formulas.json 저장됨")

time.sleep(2)

# Step 1: 2.시간대별 W4 (알림톡)
print("\n[1] 2.시간대별 W4 (알림톡 발송) — AD 필터 제거")
new_w4 = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    'COUNTIFS('
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Y:$Y,\"알림톡발송\""
    ')))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!W4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_w4]]},
).execute()
print(f"  {new_w4[:150]}...")

# Step 2: 2.시간대별 X4 (OB 성공)
print("\n[2] 2.시간대별 X4 (OB 성공) — AD 필터 제거")
new_x4 = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    'COUNTIFS('
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q,\"OB_성공\","
    "'5.콜 상담내역'!$AC:$AC,\"본사\""
    ')+COUNTIFS('
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q,\"OB_성공\","
    "'5.콜 상담내역'!$AC:$AC,\"외주 고객센터\""
    ')))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!X4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_x4]]},
).execute()
print(f"  {new_x4[:200]}...")

# Step 3: 2.시간대별 Y4 (OB 실패)
print("\n[3] 2.시간대별 Y4 (OB 실패) — AD 필터 제거")
new_y4 = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    'COUNTIFS('
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q,\"OB_실패\","
    "'5.콜 상담내역'!$AC:$AC,\"본사\""
    ')+COUNTIFS('
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q,\"OB_실패\","
    "'5.콜 상담내역'!$AC:$AC,\"외주 고객센터\""
    ')))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!Y4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_y4]]},
).execute()
print(f"  {new_y4[:200]}...")

# Step 4: 2.시간대별 Z4 (OB 통화시간)
print("\n[4] 2.시간대별 Z4 (OB 통화시간) — AD 필터 제거")
new_z4 = (
    '=ARRAYFORMULA(MAP(B4:B,C4:C,LAMBDA(d,t,IF(d="",,'
    'SUMIFS('
    "'5.콜 상담내역'!$S:$S,"
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q,\"OB_성공\","
    "'5.콜 상담내역'!$AC:$AC,\"본사\""
    ')+SUMIFS('
    "'5.콜 상담내역'!$S:$S,"
    "'5.콜 상담내역'!$N:$N,d,"
    "'5.콜 상담내역'!$P:$P,t,"
    "'5.콜 상담내역'!$Q:$Q,\"OB_성공\","
    "'5.콜 상담내역'!$AC:$AC,\"외주 고객센터\""
    ')))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!Z4",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_z4]]},
).execute()
print(f"  {new_z4[:200]}...")

# Step 5: 1.일별 AI6 (콜백 OB 처리)
print("\n[5] 1.일별 AI6 (콜백 OB 처리) — AD 필터 제거")
new_ai6 = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    'COUNTIFS('
    "'5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q,\"OB_성공\","
    "'5.콜 상담내역'!$X:$X,\"*콜백*\","
    "'5.콜 상담내역'!$AC:$AC,\"본사\""
    ')+COUNTIFS('
    "'5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q,\"OB_성공\","
    "'5.콜 상담내역'!$X:$X,\"*콜백*\","
    "'5.콜 상담내역'!$AC:$AC,\"외주 고객센터\""
    '))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AI6",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_ai6]]},
).execute()
print(f"  {new_ai6[:200]}...")

# Step 6: 4.상담사별 C3 (조건부 — OB만 운영시간 외 포함)
print("\n[6] 4.상담사별 C3 — OB만 운영시간 외 포함, IB는 내만")
new_c3 = (
    '=ARRAYFORMULA(IF(ISBLANK(B3:B50),,'
    'IF(ISBLANK($C$2:$LG$2),,'
    'MAP(B3:B50,LAMBDA(상담사,'
    'COUNTIFS('
    "'5.콜 상담내역'!$W:$W,상담사,"
    "'5.콜 상담내역'!$N:$N,$C$1:$LG$1,"
    "'5.콜 상담내역'!$Q:$Q,$C$2:$LG$2,"
    "'5.콜 상담내역'!$AD:$AD,IF(LEFT($C$2:$LG$2,2)=\"OB\",\"*\",\"내\")"
    ')))))'
    ')'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!C3",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_c3]]},
).execute()
print(f"  {new_c3}")

time.sleep(10)

# 검증
print("\n" + "=" * 80)
print("[검증] 5/11 OB 수치 (수정 후)")
print("=" * 80)

# 1.일별 5/11 행
vals = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AL30",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])

for r in vals:
    if r and r[0] == '2026-05-11':
        print(f"\n[1.일별 5/11]")
        print(f"  AA (OB부재): {r[26] if len(r) > 26 else ''}  (예상: 8 + 외 0 = 8)")
        print(f"  AB (OB 시도): {r[27] if len(r) > 27 else ''}  (예상: 70)")
        print(f"  AC (OB 성공): {r[28] if len(r) > 28 else ''}  (예상: 62)")
        print(f"  AD (OB 콜백제외): {r[29] if len(r) > 29 else ''}")
        print(f"  AF (OB 통화시간): {r[31] if len(r) > 31 else ''}")
        print(f"  AG (OB ATT): {r[32] if len(r) > 32 else ''}")
        print(f"  AI (콜백 OB 처리): {r[34] if len(r) > 34 else ''}")
        # IB 변화 없음 검증
        print(f"\n  [IB 검증 — 변화 없어야 함]")
        print(f"  O (IB 접수호): {r[14] if len(r) > 14 else ''}  (예상: 변화 없음)")
        print(f"  P (IB 응대호): {r[15] if len(r) > 15 else ''}  (예상: 변화 없음)")
        break

# 4.상담사별 5/11 - 박슬기, 정현호
print("\n[4.상담사별 5/11 — 박슬기, 정현호 OB 변화]")
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption='UNFORMATTED_VALUE',
).execute().get('values', [])

if res4 and len(res4) >= 3:
    dates = res4[0]
    types = res4[1]
    target_cols = {}
    for ci, (d, t) in enumerate(zip(dates, types)):
        if isinstance(d, str) and d == "2026-05-11":
            target_cols[t] = ci

    for ri in range(2, len(res4)):
        row = res4[ri]
        if row and len(row) > 1 and row[1] in ("CS_박슬기", "CS_정현호"):
            print(f"\n  {row[1]}:")
            for t, ci in target_cols.items():
                v = row[ci] if ci < len(row) else 0
                print(f"    {t}: {v}건")
