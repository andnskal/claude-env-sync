"""신 시스템 적용 결과 검증."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"


def hex_from_rgb(c):
    if not c: return None
    r = int(round(c.get("red",0)*255))
    g = int(round(c.get("green",0)*255))
    b = int(round(c.get("blue",0)*255))
    return f"#{r:02X}{g:02X}{b:02X}"


def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


for sheet_name, rng in [
    ("1.일별 전체 통계", "A1:AH4"),
    ("2.시간대별 전체통계", "A1:AL4"),
    ("5.콜 상담내역", "A1:Z2"),
    ("6.채팅 상담내역", "A1:Y2"),
    ("3.상담사별 채팅 실적", "A1:J2"),
    ("4.상담사별 콜 실적", "A1:J2"),
    ("★설정", "A1:Y2"),
]:
    print(f"\n{'='*60}\n📋 {sheet_name}\n{'='*60}")
    res = _sheets.spreadsheets().get(
        spreadsheetId=NEW,
        ranges=[f"'{sheet_name}'!{rng}"],
        includeGridData=True,
        fields="sheets(properties(gridProperties),merges,data(rowData(values(userEnteredFormat))))"
    ).execute()
    sheet = res["sheets"][0]
    print(f"Frozen: rows={sheet['properties']['gridProperties'].get('frozenRowCount',0)}, cols={sheet['properties']['gridProperties'].get('frozenColumnCount',0)}")
    print(f"Merges: {len(sheet.get('merges',[]))}개")
    for m in sheet.get("merges", [])[:5]:
        print(f"  - 행{m['startRowIndex']+1}-{m['endRowIndex']}, 열{col_letter(m['startColumnIndex'])}-{col_letter(m['endColumnIndex']-1)}")
    rows = sheet.get("data", [{}])[0].get("rowData", [])
    for ri in range(min(3, len(rows))):
        row = rows[ri].get("values", [])
        sample = []
        for ci, cell in enumerate(row[:8]):
            fmt = cell.get("userEnteredFormat", {})
            bg = hex_from_rgb(fmt.get("backgroundColor"))
            tf = fmt.get("textFormat", {})
            if bg and bg != "#FFFFFF":
                sample.append(f"{col_letter(ci)}: bg={bg} bold={tf.get('bold',False)} size={tf.get('fontSize')}")
        if sample:
            print(f"  행{ri+1} 헤더 샘플: {' | '.join(sample[:4])}")
