"""RAW_UserChat AH 컬럼 데이터 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# RAW_UserChat AH:AK 컬럼 (34-37) 데이터
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!AH1:AR5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("[RAW_UserChat AH:AR (34-44)]")
for ri, row in enumerate(res):
    print(f"  Row {ri+1}: {row[:10] if row else '[]'}")

# 만약 W1이 W:CS spillover라면 W=23, ..., AH=34. AH는 W에서 시작한 spillover의 12번째 컬럼.
# W1 IMPORTRANGE 결과 = UserChat의 W:CS = 23-97열 → 75 컬럼
# W1에서 spillover 시 W=column 1, X=column 2, ..., CS=column 75
# 우리가 보는 RAW_UserChat에서 W는 23번째 컬럼, AH는 34번째 → spillover로 24-34 = 12번째 = X column index

# RAW_UserChat W1 셀의 수식 확인
f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!W1",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print(f"\n[RAW_UserChat W1 수식]: {f[0][0] if f and f[0] else '없음'}")

# A1
f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print(f"[RAW_UserChat A1 수식]: {f[0][0] if f and f[0] else '없음'}")

# 행 2 데이터 (로딩 확인)
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A2:CS2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
if res2 and res2[0]:
    print(f"\n[RAW_UserChat Row 2 데이터 길이]: {len(res2[0])}")
    print(f"  A: {res2[0][0] if len(res2[0]) > 0 else '?'}")
    print(f"  V (22): {res2[0][21] if len(res2[0]) > 21 else '?'}")
    print(f"  W (23): {res2[0][22] if len(res2[0]) > 22 else '?'}")
    print(f"  AH (34): {res2[0][33] if len(res2[0]) > 33 else '?'}")
    print(f"  AK (37): {res2[0][36] if len(res2[0]) > 36 else '?'}")
