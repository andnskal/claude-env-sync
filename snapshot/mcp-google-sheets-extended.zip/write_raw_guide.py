"""RAW 업로드 시트의 시트1에 운영 가이드 작성."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"

# 시트1을 "📌 사용 가이드" 로 이름 변경
sid = _get_sheet_id_by_name(RAW, "시트1")

# 시트 이름 변경
_batch_update(RAW, [{
    "updateSheetProperties": {
        "properties": {"sheetId": sid, "title": "📌 사용 가이드"},
        "fields": "title"
    }
}])
print("OK 시트1 → 📌 사용 가이드")
time.sleep(2)

# 컬럼 너비 + 행 높이
_batch_update(RAW, [
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1},
        "properties": {"pixelSize": 30}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2},
        "properties": {"pixelSize": 200}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 3},
        "properties": {"pixelSize": 100}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 3, "endIndex": 4},
        "properties": {"pixelSize": 80}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 4, "endIndex": 5},
        "properties": {"pixelSize": 500}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 5, "endIndex": 26},
        "properties": {"pixelSize": 80}, "fields": "pixelSize"}},
])

# 데이터 작성
data = [
    # 행 1 — 큰 제목
    ["", "📞 채널톡 RAW 데이터 업로드 시트 — 사용 가이드", "", "", "", ""],
    ["", "", "", "", "", ""],
    
    # 1. 한 줄 요약
    ["", "🎯 이 시트의 역할", "", "", "", ""],
    ["", "한 줄 요약", "", "", "이 시트는 채널톡(상담 시스템)에서 받은 모든 원본 데이터를 보관하는 '저장 창고'입니다. 통계 시트는 이 데이터를 자동으로 읽어서 KPI를 계산합니다.", ""],
    ["", "", "", "", "", ""],
    
    # 2. 시트 구조
    ["", "📂 시트 구성 (8개)", "", "", "", ""],
    ["", "시트 이름", "행 수", "열 수", "역할 (무엇이 들어있는지)", "출처"],
    ["", "UserChat", "변동", "97", "채팅·전화 상담 모든 케이스 (고객별 1행). 가장 핵심 데이터.", "채널톡 자동 export"],
    ["", "UserChat meet data", "변동", "33", "전화(콜) 상세 — 통화시간, 후처리, 보류, 부재 사유 등 33가지 정보. 2026년부터 신 형식 (이전 시트는 15열만 사용).", "채널톡 자동 export"],
    ["", "Old_UserChat meet data", "변동", "15", "전화(콜) 구 형식. 2026.05.22 이후 자동 종료 예정. 호환성용.", "채널톡 자동 export"],
    ["", "User data", "변동", "70", "고객 정보 (이름, 연락처, 가입일 등).", "채널톡 자동 export"],
    ["", "Manager data", "약 20", "13", "상담사 명단 (이름, ID, 팀, 입퇴사 정보). 신규 입사 시 자동 추가.", "채널톡 자동 export"],
    ["", "Team data", "약 5", "4", "팀 구분 (본사 CS/CX/기술/외주 고객센터 등).", "채널톡 자동 export"],
    ["", "UserChatTag data", "약 220", "5", "태그 마스터 (운영시간아님, 콜백대상, 알림톡발송 등 자동 분류 태그).", "채널톡 자동 export"],
    ["", "📌 사용 가이드", "—", "—", "이 시트 (사용 가이드 안내문).", "운영 관리자 작성"],
    ["", "", "", "", "", ""],
    
    # 3. 업데이트 절차
    ["", "🔄 업데이트 방법 (매월 또는 매주 1회)", "", "", "", ""],
    ["", "단계", "", "", "수행 내용", ""],
    ["", "1️⃣ 다운로드", "", "", "채널톡 관리자 페이지 → 통계 → 상담통계 → 상담별 → 다운로드 → '상담별통계.xlsx' 파일 받기", ""],
    ["", "2️⃣ 구글 시트 가져오기", "", "", "이 시트(RAW)에서 메뉴 → 파일 → 가져오기 → 업로드 → '상담별통계.xlsx' 선택 → '기존 시트 바꾸기' 옵션 선택", ""],
    ["", "3️⃣ 자동 갱신", "", "", "통계 시트는 IMPORTRANGE로 이 시트와 자동 연결되어 있어, 즉시 모든 KPI가 갱신됩니다 (별도 작업 불필요).", ""],
    ["", "4️⃣ 검증", "", "", "통계 시트의 '1.일별 전체 통계'에서 최신 일자 데이터 확인. 채널톡 대시보드와 비교 (전체 시간 기준은 일치).", ""],
    ["", "", "", "", "", ""],
    
    # 4. 통계 시트와의 연결
    ["", "🔗 통계 시트와의 연결", "", "", "", ""],
    ["", "이 RAW 시트", "", "", "통계 시트", ""],
    ["", "UserChat (97열)", "→ 자동 IMPORTRANGE →", "", "_RAW_UserChat_p1, _RAW_UserChat_p2 (보조)", ""],
    ["", "UserChat meet data (33열)", "→ 자동 IMPORTRANGE →", "", "_RAW_NewMeet_33 (보조)", ""],
    ["", "통계 시트 URL", "", "", "https://docs.google.com/spreadsheets/d/1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU", ""],
    ["", "", "", "", "", ""],
    
    # 5. 주의사항
    ["", "⚠️ 중요 주의사항", "", "", "", ""],
    ["", "1.", "", "", "이 시트의 8개 시트 이름을 절대 변경하지 마세요. 통계 시트가 정확한 이름으로 참조하고 있습니다.", ""],
    ["", "2.", "", "", "데이터 업데이트 시 '기존 시트 바꾸기' 옵션을 사용해야 합니다. '새 시트 추가' 시 통계 갱신 안 됨.", ""],
    ["", "3.", "", "", "통계 시트의 IMPORTRANGE 권한이 한 번만 부여되면 이후 자동 동작합니다.", ""],
    ["", "4.", "", "", "데이터 누락 의심 시: 통계 시트 → '1.일별 전체 통계' → 'AU 전체 시간 기준 응대율' 컬럼이 채널톡 대시보드와 일치하는지 확인.", ""],
    ["", "5.", "", "", "공휴일 추가/변경: 통계 시트 → ★설정 → C 컬럼에 날짜 입력.", ""],
    ["", "", "", "", "", ""],
    
    # 6. 문제 발생 시
    ["", "🆘 문제 발생 시 체크 포인트", "", "", "", ""],
    ["", "현상", "", "", "확인할 곳", ""],
    ["", "통계가 안 갱신됨", "", "", "통계 시트 → _RAW_NewMeet_33 시트의 A1 수식이 #REF! 표시 시 IMPORTRANGE 권한 재부여", ""],
    ["", "신규 상담사가 안 보임", "", "", "Manager data 시트 확인 + 통계 시트 ★설정 시트 I~Y 컬럼에 매핑 추가", ""],
    ["", "특정 일자 데이터 누락", "", "", "UserChat 시트의 createdAt 또는 closedAt 컬럼에서 해당 일자 데이터 존재 확인", ""],
    ["", "응대율이 비정상적", "", "", "통계 시트 1.일별의 R(운영시간 응대율) vs AU(전체 시간 응대율) 비교, 운영시간 외 콜 비중 확인", ""],
    ["", "", "", "", "", ""],
    
    # 7. 임원 보고용 한 줄
    ["", "💼 임원 보고 시 핵심 한 줄", "", "", "", ""],
    ["", "", "", "", "이 RAW 시트는 채널톡이 자동 생성한 8가지 원본 데이터(채팅·콜·고객·상담사·팀 등)의 저장 창고이며, 통계 시트는 이 RAW를 자동 연결하여 매일 KPI를 갱신합니다.", ""],
    ["", "", "", "", "", ""],
    
    # 8. 변경 이력
    ["", "📅 변경 이력", "", "", "", ""],
    ["", "날짜", "", "", "변경 내용", ""],
    ["", "2026-04-30", "", "", "신 RAW 33열 형식으로 전환 시작 (구 15열은 호환성 유지)", ""],
    ["", "2026-05-09", "", "", "신 통계 시스템 구축 완료, 운영시간 기준 KPI 적용", ""],
]

# 한 번에 입력
_sheets.spreadsheets().values().update(
    spreadsheetId=RAW, range="'📌 사용 가이드'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": data},
).execute()
print("OK 가이드 데이터 입력")
time.sleep(2)
print(f"\n총 {len(data)}행 작성")
