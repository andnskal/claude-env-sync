"""1분단위/5분단위 포기호 시트 — RAW시간대별 동적 헤더 + 수식 재구축."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

print("=" * 70)
print("RAW시간대별 헤더 동적화 + 수식 재작성")
print("=" * 70)

# 1단계: 행 1 (상담사 이름 동적), 행 2 (컬럼 타입) 재작성
# C1=D1=1분단위!F3, E1=F1=1분단위!G3, ..., AE1=AF1=1분단위!T3 (15명 ×2열)
agent_letters = ['F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T']
# RAW 시트 컬럼 매핑: C, E, G, I, K, M, O, Q, S, U, W, Y, AA, AC, AE
raw_start_letters = ['C', 'E', 'G', 'I', 'K', 'M', 'O', 'Q', 'S', 'U', 'W', 'Y', 'AA', 'AC', 'AE']
raw_end_letters   = ['D', 'F', 'H', 'J', 'L', 'N', 'P', 'R', 'T', 'V', 'X', 'Z', 'AB', 'AD', 'AF']

# Row 1: 동적 상담사 이름
# C1 = ='1분 단위 포기호, 통화상세'!F3
# D1 = ='1분 단위 포기호, 통화상세'!F3
# E1 = ='1분 단위 포기호, 통화상세'!G3
# ... 등
row1_values = []
row2_values = []
for i, letter_1min in enumerate(agent_letters):
    formula = f"='1분 단위 포기호, 통화상세'!{letter_1min}3"
    row1_values.append(formula)  # 통화시작 컬럼
    row1_values.append(formula)  # 통화종료 컬럼 (같은 상담사)
    row2_values.append("통화시작")
    row2_values.append("통화종료")

# C1부터 시작
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!C1",
    valueInputOption="USER_ENTERED",
    body={"values": [row1_values]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!C2",
    valueInputOption="USER_ENTERED",
    body={"values": [row2_values]},
).execute()
print(f"✅ Row 1: 동적 헤더 ({len(row1_values)}열)")
print(f"✅ Row 2: 컬럼 타입 (통화시작/통화종료)")

# 2단계: Row 3 수식 (각 상담사별 FILTER) - 5.콜에서 데이터 가져오기
# 각 상담사 컬럼 (C, E, G, ..., AE)에 시작 수식
# 통화시작/통화종료 페어 형식: FILTER({D2:D, E2:E}, W=상담사이름, ...)
# 우리 시스템: D=firstEngagedAt (통화 연결), E=endedAt (종료)
# 단, 포기호는 D 비어있음 → D에 빈셀 들어가면 매칭 안됨. 다른 로직 필요.
# 실제: IB_성공/OB_성공만 통화시작/종료. IB_포기호는 별도.
# 즉 FILTER 조건에 Q="IB_성공" or Q="OB_성공" 추가.

for i, raw_start in enumerate(raw_start_letters):
    formula = (
        f"=IFERROR("
        f"IF(ISBLANK({raw_start}1),,"
        f"FILTER({{'5.콜 상담내역'!D2:D,'5.콜 상담내역'!E2:E}},"
        f"'5.콜 상담내역'!W2:W={raw_start}1,"
        f"('5.콜 상담내역'!Q2:Q=\"IB_성공\")+('5.콜 상담내역'!Q2:Q=\"OB_성공\"),"
        f"'5.콜 상담내역'!N2:N=TEXT('1분 단위 포기호, 통화상세'!$E$2,\"YYYY-MM-DD\"))),)"
    )
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'RAW시간대별 포기호, 통화상세'!{raw_start}3",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()

print(f"✅ Row 3: 15명 상담사별 FILTER 수식 (D=firstEngagedAt, E=endedAt)")

# A3 (포기호 데이터)는 그대로 유지
# 검증: 5/4 5/8 데이터 출력 확인
print("\n" + "=" * 70)
print("검증 - 5/4 데이터")
print("=" * 70)
import time; time.sleep(3)

# Row 1 표시
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A1:AF2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[Row 1 (헤더 동적)]:")
print(res[0] if res else "EMPTY")
print("\n[Row 2 (타입)]:")
print(res[1] if len(res)>1 else "EMPTY")

# 첫 상담사 통화시작/종료 (C3:D5)
res2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!C3:D10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[C3:D10 (첫 상담사 통화)]:")
for r in res2:
    print(f"  {r}")
