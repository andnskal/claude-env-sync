"""보조 시트들의 사용 형태 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# A1 수식 확인
for sheet in ["_보조 채팅 A", "_보조 채팅 B", "_보조 콜"]:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!A1",
        valueRenderOption="FORMULA",
    ).execute().get("values", [[]])
    f = res[0][0] if res and res[0] else "?"
    print(f"{sheet}!A1: {f}")

# 6.채팅 수식들 — 어떻게 보조 시트 참조하는지
print("\n[6.채팅 시트 행2 수식들]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v:
            col = chr(ord('A') + ci) if ci < 26 else 'AA'
            if "_보조" in str(v):
                print(f"  {col}2: {str(v)[:200]}")

# 5.콜 시트 행2 수식들
print("\n[5.콜 시트 행2 수식들]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AC2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v:
            col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
            if "_보조" in str(v):
                print(f"  {col}2: {str(v)[:200]}")
