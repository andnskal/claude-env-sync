"""4/30 IB_포기호 시간대 분포 재시도."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 모든 데이터 다시 (UNFORMATTED 시도)
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

# 4/30 IB 모두
print("[4/30 IB 콜 샘플]")
n_col = 13  # N = 날짜
b_col = 1   # B = direction
q_col = 16  # Q = 구분
cnt = 0
samples = []
for row in all_calls:
    if len(row) > 30:
        N = str(row[n_col]) if len(row) > n_col else ""
        B = str(row[b_col]) if len(row) > b_col else ""
        if "2026-04-30" in N and B == "inbound":
            cnt += 1
            if len(samples) < 5:
                samples.append(row)

print(f"4/30 inbound 콜 수: {cnt}")
print("\n샘플 (첫 5건):")
for s in samples:
    print(f"  C(시작)={s[2]}, B={s[1]}, Q={s[16]}, N={s[13]}, AD={s[29] if len(s)>29 else '?'}")

# 시간대 분포
from collections import defaultdict
ib_aban_by_hour = defaultdict(int)
ib_succ_by_hour = defaultdict(int)
ib_aban_op_tag = defaultdict(int)
ib_aban_alert = defaultdict(int)

for row in all_calls:
    if len(row) < 30: continue
    N = str(row[13])
    Q = str(row[16])
    B = str(row[1])
    if "2026-04-30" not in N or B != "inbound": continue
    
    C = str(row[2])
    X = str(row[23]) if len(row) > 23 else ""
    Y = str(row[24]) if len(row) > 24 else ""
    
    # 시간 파싱 - 다양한 시도
    hour = None
    if " " in C:
        try:
            time_part = C.split(" ")[1]
            hour = int(time_part.split(":")[0])
        except:
            pass
    elif isinstance(row[2], (int, float)):
        # 시리얼 값
        decimal = row[2] - int(row[2])
        hour = int(decimal * 24)
    
    if hour is None: continue
    
    if Q == "IB_성공":
        ib_succ_by_hour[hour] += 1
    elif Q == "IB_포기호":
        ib_aban_by_hour[hour] += 1
        if "운영시간아님" in X:
            ib_aban_op_tag[hour] += 1
        if Y == "알림톡발송":
            ib_aban_alert[hour] += 1

print("\n" + "=" * 100)
print("4/30 IB 시간대 분포")
print("=" * 100)
print(f"{'시간':>4} | {'IB_성공':>8} | {'IB_포기호':>10} | {'운영외태그':>10} | {'알림톡':>8} | 비고")
print("-" * 100)

all_hours = sorted(set(list(ib_aban_by_hour.keys()) + list(ib_succ_by_hour.keys())))
total_aban = sum(ib_aban_by_hour.values())
total_succ = sum(ib_succ_by_hour.values())
total_op = sum(ib_aban_op_tag.values())
total_alert = sum(ib_aban_alert.values())

for h in all_hours:
    s = ib_succ_by_hour[h]
    a = ib_aban_by_hour[h]
    ao = ib_aban_op_tag[h]
    al = ib_aban_alert[h]
    note = ""
    if h < 9: note = "🌙 운영시간 전"
    elif 12 <= h < 14: note = "🍱 점심대"
    elif 17 <= h: note = "🌆 17시 이후"
    print(f"  {h:>2}시 | {s:>8} | {a:>10} | {ao:>10} | {al:>8} | {note}")

print("-" * 100)
print(f"  합계 | {total_succ:>8} | {total_aban:>10} | {total_op:>10} | {total_alert:>8}")

# 구간별 합산
print("\n[구간별 4/30 IB_포기호]")
sec_sum = {
    "🌙 새벽 (00-06)": 0,
    "🌅 이른 아침 (07-08)": 0,
    "📞 운영 오전 (09-12)": 0,
    "🍱 점심 (12-14)": 0,
    "📞 운영 오후 (14-17)": 0,
    "🌆 늦은 오후/저녁 (17-19)": 0,
    "🌙 야간 (19-24)": 0,
}
for h, c in ib_aban_by_hour.items():
    if h < 7: sec_sum["🌙 새벽 (00-06)"] += c
    elif h < 9: sec_sum["🌅 이른 아침 (07-08)"] += c
    elif h < 12: sec_sum["📞 운영 오전 (09-12)"] += c
    elif h < 14: sec_sum["🍱 점심 (12-14)"] += c
    elif h < 17: sec_sum["📞 운영 오후 (14-17)"] += c
    elif h < 19: sec_sum["🌆 늦은 오후/저녁 (17-19)"] += c
    else: sec_sum["🌙 야간 (19-24)"] += c

for s, c in sec_sum.items():
    pct = c / total_aban * 100 if total_aban else 0
    bar = "█" * int(pct / 2)
    print(f"  {s:>30}: {c:>3}건 ({pct:>5.1f}%) {bar}")
