"""기존 시트와 객관적으로 동일하게 만들기 위한 일괄 수정."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _hex_to_rgb_dict, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

reqs = []


def fmt(sid, sr, er, sc, ec, ftype, pattern):
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": er, "startColumnIndex": sc, "endColumnIndex": ec},
            "cell": {"userEnteredFormat": {"numberFormat": {"type": ftype, "pattern": pattern}}},
            "fields": "userEnteredFormat.numberFormat",
        }
    })


def width(sid, sc, ec, px):
    reqs.append({
        "updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": sc, "endIndex": ec},
            "properties": {"pixelSize": px}, "fields": "pixelSize",
        }
    })


def freeze(sid, fr, fc):
    reqs.append({
        "updateSheetProperties": {
            "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": fr, "frozenColumnCount": fc}},
            "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount",
        }
    })


def add_group(sid, sc, ec, collapsed=False):
    reqs.append({
        "addDimensionGroup": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": sc, "endIndex": ec},
        }
    })
    if collapsed:
        reqs.append({
            "updateDimensionGroup": {
                "dimensionGroup": {
                    "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": sc, "endIndex": ec},
                    "depth": 1, "collapsed": True,
                },
                "fields": "collapsed",
            }
        })


# ============================================================
# 1.일별 전체 통계
# ============================================================
sid1 = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 데이터 형식 수정
fmt(sid1, 3, 100, 0, 1, "DATE", "yyyy\"-\"mm\"-\"dd")  # A 날짜 텍스트변환
fmt(sid1, 3, 100, 1, 2, "DATE", "yyyy\"-\"mm\"-\"dd\" (\"ddd\")\"")  # B 구분(요일포함)
# 통화시간 TIME
fmt(sid1, 3, 100, 22, 24, "TIME", "[h]:mm:ss")  # W,X (IB통화/ATT)
fmt(sid1, 3, 100, 31, 33, "TIME", "[h]:mm:ss")  # AF,AG (OB통화/평균)

# 행 고정 5 (행4=일평균, 행5=합계 추가 예정)
freeze(sid1, 5, 1)

# 열 너비 (기존 시스템과 일치)
width(sid1, 0, 1, 100)   # A 날짜
width(sid1, 1, 2, 100)   # B 구분
width(sid1, 2, 4, 100)   # C-D 카카오
width(sid1, 4, 6, 100)   # E-F 네이버
width(sid1, 6, 8, 100)   # G-H 채널톡
width(sid1, 8, 11, 100)  # I-K 합계
width(sid1, 11, 14, 100) # L-N 채팅 인하우스
width(sid1, 14, 18, 100) # O-R IB 알림톡 제외
width(sid1, 18, 22, 100) # S-V IB 기술포기호 제외
width(sid1, 22, 24, 100) # W-X 통화시간
width(sid1, 24, 26, 100) # Y-Z 투입인원
width(sid1, 26, 33, 100) # AA-AG OB
width(sid1, 33, 34, 100) # AH 알림톡

# 열 그룹 (기존: C-H, S-V, Y-AA)
add_group(sid1, 2, 8)    # C-H 채널 인입/답변 그룹 (카카오/네이버/채널톡)
add_group(sid1, 18, 22)  # S-V IB 기술포기호 제외 그룹
add_group(sid1, 24, 27)  # Y-AA 투입인원/OB부재 그룹

# ============================================================
# 2.시간대별 전체통계
# ============================================================
sid2 = _get_sheet_id_by_name(NEW, "2.시간대별 전체통계")

# 통화시간 TIME
fmt(sid2, 3, 600, 19, 21, "TIME", "[h]:mm:ss")  # T,U
fmt(sid2, 3, 600, 25, 27, "TIME", "[h]:mm:ss")  # Z,AA

# 열 너비
width(sid2, 0, 1, 100)
width(sid2, 1, 3, 60)   # B,C 날짜텍스트/시간
width(sid2, 3, 6, 55)   # D,E,F 투입인원
width(sid2, 6, 23, 80)  # G-W IB
width(sid2, 23, 27, 80) # X-AA OB
width(sid2, 27, 38, 75) # AB-AL 채팅

# 열 그룹 (기존: G-I, O-O, X-AL)
add_group(sid2, 6, 9)    # G-I 콜백+알림톡 제외
add_group(sid2, 14, 15)  # O 기술포기호 고객인원수
add_group(sid2, 23, 38)  # X-AL OB+채팅

# ============================================================
# 5.콜 상담내역
# ============================================================
sid5 = _get_sheet_id_by_name(NEW, "5.콜 상담내역")

# 통화시간/후처리/대기/보류 TIME (S, T, U, V)
fmt(sid5, 1, 3500, 18, 22, "TIME", "[h]:mm:ss")
# C, D, E (datetime), J, K
fmt(sid5, 1, 3500, 2, 5, "DATE_TIME", "yyyy\"-\"mm\"-\"dd\" \"hh\":\"mm\":\"ss")
fmt(sid5, 1, 3500, 9, 11, "DATE_TIME", "yyyy\"-\"mm\"-\"dd\" \"hh\":\"mm\":\"ss")

# 열 너비
width(sid5, 0, 1, 165)  # userChatId
width(sid5, 1, 2, 100)  # direction
width(sid5, 2, 6, 187)  # 시간 컬럼들
width(sid5, 6, 12, 100) # tags 등
width(sid5, 12, 13, 100)  # M assigneeId 정제
width(sid5, 13, 16, 100)  # 날짜/요일/시간대
width(sid5, 16, 18, 110)  # P,Q
width(sid5, 18, 22, 100)  # 통화/후처리/대기/보류
width(sid5, 22, 26, 100)  # callDuration 등

# 열 그룹 (기존 B-L)
add_group(sid5, 1, 12)

# ============================================================
# 6.채팅 상담내역
# ============================================================
sid6 = _get_sheet_id_by_name(NEW, "6.채팅 상담내역")

freeze(sid6, 0, 0)  # 행 고정 해제 (기존 0)

# B,C,D,E,F datetime
fmt(sid6, 1, 3500, 1, 6, "DATE_TIME", "yyyy\"-\"mm\"-\"dd\" \"hh\":\"mm\":\"ss")

# 열 너비
width(sid6, 0, 1, 100)
width(sid6, 1, 2, 123)
width(sid6, 2, 4, 143)
width(sid6, 4, 8, 100)
width(sid6, 8, 9, 143)  # I 인하우스
width(sid6, 9, 25, 100)

# 열 그룹 (기존 B-H)
add_group(sid6, 1, 8)

# ============================================================
# 3.상담사별 채팅 / 4.상담사별 콜
# ============================================================
sid3 = _get_sheet_id_by_name(NEW, "3.상담사별 채팅 실적")
freeze(sid3, 1, 2)  # 행 고정 1, 열 고정 2 (B열 고정)
width(sid3, 0, 1, 100)
width(sid3, 1, 2, 147)
add_group(sid3, 0, 1, collapsed=True)

sid4 = _get_sheet_id_by_name(NEW, "4.상담사별 콜 실적")
freeze(sid4, 1, 2)
width(sid4, 0, 1, 119)
width(sid4, 1, 2, 151)
add_group(sid4, 0, 1, collapsed=True)

# ============================================================
# ★설정 — 구조 자체가 다름. 별도 처리 필요
# ============================================================
# 우선 행 고정 0으로 변경, 열 그룹 B-E
sids = _get_sheet_id_by_name(NEW, "★설정")
freeze(sids, 0, 0)
add_group(sids, 1, 5, collapsed=True)

# ============================================================
# 실행
# ============================================================
print(f"총 {len(reqs)}개 요청")
B = 50
for i in range(0, len(reqs), B):
    batch = reqs[i:i+B]
    try:
        _batch_update(NEW, batch)
        print(f"  ✅ 배치 {i//B+1}: {len(batch)}개")
    except Exception as e:
        print(f"  ❌ 배치 {i//B+1}: {e}")
print("🎉 완료")
