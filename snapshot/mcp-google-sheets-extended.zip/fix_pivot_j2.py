"""3,4 시트 J2 #REF! 수정 — C2 ARRAYFORMULA spillover와 충돌하는 J2 BYROW 제거."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# J2의 BYROW(A2:A,...)는 A 컬럼이 비어있어 의미없는 수식.
# 또한 C2 ARRAYFORMULA가 J2를 침범하여 #REF! 발생.
# J2를 비우면 자동 해결.

for sheet_name in ["3.상담사별 채팅 실적", "4.상담사별 콜 실적"]:
    _sheets.spreadsheets().values().clear(
        spreadsheetId=NEW, range=f"'{sheet_name}'!J2",
    ).execute()
    print(f"✅ {sheet_name} J2 클리어")

time.sleep(3)

# 검증
for sheet_name in ["3.상담사별 채팅 실적", "4.상담사별 콜 실적"]:
    print(f"\n[{sheet_name} 검증]")
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet_name}'!A1:N5",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    for ri, row in enumerate(res):
        # 비어있지 않은 셀 출력
        non_empty = [(chr(ord('A') + ci), str(v)[:20]) for ci, v in enumerate(row) if v]
        if non_empty:
            print(f"  Row {ri+1}: {non_empty[:8]}")
