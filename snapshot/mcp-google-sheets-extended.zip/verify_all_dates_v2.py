"""모든 일자 종합 재검증 (수정 후)."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

time.sleep(15)  # 수식 재계산 충분히 대기

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_5col = defaultdict(lambda: defaultdict(int))
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        Z = row[25] if len(row) > 25 else ""
        AD = row[29] if len(row) > 29 else ""
        AC = row[28] if len(row) > 28 else ""
        if not N or AD != "내": continue
        if Q == "IB_성공":
            date_5col[N]["IB_성공"] += 1
        elif Q == "OB_성공":
            date_5col[N]["OB_성공"] += 1
            if AC in ("본사", "외주 고객센터"):
                date_5col[N]["OB_성공_본사+외주"] += 1
        elif Q == "OB_실패":
            date_5col[N]["OB_실패"] += 1
        elif Q == "IB_포기호":
            date_5col[N]["IB_포기호_전체"] += 1
            if Y != "알림톡발송":
                date_5col[N]["IB_포기호_알림제외"] += 1
                if Z != "기술부재포기호":
                    date_5col[N]["IB_포기호_기술제외"] += 1

date_chat = defaultdict(lambda: defaultdict(int))
for row in all_chats:
    if len(row) > 25:
        O = row[14] if len(row) > 14 else ""
        M = row[12] if len(row) > 12 else ""
        Y_chat = row[24] if len(row) > 24 else ""
        Z_chat = row[25] if len(row) > 25 else ""
        if not O or Z_chat != "내": continue
        if Y_chat == "Y":
            date_chat[O][f"답변_{M}"] += 1

daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 100)
print("📊 모든 일자 × 모든 KPI 일치성 재검증")
print("=" * 100)
all_match = True
total = 0
matched = 0
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]:
        continue
    date = row[0]
    if date not in date_5col and date not in date_chat:
        continue
    
    daily_vals = {
        "P (응대호)": row[15] if len(row) > 15 else "",
        "Q (포기호 알림제외)": row[16] if len(row) > 16 else "",
        "U (포기호 기술제외)": row[20] if len(row) > 20 else "",
        "AC (OB 성공)": row[28] if len(row) > 28 else "",
        "D (카카오 답변)": row[3] if len(row) > 3 else "",
        "F (네이버 답변)": row[5] if len(row) > 5 else "",
        "H (채널톡 답변)": row[7] if len(row) > 7 else "",
    }
    expected = {
        "P (응대호)": date_5col[date]["IB_성공"],
        "Q (포기호 알림제외)": date_5col[date]["IB_포기호_알림제외"],
        "U (포기호 기술제외)": date_5col[date]["IB_포기호_기술제외"],
        "AC (OB 성공)": date_5col[date]["OB_성공_본사+외주"],
        "D (카카오 답변)": date_chat[date]["답변_카카오"],
        "F (네이버 답변)": date_chat[date]["답변_네이버"],
        "H (채널톡 답변)": date_chat[date]["답변_채널톡"],
    }
    
    date_match = True
    for kpi, exp in expected.items():
        actual = daily_vals[kpi]
        if actual != exp:
            all_match = False
            date_match = False
            print(f"\n📅 {date}: ❌ {kpi} 1.일별={actual} vs 직접={exp}")
        total += 1
        if actual == exp:
            matched += 1
    if date_match:
        print(f"📅 {date}: ✅ 7/7 일치")

print("\n" + "=" * 100)
print(f"📈 일치율: {matched}/{total} ({matched*100/total:.1f}%)")
if all_match:
    print("🎉 모든 일자 × 모든 KPI 100% 일치!")
else:
    print("⚠️ 추가 수정 필요")
print("=" * 100)
