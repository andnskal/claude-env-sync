"""발견된 모든 이슈 수정."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) Y6 범위 확장 A6:A100 → A6:A1000
print("[1] 1.일별 Y6 범위 확장")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!Y6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
y6_old = res[0][0] if res and res[0] else ""
y6_new = y6_old.replace("A6:A100", "A6:A1000")
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!Y6",
    valueInputOption="USER_ENTERED",
    body={"values": [[y6_new]]},
).execute()
print(f"  OK Y6: A6:A100 -> A6:A1000")

# 2) 모든 RAW + 6.채팅 freeze 적용
print("\n[2] 행 freeze 적용")
freeze_targets = [
    ("6.채팅 상담내역", 1),
    ("_RAW_NewMeet_33", 1),
    ("_RAW_UserChat_p1", 1),
    ("_RAW_UserChat_p2", 1),
    ("RAW 55번 기술 이관", 2),
    ("RAW_현시간 전화 모니터링", 2),
]
reqs = []
for sheet, fr in freeze_targets:
    sid = _get_sheet_id_by_name(NEW, sheet)
    reqs.append({
        "updateSheetProperties": {
            "properties": {
                "sheetId": sid,
                "gridProperties": {"frozenRowCount": fr}
            },
            "fields": "gridProperties.frozenRowCount"
        }
    })
    print(f"  OK {sheet}: 행 freeze = {fr}")
_batch_update(NEW, reqs)

# 3) 1.일별 행 6의 다른 BYROW 셀들도 모두 A6:A 또는 A6:A1000 사용 확인 + 수정
print("\n[3] 1.일별 모든 BYROW/MAP 범위 점검 + 수정")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT6",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])

import re
def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

if res and res[0]:
    fixed = 0
    for ci, v in enumerate(res[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(ci)
            # A6:A100 패턴 (정확한 한정) 찾기 - A6:A 또는 A6:A1000은 OK
            patterns = re.findall(r"A6:A(\d+)", v)
            need_fix = False
            for p in patterns:
                if int(p) < 1000:
                    need_fix = True
                    break
            if need_fix:
                new_v = re.sub(r"A6:A(\d{1,3})\b", "A6:A1000", v)
                _sheets.spreadsheets().values().update(
                    spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{col}6",
                    valueInputOption="USER_ENTERED",
                    body={"values": [[new_v]]},
                ).execute()
                print(f"  OK {col}6 범위 1000으로 확장")
                fixed += 1
    print(f"  → 수정: {fixed}개")

# 4) 6.채팅 M 수식 ★설정 매핑 사용 (선택적이지만 미래 확장성)
# 현재 IF chain (appkakao→카카오, appnavertalk→네이버) - 작동 정상
# ★설정 V-Y에 새 채널 추가 시 자동 반영 안됨
# 일단 현재 작동하므로 변경 안 함 (BREAKING 변경 가능성)

print("\n[4] 6.채팅 M (채널 한글) 수식")
print("  현재: IF chain (appkakao->카카오, appnavertalk->네이버, phone->전화, 그 외->채널톡)")
print("  → ★설정 매핑 미사용. 새 채널 추가 시 수식 수정 필요. 작동은 정상.")

# 5) 또 다른 잠재 이슈 검사: 1.일별 행 5 (합계) 수식 봐서 운영시간 영향 확인
print("\n[5] 1.일별 합계 행 (행 5) 모든 셀 검사")
res5 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A5:AT5",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
if res5 and res5[0]:
    for ci, v in enumerate(res5[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(ci)
            patterns = re.findall(r"[A-Z]+6:[A-Z]+(\d+)", v)
            need_fix = False
            for p in patterns:
                if int(p) < 1000:
                    need_fix = True
                    break
            if need_fix:
                # SUM(C6:C100) → SUM(C6:C1000) 같은 변환
                new_v = re.sub(r"([A-Z]+)6:([A-Z]+)(\d{1,3})\b", r"\g<1>6:\g<2>1000", v)
                _sheets.spreadsheets().values().update(
                    spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{col}5",
                    valueInputOption="USER_ENTERED",
                    body={"values": [[new_v]]},
                ).execute()
                print(f"  OK {col}5 범위 확장")

# 6) 행 4 (평균) 동일
print("\n[6] 1.일별 평균 행 (행 4) 모든 셀 검사")
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A4:AT4",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
if res4 and res4[0]:
    for ci, v in enumerate(res4[0]):
        if v and isinstance(v, str) and v.startswith("="):
            col = col_letter(ci)
            patterns = re.findall(r"[A-Z]+6:[A-Z]+(\d+)", v)
            need_fix = False
            for p in patterns:
                if int(p) < 1000:
                    need_fix = True
                    break
            if need_fix:
                new_v = re.sub(r"([A-Z]+)6:([A-Z]+)(\d{1,3})\b", r"\g<1>6:\g<2>1000", v)
                _sheets.spreadsheets().values().update(
                    spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{col}4",
                    valueInputOption="USER_ENTERED",
                    body={"values": [[new_v]]},
                ).execute()
                print(f"  OK {col}4 범위 확장")

# 7) RAW시간대별 freeze 확인
print("\n[7] RAW시간대별 freeze 확인")
print("  ✅ RAW시간대별: 이미 행 freeze 2 (정상)")

print("\n" + "=" * 80)
print("모든 발견 이슈 수정 완료")
print("=" * 80)
