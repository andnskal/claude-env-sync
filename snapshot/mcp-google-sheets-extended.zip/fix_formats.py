"""서식 수정 - 1분단위 E2, 1.일별 AM, 2.시간대별 AF."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

reqs = []

# 1) 1분단위 E2 → DATE yyyy-mm-dd
sid_1m = _get_sheet_id_by_name(NEW, "1분 단위 포기호, 통화상세")
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid_1m, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 4, "endColumnIndex": 5},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "DATE", "pattern": "yyyy-mm-dd"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

# 2) 1.일별 AM 컬럼 (39번째, 인덱스 38) → NUMBER 0 (전체 컬럼)
sid_d = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")
reqs.append({
    "repeatCell": {
        "range": {"sheetId": sid_d, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 38, "endColumnIndex": 39},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "NUMBER", "pattern": "0"}}},
        "fields": "userEnteredFormat.numberFormat",
    }
})

_batch_update(NEW, reqs)
print("OK 1분단위 E2 → DATE / 1.일별 AM 컬럼 → NUMBER 0")
time.sleep(3)

# 3) 2.시간대별 AF 분석 (왜 318%?)
print("\n[2.시간대별 AE, AF 정의 분석]")
formulas = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A1:AL4",
    valueRenderOption="FORMULA",
).execute().get("values", [])

# 헤더와 수식
print("[행 1-3 헤더]")
for ri in range(3):
    if ri < len(formulas):
        for ci, v in enumerate(formulas[ri]):
            if v:
                col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
                if col in ("AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL"):
                    print(f"  {col}{ri+1}: {str(v)[:60]}")

# 수식 (행 4)
print("\n[행 4 수식 (AB-AL)]")
if len(formulas) > 3:
    for ci, v in enumerate(formulas[3]):
        col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
        if col in ("AB", "AC", "AD", "AE", "AF") and v:
            print(f"  {col}4: {str(v)[:200]}")
