"""1.일별 M(기술이관) 수식에 RAW 55 통합 + 운영 가이드."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 M 수식 — 6.채팅 (본사) + RAW 55 (외주 도급사) 합산
new_m6 = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    # 본사 채팅 기술이관 (기존)
    "COUNTIFS('6.채팅 상담내역'!$O:$O,LEFT(d,10),"
    "'6.채팅 상담내역'!$M:$M," + '"기술이관"' + ","
    "'6.채팅 상담내역'!$Z:$Z," + '"내"' + ")"
    # 외주 도급사 RAW 55 — TCK 또는 CS쉐어링 + 채팅 인입
    "+COUNTIFS('RAW 55번 기술 이관'!$M:$M,LEFT(d,10),"
    "'RAW 55번 기술 이관'!$K:$K," + '"기술이관"' + ","
    "'RAW 55번 기술 이관'!$H:$H," + '"채팅"' + ","
    "'RAW 55번 기술 이관'!$N:$N," + '"내"' + ","
    "'RAW 55번 기술 이관'!$J:$J," + '"TCK_*"' + ")"
    "+COUNTIFS('RAW 55번 기술 이관'!$M:$M,LEFT(d,10),"
    "'RAW 55번 기술 이관'!$K:$K," + '"기술이관"' + ","
    "'RAW 55번 기술 이관'!$H:$H," + '"채팅"' + ","
    "'RAW 55번 기술 이관'!$N:$N," + '"내"' + ","
    "'RAW 55번 기술 이관'!$J:$J," + '"CS쉐어링_*"' + "))))"
)

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!M6",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_m6]]},
).execute()
print("OK 1.일별 M6 — 본사 채팅 기술이관 + 외주 도급사 RAW 55 통합")
time.sleep(5)

# 검증 - 5/9 이전 도급사 데이터 카운트 시뮬레이션
print("\n[검증 - 일자별 M 값]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:M30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in res:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        date = row[0]
        H = row[7] if len(row) > 7 else "?"  # 채널톡 답변
        L = row[11] if len(row) > 11 else "?"  # 본사+외주 합계
        M = row[12] if len(row) > 12 else "?"  # 기술이관 (수정된 값)
        print(f"  {date}: H={H}, L={L}, M={M}")

# 실제 RAW 55에서 4/30+ 데이터 카운트 (현재 도급사 미운영이지만 외부 시트에 데이터 있을 수 있음)
all_55 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!H2:N10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import defaultdict
date_55 = defaultdict(int)
for row in all_55:
    if len(row) > 5:
        H_route = row[0] if len(row) > 0 else ""  # H 인입 경로
        K_tag = row[3] if len(row) > 3 else ""    # K 기술이관
        M_date = row[5] if len(row) > 5 else ""   # M 신 형식 날짜
        if H_route == "채팅" and K_tag == "기술이관" and M_date and "2026" in M_date:
            if M_date >= "2026-04-30":
                date_55[M_date] += 1

print(f"\n[RAW 55 4/30+ 채팅 기술이관 카운트]")
for d in sorted(date_55.keys())[:10]:
    print(f"  {d}: {date_55[d]}건")
print(f"  총: {sum(date_55.values())}건")
