"""1.일별 Y6 #ERROR! 진단."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Y6 수식 단순화 테스트
# 임시 셀에서 BYROW 단계별 검증
test_formulas = [
    ("AZ1", '=COUNTIFS(\'5.콜 상담내역\'!N:N, "2026-04-30", \'5.콜 상담내역\'!Q:Q, "IB_성공")'),
    ("AZ2", '=COUNTA(UNIQUE(FILTER(\'5.콜 상담내역\'!W:W, \'5.콜 상담내역\'!N:N="2026-04-30", \'5.콜 상담내역\'!Q:Q="IB_성공", \'5.콜 상담내역\'!W:W<>"기타", \'5.콜 상담내역\'!W:W<>"")))'),
    ("AZ3", '=A6'),  # A6 값 확인
    ("AZ4", '=LEFT(A6, 10)'),  # A6 LEFT 10
    ("AZ5", '=ARRAYFORMULA(IF(A6:A100="",,IF(COUNTIFS(\'5.콜 상담내역\'!$N:$N, LEFT(A6:A100,10), \'5.콜 상담내역\'!$Q:$Q, "IB_성공")=0, 0, "TODO")))'),
]

for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1.일별 전체 통계'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(3)

res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AZ1:AZ20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

labels = [
    "4/30 IB_성공 카운트",
    "4/30 unique 상담사 카운트",
    "A6 값",
    "LEFT(A6, 10)",
    "ARRAYFORMULA 단순화 (A6:A100)"
]
for i, label in enumerate(labels):
    val = res[i][0] if i < len(res) and res[i] else 'N/A'
    print(f"  {label}: {val}")

# spillover 확인 (AZ5)
print("\n[AZ5 spillover]")
for i in range(1, 15):
    val = res[i][0] if i < len(res) and res[i] else ''
    if val:
        print(f"  AZ{i+1}: {val}")
