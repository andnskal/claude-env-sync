"""한 번의 batch에 7개 그룹 동시 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 기존 그룹 삭제
print("[기존 그룹 삭제]")
for attempt in range(15):
    meta = _sheets.spreadsheets().get(
        spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
    ).execute()
    found_groups = []
    for s in meta.get("sheets", []):
        if s["properties"]["sheetId"] == sid:
            found_groups = s.get("columnGroups", [])
            break
    if not found_groups:
        break
    g = sorted(found_groups, key=lambda x: -x.get("depth", 1))[0]
    r = g["range"]
    try:
        _batch_update(NEW, [{
            "deleteDimensionGroup": {
                "range": {
                    "sheetId": sid, "dimension": "COLUMNS",
                    "startIndex": r.get("startIndex", 0),
                    "endIndex": r.get("endIndex", 0),
                }
            }
        }])
        time.sleep(0.5)
    except: break
print("  완료")
time.sleep(2)

# 한 번의 batch에 7개 동시 추가
print("\n[batch 한번에 7개 그룹]")
groups = [
    (2, 14),    # C-N 채팅
    (14, 26),   # O-Z IB
    (26, 34),   # AA-AH OB
    (34, 36),   # AI-AJ 콜백
    (36, 39),   # AK-AM KPI
    (39, 46),   # AN-AT 부재중
    (46, 49),   # AU-AW 참고
]
reqs = []
for start, end in groups:
    reqs.append({
        "addDimensionGroup": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": start, "endIndex": end}
        }
    })
_batch_update(NEW, reqs)
time.sleep(3)

# 결과
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
).execute()
def cl(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        groups_now = s.get("columnGroups", [])
        print(f"\n결과: {len(groups_now)}개")
        for g in groups_now:
            r = g["range"]
            print(f"  depth {g.get('depth',0)}: {cl(r['startIndex'])}-{cl(r['endIndex']-1)}")
        break
