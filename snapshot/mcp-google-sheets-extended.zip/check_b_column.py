"""★설정 B 컬럼 구조 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# B 컬럼 수식 확인 (수식인지 정적 값인지)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B10",
    valueRenderOption="FORMULA",
).execute().get("values", [])
print("[B 컬럼 행 1-10 수식 (FORMULA)]")
for ri, r in enumerate(res):
    if r and r[0]:
        print(f"  B{ri+1}: {r[0]}")

# 정확한 점심 시간대 표시 (12:30~13:30 직전)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!B1:B600",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print(f"\n[B 컬럼 점심시간대 (12:30 ~ 13:30 직전)]")
in_lunch = False
for ri, r in enumerate(res):
    if r and r[0]:
        v = r[0]
        if v in ["12:28", "12:29", "12:30", "12:31"]:
            print(f"  B{ri+1}: {v} {'← 점심 시작 (제거 대상)' if v == '12:30' else ''}")
        elif v in ["13:28", "13:29", "13:30", "13:31"]:
            print(f"  B{ri+1}: {v} {'← 점심 종료 직전 (제거 대상 마지막)' if v == '13:29' else '← 점심 종료 (유지)' if v == '13:30' else ''}")
