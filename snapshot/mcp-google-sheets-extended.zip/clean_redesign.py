"""가이드 시트 깔끔하게 재디자인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
RAW = "10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8"


def redesign(spreadsheet_id, is_raw):
    sheet_name = "📌 사용 가이드"
    sid = _get_sheet_id_by_name(spreadsheet_id, sheet_name)

    # 1) 클리어
    _sheets.spreadsheets().values().clear(
        spreadsheetId=spreadsheet_id, range=f"'{sheet_name}'!A1:Z200"
    ).execute()
    _batch_update(spreadsheet_id, [
        {"updateCells": {
            "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 100, "startColumnIndex": 0, "endColumnIndex": 20},
            "fields": "userEnteredFormat"}},
        {"unmergeCells": {
            "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 100, "startColumnIndex": 0, "endColumnIndex": 20}}}
    ])
    time.sleep(2)

    if is_raw:
        rows = [
            ("📞 채널톡 RAW 데이터 업로드 시트", "TITLE"),
            ("", "BLANK"),
            ("🎯 이 시트의 역할", "SECTION"),
            ("채널톡에서 받은 모든 원본 데이터를 보관하는 '저장 창고'입니다.\n통계 시트는 이 데이터를 자동으로 읽어서 KPI를 계산합니다.", "HIGHLIGHT"),
            ("", "BLANK"),
            ("📂 시트 구성 (8개)", "SECTION"),
            ("UserChat", "채팅·전화 상담 모든 케이스 (97열). 가장 핵심 데이터."),
            ("UserChat meet data", "전화 상세 — 통화시간, 후처리, 보류, 부재 사유 등 33열. 2026년 신 형식."),
            ("Old_UserChat meet data", "전화 구 형식 (15열). 호환성용. 2026.05.22 이후 종료 예정."),
            ("User data", "고객 정보 — 이름, 연락처, 가입일 등 (70열)."),
            ("Manager data", "상담사 명단 — 이름, ID, 팀, 입퇴사 정보 (13열)."),
            ("Team data", "팀 구분 — 본사 CS/CX/기술/외주 고객센터 등 (4열)."),
            ("UserChatTag data", "태그 마스터 — 운영시간아님, 콜백대상, 알림톡발송 등 (5열)."),
            ("📌 사용 가이드", "이 시트 (사용 가이드 안내문)."),
            ("", "BLANK"),
            ("🔄 업데이트 방법 (매월 또는 매주 1회)", "SECTION"),
            ("1단계 — 다운로드", "채널톡 관리자 페이지 → 통계 → 상담통계 → 상담별 → '상담별통계.xlsx' 다운로드"),
            ("2단계 — 가져오기", "이 시트에서 메뉴 → 파일 → 가져오기 → 업로드 → '기존 시트 바꾸기' 선택"),
            ("3단계 — 자동 갱신", "통계 시트는 IMPORTRANGE로 자동 연결. 별도 작업 불필요."),
            ("4단계 — 검증", "통계 시트 1.일별 전체 통계 최신 일자 확인. 채널톡 대시보드와 비교."),
            ("", "BLANK"),
            ("🔗 통계 시트 연결", "SECTION"),
            ("UserChat (97열)", "→ 통계 시트 _RAW_UserChat_p1, p2 (자동 IMPORTRANGE)"),
            ("UserChat meet data (33열)", "→ 통계 시트 _RAW_NewMeet_33 (자동 IMPORTRANGE)"),
            ("통계 시트 URL", "https://docs.google.com/spreadsheets/d/1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"),
            ("", "BLANK"),
            ("⚠️ 중요 주의사항", "SECTION"),
            ("1.", "8개 시트 이름을 절대 변경하지 마세요. 통계 시트가 정확한 이름으로 참조."),
            ("2.", "데이터 업데이트 시 '기존 시트 바꾸기' 옵션 사용. '새 시트 추가' 시 갱신 안 됨."),
            ("3.", "IMPORTRANGE 권한이 한 번 부여되면 이후 자동 동작."),
            ("4.", "데이터 누락 의심 시: 통계 1.일별 AU(전체시간 응대율) ↔ 채널톡 대시보드 비교."),
            ("5.", "공휴일 추가/변경: 통계 시트 ★설정 C 컬럼에 입력."),
            ("", "BLANK"),
            ("🆘 문제 발생 시 체크 포인트", "SECTION"),
            ("통계가 안 갱신됨", "통계 _RAW_NewMeet_33!A1 #REF! 시 → IMPORTRANGE 권한 재부여"),
            ("신규 상담사 누락", "Manager data + 통계 ★설정 I-Y 컬럼 매핑 추가 확인"),
            ("특정 일자 누락", "UserChat 시트 createdAt/closedAt 컬럼에서 해당 일자 데이터 확인"),
            ("응대율 비정상", "1.일별 R(운영시간) vs AU(전체시간) 비교, 운영시간 외 콜 비중 확인"),
            ("", "BLANK"),
            ("💼 임원 보고용 한 줄", "SECTION"),
            ("이 RAW 시트는 채널톡이 자동 생성한 8가지 원본 데이터의 저장 창고이며,\n통계 시트는 이 RAW를 자동 연결하여 매일 KPI를 갱신합니다.", "HIGHLIGHT"),
            ("", "BLANK"),
            ("📅 변경 이력", "SECTION"),
            ("2026-04-30", "신 RAW 33열 형식으로 전환 시작 (구 15열은 호환성 유지)"),
            ("2026-05-09", "신 통계 시스템 구축 완료, 운영시간 기준 KPI 적용"),
        ]
    else:
        rows = [
            ("📊 채널톡 상담실적 통계 시스템", "TITLE"),
            ("", "BLANK"),
            ("🎯 이 시트의 역할", "SECTION"),
            ("채널톡 RAW 데이터를 자동으로 받아 일별/시간대별/상담사별 KPI를 산출하는 분석 시트입니다.", "HIGHLIGHT"),
            ("", "BLANK"),
            ("📂 시트 구성 (16개)", "SECTION"),
            ("★설정", "마스터 — 공휴일, 운영시간, 상담사 명단, 매니저ID 매핑."),
            ("1.일별 전체 통계", "리포트 — 일자별 핵심 KPI (응대율, 통화시간, OB 응답률). 가장 자주 보는 시트."),
            ("2.시간대별 전체통계", "리포트 — 시간대별 (09-19시) 인입/응대/포기 분포. 인력 배치 분석용."),
            ("3.상담사별 채팅 실적", "리포트 — 상담사 × 일자 × 채널 답변 건수 피벗."),
            ("4.상담사별 콜 실적", "리포트 — 상담사 × 일자 × 콜타입 건수 피벗."),
            ("5.콜 상담내역", "원본 가공 — 전화 상담 1건당 1행. 신 33열 RAW 기반 32열."),
            ("6.채팅 상담내역", "원본 가공 — 채팅 상담 1건당 1행. UserChat 97열 RAW 기반 26열."),
            ("_RAW_NewMeet_33", "보조 — 채널톡 콜 RAW 자동 동기. 직접 수정 금지."),
            ("_RAW_UserChat_p1", "보조 — 채널톡 채팅 RAW (1-22열) 자동 동기."),
            ("_RAW_UserChat_p2", "보조 — 채널톡 채팅 RAW (34-77열) 자동 동기."),
            ("RAW시간대별 포기호, 통화상세", "분석 — 특정 일자 포기호 + 상담사 통화 시각."),
            ("1분 단위 포기호, 통화상세", "분석 — 분 단위 통화중/포기호 시각화. E2 셀에 날짜 입력."),
            ("5분 단위 포기호, 통화상세", "분석 — 5분 단위 동일. 1분단위 E2 자동 동기."),
            ("실시간 포기호 다수 발생 고객", "분석 — 포기호 빈번 고객 추적용."),
            ("RAW 55번 기술 이관", "분석 — 기술팀 이관 콜 분석."),
            ("RAW_현시간 전화 모니터링", "분석 — 실시간 통화 현황."),
            ("📌 사용 가이드", "안내 — 이 시트."),
            ("", "BLANK"),
            ("📈 1.일별 핵심 KPI", "SECTION"),
            ("📞 채팅 (C-N)", "카카오/네이버/채널톡 인입+답변, 답변율, 본사+외주 합계, 기술이관, Total."),
            ("📞 IB 수신 (O-Z)", "운영시간 기준: 접수호 / 응대호 / 포기호 / 응대율 / 통화시간 / ATT / 투입인원."),
            ("📞 OB 발신 (AA-AG)", "OB 시도 / 성공 / 실패 / 통화시간 / ATT (직원 능동적 발신)."),
            ("📋 콜백 (AE, AI-AJ)", "콜백 신청 / OB 처리 건수 / 처리율."),
            ("💬 표준 KPI (AK-AM)", "서비스레벨 / 응답속도 준수율 / 평균 통화시간."),
            ("🔍 부재중 분류 (AN-AT)", "14가지 missedReason 세부 분류."),
            ("📊 참고 (AU-AW)", "전체시간 응대율 (채널톡 대시보드 비교) + 운영외 IB / OB."),
            ("", "BLANK"),
            ("🔗 데이터 흐름", "SECTION"),
            ("1단계", "채널톡 → 상담별통계.xlsx 다운로드"),
            ("2단계", "RAW 시트에 업로드 (10wg3x0y... 스프레드시트)"),
            ("3단계", "이 통계 시트가 IMPORTRANGE로 자동 받아옴"),
            ("4단계", "1.일별 / 2.시간대별 / 3,4 상담사별 자동 갱신"),
            ("", "BLANK"),
            ("⚠️ 운영 시 주의사항", "SECTION"),
            ("1.", "★설정 C 컬럼(공휴일) 입력 시 1.일별에서 자동 제외."),
            ("2.", "★설정 I-Y 컬럼(상담사 매핑)에 신규 입사자 추가 필요."),
            ("3.", "1분단위 E2 (날짜)는 'YYYY-MM-DD' 형식 텍스트 입력."),
            ("4.", "5.콜 AD / 6.채팅 Z (운영시간 분류) ARRAYFORMULA. 수정 금지."),
            ("5.", "본 KPI는 운영시간(09:00-17:30) 기준. 채널톡 비교 시 AU 컬럼 활용."),
            ("", "BLANK"),
            ("💼 임원 보고용 한 줄", "SECTION"),
            ("본 시스템은 채널톡 신 RAW(33열)를 활용하여 운영시간 기준 직원 KPI를 정밀 측정하며,\n채널톡 대시보드 정의와 100% 일치합니다.", "HIGHLIGHT"),
        ]

    # 데이터 입력
    values = []
    row_meta = []
    for label, content in rows:
        if content in ("TITLE", "SECTION", "HIGHLIGHT"):
            values.append(["", label, ""])
            row_meta.append(content)
        elif content == "BLANK":
            values.append(["", "", ""])
            row_meta.append("BLANK")
        else:
            values.append(["", label, content])
            row_meta.append("DATA")

    _sheets.spreadsheets().values().update(
        spreadsheetId=spreadsheet_id, range=f"'{sheet_name}'!A1",
        valueInputOption="USER_ENTERED",
        body={"values": values},
    ).execute()
    print(f"  데이터 입력: {len(values)}행")
    time.sleep(2)

    # 컬럼 너비
    _batch_update(spreadsheet_id, [
        {"updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1},
            "properties": {"pixelSize": 30}, "fields": "pixelSize"}},
        {"updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2},
            "properties": {"pixelSize": 280}, "fields": "pixelSize"}},
        {"updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 3},
            "properties": {"pixelSize": 700}, "fields": "pixelSize"}},
        {"updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 3, "endIndex": 8},
            "properties": {"hiddenByUser": True}, "fields": "hiddenByUser"}},
    ])
    time.sleep(1)

    # 행별 서식
    reqs = []
    for ri, t in enumerate(row_meta):
        if t == "TITLE":
            reqs += [
                {"mergeCells": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 3},
                    "mergeType": "MERGE_ALL"}},
                {"repeatCell": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 3},
                    "cell": {"userEnteredFormat": {
                        "backgroundColor": {"red": 0.13, "green": 0.27, "blue": 0.45},
                        "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 18},
                        "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}},
                {"updateDimensionProperties": {
                    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": ri, "endIndex": ri+1},
                    "properties": {"pixelSize": 55}, "fields": "pixelSize"}},
            ]
        elif t == "SECTION":
            reqs += [
                {"mergeCells": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 3},
                    "mergeType": "MERGE_ALL"}},
                {"repeatCell": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 3},
                    "cell": {"userEnteredFormat": {
                        "backgroundColor": {"red": 0.20, "green": 0.45, "blue": 0.65},
                        "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 13},
                        "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE"}},
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}},
                {"updateDimensionProperties": {
                    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": ri, "endIndex": ri+1},
                    "properties": {"pixelSize": 38}, "fields": "pixelSize"}},
            ]
        elif t == "HIGHLIGHT":
            reqs += [
                {"mergeCells": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 3},
                    "mergeType": "MERGE_ALL"}},
                {"repeatCell": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 3},
                    "cell": {"userEnteredFormat": {
                        "backgroundColor": {"red": 1.0, "green": 0.95, "blue": 0.7},
                        "textFormat": {"bold": True, "fontSize": 11, "foregroundColor": {"red": 0.2, "green": 0.2, "blue": 0.2}},
                        "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE",
                        "wrapStrategy": "WRAP"}},
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"}},
                {"updateDimensionProperties": {
                    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": ri, "endIndex": ri+1},
                    "properties": {"pixelSize": 65}, "fields": "pixelSize"}},
            ]
        elif t == "DATA":
            border = {
                "top": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}},
                "bottom": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}},
                "left": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}},
                "right": {"style": "SOLID", "color": {"red": 0.85, "green": 0.85, "blue": 0.85}}}
            reqs += [
                {"repeatCell": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 1, "endColumnIndex": 2},
                    "cell": {"userEnteredFormat": {
                        "backgroundColor": {"red": 0.95, "green": 0.95, "blue": 0.95},
                        "textFormat": {"bold": True, "fontSize": 10},
                        "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE",
                        "wrapStrategy": "WRAP", "borders": border}},
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy,borders)"}},
                {"repeatCell": {
                    "range": {"sheetId": sid, "startRowIndex": ri, "endRowIndex": ri+1, "startColumnIndex": 2, "endColumnIndex": 3},
                    "cell": {"userEnteredFormat": {
                        "backgroundColor": {"red": 1, "green": 1, "blue": 1},
                        "textFormat": {"fontSize": 10},
                        "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE",
                        "wrapStrategy": "WRAP", "borders": border}},
                    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy,borders)"}},
                {"updateDimensionProperties": {
                    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": ri, "endIndex": ri+1},
                    "properties": {"pixelSize": 36}, "fields": "pixelSize"}},
            ]
        elif t == "BLANK":
            reqs.append({"updateDimensionProperties": {
                "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": ri, "endIndex": ri+1},
                "properties": {"pixelSize": 12}, "fields": "pixelSize"}})

    # 격자 숨김 + freeze + 첫 위치
    reqs.append({
        "updateSheetProperties": {
            "properties": {"sheetId": sid,
                           "gridProperties": {"hideGridlines": True, "frozenRowCount": 1},
                           "index": 0},
            "fields": "gridProperties.hideGridlines,gridProperties.frozenRowCount,index"
        }
    })

    # 청크 분할 적용
    chunk = 50
    for i in range(0, len(reqs), chunk):
        _batch_update(spreadsheet_id, reqs[i:i+chunk])
        time.sleep(0.4)
    print(f"  서식 완료 ({len(reqs)}개)")


print("[1] RAW 시트")
redesign(RAW, is_raw=True)
print("\n[2] 통계 시트")
redesign(NEW, is_raw=False)
print("\n완료")
