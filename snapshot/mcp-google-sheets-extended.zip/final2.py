"""마지막 폴리시 v2."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

reqs = []

def w(sid, sc, ec, px):
    reqs.append({
        "updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": sc, "endIndex": ec},
            "properties": {"pixelSize": px}, "fields": "pixelSize",
        }
    })

def freeze(sid, fr, fc):
    reqs.append({
        "updateSheetProperties": {
            "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": fr, "frozenColumnCount": fc}},
            "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount",
        }
    })

# 2.시간대별 열 너비 추가 조정
sid2 = _get_sheet_id_by_name(NEW, "2.시간대별 전체통계")
w(sid2, 17, 18, 81)   # R
w(sid2, 18, 19, 81)   # S
w(sid2, 20, 21, 131)  # U
w(sid2, 26, 27, 134)  # AA
w(sid2, 27, 28, 54)   # AB
w(sid2, 28, 29, 124)  # AC
w(sid2, 29, 30, 67)   # AD
w(sid2, 30, 31, 117)  # AE
w(sid2, 31, 32, 80)   # AF
w(sid2, 32, 33, 60)   # AG
w(sid2, 33, 34, 60)   # AH
w(sid2, 34, 35, 60)   # AI
w(sid2, 35, 36, 60)   # AJ
w(sid2, 36, 37, 60)   # AK
w(sid2, 37, 38, 60)   # AL

# 6.채팅 열 너비
sid6 = _get_sheet_id_by_name(NEW, "6.채팅 상담내역")
w(sid6, 2, 3, 115)
w(sid6, 9, 10, 143)

# 3·4 상담사별 행 고정 0으로
sid3 = _get_sheet_id_by_name(NEW, "3.상담사별 채팅 실적")
sid4 = _get_sheet_id_by_name(NEW, "4.상담사별 콜 실적")
freeze(sid3, 0, 2)
freeze(sid4, 0, 2)

# ★설정 행 고정 0
sids = _get_sheet_id_by_name(NEW, "★설정")
freeze(sids, 0, 0)

_batch_update(NEW, reqs)
print(f"✅ {len(reqs)}개 적용")

# 1.일별 1행 헤더 줄바꿈 추가 보강 (Z 컬럼 등)
# Z 헤더는 "투입인원\n- 시간대별합 ÷ 9" — 사용자 결정에 따라 9 유지

# 6.채팅 행 고정 0
freeze(sid6, 0, 0)
_batch_update(NEW, [{
    "updateSheetProperties": {
        "properties": {"sheetId": sid6, "gridProperties": {"frozenRowCount": 0, "frozenColumnCount": 0}},
        "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount",
    }
}])
print("✅ 6.채팅 행 고정 0")
print("🎉 완료")
