"""5.콜 AD + 6.채팅 Z 수식에 시간 조건 추가 (X 태그 + 09:00-17:30 시간 범위)."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 AD: X="운영시간아님" 또는 시간 < 09:00 또는 시간 >= 17:30 → "외"
# 540 = 9*60, 1050 = 17.5*60
ad_formula = (
    '=ARRAYFORMULA(IF(N2:N="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",X2:X)),"외",'
    'IF((HOUR(C2:C)*60+MINUTE(C2:C)>=540)*(HOUR(C2:C)*60+MINUTE(C2:C)<1050),"내","외"))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2",
    valueInputOption="USER_ENTERED",
    body={"values": [[ad_formula]]},
).execute()
print("OK 5.콜 AD2 수식 업데이트 (X 태그 + 시간 09:00-17:30)")

# 6.채팅 Z: 동일 (시간 컬럼은 B = createdAt)
z_formula = (
    '=ARRAYFORMULA(IF(O2:O="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",K2:K)),"외",'
    'IF((HOUR(B2:B)*60+MINUTE(B2:B)>=540)*(HOUR(B2:B)*60+MINUTE(B2:B)<1050),"내","외"))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z2",
    valueInputOption="USER_ENTERED",
    body={"values": [[z_formula]]},
).execute()
print("OK 6.채팅 Z2 수식 업데이트 (X 태그 + 시간 09:00-17:30)")

time.sleep(8)

# 검증
print("\n[5.콜 AD 분포 (수정 후)]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
counts = Counter(r[0] for r in res if r and r[0])
for k, v in counts.most_common():
    print(f"  {k}: {v}건")

# 4/30 outlier 콜 재확인
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n[4/30 시간대별 외 콜 (수정 후 AD 값)]")
for row in all_calls:
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        P = row[15] if len(row) > 15 else ""
        AD = row[29] if len(row) > 29 else ""
        if N == "2026-04-30" and P in ("06-07", "07-08", "08-09", "19-20"):
            if Q in ("IB_포기호", "OB_성공"):
                print(f"  {row[2]} | {Q} | P={P} | AD={AD}")
