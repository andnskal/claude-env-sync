"""KPI 매핑 수정 후 재검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

all_f = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!F2:F3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict

# 분리된 카운트
date_aban_callback = defaultdict(int)  # IB_포기호 콜백만
date_ob_callback = defaultdict(int)  # OB_성공 + 콜백 태그 (본사+외주)
date_ob_attempt_no_callback = defaultdict(int)  # OB 시도 - 콜백 OB
date_alert_send = defaultdict(int)
date_tech_chat = defaultdict(int)
date_ob_total = defaultdict(int)  # 모든 outbound

for ri, row in enumerate(all_calls):
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        Y = row[24] if len(row) > 24 else ""
        X = row[23] if len(row) > 23 else ""
        AC = row[28] if len(row) > 28 else ""
        AD = row[29] if len(row) > 29 else ""
        if not N or AD != "내": continue
        if Q == "IB_포기호" and Y == "콜백":
            date_aban_callback[N] += 1
        if Q == "OB_성공" and "콜백" in X and AC in ("본사", "외주 고객센터"):
            date_ob_callback[N] += 1
        if Y == "알림톡발송":
            date_alert_send[N] += 1
        if row[1] == "outbound":
            date_ob_total[N] += 1

# 채팅 기술이관
for row in all_chats:
    if len(row) > 25:
        O = row[14] if len(row) > 14 else ""
        M = row[12] if len(row) > 12 else ""
        Y_chat = row[24] if len(row) > 24 else ""
        Z_chat = row[25] if len(row) > 25 else ""
        if not O or Z_chat != "내": continue
        if M == "기술이관" and Y_chat == "Y":
            date_tech_chat[O] += 1

# 1.일별
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 100)
print("KPI 매핑 정확화 후 재검증")
print("=" * 100)
all_match = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_aban_callback and date not in date_ob_total:
        if not (date_alert_send[date] or date_tech_chat[date]):
            continue
    
    # 1.일별 컬럼 매핑
    daily_vals = {
        "M (기술이관 - 채팅)": row[12] if len(row) > 12 else "",
        "AB (OB 시도)": row[27] if len(row) > 27 else "",
        "AE (콜백 등록 = IB_포기호 콜백)": row[30] if len(row) > 30 else "",
        "AH (상담톡 발송)": row[33] if len(row) > 33 else "",
        "AI (콜백 OB 처리)": row[34] if len(row) > 34 else "",
    }
    expected = {
        "M (기술이관 - 채팅)": date_tech_chat[date],
        "AB (OB 시도)": date_ob_total[date],
        "AE (콜백 등록 = IB_포기호 콜백)": date_aban_callback[date],
        "AH (상담톡 발송)": date_alert_send[date],
        "AI (콜백 OB 처리)": date_aban_callback[date] + date_ob_callback[date],
    }
    
    date_match = True
    msgs = []
    for kpi, exp in expected.items():
        actual = daily_vals[kpi]
        if actual != exp:
            msgs.append(f"❌ {kpi}: {actual} vs {exp}")
            all_match = False
            date_match = False
        else:
            msgs.append(f"✅ {kpi}: {actual}")
    
    if not date_match:
        print(f"\n📅 {date}:")
        for m in msgs:
            print(f"  {m}")
    else:
        print(f"📅 {date}: ✅ 5/5 일치")

print("\n" + "=" * 100)
if all_match:
    print("🎉 추가 KPI 100% 일치!")
else:
    print("⚠️ 불일치")
print("=" * 100)
