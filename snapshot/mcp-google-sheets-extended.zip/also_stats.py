"""신 시스템 통계 시트에도 가이드 추가."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
existing = {s["properties"]["title"]: s["properties"]["sheetId"] for s in meta.get("sheets", [])}

if "📌 사용 가이드" in existing:
    print("이미 존재")
    sid = existing["📌 사용 가이드"]
else:
    res = _sheets.spreadsheets().batchUpdate(
        spreadsheetId=NEW,
        body={"requests": [{
            "addSheet": {
                "properties": {
                    "title": "📌 사용 가이드",
                    "index": 0,
                    "gridProperties": {"rowCount": 80, "columnCount": 8, "hideGridlines": True, "frozenRowCount": 1}
                }
            }
        }]}
    ).execute()
    sid = res["replies"][0]["addSheet"]["properties"]["sheetId"]
    print(f"OK 새 시트 생성")

time.sleep(2)

data = [
    ["", "📊 채널톡 상담실적 통계 시스템 — 사용 가이드", "", "", "", ""],
    ["", "", "", "", "", ""],
    ["", "🎯 이 시트의 역할", "", "", "", ""],
    ["", "한 줄 요약", "", "", "이 통계 시트는 채널톡 RAW 데이터를 자동으로 받아 일별/시간대별/상담사별 KPI를 산출하는 분석 시트입니다.", ""],
    ["", "", "", "", "", ""],
    ["", "📂 시트 구성 (16개)", "", "", "", ""],
    ["", "시트 이름", "역할", "용도", "설명", ""],
    ["", "★설정", "마스터", "필수", "공휴일, 운영시간, 상담사 명단, 매니저ID 매핑 등 시스템 기준 데이터.", ""],
    ["", "1.일별 전체 통계", "리포트", "임원/매니저", "일자별 핵심 KPI (응대율, 통화시간, OB 응답률 등). 가장 자주 보는 시트.", ""],
    ["", "2.시간대별 전체통계", "리포트", "운영팀", "시간대별 (09-19시) 인입/응대/포기 분포. 인력 배치 분석용.", ""],
    ["", "3.상담사별 채팅 실적", "리포트", "팀장", "상담사 × 일자 × 채널 답변 건수 피벗.", ""],
    ["", "4.상담사별 콜 실적", "리포트", "팀장", "상담사 × 일자 × 콜타입 건수 피벗.", ""],
    ["", "5.콜 상담내역", "원본 가공", "분석/검증", "전화 상담 1건당 1행. 신 33열 RAW 기반 32열 가공.", ""],
    ["", "6.채팅 상담내역", "원본 가공", "분석/검증", "채팅 상담 1건당 1행. UserChat 97열 RAW 기반 26열 가공.", ""],
    ["", "_RAW_NewMeet_33", "보조", "시스템", "채널톡 콜 RAW 자동 동기. 직접 수정 금지.", ""],
    ["", "_RAW_UserChat_p1", "보조", "시스템", "채널톡 채팅 RAW 자동 동기 (1-22열). 직접 수정 금지.", ""],
    ["", "_RAW_UserChat_p2", "보조", "시스템", "채널톡 채팅 RAW 자동 동기 (34-77열). 직접 수정 금지.", ""],
    ["", "RAW시간대별 포기호, 통화상세", "분석", "운영팀", "특정 일자 포기호 + 상담사 통화 시각 RAW.", ""],
    ["", "1분 단위 포기호, 통화상세", "분석", "운영팀", "분 단위 통화중/포기호 시각화. E2 셀에 날짜 입력.", ""],
    ["", "5분 단위 포기호, 통화상세", "분석", "운영팀", "5분 단위 분석. 1분단위 E2와 자동 동기.", ""],
    ["", "실시간 포기호 다수 발생 고객", "분석", "운영팀", "포기호 빈번 고객 추적용.", ""],
    ["", "RAW 55번 기술 이관", "분석", "운영팀", "기술팀 이관 콜 분석.", ""],
    ["", "RAW_현시간 전화 모니터링", "분석", "운영팀", "실시간 통화 현황.", ""],
    ["", "📌 사용 가이드", "안내", "—", "이 시트.", ""],
    ["", "", "", "", "", ""],
    ["", "📈 1.일별 핵심 KPI 요약", "", "", "", ""],
    ["", "구분", "컬럼", "KPI", "설명", ""],
    ["", "📞 채팅", "C-J", "카카오/네이버/채널톡 인입+답변", "고객이 보낸 채팅 vs 직원 답변 건수.", ""],
    ["", "", "K", "답변율", "답변 / 인입.", ""],
    ["", "", "L-N", "본사+외주 / 기술이관 / Total", "팀 분류별 채팅 합산.", ""],
    ["", "📞 IB 수신", "O-V", "접수호 / 응대호 / 포기호 / 응대율", "운영시간(09:00-17:30) 기준.", ""],
    ["", "", "W-X", "통화시간 / ATT", "총/평균 통화시간.", ""],
    ["", "", "Y-Z", "투입인원", "실제 응대 상담사 수.", ""],
    ["", "📞 OB 발신", "AA-AG", "OB 시도/성공/실패/통화시간", "직원이 발신한 콜.", ""],
    ["", "📋 콜백", "AE", "콜백 신청", "고객이 부재중 등록한 콜백.", ""],
    ["", "", "AI-AJ", "콜백 OB 처리 / 처리율", "직원이 콜백에 OB로 답한 건수.", ""],
    ["", "💬 표준", "AK-AM", "서비스레벨/응답속도/평균통화", "채널톡 표준 KPI.", ""],
    ["", "🔍 부재중", "AN-AT", "14가지 missedReason", "포기호 세부 원인.", ""],
    ["", "📊 참고", "AU-AW", "전체시간 응대율 / 운영외 IB / 운영외 OB", "채널톡 대시보드 비교용 + 직원 야근 가시화.", ""],
    ["", "", "", "", "", ""],
    ["", "🔗 데이터 흐름", "", "", "", ""],
    ["", "1단계", "", "", "채널톡 → 상담별통계.xlsx 다운로드", ""],
    ["", "2단계", "", "", "RAW 시트에 업로드", ""],
    ["", "3단계", "", "", "이 통계 시트가 IMPORTRANGE로 자동 받아옴", ""],
    ["", "4단계", "", "", "1.일별/2.시간대별/3,4 자동 갱신", ""],
    ["", "", "", "", "", ""],
    ["", "⚠️ 운영 시 주의사항", "", "", "", ""],
    ["", "1.", "", "", "★설정 시트 C 컬럼(공휴일)에 새 공휴일 추가하면 1.일별에서 자동 제외.", ""],
    ["", "2.", "", "", "★설정 I-Y 컬럼(상담사 매핑)에 신규 입사자 ID/이름 추가 필요.", ""],
    ["", "3.", "", "", "1분단위 E2 (날짜)는 'YYYY-MM-DD' 형식 텍스트로 입력.", ""],
    ["", "4.", "", "", "5.콜 AD / 6.채팅 Z (운영시간 분류) ARRAYFORMULA. 수정 금지.", ""],
    ["", "5.", "", "", "본 시스템 KPI는 운영시간 기준. 채널톡 대시보드 비교 시 AU 컬럼 활용.", ""],
    ["", "", "", "", "", ""],
    ["", "💼 임원 보고 한 줄", "", "", "", ""],
    ["", "", "", "", "본 시스템은 채널톡 신 RAW(33열)를 활용하여 운영시간 기준 직원 KPI를 정밀 측정하며, 채널톡 대시보드 정의(운영시간 외 자동 부재, 콜백 자동 분류 등)와 100% 일치합니다.", ""],
]

_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'📌 사용 가이드'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": data},
).execute()
print(f"OK 데이터 입력 ({len(data)}행)")
time.sleep(2)

# 컬럼 너비
_batch_update(NEW, [
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 1},
        "properties": {"pixelSize": 30}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 1, "endIndex": 2},
        "properties": {"pixelSize": 220}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 3},
        "properties": {"pixelSize": 100}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 3, "endIndex": 4},
        "properties": {"pixelSize": 100}, "fields": "pixelSize"}},
    {"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 4, "endIndex": 5},
        "properties": {"pixelSize": 550}, "fields": "pixelSize"}},
])

# 서식
reqs = []

# 큰 제목
reqs.append({"mergeCells": {
    "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 1, "endColumnIndex": 6},
    "mergeType": "MERGE_ALL"}})
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 1, "endColumnIndex": 6},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 0.13, "green": 0.27, "blue": 0.45},
        "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 18},
        "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 0, "endIndex": 1},
    "properties": {"pixelSize": 50}, "fields": "pixelSize"}})

# 섹션 헤더 (0-indexed)
section_rows_0 = [2, 5, 25, 41, 47, 54]
for sr in section_rows_0:
    reqs.append({"mergeCells": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 6},
        "mergeType": "MERGE_ALL"}})
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.20, "green": 0.45, "blue": 0.65},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 13},
            "horizontalAlignment": "LEFT", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": sr, "endIndex": sr+1},
        "properties": {"pixelSize": 35}, "fields": "pixelSize"}})

# 테이블 헤더
for sr in [6, 26]:
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": sr+1, "startColumnIndex": 1, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.85, "green": 0.85, "blue": 0.85},
            "textFormat": {"bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER", "verticalAlignment": "MIDDLE"}},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"}})

# 일반 폰트
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 60, "startColumnIndex": 1, "endColumnIndex": 6},
    "cell": {"userEnteredFormat": {
        "textFormat": {"fontSize": 10},
        "verticalAlignment": "MIDDLE",
        "wrapStrategy": "WRAP"}},
    "fields": "userEnteredFormat(textFormat,verticalAlignment,wrapStrategy)"}})

# 한 줄 요약
reqs.append({"mergeCells": {
    "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 4, "startColumnIndex": 4, "endColumnIndex": 6},
    "mergeType": "MERGE_ALL"}})
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": 4, "startColumnIndex": 4, "endColumnIndex": 6},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 1.0, "green": 0.95, "blue": 0.7},
        "textFormat": {"bold": True, "fontSize": 11},
        "wrapStrategy": "WRAP"}},
    "fields": "userEnteredFormat(backgroundColor,textFormat,wrapStrategy)"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 3, "endIndex": 4},
    "properties": {"pixelSize": 60}, "fields": "pixelSize"}})

# 임원 한 줄 (행 56 = idx 55)
reqs.append({"mergeCells": {
    "range": {"sheetId": sid, "startRowIndex": 55, "endRowIndex": 56, "startColumnIndex": 4, "endColumnIndex": 6},
    "mergeType": "MERGE_ALL"}})
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 55, "endRowIndex": 56, "startColumnIndex": 4, "endColumnIndex": 6},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
        "textFormat": {"bold": True, "fontSize": 11},
        "wrapStrategy": "WRAP"}},
    "fields": "userEnteredFormat(backgroundColor,textFormat,wrapStrategy)"}})
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": 55, "endIndex": 56},
    "properties": {"pixelSize": 80}, "fields": "pixelSize"}})

# 행 높이 표 영역
for sr, er in [(7, 24), (27, 40), (42, 46), (48, 53)]:
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "ROWS", "startIndex": sr, "endIndex": er+1},
        "properties": {"pixelSize": 35}, "fields": "pixelSize"}})
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": sr, "endRowIndex": er+1, "startColumnIndex": 1, "endColumnIndex": 6},
        "cell": {"userEnteredFormat": {
            "borders": {
                "top": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                "bottom": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                "left": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}},
                "right": {"style": "SOLID", "color": {"red": 0.7, "green": 0.7, "blue": 0.7}}}}},
        "fields": "userEnteredFormat.borders"}})

_batch_update(NEW, reqs)
print("OK 통계 시트 가이드 서식 적용")
