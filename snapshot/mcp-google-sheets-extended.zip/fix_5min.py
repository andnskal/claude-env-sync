"""5분단위 시트 — 1분단위와 동일 구조로 재작성. E2 = 1분단위!E2 동기화."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Step 1: E2 동기화 → 1분단위!E2 참조
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E2",
    valueInputOption="USER_ENTERED",
    body={"values": [["='1분 단위 포기호, 통화상세'!E2"]]},
).execute()
print("✅ 5분단위 E2 = 1분단위!E2 동기화")

# Step 2: F3 동적 헤더 (1분단위와 동일)
f3_formula = (
    '=IFERROR(TRANSPOSE(SORT(UNIQUE(FILTER(\'5.콜 상담내역\'!W2:W,'
    '\'5.콜 상담내역\'!W2:W<>"",\'5.콜 상담내역\'!W2:W<>"기타",'
    '\'5.콜 상담내역\'!N2:N=TEXT($E$2,"YYYY-MM-DD"),'
    '(\'5.콜 상담내역\'!Q2:Q="IB_성공")+(\'5.콜 상담내역\'!Q2:Q="OB_성공"))),1,TRUE)),)'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!F3",
    valueInputOption="USER_ENTERED",
    body={"values": [[f3_formula]]},
).execute()
print("✅ 5분단위 F3 동적 헤더")

# Step 3: A4-D4 동일 구조 (5분 간격)
# A4: 날짜, B4: 시간 (5분 간격), C4: 날짜+시간, D4: BYROW COUNTA
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(B4:B="",,$E$2))']]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!B4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(TIME(9,0,0)+SEQUENCE(132,1,0,1)*5/1440)']]},
).execute()  # 132 buckets * 5분 = 660분 (11시간) = 9시-20시
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!C4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=ARRAYFORMULA(IF(B4:B="",,TEXT(A4:A+B4:B,"yyyy-mm-dd hh:mm:ss")))']]},
).execute()
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!D4",
    valueInputOption="USER_ENTERED",
    body={"values": [['=BYROW(F4:T135, LAMBDA(row, IF(COUNTA(row)=0,, COUNTA(row))))']]},
).execute()
print("✅ 5분단위 A4-D4 (5분 간격)")

# Step 4: E4 + F4:T4 - HOUR/MINUTE 비교 (5분 bucket)
def make_5min_formula(raw_a, raw_b):
    """5분 bucket용. A_분 < 일시분+5 AND B_분 >= 일시분."""
    return (
        f'=MAP($C$4:$C$135, LAMBDA(일시, '
        f'IF(ISBLANK(일시),, '
        f'IF(SUMPRODUCT('
        f'IF(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300="",0,'
        f'(LEFT(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300,10)=LEFT(일시,10))*'
        f'((HOUR(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!${raw_a}$3:${raw_a}$300)) < HOUR(일시)*60+MINUTE(일시)+5)*'
        f'((HOUR(\'RAW시간대별 포기호, 통화상세\'!${raw_b}$3:${raw_b}$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!${raw_b}$3:${raw_b}$300)) >= HOUR(일시)*60+MINUTE(일시))'
        f'))>0, "********",)))'
    )

# E4 (포기호)
e4 = make_5min_formula("A", "B")
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E4",
    valueInputOption="USER_ENTERED",
    body={"values": [[e4]]},
).execute()
print(f"✅ 5분단위 E4 (포기호)")

# F4:T4 (15명)
agent_starts = ['C', 'E', 'G', 'I', 'K', 'M', 'O', 'Q', 'S', 'U', 'W', 'Y', 'AA', 'AC', 'AE']
agent_ends   = ['D', 'F', 'H', 'J', 'L', 'N', 'P', 'R', 'T', 'V', 'X', 'Z', 'AB', 'AD', 'AF']
oneminute_letters = ['F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T']

for letter, raw_a, raw_b in zip(oneminute_letters, agent_starts, agent_ends):
    formula = make_5min_formula(raw_a, raw_b)
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'5분 단위 포기호, 통화상세'!{letter}4",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
print(f"✅ 5분단위 F4:T4 (15명)")

# 검증
time.sleep(5)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A4:V40",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[5분단위 9:00~12:00 — 일부 출력]")
print(f"{'행':>4} | {'시간':>6} | {'통화중':>4} | {'포기호':>10} | {'F':>10}")
for ri, row in enumerate(res):
    if not row: continue
    time_str = row[1] if len(row) > 1 else ""
    counta = row[3] if len(row) > 3 else ""
    e = row[4] if len(row) > 4 else ""
    f = row[5] if len(row) > 5 else ""
    print(f"{ri+4:>4} | {time_str:>6} | {counta:>4} | {e:>10} | {f:>10}")
