"""마지막 차이점 수정."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# === 1.일별 A 컬럼: 텍스트 yyyy-mm-dd → yyyy-mm-dd (ddd) ===
# 기존 BYROW에서 d로 비교하므로 텍스트 형식 변경 시 매칭 깨짐.
# 해결: A 수식을 DATE 값으로 변경 + BYROW의 d 비교 시 TEXT 변환 추가.
# 작업량 부담 → 텍스트 그대로 두고, 별도 표시는 B 컬럼에 (ddd 포함)
# B는 이미 요일/공휴일 표시 → 둘 중 하나로.
# 결정: A를 "2026-04-30 (목)" 형식 텍스트로 변경, BYROW에서 LEFT(d,10) 변환.

# 1.일별 A4 수식 변경 (텍스트 출력에 요일 포함)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW,
    range="'1.일별 전체 통계'!A4",
    valueInputOption="USER_ENTERED",
    body={"values": [[
        '=ARRAYFORMULA(IF(SEQUENCE(60,1,0,1)>=0,TEXT(DATE(2026,4,29)+SEQUENCE(60,1,0,1),"yyyy-mm-dd")&" ("&CHOOSE(WEEKDAY(DATE(2026,4,29)+SEQUENCE(60,1,0,1)),"일","월","화","수","목","금","토")&")",))'
    ]]},
).execute()

# 모든 BYROW 수식의 d → LEFT(d,10) 변환 필요
# 그러나 신 시스템 BYROW가 SUMIFS로 시간대별 B 컬럼(날짜 텍스트 yyyy-mm-dd)을 참조.
# A가 "2026-04-30 (목)"이고 시간대별 B가 "2026-04-30"이라면 매칭 안 됨.
# 해결: 시간대별 B (날짜 텍스트변환)도 동일 형식으로 출력.
# 하지만 시간대별 B는 다른 시트 데이터의 키.
# 대안: A 수식을 두 가지 출력 — A는 텍스트 (요일 포함), 그러나 BYROW 매칭 시 LEFT(A,10) 변환

# 모든 BYROW 수식의 d → LEFT(d,10) 변환
# C, D, E, F, G, H 등 다 갱신 필요
import re

def patch_byrow(cell_range, formula):
    # SUMIFS('2.시간대별...!$B:$B,d → SUMIFS('2.시간대별...!$B:$B,LEFT(d,10)
    # 모든 d 매칭을 LEFT(d,10)으로
    new_formula = formula.replace(
        ",d))))", ",LEFT(d,10)))))"
    ).replace(
        "$B:$B,d,", "$B:$B,LEFT(d,10),"
    ).replace(
        "$N:$N,d,", "$N:$N,LEFT(d,10),"
    ).replace(
        "$N:$N=d,", "$N:$N=LEFT(d,10),"
    ).replace(
        "$O:$O,d,", "$O:$O,LEFT(d,10),"
    ).replace(
        "$O:$O=d,", "$O:$O=LEFT(d,10),"
    )
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=cell_range,
        valueInputOption="USER_ENTERED", body={"values": [[new_formula]]},
    ).execute()


# 1.일별 모든 BYROW 셀의 수식 가져와서 갱신
existing = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!C4:AH4",
    valueRenderOption="FORMULA"
).execute().get("values", [[]])[0]

cols = "CDEFGHIJKLMNOPQRSTUVWXYZ"
extra = ["AA","AB","AC","AD","AE","AF","AG","AH"]
all_cols = list(cols) + extra
for col, formula in zip(all_cols, existing):
    if isinstance(formula, str) and formula.startswith("=") and "BYROW" in formula:
        try:
            patch_byrow(f"'1.일별 전체 통계'!{col}4", formula)
        except Exception as e:
            print(f"  ⚠️ {col}: {e}")
print("✅ 1.일별 BYROW 수식의 d → LEFT(d,10) 변환 (날짜 매칭 보정)")

# === 2.시간대별 AG/AI/AK 행2 헤더 ("카카오"/"네이버"/"채널톡") ===
# 현재 병합으로 AG2:AH2 = "카카오"가 되어야 하는데 ""로 비어있음
# 병합 셀의 첫 셀에 텍스트 입력
for col, text in [("AG", "카카오"), ("AI", "네이버"), ("AK", "채널톡")]:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'2.시간대별 전체통계'!{col}2",
        valueInputOption="RAW", body={"values": [[text]]},
    ).execute()
print("✅ 2.시간대별 AG/AI/AK 행2 헤더 텍스트 입력")

# === 열 너비 정확 조정 ===
sid1 = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")
sid2 = _get_sheet_id_by_name(NEW, "2.시간대별 전체통계")
sid5 = _get_sheet_id_by_name(NEW, "5.콜 상담내역")

reqs = []

def w(sid, sc, ec, px):
    reqs.append({
        "updateDimensionProperties": {
            "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": sc, "endIndex": ec},
            "properties": {"pixelSize": px}, "fields": "pixelSize",
        }
    })

# 1.일별 차이 열 너비 (D=89, L=109, T=90, AG=147)
w(sid1, 3, 4, 89)
w(sid1, 11, 12, 109)
w(sid1, 19, 20, 90)
w(sid1, 32, 33, 147)

# 2.시간대별 (기존 정확히)
w(sid2, 0, 1, 82)   # A 일자
w(sid2, 1, 3, 61)   # B,C 날짜텍스트/시간
w(sid2, 3, 4, 65)   # D 투입IB
w(sid2, 4, 5, 55)   # E 투입OB
w(sid2, 5, 6, 52)   # F 투입채팅
w(sid2, 6, 7, 81)   # G
w(sid2, 7, 23, 100) # H-W
w(sid2, 23, 27, 100) # X-AA
w(sid2, 27, 38, 80)  # AB-AL

# 5.콜 (기존)
w(sid5, 4, 5, 162)   # E endedAt
w(sid5, 5, 6, 100)   # F missedReason
w(sid5, 16, 17, 132) # Q 구분
w(sid5, 17, 18, 172) # R callDuration
w(sid5, 18, 19, 154) # S 통화시간
w(sid5, 19, 20, 130) # T 후처리
w(sid5, 20, 21, 159) # U 대기

_batch_update(NEW, reqs)
print(f"✅ 열 너비 {len(reqs)}개 정확 조정")

# === 1.일별 A 컬럼 데이터 형식 (DATE) ===
# A 셀이 텍스트 출력이라 DATE 형식 적용 의미 없음.
# 그러나 일관성 위해 형식만 적용
reqs2 = [{
    "repeatCell": {
        "range": {"sheetId": sid1, "startRowIndex": 3, "endRowIndex": 100, "startColumnIndex": 0, "endColumnIndex": 2},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "DATE", "pattern": 'yyyy"-"mm"-"dd" ("ddd")"'}}},
        "fields": "userEnteredFormat.numberFormat",
    }
}]
_batch_update(NEW, reqs2)
print("✅ 1.일별 A,B 데이터 형식 yyyy-mm-dd (ddd)")

print("\n🎉 마지막 보정 완료")
