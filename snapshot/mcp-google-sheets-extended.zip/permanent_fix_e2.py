"""1분단위 E2 영구 수정 - DATE 서식 + 데이터 검증."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

sid = _get_sheet_id_by_name(NEW, "1분 단위 포기호, 통화상세")

# 1) 텍스트로 입력하여 자동 DATE 인식
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
    valueInputOption="USER_ENTERED",
    body={"values": [["2026-05-08"]]},
).execute()
print("OK E2 텍스트로 입력 (자동 DATE 인식)")

# 2) 데이터 검증 (DATE)
reqs = [
    {
        "setDataValidation": {
            "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2,
                      "startColumnIndex": 4, "endColumnIndex": 5},
            "rule": {
                "condition": {"type": "DATE_IS_VALID"},
                "showCustomUi": True,
                "strict": True,
            }
        }
    },
    # 서식 재적용
    {
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2,
                      "startColumnIndex": 4, "endColumnIndex": 5},
            "cell": {"userEnteredFormat": {
                "numberFormat": {"type": "DATE", "pattern": "yyyy-mm-dd"},
                "backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
                "textFormat": {"bold": True, "fontSize": 11,
                               "foregroundColor": {"red": 0.6, "green": 0.0, "blue": 0.0}},
                "horizontalAlignment": "CENTER",
            }},
            "fields": "userEnteredFormat(numberFormat,backgroundColor,textFormat,horizontalAlignment)",
        }
    }
]
_batch_update(NEW, reqs)
print("OK 데이터 검증 (DATE) 추가 + 서식 재적용")

time.sleep(3)

# 검증
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'1분 단위 포기호, 통화상세'!E2"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue,dataValidation))))"
).execute()
cell = fmt["sheets"][0]["data"][0]["rowData"][0]["values"][0]
ftype = cell.get("userEnteredFormat", {}).get("numberFormat", {}).get("type", "?")
val = cell.get("formattedValue", "?")
dv = cell.get("dataValidation", {}).get("condition", {}).get("type", "?")
print(f"\n[E2 최종]")
print(f"  표시: '{val}'")
print(f"  서식: {ftype}")
print(f"  데이터 검증: {dv}")

# 5분단위 E2 = 1분단위!E2 동기화 확인
res5 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!E2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])
print(f"\n5분단위 E2: '{res5[0][0] if res5 and res5[0] else '?'}'")
