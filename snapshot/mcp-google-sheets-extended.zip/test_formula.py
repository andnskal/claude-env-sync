"""1분단위 E열 수식 디버그 - 왜 09:08에 '********' 가 표시되는지 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 테스트 셀에 단계별 수식 입력 → 결과 확인
# X1, X2, X3, X4 등에 임시 검증 수식
test_formulas = [
    ("X1", '=COUNTA(\'RAW시간대별 포기호, 통화상세\'!A3:A300)'),  # A 데이터 개수
    ("X2", '=COUNTA(\'RAW시간대별 포기호, 통화상세\'!B3:B300)'),  # B 데이터 개수
    ("X3", '=ISNUMBER(\'RAW시간대별 포기호, 통화상세\'!A3)'),    # A3가 숫자인가?
    ("X4", '=ISTEXT(\'RAW시간대별 포기호, 통화상세\'!A3)'),       # A3가 텍스트인가?
    ("X5", '=VALUE(\'RAW시간대별 포기호, 통화상세\'!A3)'),         # VALUE 변환값
    ("X6", '=VALUE(\'RAW시간대별 포기호, 통화상세\'!B3)'),
    ("X7", '=INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!A3))'),  # INT 변환값
    ("X8", '=INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!A3)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!A3)))*1440)'),  # 분
    ("X9", '=INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!B3)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!B3)))*1440)'),
    ("X10", '=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C12)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C12)))*1440)'),  # 09:08 분
    ("X11", '=SUMPRODUCT((INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300))=INT(VALUE(\'1분 단위 포기호, 통화상세\'!C12)))*(INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300)))*1440)<=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C12)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C12)))*1440))*(INT((VALUE(\'RAW시간대별 포기호, 통화상세\'!$B$3:$B$300)-INT(VALUE(\'RAW시간대별 포기호, 통화상세\'!$B$3:$B$300)))*1440)>=INT((VALUE(\'1분 단위 포기호, 통화상세\'!C12)-INT(VALUE(\'1분 단위 포기호, 통화상세\'!C12)))*1440)))'),
]

# 1분단위 시트의 X1:X11에 입력
data = [[v] for _, v in test_formulas]
for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'1분 단위 포기호, 통화상세'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()

# 1초 대기 (수식 평가)
import time; time.sleep(2)

# 결과 읽기
result = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!X1:X11",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 70)
print("수식 디버그 결과")
print("=" * 70)
labels = ["A 개수", "B 개수", "A3 숫자?", "A3 텍스트?", "VALUE(A3)", "VALUE(B3)",
          "INT(VALUE(A3))=날짜시리얼", "A3 분", "B3 분", "C12(09:08) 분", "SUMPRODUCT for C12"]
for i, label in enumerate(labels):
    val = result[i][0] if i < len(result) and result[i] else 'N/A'
    print(f"  X{i+1}: {label} = {val}")
