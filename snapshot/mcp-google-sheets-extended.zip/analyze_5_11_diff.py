"""5/11 박슬기, 정현호 채널톡과 1건씩 차이 원인 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 5/11 데이터
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 4.상담사별 5/11 IB_성공 카운트 확인
res4 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("[4.상담사별 5/11 IB_성공]")
if res4 and len(res4) >= 3:
    dates = res4[0]
    types = res4[1]
    target_col = None
    for ci, (d, t) in enumerate(zip(dates, types)):
        if isinstance(d, str) and d == "2026-05-11" and t == "IB_성공":
            target_col = ci
            break
    if target_col:
        for ri in range(2, len(res4)):
            row = res4[ri]
            if row and len(row) > 1:
                name = row[1]
                val = row[target_col] if target_col < len(row) and isinstance(row[target_col], (int, float)) else 0
                if name and "박슬기" in str(name):
                    print(f"  {name}: {val}건 (채널톡=35)")
                if name and "정현호" in str(name):
                    print(f"  {name}: {val}건 (채널톡=25)")

# CS_박슬기 5/11 IB_성공 콜 모두
print("\n[5/11 CS_박슬기 IB_성공 콜 전체]")
print(f"{'시각':>20} | {'AD':>4} | {'X (tags)':>30}")
print("-" * 70)
parksul = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_박슬기" or row[16] != "IB_성공": continue
    C = row[2]
    AD = row[29]
    X = row[23] if len(row) > 23 else ""
    parksul.append((C, AD, X))

for i, (c, ad, x) in enumerate(parksul):
    print(f"  {c} | {ad} | {str(x)[:30]}")

print(f"\n  총: {len(parksul)}건 (우리 시스템)")
print(f"  채널톡: 35건")
print(f"  차이: {len(parksul) - 35}건")

# CS_정현호 5/11 IB_성공
print("\n[5/11 CS_정현호 IB_성공 콜 전체]")
print(f"{'시각':>20} | {'AD':>4} | {'X (tags)':>30}")
print("-" * 70)
junghyun = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_정현호" or row[16] != "IB_성공": continue
    C = row[2]
    AD = row[29]
    X = row[23] if len(row) > 23 else ""
    junghyun.append((C, AD, X))

for i, (c, ad, x) in enumerate(junghyun):
    print(f"  {c} | {ad} | {str(x)[:30]}")

print(f"\n  총: {len(junghyun)}건 (우리 시스템)")
print(f"  채널톡: 25건")
print(f"  차이: {len(junghyun) - 25}건")

# 분석 — 두 사람의 5/11 콜 시간대 분포
print("\n" + "=" * 80)
print("[원인 추적] 5/11 박슬기, 정현호 콜 중 의심 케이스")
print("=" * 80)

# 11:50-13:00 (예외 점심 직전/직후) 콜이 있는지
# 12:50-14:00 (기본 점심) 영향
# 17시 경계

for name, calls, expected in [("박슬기", parksul, 35), ("정현호", junghyun, 25)]:
    print(f"\n[{name}] - 우리 {len(calls)}건 vs 채널톡 {expected}건")
    print(f"  시간대 분포:")
    from collections import defaultdict
    by_section = defaultdict(int)
    for c, ad, x in calls:
        try:
            h, m = int(c.split(" ")[1].split(":")[0]), int(c.split(" ")[1].split(":")[1])
            tm = h*60+m
        except:
            continue
        if tm < 540: sec = "09시 미만"
        elif tm < 710: sec = "09:00-11:49"
        elif tm < 780: sec = "11:50-12:59 (예외점심)"
        elif tm < 840: sec = "13:00-13:59 (기본 점심?)"
        elif tm < 1050: sec = "14:00-17:29"
        else: sec = "17:30 이후"
        by_section[sec] += 1
    for s, c in sorted(by_section.items()):
        print(f"    {s}: {c}건")
