"""★설정 공휴일 명단 확인 + 5/5 매칭 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# ★설정 C-E (공휴일 입력, 비고, 텍스트변환) 확인
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!C1:E20",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("[★설정 C-E (공휴일 + 비고 + 텍스트변환)]")
for ri, row in enumerate(res):
    if row:
        print(f"  Row {ri+1}: C={row[0] if len(row)>0 else ''} | D={row[1] if len(row)>1 else ''} | E={row[2] if len(row)>2 else ''}")

# 또한 D 컬럼이 텍스트인지 시리얼인지 확인
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'★설정'!C1:E10"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue,userEnteredValue))))"
).execute()
rows = fmt["sheets"][0]["data"][0]["rowData"]
print("\n[★설정 C-E 서식 + raw value]")
for ri, r in enumerate(rows[:8]):
    for ci, cell in enumerate(r.get("values", [])):
        ftype = cell.get("userEnteredFormat", {}).get("numberFormat", {}).get("type", "AUTO")
        val = cell.get("formattedValue", "")
        raw = cell.get("userEnteredValue", {})
        col = chr(ord('C') + ci)
        if val:
            print(f"  {col}{ri+1}: '{val}' / type={ftype} / raw={raw}")

# A6의 출력 (5/5 포함 여부)
print("\n[1.일별 A 컬럼 출력 일자]")
res_a = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:A20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(res_a):
    if r and r[0]:
        print(f"  A{ri+6}: {r[0]}")
