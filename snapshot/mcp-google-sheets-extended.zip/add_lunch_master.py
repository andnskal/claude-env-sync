"""점심시간 마스터 데이터 추가 + AD/Z 수식 업데이트."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Step 1: ★설정에 점심시간 마스터 추가 (Z, AA, AB 컬럼 - 시트 너비 확장)
print("[1] ★설정 시트 컬럼 확장 (Y → AB)")
sid_set = _get_sheet_id_by_name(NEW, "★설정")

# 현재 시트는 26열까지. AB까지 필요 (28열). 확장
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid_set:
        current_cols = s["properties"]["gridProperties"].get("columnCount", 0)
        print(f"  현재 컬럼: {current_cols}")
        if current_cols < 28:
            _batch_update(NEW, [{
                "appendDimension": {
                    "sheetId": sid_set,
                    "dimension": "COLUMNS",
                    "length": 28 - current_cols
                }
            }])
            print(f"  → 28열로 확장")
        break
time.sleep(2)

# Step 2: 점심시간 마스터 헤더 + 기본값 + 예외
print("\n[2] 점심시간 마스터 데이터 입력")

# Z1, AA1, AB1 헤더
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!Z1:AB1",
    valueInputOption="USER_ENTERED",
    body={"values": [["점심시간 예외 일자", "점심 시작", "점심 종료"]]},
).execute()

# 기본값 (행 2)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!Z2:AB2",
    valueInputOption="USER_ENTERED",
    body={"values": [["(기본)", "12:30", "13:30"]]},
).execute()

# 예외 일자 등록 (행 3+)
# 5/11 어제 전산오류로 점심 11:50-13:00 임시 적용
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'★설정'!Z3:AB3",
    valueInputOption="USER_ENTERED",
    body={"values": [["2026-05-11", "11:50", "13:00"]]},
).execute()
print("  Z2:AB2 기본값: 12:30 ~ 13:30")
print("  Z3:AB3 예외 5/11: 11:50 ~ 13:00")

time.sleep(2)

# Step 3: AB 컬럼 (행 2) 헤더 안내 (사용자가 추가 예외 입력 시 가이드)
# 헤더 영역 서식
reqs = [
    # Z1:AB1 헤더 진한 배경
    {"repeatCell": {
        "range": {"sheetId": sid_set, "startRowIndex": 0, "endRowIndex": 1, "startColumnIndex": 25, "endColumnIndex": 28},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 0.95, "green": 0.6, "blue": 0.2},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
    }},
    # Z2:AB2 기본값 색상 (노란색 — 기본값 표시)
    {"repeatCell": {
        "range": {"sheetId": sid_set, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 25, "endColumnIndex": 28},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": 1.0, "green": 0.95, "blue": 0.7},
            "textFormat": {"bold": True, "fontSize": 10},
            "horizontalAlignment": "CENTER",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
    }},
    # 시간 컬럼 (AA, AB) TIME 서식
    {"repeatCell": {
        "range": {"sheetId": sid_set, "startRowIndex": 1, "endRowIndex": 100, "startColumnIndex": 26, "endColumnIndex": 28},
        "cell": {"userEnteredFormat": {"numberFormat": {"type": "TIME", "pattern": "hh:mm"}}},
        "fields": "userEnteredFormat.numberFormat"
    }},
    # 컬럼 너비
    {"updateDimensionProperties": {
        "range": {"sheetId": sid_set, "dimension": "COLUMNS", "startIndex": 25, "endIndex": 28},
        "properties": {"pixelSize": 110}, "fields": "pixelSize"}},
]
_batch_update(NEW, reqs)
print("  서식 적용")

time.sleep(2)

# Step 4: 5.콜 AD 수식 업데이트 — 점심 시간 분리 처리
print("\n[3] 5.콜 AD 수식 업데이트 (점심 시간 제외 로직)")
new_ad = (
    '=ARRAYFORMULA(IF(N2:N="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",X2:X)),"외",'
    'IF('
    # 09:00 - 17:30 안에 있으면서
    '(HOUR(C2:C)*60+MINUTE(C2:C)>=540)*(HOUR(C2:C)*60+MINUTE(C2:C)<1050)*'
    # 점심 시간 외 (점심 시작 미만 OR 점심 종료 이상)
    '((HOUR(C2:C)*60+MINUTE(C2:C)<'
    '(HOUR(IFNA(XLOOKUP(N2:N,\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))*60+'
    'MINUTE(IFNA(XLOOKUP(N2:N,\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))))+'
    '(HOUR(C2:C)*60+MINUTE(C2:C)>='
    '(HOUR(IFNA(XLOOKUP(N2:N,\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2))*60+'
    'MINUTE(IFNA(XLOOKUP(N2:N,\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2)))))'
    ',"내","외"))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5.콜 상담내역'!AD2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_ad]]},
).execute()
print("  5.콜 AD2 업데이트")

# Step 5: 6.채팅 Z 수식 동일 업데이트
print("\n[4] 6.채팅 Z 수식 업데이트")
new_z_chat = (
    '=ARRAYFORMULA(IF(O2:O="",,'
    'IF(ISNUMBER(SEARCH("운영시간아님",K2:K)),"외",'
    'IF('
    '(HOUR(B2:B)*60+MINUTE(B2:B)>=540)*(HOUR(B2:B)*60+MINUTE(B2:B)<1050)*'
    '((HOUR(B2:B)*60+MINUTE(B2:B)<'
    '(HOUR(IFNA(XLOOKUP(O2:O,\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))*60+'
    'MINUTE(IFNA(XLOOKUP(O2:O,\'★설정\'!$Z$3:$Z,\'★설정\'!$AA$3:$AA),\'★설정\'!$AA$2))))+'
    '(HOUR(B2:B)*60+MINUTE(B2:B)>='
    '(HOUR(IFNA(XLOOKUP(O2:O,\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2))*60+'
    'MINUTE(IFNA(XLOOKUP(O2:O,\'★설정\'!$Z$3:$Z,\'★설정\'!$AB$3:$AB),\'★설정\'!$AB$2)))))'
    ',"내","외"))))'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!Z2",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_z_chat]]},
).execute()
print("  6.채팅 Z2 업데이트")

time.sleep(8)

# Step 6: 검증
print("\n[5] 검증")

# 5/8 점심시간 콜 분류 확인 (12:30-13:30 → "외" 되어야)
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

print("\n[5/8 점심시간 (12:30-13:30) 콜 분류 확인]")
print(f"{'시각':>20} | {'구분':>8} | {'AD':>4}")
print("-" * 50)
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h * 60 + m
    except:
        continue
    if 750 <= tm < 810:  # 12:30 - 13:30
        print(f"  {C} | {row[16]:>8} | {row[29]:>4}")

# 5/11 예외 점심시간 (11:50-13:00) 콜 분류 확인
print("\n[5/11 예외 점심시간 (11:50-13:00) 콜 분류 확인]")
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h * 60 + m
    except:
        continue
    if 710 <= tm < 780:  # 11:50 - 13:00
        print(f"  {C} | {row[16]:>8} | {row[29]:>4}")

# 운영시간 (09:00-17:30) 외 점심 외에는 정상 "내"인지
print("\n[5/8 정상 운영시간 콜 샘플 (점심 외)]")
cnt = 0
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-08": continue
    C = row[2]
    if " " not in C: continue
    try:
        h, m = int(C.split(" ")[1].split(":")[0]), int(C.split(" ")[1].split(":")[1])
        tm = h * 60 + m
    except:
        continue
    if (540 <= tm < 750) or (810 <= tm < 1050):  # 운영시간 내, 점심 외
        cnt += 1
        if cnt <= 3:
            print(f"  {C} | {row[16]:>8} | {row[29]:>4}")
print(f"  ... 총 {cnt}건 운영시간 내 (점심 외)")
