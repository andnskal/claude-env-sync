"""모든 시트의 헤더, 행 1-2 수식 추출 - 프로그램 명세서용."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()

all_specs = {}
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = p["gridProperties"].get("rowCount", 0)
    cols = p["gridProperties"].get("columnCount", 0)
    if rows == 0 or cols == 0 or name == "📌 사용 가이드": continue
    
    # 헤더 (행 1-3) + 수식 (행 2, 4, 6 등)
    rng = f"'{name}'!A1:{col_letter(min(cols, 100)-1)}10"
    try:
        vals = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
    except: continue
    
    all_specs[name] = {
        "rows": rows,
        "cols": cols,
        "headers": [],
        "formulas": {},
    }
    
    # 헤더 추출 (행 1-3)
    for ri in range(min(3, len(vals))):
        for ci, v in enumerate(vals[ri]):
            if v:
                col = col_letter(ci)
                all_specs[name]["headers"].append((f"{col}{ri+1}", v))
    
    # 수식 추출 (모든 셀)
    for ri, row in enumerate(formulas):
        for ci, v in enumerate(row):
            if v and isinstance(v, str) and v.startswith("="):
                col = col_letter(ci)
                all_specs[name]["formulas"][f"{col}{ri+1}"] = v

# JSON 출력
with open("sheet_specs.json", "w", encoding="utf-8") as f:
    json.dump(all_specs, f, ensure_ascii=False, indent=2)

# 요약
print("=" * 80)
print(f"전체 시트: {len(all_specs)}")
for name, spec in all_specs.items():
    print(f"\n{name}: {spec['rows']}행 × {spec['cols']}열")
    print(f"  헤더: {len(spec['headers'])}개")
    print(f"  수식 셀: {len(spec['formulas'])}개")
