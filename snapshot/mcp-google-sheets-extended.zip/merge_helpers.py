"""두 보조 채팅 시트를 RAW_UserChat 하나로 통합."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# Step 1: _보조 채팅 A → RAW_UserChat로 이름 변경
sid_a = _get_sheet_id_by_name(NEW, "_보조 채팅 A")
sid_b = _get_sheet_id_by_name(NEW, "_보조 채팅 B")
sid_call = _get_sheet_id_by_name(NEW, "_보조 콜")

_batch_update(NEW, [
    {"updateSheetProperties": {
        "properties": {"sheetId": sid_a, "title": "RAW_UserChat"},
        "fields": "title"}},
    {"updateSheetProperties": {
        "properties": {"sheetId": sid_call, "title": "RAW_NewMeet"},
        "fields": "title"}},
])
print("OK 이름 변경:")
print("  _보조 채팅 A → RAW_UserChat")
print("  _보조 콜 → RAW_NewMeet")
time.sleep(2)

# Step 2: RAW_UserChat A1 수식을 전체 97열로 변경
new_formula = '=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat!A1:CS")'
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": [[new_formula]]},
).execute()
print(f"\nOK RAW_UserChat A1: A1:CS 전체 97열 IMPORTRANGE")
time.sleep(8)  # IMPORTRANGE 로딩 대기

# Step 3: 6.채팅의 _보조 채팅 B 참조를 RAW_UserChat로 변경 + 컬럼 시프트 (+33)
# _보조 채팅 B의 A=원본 AH (33+1=34, +33 시프트)
# 컬럼 시프트 매핑: B 컬럼 인덱스 X → RAW_UserChat 인덱스 X+33
def shift_col(col):
    """A → AH 같이 +33 컬럼 시프트."""
    # col 문자 → 인덱스
    idx = 0
    for c in col:
        idx = idx * 26 + (ord(c) - ord('A') + 1)
    new_idx = idx + 33
    # 인덱스 → 문자
    s = ""
    n = new_idx
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

# 6.채팅 행 2 수식 모두 가져오기
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])

import re
updates = []
if res and res[0]:
    for ci, v in enumerate(res[0]):
        if v and isinstance(v, str) and "_보조 채팅 B" in v:
            # _보조 채팅 B!XCOL2:XCOL → RAW_UserChat!SHIFTED2:SHIFTED
            def replacer(match):
                col = match.group(1)
                shifted = shift_col(col)
                return f"RAW_UserChat'!{shifted}2:{shifted}"
            new_v = re.sub(r"_보조 채팅 B'!([A-Z]+)2:[A-Z]+", replacer, v)
            new_v = new_v.replace("'_보조 채팅 B'", "'RAW_UserChat'")  # 마지막 단순 치환 안전망
            # ' 부호 처리: 원본 형태 '_보조 채팅 B'! → 'RAW_UserChat'! (위 replacer는 이미 처리)
            # 직접 다시 처리
            new_v_safe = re.sub(r"'_보조 채팅 B'!([A-Z]+)2:([A-Z]+)",
                                lambda m: f"'RAW_UserChat'!{shift_col(m.group(1))}2:{shift_col(m.group(2))}",
                                v)
            col_letter_disp = chr(ord('A') + ci) if ci < 26 else 'AA'
            updates.append((col_letter_disp, new_v_safe))
            print(f"  {col_letter_disp}2: {v[:80]}")
            print(f"      → {new_v_safe[:80]}")

# 적용
for col, new_v in updates:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'6.채팅 상담내역'!{col}2",
        valueInputOption="USER_ENTERED",
        body={"values": [[new_v]]},
    ).execute()
print(f"\nOK 6.채팅 시트 {len(updates)}개 수식 시프트 + 이름 변경")
time.sleep(3)

# Step 4: _보조 채팅 B 시트 삭제
_batch_update(NEW, [{
    "deleteSheet": {"sheetId": sid_b}
}])
print("\nOK _보조 채팅 B 시트 삭제")
time.sleep(3)

# Step 5: 검증
print("\n" + "=" * 80)
print("[검증]")
print("=" * 80)

# 6.채팅 행 5 데이터 (5/8 데이터 있는 부분)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z6",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    print(f"  Row {ri+2}: {row[:7]}...")

# 1.일별 5/8 KPI 검증
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"\n  5/8 P (응대호): {row[15]}")
        print(f"  5/8 H (채널톡 답변): {row[7]}")
        print(f"  5/8 AC (OB 성공): {row[28]}")
        break
