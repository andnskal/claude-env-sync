"""콜백 정의 수정 - AI = OB + 콜백대상 태그만."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 AI6: OB 성공 + X에 "콜백" 태그 (본사+외주, 운영시간 내)
ai_formula = (
    '=BYROW(A6:A,LAMBDA(d,IF(d="",,'
    "COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$X:$X," + '"*콜백*"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"본사"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + ")"
    "+COUNTIFS('5.콜 상담내역'!$N:$N,LEFT(d,10),"
    "'5.콜 상담내역'!$Q:$Q," + '"OB_성공"' + ","
    "'5.콜 상담내역'!$X:$X," + '"*콜백*"' + ","
    "'5.콜 상담내역'!$AC:$AC," + '"외주 고객센터"' + ","
    "'5.콜 상담내역'!$AD:$AD," + '"내"' + "))))"
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AI6",
    valueInputOption="USER_ENTERED",
    body={"values": [[ai_formula]]},
).execute()
print("OK AI6 수정 — OB_성공 + 콜백대상 태그 (본사+외주, 운영시간 내)")

# 2.시간대별 V도 동일 정의로 변경 검토:
# V (콜백 — 시간대별)는 시간대별 콜백 신청 (IB_포기호+콜백). 사용자 정의는 OB+콜백.
# V4 의미: "콜백 신청" 그대로 유지 (이게 1.일별 AE의 source)
# 또한 V를 OB+콜백으로 변경하면 의미 충돌. 현재 V = 콜백 신청 유지.

# 1.일별 AE6 = SUMIFS(V) = 콜백 등록 신청. 현재 그대로 유지.
# AI는 OB 콜백 처리. AE-AI 차이 = 미처리 콜백.

# AJ6 (콜백 처리율) = AI/AE 의미 = 신청 대비 처리. 그대로 유지.

# 2.시간대별 V4 헤더 의미 명확히: "콜백 신청 (IB_포기호+콜백)"
# (변경 없음, 이미 그렇게 정의됨)

time.sleep(5)

# 검증
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 콜백 KPI 재검증]")
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    AE = row[30] if len(row) > 30 else "?"  # 콜백 등록 (신청)
    AI = row[34] if len(row) > 34 else "?"  # 콜백 OB 처리
    AJ = row[35] if len(row) > 35 else "?"  # 콜백 처리율
    AC = row[28] if len(row) > 28 else "?"  # OB 성공
    AD = row[29] if len(row) > 29 else "?"  # OB(콜백제외)
    print(f"  {date}:")
    print(f"    AE 콜백 신청 (IB부재중+콜백): {AE}")
    print(f"    AI 콜백 OB 처리 (OB성공+콜백): {AI}")
    print(f"    AJ 콜백 처리율 (AI/AE): {AJ if not isinstance(AJ, float) else f'{AJ*100:.1f}%'}")
    print(f"    AC OB 성공: {AC}")
    print(f"    AD OB(콜백제외) = AC - AI: {AD}")
