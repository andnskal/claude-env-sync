"""시간 관련 KPI 검증 - W (IB 통화시간), X (ATT), AF (OB 통화시간), AG (OB ATT), AM (전체 평균)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 모든 데이터 + S (통화시간 초)
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# S 컬럼 (통화시간 - 시리얼 값) 별도
all_s_serial = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!S2:S3500",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict

date_ib_call_total = defaultdict(float)  # IB 통화시간 합 (초)
date_ib_count = defaultdict(int)
date_ob_call_total = defaultdict(float)
date_ob_count = defaultdict(int)

for ri, row in enumerate(all_calls):
    if len(row) > 29:
        N = row[13] if len(row) > 13 else ""
        Q = row[16] if len(row) > 16 else ""
        AD = row[29] if len(row) > 29 else ""
        AC = row[28] if len(row) > 28 else ""
        if not N or AD != "내": continue
        s_ser = all_s_serial[ri][0] if ri < len(all_s_serial) and all_s_serial[ri] else 0
        if not isinstance(s_ser, (int, float)): s_ser = 0
        s_sec = s_ser * 86400  # 시리얼 → 초
        if Q == "IB_성공":
            date_ib_call_total[N] += s_sec
            date_ib_count[N] += 1
        elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
            date_ob_call_total[N] += s_sec
            date_ob_count[N] += 1

# 1.일별 시간 컬럼
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

print("=" * 100)
print("시간 KPI 검증 (모든 일자)")
print("=" * 100)
print("- W (IB 통화시간 총)")
print("- X (IB ATT - 평균)")
print("- AF (OB 통화시간 총)")
print("- AG (OB ATT - 평균)")
print("- AM (평균 통화시간 IB+OB, 초)")

all_match = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_ib_call_total and date not in date_ob_call_total: continue
    
    # 1.일별 시리얼값 → 초 변환
    W_serial = row[22] if len(row) > 22 else 0
    X_serial = row[23] if len(row) > 23 else 0
    AF_serial = row[31] if len(row) > 31 else 0
    AG_serial = row[32] if len(row) > 32 else 0
    AM_val = row[38] if len(row) > 38 else 0  # AM은 초 단위 정수
    
    W_sec = W_serial * 86400 if isinstance(W_serial, (int, float)) else 0
    X_sec = X_serial * 86400 if isinstance(X_serial, (int, float)) else 0
    AF_sec = AF_serial * 86400 if isinstance(AF_serial, (int, float)) else 0
    AG_sec = AG_serial * 86400 if isinstance(AG_serial, (int, float)) else 0
    
    expected_w = date_ib_call_total[date]
    expected_x = date_ib_call_total[date] / date_ib_count[date] if date_ib_count[date] else 0
    expected_af = date_ob_call_total[date]
    expected_ag = date_ob_call_total[date] / date_ob_count[date] if date_ob_count[date] else 0
    expected_am = (date_ib_call_total[date] + date_ob_call_total[date]) / (date_ib_count[date] + date_ob_count[date]) if (date_ib_count[date] + date_ob_count[date]) else 0
    
    # ±2초 허용 (반올림 오차)
    def m(a, b, tol=2):
        return "✅" if abs(a - b) < tol else "❌"
    
    print(f"\n📅 {date}:")
    print(f"  W IB 통화시간 총: 시트={W_sec:.0f}초, 직접={expected_w:.0f}초 {m(W_sec, expected_w, 5)}")
    print(f"  X IB ATT: 시트={X_sec:.1f}초, 직접={expected_x:.1f}초 {m(X_sec, expected_x, 1)}")
    print(f"  AF OB 통화시간 총: 시트={AF_sec:.0f}초, 직접={expected_af:.0f}초 {m(AF_sec, expected_af, 5)}")
    print(f"  AG OB ATT: 시트={AG_sec:.1f}초, 직접={expected_ag:.1f}초 {m(AG_sec, expected_ag, 1)}")
    print(f"  AM 평균 통화시간: 시트={AM_val:.1f}, 직접={expected_am:.1f} {m(AM_val, expected_am, 1)}")
    
    if abs(W_sec - expected_w) > 5 or abs(X_sec - expected_x) > 1 or abs(AM_val - expected_am) > 1:
        all_match = False

print("\n" + "=" * 100)
if all_match:
    print("🎉 시간 KPI 100% 일치!")
else:
    print("⚠️ 불일치")
print("=" * 100)
