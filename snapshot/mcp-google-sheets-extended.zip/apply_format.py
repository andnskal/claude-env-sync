"""1분단위/5분단위 시각적 서식 적용."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

for sheet_name, max_row in [("1분 단위 포기호, 통화상세", 513), ("5분 단위 포기호, 통화상세", 135)]:
    sid = _get_sheet_id_by_name(NEW, sheet_name)
    reqs = []

    # 1) 헤더 행 (1, 2, 3) 진한 배경
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 3, "startColumnIndex": 0, "endColumnIndex": 32},
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 0.18, "green": 0.27, "blue": 0.4},
                "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 10},
                "horizontalAlignment": "CENTER",
                "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
        }
    })

    # 2) E2 (날짜설정) 강조
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 4, "endColumnIndex": 5},
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
                "textFormat": {"bold": True, "fontSize": 11, "foregroundColor": {"red": 0.6, "green": 0.0, "blue": 0.0}},
                "horizontalAlignment": "CENTER",
            }},
            "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
        }
    })

    # 3) F2:T2 카운트 옅은 회색
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 5, "endColumnIndex": 20},
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 0.85, "green": 0.85, "blue": 0.85},
                "textFormat": {"foregroundColor": {"red": 0.3, "green": 0.3, "blue": 0.3}, "fontSize": 9},
                "horizontalAlignment": "CENTER",
            }},
            "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
        }
    })

    # 4) C2 라벨 강조
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 1, "endRowIndex": 2, "startColumnIndex": 2, "endColumnIndex": 5},
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 0.95, "green": 0.95, "blue": 0.85},
                "textFormat": {"bold": True, "fontSize": 10},
                "horizontalAlignment": "CENTER",
            }},
            "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
        }
    })

    # 5) 데이터 영역 — 작은 글꼴 + 중앙 정렬
    reqs.append({
        "repeatCell": {
            "range": {"sheetId": sid, "startRowIndex": 3, "endRowIndex": max_row, "startColumnIndex": 0, "endColumnIndex": 32},
            "cell": {"userEnteredFormat": {
                "textFormat": {"fontSize": 9},
                "horizontalAlignment": "CENTER",
                "verticalAlignment": "MIDDLE",
            }},
            "fields": "userEnteredFormat(textFormat,horizontalAlignment,verticalAlignment)"
        }
    })

    # 6) 컬럼 너비
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 2},
        "properties": {"pixelSize": 65}, "fields": "pixelSize"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 2, "endIndex": 3},
        "properties": {"pixelSize": 130}, "fields": "pixelSize"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 3, "endIndex": 5},
        "properties": {"pixelSize": 70}, "fields": "pixelSize"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 5, "endIndex": 20},
        "properties": {"pixelSize": 75}, "fields": "pixelSize"}})
    reqs.append({"updateDimensionProperties": {
        "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 21, "endIndex": 22},
        "properties": {"pixelSize": 130}, "fields": "pixelSize"}})

    # 7) Freeze
    reqs.append({"updateSheetProperties": {
        "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": 3, "frozenColumnCount": 5}},
        "fields": "gridProperties.frozenRowCount,gridProperties.frozenColumnCount"}})

    _batch_update(NEW, reqs)

    # 8) 조건부 서식 정리
    sheet_data = _sheets.spreadsheets().get(
        spreadsheetId=NEW, ranges=[f"'{sheet_name}'!A1"], includeGridData=False
    ).execute()
    rules = sheet_data["sheets"][0].get("conditionalFormats", [])
    if rules:
        del_reqs = []
        for ri in range(len(rules)-1, -1, -1):
            del_reqs.append({"deleteConditionalFormatRule": {"sheetId": sid, "index": ri}})
        if del_reqs:
            _batch_update(NEW, del_reqs)

    cf_reqs = [
        {"addConditionalFormatRule": {
            "rule": {
                "ranges": [{"sheetId": sid, "startRowIndex": 3, "endRowIndex": max_row, "startColumnIndex": 4, "endColumnIndex": 5}],
                "booleanRule": {
                    "condition": {"type": "TEXT_CONTAINS", "values": [{"userEnteredValue": "*"}]},
                    "format": {"backgroundColor": {"red": 0.95, "green": 0.4, "blue": 0.4},
                               "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True}}
                }
            }, "index": 0}},
        {"addConditionalFormatRule": {
            "rule": {
                "ranges": [{"sheetId": sid, "startRowIndex": 3, "endRowIndex": max_row, "startColumnIndex": 5, "endColumnIndex": 20}],
                "booleanRule": {
                    "condition": {"type": "TEXT_CONTAINS", "values": [{"userEnteredValue": "*"}]},
                    "format": {"backgroundColor": {"red": 0.6, "green": 0.85, "blue": 1.0},
                               "textFormat": {"foregroundColor": {"red": 0.0, "green": 0.0, "blue": 0.6}, "bold": True}}
                }
            }, "index": 1}},
        {"addConditionalFormatRule": {
            "rule": {
                "ranges": [{"sheetId": sid, "startRowIndex": 3, "endRowIndex": max_row, "startColumnIndex": 3, "endColumnIndex": 4}],
                "booleanRule": {
                    "condition": {"type": "NUMBER_GREATER_THAN_EQ", "values": [{"userEnteredValue": "5"}]},
                    "format": {"backgroundColor": {"red": 1.0, "green": 0.92, "blue": 0.4},
                               "textFormat": {"bold": True}}
                }
            }, "index": 2}},
    ]
    _batch_update(NEW, cf_reqs)
    print(f"OK {sheet_name}: format + conditional format applied")

print("\n전체 서식 적용 완료")
