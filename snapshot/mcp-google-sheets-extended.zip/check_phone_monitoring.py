"""RAW_현시간 전화 모니터링도 같은 방식 참조 검색."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 이전 시트 5.콜 A2 수식 + 다른 시트 참조
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'5.콜 상담내역'!A2",
    valueRenderOption="FORMULA",
).execute().get("values", [[]])
print("[이전 시트 5.콜!A2 수식]")
print(res[0][0] if res and res[0] else "")

# 전체 시트에서 RAW_현시간 전화 모니터링 참조 검색
print("\n" + "=" * 80)
print("RAW_현시간 전화 모니터링 참조 검색")
print("=" * 80)
meta = _sheets.spreadsheets().get(spreadsheetId=OLD).execute()
ref_locations = []
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    if name == "RAW_현시간 전화 모니터링": continue
    rows = min(p["gridProperties"].get("rowCount", 0), 1000)
    cols = min(p["gridProperties"].get("columnCount", 0), 100)
    if rows == 0: continue
    def cl(idx):
        s, n = "", idx + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(ord("A") + r) + s
        return s
    rng = f"'{name}'!A1:{cl(cols-1)}{rows}"
    try:
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=OLD, range=rng,
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        for ri, row in enumerate(formulas):
            for ci, v in enumerate(row):
                if v and isinstance(v, str) and "RAW_현시간" in v:
                    ref_locations.append((name, f"{cl(ci)}{ri+1}", str(v)[:200]))
    except: continue

print(f"발견: {len(ref_locations)}건")
for s, c, f in ref_locations[:5]:
    print(f"\n  📍 {s}!{c}")
    print(f"     {f}")

# 이전 시트 5.콜에서 외주(TCK, CS쉐어링) 데이터 어디서 오는지
print("\n" + "=" * 80)
print("[이전 시트 5.콜 상담사 분포 + 데이터 행 수]")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'5.콜 상담내역'!U2:U",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
from collections import Counter
agents = Counter(r[0] for r in res if r and r[0])
total = sum(agents.values())
print(f"  총 콜 행 수: {total}")
print(f"  상담사 종류: {len(agents)}")
print("  상위 15:")
for ag, cnt in agents.most_common(15):
    print(f"    {ag}: {cnt}")
