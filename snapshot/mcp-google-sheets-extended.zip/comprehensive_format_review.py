"""모든 시트 모든 셀 서식 + 분모 이슈 종합 점검."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

print("=" * 100)
print("전체 시트 분모/서식 종합 점검")
print("=" * 100)

# 1) 1.일별 비율 KPI 모든 일자 검증
print("\n[1.일별 비율 KPI 모든 일자 (R, V, K, AD, AJ, AK, AL)]")
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

issues = []
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    
    # K = J/I (답변율)
    I = row[8] if len(row) > 8 else 0
    J = row[9] if len(row) > 9 else 0
    K = row[10] if len(row) > 10 else 0
    if isinstance(I, (int, float)) and I > 0 and isinstance(J, (int, float)):
        exp_k = J / I
        if isinstance(K, (int, float)) and abs(K - exp_k) > 0.001:
            issues.append((date, "K", K, exp_k))
    
    # R = P/O
    O = row[14] if len(row) > 14 else 0
    P = row[15] if len(row) > 15 else 0
    R = row[17] if len(row) > 17 else 0
    if isinstance(O, (int, float)) and O > 0 and isinstance(P, (int, float)):
        exp_r = P / O
        if isinstance(R, (int, float)) and abs(R - exp_r) > 0.001:
            issues.append((date, "R", R, exp_r))
    
    # V = T/S
    S = row[18] if len(row) > 18 else 0
    T = row[19] if len(row) > 19 else 0
    V = row[21] if len(row) > 21 else 0
    if isinstance(S, (int, float)) and S > 0 and isinstance(T, (int, float)):
        exp_v = T / S
        if isinstance(V, (int, float)) and abs(V - exp_v) > 0.001:
            issues.append((date, "V", V, exp_v))
    
    # AJ = AI/AE
    AE = row[30] if len(row) > 30 else 0
    AI = row[34] if len(row) > 34 else 0
    AJ = row[35] if len(row) > 35 else 0
    if isinstance(AE, (int, float)) and AE > 0 and isinstance(AI, (int, float)):
        exp_aj = AI / AE
        if isinstance(AJ, (int, float)) and abs(AJ - exp_aj) > 0.001:
            issues.append((date, "AJ", AJ, exp_aj))

print(f"  비율 이슈: {len(issues)}개")
for d, k, a, e in issues[:5]:
    print(f"    !!{d} {k}: 시트={a:.4f} 계산={e:.4f}")

# 2) 2.시간대별 비율 KPI
print("\n[2.시간대별 비율 KPI (I, M, S, AA, AD, AF)]")
hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:AL700",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

h_issues = []
for row in hourly:
    if len(row) < 32 or not (isinstance(row[1], str) and "2026" in row[1]): continue
    date = row[1]
    time = row[2]
    
    # I = (G-H)/G 수식 봤듯 I=R/G, R=L (응대호)
    G = row[6] if len(row) > 6 else 0
    R_v = row[17] if len(row) > 17 else 0
    I_v = row[8] if len(row) > 8 else 0
    if isinstance(G, (int, float)) and G > 0 and isinstance(R_v, (int, float)):
        exp_i = R_v / G
        if isinstance(I_v, (int, float)) and abs(I_v - exp_i) > 0.001:
            h_issues.append((date, time, "I", I_v, exp_i))
    
    # AD = AC/AB
    AB = row[27] if len(row) > 27 else 0
    AC = row[28] if len(row) > 28 else 0
    AD = row[29] if len(row) > 29 else 0
    if isinstance(AB, (int, float)) and AB > 0 and isinstance(AC, (int, float)):
        exp_ad = AC / AB
        if isinstance(AD, (int, float)) and abs(AD - exp_ad) > 0.001:
            h_issues.append((date, time, "AD", AD, exp_ad))
    
    # AF = AE/AB
    AE = row[30] if len(row) > 30 else 0
    AF = row[31] if len(row) > 31 else 0
    if isinstance(AB, (int, float)) and AB > 0 and isinstance(AE, (int, float)):
        exp_af = AE / AB
        if isinstance(AF, (int, float)) and abs(AF - exp_af) > 0.001:
            h_issues.append((date, time, "AF", AF, exp_af))
    # AF 100% 초과 케이스 (AE > AB)
    if isinstance(AF, (int, float)) and AF > 1.0:
        h_issues.append((date, time, "AF>100%", AF, AE/AB if AB else "?"))

print(f"  비율 이슈: {len(h_issues)}개")
for d, t, k, a, e in h_issues[:8]:
    print(f"    !!{d} {t} {k}: 시트={a} 계산={e}")

# 3) 시간 서식 점검
print("\n[시간 KPI 표시 검증]")
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'1.일별 전체 통계'!AM6:AM12"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue))))"
).execute()
rows = fmt["sheets"][0]["data"][0]["rowData"]
for ri, r in enumerate(rows):
    if "values" in r and r["values"]:
        c = r["values"][0]
        ftype = c.get("userEnteredFormat", {}).get("numberFormat", {}).get("type", "AUTO")
        val = c.get("formattedValue", "")
        print(f"  AM{ri+6}: '{val}' ({ftype})")
