"""RAW시간대별 시트 서식 적용."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

sid = _get_sheet_id_by_name(NEW, "RAW시간대별 포기호, 통화상세")
reqs = []

# 1) 헤더 (행 1, 2) 진한 배경
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 2, "startColumnIndex": 0, "endColumnIndex": 32},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 0.18, "green": 0.27, "blue": 0.4},
        "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
        "horizontalAlignment": "CENTER",
        "verticalAlignment": "MIDDLE",
    }},
    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment)"
}})

# 2) 첫 번째 컬럼 쌍 (포기호) — A:B 적색 강조
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 2, "startColumnIndex": 0, "endColumnIndex": 2},
    "cell": {"userEnteredFormat": {
        "backgroundColor": {"red": 0.7, "green": 0.2, "blue": 0.2},
        "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
        "horizontalAlignment": "CENTER",
    }},
    "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)"
}})

# 3) 데이터 영역 — 작은 글꼴
reqs.append({"repeatCell": {
    "range": {"sheetId": sid, "startRowIndex": 2, "endRowIndex": 300, "startColumnIndex": 0, "endColumnIndex": 32},
    "cell": {"userEnteredFormat": {
        "textFormat": {"fontSize": 9},
        "horizontalAlignment": "CENTER",
    }},
    "fields": "userEnteredFormat(textFormat,horizontalAlignment)"
}})

# 4) 컬럼 너비
reqs.append({"updateDimensionProperties": {
    "range": {"sheetId": sid, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 32},
    "properties": {"pixelSize": 130}, "fields": "pixelSize"}})

# 5) Freeze 헤더
reqs.append({"updateSheetProperties": {
    "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": 2}},
    "fields": "gridProperties.frozenRowCount"}})

_batch_update(NEW, reqs)
print("OK RAW시간대별 서식 적용")
