"""신 시스템 전체 셀 단위 검증."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 모든 시트 정보
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
SHEETS = [(s["properties"]["title"], s["properties"]["gridProperties"].get("rowCount", 0),
           s["properties"]["gridProperties"].get("columnCount", 0))
          for s in meta.get("sheets", [])]

ERROR_PATTERNS = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")


def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


total_errors = 0
issues = []

for name, rows, cols in SHEETS:
    if name in ("시트1",) or rows == 0:
        continue
    # 검증 범위 — 데이터 있을 만한 영역
    max_check_row = min(rows, 60 if "1.일별" in name else (200 if "시간대" in name else 100))
    max_check_col = min(cols, 50)
    rng = f"'{name}'!A1:{col_letter(max_check_col-1)}{max_check_row}"
    try:
        result = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute()
    except Exception as e:
        issues.append(f"❌ {name}: 읽기 실패 - {e}")
        continue
    values = result.get("values", [])
    sheet_errors = 0
    for ri, row in enumerate(values):
        for ci, cell in enumerate(row):
            if isinstance(cell, str):
                for pattern in ERROR_PATTERNS:
                    if pattern in cell:
                        sheet_errors += 1
                        if sheet_errors <= 5:  # 시트당 5개까지만 표시
                            issues.append(f"❌ {name}!{col_letter(ci)}{ri+1} = {cell[:50]}")
                        break
    total_errors += sheet_errors
    if sheet_errors > 5:
        issues.append(f"  ⚠️ {name}: 총 {sheet_errors}개 에러 셀")
    elif sheet_errors == 0:
        issues.append(f"✅ {name}: 에러 없음 (검증 범위 {len(values)}행 × {max(len(r) for r in values) if values else 0}열)")


print("=" * 70)
print(f"🔍 신 시스템 전체 셀 단위 검증")
print("=" * 70)
print(f"검증 시트: {len([s for s,_,_ in SHEETS if s != '시트1'])}개")
print(f"발견된 에러 셀: {total_errors}개\n")
for issue in issues:
    print(issue)

print("\n" + "=" * 70)
print("📊 시나리오 검증")
print("=" * 70)

# 시나리오 1: 1.일별 IB 응대율 = 응대호/접수호
print("\n[1] 1.일별 IB 응대율 = 응대호 / 접수호 (행6 4/30)")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!O6:R6",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [[]])[0]
if len(res) >= 4:
    O, P, Q, R = res
    expected = P / O if O else 0
    actual = R if isinstance(R, (int, float)) else 0
    print(f"  접수호 O={O}, 응대호 P={P}, 포기호 Q={Q}, 응대율 R={actual:.4f}")
    print(f"  계산 P/O = {expected:.4f}")
    if abs(expected - actual) < 0.001:
        print("  ✅ 일치")
    else:
        print("  ❌ 불일치")

# 시나리오 2: 1.일별 OB 콜백제외 = OB 성공 - 콜백
print("\n[2] 1.일별 OB(콜백제외) = OB 성공 - 콜백 (행6 4/30)")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!AC6:AE6",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [[]])[0]
if len(res) >= 3:
    AC, AD, AE = res
    expected = AC - AE
    print(f"  OB 성공 AC={AC}, OB 콜백제외 AD={AD}, 콜백 AE={AE}")
    print(f"  계산 AC-AE = {expected}")
    if AD == expected:
        print("  ✅ 일치")
    else:
        print("  ❌ 불일치")

# 시나리오 3: 1.일별 합계 = 일별 합산
print("\n[3] 1.일별 합계 (행5) = 행6+ 합산 (P 응대호)")
total_p = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!P5",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [[]])[0]
data_p = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!P6:P100",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
if total_p and total_p[0]:
    total = total_p[0]
    actual_sum = sum(r[0] for r in data_p if r and isinstance(r[0], (int, float)))
    print(f"  합계 P5={total}, 데이터 합산={actual_sum}")
    if total == actual_sum:
        print("  ✅ 일치")
    else:
        print("  ❌ 불일치")

# 시나리오 4: 1.일별 평균 (행4)
print("\n[4] 1.일별 일평균 (행4) = AVG(행6+) (P 응대호)")
avg_p = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!P4",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [[]])[0]
if avg_p and avg_p[0] is not None:
    expected_avg = sum(r[0] for r in data_p if r and isinstance(r[0], (int, float))) / max(1, len([r for r in data_p if r and isinstance(r[0], (int, float))]))
    print(f"  평균 P4={avg_p[0]:.2f}, 계산={expected_avg:.2f}")
    if abs(avg_p[0] - expected_avg) < 1:
        print("  ✅ 일치")
    else:
        print("  ❌ 불일치")

# 시나리오 5: 2.시간대별 한 일자 합산 = 1.일별 해당 일자
print("\n[5] 2.시간대별 4/30 P-Q-R 합산 = 1.일별 4/30 P-Q-R")
hourly = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'2.시간대별 전체통계'!A4:R200",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
target_date = "2026-04-30"
hourly_sum_p, hourly_sum_q, hourly_sum_r = 0, 0, 0
for row in hourly:
    if len(row) > 16 and isinstance(row[1], str) and row[1] == target_date:
        # 시간대별 P, Q, R = 인덱스 15, 16, 17
        if len(row) > 15 and isinstance(row[15], (int, float)):
            hourly_sum_p += row[15]
        if len(row) > 16 and isinstance(row[16], (int, float)):
            hourly_sum_q += row[16]
        if len(row) > 17 and isinstance(row[17], (int, float)):
            hourly_sum_r += row[17]
daily_4_30 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!P6:R6",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [[]])[0]
if len(daily_4_30) >= 3:
    P_d, Q_d, R_d = daily_4_30
    print(f"  2.시간대별 4/30 P 합={hourly_sum_p}, 1.일별 P={P_d}")
    print(f"  2.시간대별 4/30 Q 합={hourly_sum_q}, 1.일별 Q={Q_d}")
    if abs(hourly_sum_p - P_d) <= 1 and abs(hourly_sum_q - Q_d) <= 1:
        print("  ✅ 일치 (시간대별 → 일별 정상 합산)")
    else:
        print("  ❌ 불일치")

# 시나리오 6: 5.콜 IB_성공 카운트 = 6.채팅 mediumType=phone INBOUND 카운트
print("\n[6] 5.콜 4/30 IB_성공 카운트")
call_q = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:N5000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
call_q_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!Q2:Q5000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
ib_succ = 0
for n_row, q_row in zip(call_q, call_q_data):
    n = n_row[0] if n_row else ""
    q = q_row[0] if q_row else ""
    if n == "2026-04-30" and q == "IB_성공":
        ib_succ += 1
print(f"  5.콜 4/30 IB_성공: {ib_succ}건")
print(f"  1.일별 행6 P (응대호) = {P_d}")
if ib_succ == P_d:
    print("  ✅ 일치")
else:
    print(f"  ⚠️ 차이 {abs(ib_succ - P_d)}건")

# 시나리오 7: 3·4 상담사별 합산 검증
print("\n[7] 3.상담사별 채팅 — 4/30 채널톡 답변 합 = 1.일별 4/30 H 채널톡 답변")
chat_pivot = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:Z30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
# 행1 날짜 행에서 4/30 (= 46142) 찾고 그 다음 채널톡 컬럼 (4번째: 카카오/네이버/채널톡/기술이관)
header_dates = chat_pivot[0] if chat_pivot else []
header_channels = chat_pivot[1] if len(chat_pivot) > 1 else []
target_date_serial = 46142  # 4/30
sum_chat_4_30 = 0
for ci, (d, ch) in enumerate(zip(header_dates, header_channels)):
    if d == target_date_serial and ch == "채널톡":
        # 모든 상담사 행의 합
        for ri in range(2, len(chat_pivot)):
            row = chat_pivot[ri]
            if ci < len(row) and isinstance(row[ci], (int, float)):
                sum_chat_4_30 += row[ci]
        break
H_d = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!H6",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [[]])[0]
print(f"  3.상담사별 4/30 채널톡 답변 합 = {sum_chat_4_30}")
print(f"  1.일별 H6 (채널톡 답변) = {H_d[0] if H_d else 'N/A'}")
if H_d and sum_chat_4_30 == H_d[0]:
    print("  ✅ 일치")
else:
    print(f"  ⚠️ 차이 ({sum_chat_4_30} vs {H_d[0] if H_d else 'N/A'})")

# 시나리오 8: ★설정 인하우스/외주 명단
print("\n[8] ★설정 X (본사 명단), Y (외주 명단)")
settings_data = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!I2:Y16",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
nat = []
ext = []
for row in settings_data:
    if len(row) >= 2:
        name, team = row[0], row[1] if len(row) > 1 else ""
        if name and team in ("본사", "기술"):
            nat.append(name)
        elif name and team == "외주 고객센터":
            ext.append(name)
print(f"  본사: {len(nat)}명 - {nat[:5]}")
print(f"  외주: {len(ext)}명 - {ext[:5]}")
print(f"  ✅ 분류 정상" if nat and ext else "  ⚠️ 분류 데이터 없음")
