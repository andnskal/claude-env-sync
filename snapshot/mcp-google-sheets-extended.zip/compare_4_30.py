"""이전 시트 vs 신 시스템 4/30 데이터 비교."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 이전 시트 시트 목록 확인
try:
    meta_old = _sheets.spreadsheets().get(spreadsheetId=OLD).execute()
    print("[이전 시트 시트 목록]")
    for s in meta_old.get("sheets", []):
        p = s["properties"]
        print(f"  - {p['title']}")
except Exception as e:
    print(f"이전 시트 접근 오류: {e}")
    sys.exit(1)

# 신 시스템 시트 목록
print("\n[신 시스템 시트 목록]")
meta_new = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta_new.get("sheets", []):
    p = s["properties"]
    print(f"  - {p['title']}")
