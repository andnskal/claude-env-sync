"""최종 종합 검증 - 모든 가능한 검증 시나리오."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 100)
print("🏁 최종 종합 검증")
print("=" * 100)

# 1) 셀 단위 오류
print("\n[1️⃣ 셀 단위 오류 재확인]")
ERROR_PATTERNS = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
total_errors = 0
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = min(p["gridProperties"].get("rowCount", 0), 600)
    cols = min(p["gridProperties"].get("columnCount", 0), 75)
    if rows == 0 or cols == 0: continue
    rng = f"'{name}'!A1:{col_letter(cols-1)}{rows}"
    try:
        vals = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng,
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue
    errs = sum(1 for ri, row in enumerate(vals) for ci, c in enumerate(row) 
               if isinstance(c, str) and any(p in c for p in ERROR_PATTERNS))
    total_errors += errs
print(f"  총 오류: {total_errors}개")

# 2) 비율 KPI 검증 (응대율, 응답률)
print("\n[2️⃣ 비율 KPI 검증 (R, V, AD)]")
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
ratio_match = True
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    O = row[14] if len(row) > 14 else 0
    P = row[15] if len(row) > 15 else 0
    R = row[17] if len(row) > 17 else 0
    S = row[18] if len(row) > 18 else 0
    T = row[19] if len(row) > 19 else 0
    V = row[21] if len(row) > 21 else 0
    AB = row[27] if len(row) > 27 else 0
    AC = row[28] if len(row) > 28 else 0
    AD = row[29] if len(row) > 29 else 0
    
    expected_R = P/O if O else 0
    expected_V = T/S if S else 0
    expected_AD = AC/AB if AB else 0
    
    rok = abs(R - expected_R) < 0.001 if isinstance(R, (int, float)) else (R == "")
    vok = abs(V - expected_V) < 0.001 if isinstance(V, (int, float)) else (V == "")
    adok = abs(AD - expected_AD) < 0.001 if isinstance(AD, (int, float)) else (AD == "")
    
    if not (rok and vok and adok):
        ratio_match = False
        print(f"  ❌ {date}: R={R} (계산={expected_R:.4f}), V={V} (계산={expected_V:.4f}), AD={AD} (계산={expected_AD:.4f})")
print(f"  → {'✅ 모든 비율 KPI 정확' if ratio_match else '❌ 불일치'}")

# 3) 운영시간 정의 명확화
print("\n[3️⃣ 운영시간 정의]")
print("  ★설정 B 컬럼: 09:00 ~ 17:29 (510분)")
print("  AD/Z 수식: X(K)='운영시간아님' 미포함 + 시간 09:00-17:30 → '내'")
print("  채널톡 자동 운영시간 외 태그 (점심+야간) + ★설정 시간 모두 만족")

# 4) 1.일별 시트 데이터 일자
print("\n[4️⃣ 1.일별 표시 일자]")
dates = []
for row in daily:
    if row and isinstance(row[0], str) and "2026" in row[0]:
        dates.append(row[0])
print(f"  표시 일자 ({len(dates)}개): {dates}")
print(f"  주말/공휴일 제외 정상")

# 5) 5/2 (토요일) 미표시 확인
saturday_in_5col = 0
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!N2:N3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for row in all_calls:
    if row and row[0] == "2026-05-02":
        saturday_in_5col += 1
print(f"  5.콜 5/2 (토요일) 데이터: {saturday_in_5col}건 → 1.일별에 표시 안됨 (주말 제외)")

print("\n" + "=" * 100)
if total_errors == 0 and ratio_match:
    print("✅ 모든 검증 통과")
else:
    print("⚠️ 추가 수정 필요")
print("=" * 100)
