"""최종 상태 - 큰 그룹 1개 유지 + 카테고리 색상 강화."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 큰 그룹 (C-AW depth 1) 유지 - 한번에 토글하고 싶을 때 유용
print("[현재 상태]")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
).execute()
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        for g in s.get("columnGroups", []):
            r = g["range"]
            print(f"  그룹 depth {g.get('depth',0)}: col {r['startIndex']}-{r['endIndex']-1}")
        break

# 카테고리별 색상 강화 (서식)
print("\n[카테고리별 헤더 색상 적용]")
group_colors = [
    (0, 2, (0.4, 0.5, 0.6), "날짜/구분"),
    (2, 11, (0.20, 0.55, 0.55), "채팅 전체"),
    (11, 14, (0.30, 0.65, 0.65), "채팅 합계"),
    (14, 26, (0.20, 0.40, 0.65), "IB"),
    (26, 33, (0.45, 0.40, 0.65), "OB"),
    (33, 34, (0.65, 0.55, 0.40), "상담톡"),
    (34, 36, (0.85, 0.78, 0.55), "콜백"),
    (36, 39, (0.85, 0.55, 0.40), "KPI"),
    (39, 46, (0.80, 0.40, 0.40), "부재중사유"),
    (46, 49, (0.55, 0.55, 0.55), "참고 (전체시간)"),
]
reqs = []
for start, end, (r, g, b), label in group_colors:
    reqs.append({"repeatCell": {
        "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 3, "startColumnIndex": start, "endColumnIndex": end},
        "cell": {"userEnteredFormat": {
            "backgroundColor": {"red": r, "green": g, "blue": b},
            "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1}, "bold": True, "fontSize": 9},
            "horizontalAlignment": "CENTER",
            "verticalAlignment": "MIDDLE",
            "wrapStrategy": "WRAP",
        }},
        "fields": "userEnteredFormat(backgroundColor,textFormat,horizontalAlignment,verticalAlignment,wrapStrategy)"
    }})

_batch_update(NEW, reqs)
print(f"OK 10개 카테고리 색상 적용")
