"""5분단위 포기호 시트 확인."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5분 단위 포기호 시트의 모든 셀 확인
formulas = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A1:Z30",
    valueRenderOption="FORMULA",
).execute().get("values", [])
values = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!A1:Z30",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("5분단위 포기호 시트 — 수식 + 값 (A1:Z30)")
for ri, row in enumerate(formulas):
    for ci, cell in enumerate(row):
        if cell:
            v = values[ri][ci] if ri < len(values) and ci < len(values[ri]) else ""
            col = col_letter(ci)
            print(f"  {col}{ri+1}: 수식={str(cell)[:80]} / 값={str(v)[:40]}")
