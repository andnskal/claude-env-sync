"""모든 변경 후 종합 재검증."""
import os, sys, time, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 100)
print("종합 재검증")
print("=" * 100)
issues = []

# 1. 셀 오류
print("\n[1] 셀 오류")
ERR = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = p["gridProperties"].get("rowCount", 0)
    cols = p["gridProperties"].get("columnCount", 0)
    if rows == 0: continue
    rng = f"'{name}'!A1:{col_letter(cols-1)}{min(rows, 600)}"
    try:
        v = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng, valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue
    err = []
    for ri, row in enumerate(v):
        for ci, c in enumerate(row):
            if isinstance(c, str):
                for ptn in ERR:
                    if ptn in c:
                        err.append(f"{col_letter(ci)}{ri+1}={ptn}")
                        break
    if err:
        issues.append(f"오류:{name} {len(err)}건")
        print(f"  ❌ {name}: {len(err)}건 - {err[:3]}")
print(f"  → 오류 시트: {sum(1 for i in issues if i.startswith('오류:'))}개")

# 2. 직접 카운트 vs 시트
print("\n[2] 직접 카운트 vs 시트")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_p = defaultdict(int)
date_q = defaultdict(int)
date_ac = defaultdict(int)
date_h = defaultdict(int)
for row in all_calls:
    if len(row) > 29:
        N, Q, Y, AC, AD = row[13], row[16], row[24], row[28], row[29]
        if not N or AD != "내": continue
        if Q == "IB_성공": date_p[N] += 1
        elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"): date_ac[N] += 1
        elif Q == "IB_포기호" and Y != "알림톡발송": date_q[N] += 1

for row in all_chats:
    if len(row) > 25:
        O, M, Y, Z = row[14], row[12], row[24], row[25]
        if O and Z == "내" and Y == "Y" and M == "채널톡":
            date_h[O] += 1

daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
total = m = 0
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    for ci, key, exp_d in [(15, "P", date_p), (16, "Q", date_q), (28, "AC", date_ac), (7, "H", date_h)]:
        actual = row[ci] if len(row) > ci else 0
        expected = exp_d.get(date, 0)
        total += 1
        if actual == expected: m += 1
        else: issues.append(f"불일치:{date} {key}={actual} vs {expected}")
print(f"  → 일치: {m}/{total}")

# 3. 자동확장
print("\n[3] 자동확장")
checks = [
    ("RAW_UserChat", "A2:A", "AH2:AH"),
    ("5.콜 상담내역", "A2:A", "AD2:AD"),
    ("6.채팅 상담내역", "A2:A", "Z2:Z"),
    ("RAW 55번 기술 이관", "A2:A", "R2:R"),
]
for sheet, src, target in checks:
    src_v = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{src}",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    tgt_v = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{target}",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    src_c = sum(1 for r in src_v if r and r[0])
    tgt_c = sum(1 for r in tgt_v if r and r[0])
    print(f"  {sheet}: src={src_c} target={tgt_c}")
    if abs(src_c - tgt_c) > 5:
        issues.append(f"확장불일치:{sheet} {src_c}vs{tgt_c}")

# 4. M (기술이관) 검증
print("\n[4] M 기술이관 5/8 직접 카운트")
all_55 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW 55번 기술 이관'!K2:R10000",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
date_m = defaultdict(int)
for row in all_55:
    if len(row) > 7:
        K = row[0]
        M_date = row[2] if len(row) > 2 else ""
        N_op = row[3] if len(row) > 3 else ""
        R_cls = row[7] if len(row) > 7 else ""
        if K != "기술이관" or N_op != "내": continue
        if R_cls in ("외주_채팅", "외주_비채팅", "본사_비채팅"):
            date_m[M_date] += 1

date_chat_m = defaultdict(int)
for row in all_chats:
    if len(row) > 25:
        O, M, Y, Z = row[14], row[12], row[24], row[25]
        if O and Z == "내" and Y == "Y" and M == "기술이관":
            date_chat_m[O] += 1

m_match = 0
m_total = 0
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date < "2026-04-30": continue
    chat_m = date_chat_m.get(date, 0)
    rule_m = date_m.get(date, 0)
    total_m = chat_m + rule_m
    sheet_m = row[12] if len(row) > 12 else 0
    m_total += 1
    if sheet_m == total_m:
        m_match += 1
        print(f"  ✅ {date}: 계산={total_m} 시트={sheet_m}")
    else:
        issues.append(f"M불일치:{date} 계산={total_m} 시트={sheet_m}")
        print(f"  ❌ {date}: 계산={total_m} 시트={sheet_m}")

# 5. 1분/5분 단위 동기
print("\n[5] 1분/5분단위 동기")
e2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])
e2_val = e2[0][0] if e2 and e2[0] else "?"
raw = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
raw_cnt = sum(1 for r in raw if r and r[0])
daily_u = "?"
for row in daily:
    if row and row[0] == e2_val:
        daily_u = row[20] if len(row) > 20 else "?"
        break
print(f"  E2={e2_val}, RAW={raw_cnt}, U={daily_u}")
if raw_cnt != daily_u:
    issues.append(f"1분단위:{e2_val}={raw_cnt}vs{daily_u}")

# 6. 디버깅 잔재
print("\n[6] 디버깅 잔재")
잔재 = [
    ("1.일별 전체 통계", "AY1:BD200"),
    ("1분 단위 포기호, 통화상세", "W1:Z1000"),
    ("5분 단위 포기호, 통화상세", "W1:Z1000"),
]
for sheet, rng in 잔재:
    try:
        res = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=f"'{sheet}'!{rng}",
            valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
        non_empty = sum(1 for row in res for c in row if c)
        if non_empty > 0:
            issues.append(f"잔재:{sheet}={non_empty}")
            print(f"  ⚠️ {sheet}: {non_empty}건")
        else:
            print(f"  ✅ {sheet}: 깨끗")
    except: pass

# 7. 시트 목록
print("\n[7] 시트 목록")
for s in meta.get("sheets", []):
    print(f"  - {s['properties']['title']}")

print("\n" + "=" * 100)
if not issues:
    print("✅ 검증한 모든 영역 정상")
else:
    print(f"⚠️ 발견된 이슈: {len(issues)}건")
    for i in issues[:20]:
        print(f"  - {i}")
print("=" * 100)
