"""COUNTIFS 와일드카드 매칭 디버그."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 임시 셀 (★설정의 빈 영역)에 테스트 수식
tests = [
    ("Z1", '=COUNTIFS(\'RAW 55번 기술 이관\'!$M:$M,"2026-05-08")'),
    ("Z2", '=COUNTIFS(\'RAW 55번 기술 이관\'!$M:$M,"2026-05-08",\'RAW 55번 기술 이관\'!$H:$H,"채팅")'),
    ("Z3", '=COUNTIFS(\'RAW 55번 기술 이관\'!$M:$M,"2026-05-08",\'RAW 55번 기술 이관\'!$H:$H,"채팅",\'RAW 55번 기술 이관\'!$K:$K,"기술이관")'),
    ("Z4", '=COUNTIFS(\'RAW 55번 기술 이관\'!$M:$M,"2026-05-08",\'RAW 55번 기술 이관\'!$H:$H,"채팅",\'RAW 55번 기술 이관\'!$K:$K,"기술이관",\'RAW 55번 기술 이관\'!$J:$J,"TCK_*")'),
    # J에 TCK_ 들어있는지 직접
    ("Z5", '=COUNTIF(\'RAW 55번 기술 이관\'!$J:$J,"TCK_*")'),
    ("Z6", '=COUNTIF(\'RAW 55번 기술 이관\'!$J:$J,"TCK_손성은")'),
    # M 컬럼에 5/8 있는지
    ("Z7", '=COUNTIF(\'RAW 55번 기술 이관\'!$M:$M,"2026-05-08")'),
]

for cell, formula in tests:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'★설정'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(3)

# 결과
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!Z1:Z10",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
labels = ["Z1: 5/8 M 카운트", "Z2: 5/8 + 채팅", "Z3: 5/8 + 채팅 + 기술이관", "Z4: 5/8 + 채팅 + 기술이관 + TCK_*",
          "Z5: 전체 J에 TCK_* 카운트", "Z6: J=TCK_손성은", "Z7: M=2026-05-08"]
for i, lbl in enumerate(labels):
    val = res[i][0] if i < len(res) and res[i] else 'N/A'
    print(f"  {lbl}: {val}")

# 정리
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'★설정'!Z1:Z10"
).execute()
