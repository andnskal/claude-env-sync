"""정말 최종 검사 - E2 변경 없이."""
import os, sys, time, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

def col_letter(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s

print("=" * 100)
print("정말 최종 검사 (E2 영향 없이)")
print("=" * 100)
issues = []

# A. 셀 오류
ERR = ("#REF!", "#ERROR!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
print("\n[A] 셀 오류 (모든 시트)")
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    rows = p["gridProperties"].get("rowCount", 0)
    cols = p["gridProperties"].get("columnCount", 0)
    if rows == 0: continue
    rng = f"'{name}'!A1:{col_letter(cols-1)}{min(rows, 600)}"
    try:
        v = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=rng, valueRenderOption="FORMATTED_VALUE",
        ).execute().get("values", [])
    except: continue
    err = sum(1 for r in v for c in r if isinstance(c, str) and any(p in c for p in ERR))
    if err > 0:
        issues.append(f"A:{name} {err}")
print(f"  -> {sum(1 for i in issues if i.startswith('A:'))}건")

# B. 한정 범위
print("\n[B] 한정 범위")
for sheet, ranges in [
    ("1.일별 전체 통계", ["A4:AT6"]),
    ("2.시간대별 전체통계", ["A4:AL4"]),
]:
    for rng in ranges:
        res = _sheets.spreadsheets().values().get(
            spreadsheetId=NEW, range=f"'{sheet}'!{rng}",
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        for ri, row in enumerate(res):
            for ci, v in enumerate(row):
                if v and isinstance(v, str):
                    pats = re.findall(r":([A-Z]+)(\d+)", v)
                    found = False
                    for p_col, p_num in pats:
                        if int(p_num) < 1000:
                            issues.append(f"B:{sheet}{col_letter(ci)} :{p_col}{p_num}")
                            found = True
                            break
                    if found: break
print(f"  -> {sum(1 for i in issues if i.startswith('B:'))}건")

# C. 디버깅 잔재
print("\n[C] 디버깅 잔재")
잔재 = [
    ("1분 단위 포기호, 통화상세", "W1:Z1000"),
    ("5분 단위 포기호, 통화상세", "W1:Z1000"),
    ("1.일별 전체 통계", "AU1:AX200"),
]
for sheet, rng in 잔재:
    res = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{rng}",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    non_empty = sum(1 for row in res for c in row if c)
    if non_empty > 0:
        issues.append(f"C:{sheet} {non_empty}")
print(f"  -> {sum(1 for i in issues if i.startswith('C:'))}건")

# D. freeze
print("\n[D] freeze")
for s in meta.get("sheets", []):
    p = s["properties"]
    name = p["title"]
    fr = p.get("gridProperties", {}).get("frozenRowCount", 0)
    if fr == 0:
        issues.append(f"D:{name}")
print(f"  -> {sum(1 for i in issues if i.startswith('D:'))}건")

# E. KPI
print("\n[E] KPI 일치")
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
all_chats = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

from collections import defaultdict
date_counts = defaultdict(lambda: defaultdict(int))
for row in all_calls:
    if len(row) > 29:
        N, Q, Y, Z, X, AC, AD = row[13], row[16], row[24], row[25], row[23], row[28], row[29]
        if not N or AD != "내": continue
        if Q == "IB_성공": date_counts[N]["P"] += 1
        elif Q == "OB_성공" and AC in ("본사", "외주 고객센터"):
            date_counts[N]["AC"] += 1
            if "콜백" in X: date_counts[N]["AI"] += 1
        elif Q == "IB_포기호":
            if Y != "알림톡발송":
                date_counts[N]["Q"] += 1
                if Z != "기술부재포기호": date_counts[N]["U"] += 1
            if Y == "콜백": date_counts[N]["AE"] += 1
        if Y == "알림톡발송": date_counts[N]["AH"] += 1
        if row[1] == "outbound": date_counts[N]["AB"] += 1

for row in all_chats:
    if len(row) > 25:
        O, M, Y, Z = row[14], row[12], row[24], row[25]
        if not O or Z != "내": continue
        if Y == "Y":
            if M == "카카오": date_counts[O]["D"] += 1
            elif M == "네이버": date_counts[O]["F"] += 1
            elif M == "채널톡": date_counts[O]["H"] += 1
            elif M == "기술이관": date_counts[O]["M_chat"] += 1

daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
dmap = {"D":3, "F":5, "H":7, "M_chat":12, "P":15, "Q":16, "U":20,
        "AB":27, "AC":28, "AE":30, "AH":33, "AI":34}
total = m = 0
for row in daily:
    if not row or not isinstance(row[0], str) or "2026" not in row[0]: continue
    date = row[0]
    if date not in date_counts: continue
    for key, idx in dmap.items():
        actual = row[idx] if idx < len(row) else None
        expected = date_counts[date].get(key, 0)
        total += 1
        if actual == expected: m += 1
        else: issues.append(f"E:{date} {key}")
print(f"  -> {m}/{total}")

# F. 1분단위 현재 (E2 변경 없이)
print("\n[F] 1분단위 현재")
e2 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!E2",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [[]])
e2_val = e2[0][0] if e2 and e2[0] else "?"
raw = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW시간대별 포기호, 통화상세'!A3:A300",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
raw_cnt = sum(1 for r in raw if r and r[0])
daily_u = None
for row in daily:
    if row and isinstance(row[0], str) and row[0] == e2_val:
        daily_u = row[20] if len(row) > 20 else None
        break
match = raw_cnt == daily_u if daily_u is not None else False
if not match:
    issues.append(f"F:{e2_val}={raw_cnt}vs{daily_u}")
print(f"  E2={e2_val}, RAW={raw_cnt}, U={daily_u}")

# G. 운영시간 자동확장
print("\n[G] 운영시간 자동확장")
for sheet, op_col in [("5.콜 상담내역", "AD"), ("6.채팅 상담내역", "Z")]:
    src = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!A2:A3500",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    op = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range=f"'{sheet}'!{op_col}2:{op_col}3500",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    src_cnt = sum(1 for r in src if r and r[0])
    op_cnt = sum(1 for r in op if r and r[0])
    if src_cnt != op_cnt:
        issues.append(f"G:{sheet}")
    print(f"  {sheet}: src={src_cnt} op={op_cnt}")

# H. 공휴일
print("\n[H] 공휴일")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:A20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
dates = [r[0] for r in res if r and r[0]]
holidays = [d for d in dates if d in ("2026-05-01", "2026-05-05")]
if holidays:
    issues.append(f"H:{holidays}")
print(f"  표시: {dates}")

# I. E2 서식
print("\n[I] E2")
for sheet in ["1분 단위 포기호, 통화상세", "5분 단위 포기호, 통화상세"]:
    fmt = _sheets.spreadsheets().get(
        spreadsheetId=NEW, ranges=[f"'{sheet}'!E2"],
        includeGridData=True,
        fields="sheets(data(rowData(values(userEnteredFormat,formattedValue,dataValidation))))"
    ).execute()
    cell = fmt["sheets"][0]["data"][0]["rowData"][0]["values"][0]
    ftype = cell.get("userEnteredFormat", {}).get("numberFormat", {}).get("type", "?")
    val = cell.get("formattedValue", "?")
    dv = "있음" if "dataValidation" in cell else "없음"
    if ftype != "DATE":
        issues.append(f"I:{sheet} 서식")
    print(f"  {sheet}: '{val}' / {ftype} / 검증={dv}")

print("\n" + "=" * 100)
if not issues:
    print(">>> 모든 검사 통과 <<<")
else:
    print(f"이슈 {len(issues)}개:")
    for i in issues[:30]:
        print(f"  - {i}")
print("=" * 100)
