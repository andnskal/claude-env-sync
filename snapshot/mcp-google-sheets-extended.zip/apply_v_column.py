"""V열 (통화 외 시간) 적용 - 레거시 시트 패턴 따라."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 레거시 V4 수식: =(COUNTBLANK(INDEX(F4:Q514,, MATCH(V3, F3:Q3, 0)))-60)/60
# V3에 상담사 이름을 입력하면, 해당 상담사 컬럼의 통화 안한 분 수를 시간으로 반환
# 60을 빼는 것은 60분 (즉 1시간 점심) 제외
# 510분 (9:00~17:30) 운영시간에서 통화 안한 분 = 510 - 통화한 분
# 다만 이 시트는 9:00 ~ 19시 (10시간 = 600분)이지만 510개 분 데이터가 있음

# V열은 분석용 (특정 상담사의 비통화 시간 측정). 1분단위에 적용
# V3에 상담사 이름 (사용자 입력) → V4가 자동 계산

# V4 수식
v4_formula = (
    '=IF(V3="",,'
    '(COUNTBLANK(INDEX(F4:T513,, MATCH(V3, F3:T3, 0)))-60)/60)'
)

# V3 헤더는 "통화 외 시간" 텍스트 그대로 유지하되 위에 V2 자리에 값 입력 가능
# 사용자가 V3에 상담사 이름 입력하면 V4가 계산되도록

# V3 라벨 변경: "상담사 입력" 으로 (사용자가 이름 입력하는 셀)
# 하지만 V2 헤더 = "통화 외 시간" 유지
# V4 = 계산 수식

# V2: "통화 외 시간 (시간)"
# V3: 사용자 입력 셀 (드롭다운으로 상담사 선택 가능하게)
# V4: 계산값

# 기존 V3 = "통화 외 시간" 텍스트 유지하지만, 그래도 활용도 보장위해
# 해당 셀에는 상담사 이름 (드롭다운으로 선택)이 들어오게

# 데이터 검증 (드롭다운) 추가
from server import _get_sheet_id_by_name, _batch_update
sid = _get_sheet_id_by_name(NEW, "1분 단위 포기호, 통화상세")

# V3에 데이터 검증 추가 (상담사 동적 리스트에서 선택)
# 단, 동적 리스트는 F3:T3 → 데이터 검증으로 직접 참조 가능
reqs = [{
    "setDataValidation": {
        "range": {"sheetId": sid, "startRowIndex": 2, "endRowIndex": 3, "startColumnIndex": 21, "endColumnIndex": 22},
        "rule": {
            "condition": {
                "type": "ONE_OF_RANGE",
                "values": [{"userEnteredValue": "='1분 단위 포기호, 통화상세'!$F$3:$T$3"}]
            },
            "showCustomUi": True,
            "strict": False,
        }
    }
}]
_batch_update(NEW, reqs)
print("✅ V3 드롭다운 추가 (F3:T3 동적 상담사)")

# V4 수식 입력
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V4",
    valueInputOption="USER_ENTERED",
    body={"values": [[v4_formula]]},
).execute()
print("✅ V4 수식 (선택 상담사의 통화 외 시간 계산)")

# V3 안내문구는 그대로 두고 사용자가 입력 시 V4 자동 계산
# 5분단위에도 동일 적용
sid5 = _get_sheet_id_by_name(NEW, "5분 단위 포기호, 통화상세")
reqs5 = [{
    "setDataValidation": {
        "range": {"sheetId": sid5, "startRowIndex": 2, "endRowIndex": 3, "startColumnIndex": 21, "endColumnIndex": 22},
        "rule": {
            "condition": {
                "type": "ONE_OF_RANGE",
                "values": [{"userEnteredValue": "='5분 단위 포기호, 통화상세'!$F$3:$T$3"}]
            },
            "showCustomUi": True,
            "strict": False,
        }
    }
}]
_batch_update(NEW, reqs5)

# 5분단위 V4: 5분 단위 ÷ 12 = 시간 단위 변환
# COUNTBLANK으로 통화 안한 5분 buckets 수, 각 bucket = 5분
# 점심시간 12 buckets 제외
v4_5min_formula = (
    '=IF(V3="",,'
    '(COUNTBLANK(INDEX(F4:T135,, MATCH(V3, F3:T3, 0)))-12)*5/60)'
)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!V4",
    valueInputOption="USER_ENTERED",
    body={"values": [[v4_5min_formula]]},
).execute()
print("✅ 5분단위 V3 드롭다운 + V4 계산")

# 검증
time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1분 단위 포기호, 통화상세'!V1:V4",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[1분단위 V1:V4]: {res}")
