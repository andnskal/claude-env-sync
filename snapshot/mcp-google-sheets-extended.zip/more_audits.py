"""추가 검증: 3,4 상담사별 vs 1.일별, 시트1 삭제, ★설정 검증."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 시트1 삭제
print("=" * 80)
print("1️⃣ 시트1 (빈 시트) 삭제")
print("=" * 80)
try:
    sid = _get_sheet_id_by_name(NEW, "시트1")
    _batch_update(NEW, [{"deleteSheet": {"sheetId": sid}}])
    print("✅ 시트1 삭제 완료")
except Exception as e:
    print(f"  ⚠️ 시트1 삭제 실패: {e}")

# 2) 4.상담사별 콜 5/8 합계 vs 1.일별 5/8 IB/OB
print("\n" + "=" * 80)
print("2️⃣ 4.상담사별 콜 5/8 vs 1.일별 5/8 IB 응대호")
print("=" * 80)

# 4.상담사별 헤더 (행 1, 2)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'4.상담사별 콜 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

if not res or len(res) < 3:
    print("  ⚠️ 4.상담사별 데이터 없음")
else:
    headers_dates = res[0]  # 행 1: 날짜
    headers_types = res[1]  # 행 2: IB_성공/OB_성공/OB_실패
    
    # 5/8 IB_성공 컬럼 찾기
    sum_ib_5_8 = sum_ob_5_8 = 0
    for ci, (d, t) in enumerate(zip(headers_dates, headers_types)):
        if isinstance(d, str) and d == "2026-05-08":
            for ri in range(2, len(res)):
                row = res[ri]
                if ci < len(row) and isinstance(row[ci], (int, float)):
                    if t == "IB_성공":
                        sum_ib_5_8 += row[ci]
                    elif t == "OB_성공":
                        sum_ob_5_8 += row[ci]
    print(f"  4.상담사별 5/8 IB_성공 합: {sum_ib_5_8}")
    print(f"  4.상담사별 5/8 OB_성공 합: {sum_ob_5_8}")

# 1.일별 5/8 P (응대호)
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        P = row[15] if len(row) > 15 else "?"
        AC = row[28] if len(row) > 28 else "?"
        print(f"  1.일별 5/8 P (응대호): {P}")
        print(f"  1.일별 5/8 AC (OB 성공): {AC}")
        break

# 3) 3.상담사별 채팅 5/8 합계 vs 1.일별 5/8
print("\n" + "=" * 80)
print("3️⃣ 3.상담사별 채팅 5/8 vs 1.일별 5/8 채팅 답변")
print("=" * 80)

res3 = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'3.상담사별 채팅 실적'!A1:BD30",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])

if res3 and len(res3) >= 3:
    headers_dates = res3[0]
    headers_chans = res3[1]
    
    sum_kakao = sum_naver = sum_channel = sum_tech = 0
    for ci, (d, ch) in enumerate(zip(headers_dates, headers_chans)):
        if isinstance(d, str) and d == "2026-05-08":
            for ri in range(2, len(res3)):
                row = res3[ri]
                if ci < len(row) and isinstance(row[ci], (int, float)):
                    if ch == "카카오":
                        sum_kakao += row[ci]
                    elif ch == "네이버":
                        sum_naver += row[ci]
                    elif ch == "채널톡":
                        sum_channel += row[ci]
                    elif ch == "기술이관":
                        sum_tech += row[ci]
    print(f"  3.상담사별 5/8 카카오: {sum_kakao}")
    print(f"  3.상담사별 5/8 네이버: {sum_naver}")
    print(f"  3.상담사별 5/8 채널톡: {sum_channel}")
    print(f"  3.상담사별 5/8 기술이관: {sum_tech}")

# 1.일별 5/8 채팅 답변 (D, F, H, M)
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        D_val = row[3] if len(row) > 3 else "?"
        F_val = row[5] if len(row) > 5 else "?"
        H_val = row[7] if len(row) > 7 else "?"
        M_val = row[12] if len(row) > 12 else "?"
        print(f"  1.일별 5/8 D 카카오 답변: {D_val}")
        print(f"  1.일별 5/8 F 네이버 답변: {F_val}")
        print(f"  1.일별 5/8 H 채널톡 답변: {H_val}")
        print(f"  1.일별 5/8 M 기술이관: {M_val}")
        break
