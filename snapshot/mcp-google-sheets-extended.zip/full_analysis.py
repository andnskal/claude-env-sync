"""외부 시트 기술 이관 구조 + 이전 6.채팅 분류 수식 + 신 시스템 ★설정 비교."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

EXTERNAL = "1-6uipG0sTwxFW30T1-rfXmcxiBsfiEYQMlmv_CFe8xk"
OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"
NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1) 외부 시트 "기술 이관" 헤더 + 데이터 샘플
print("=" * 80)
print("[외부 시트 '기술 이관' 구조]")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=EXTERNAL, range="'기술 이관'!A1:Q10",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print("\n행 1 (헤더):")
if res:
    for ci, h in enumerate(res[0]):
        if h:
            col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
            print(f"  {col}: {h}")

print("\n행 2 (헤더 또는 첫 데이터):")
if len(res) > 1:
    for ci, h in enumerate(res[1]):
        if h:
            col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
            print(f"  {col}: {h}")

print("\n행 3-5 (데이터 샘플):")
for ri in range(2, min(5, len(res))):
    if res[ri]:
        non_empty = [(chr(ord('A')+ci), str(c)[:30]) for ci, c in enumerate(res[ri]) if c]
        print(f"  Row {ri+1}: {non_empty[:8]}")

# 2) 이전 시트 6.채팅 모든 가공 수식 (행 2)
print("\n" + "=" * 80)
print("[이전 시트 6.채팅!행 2 모든 수식]")
print("=" * 80)
res_f = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'6.채팅 상담내역'!A2:Z2",
    valueRenderOption="FORMULA",
).execute().get("values", [])
labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
if res_f and res_f[0]:
    for ci, v in enumerate(res_f[0]):
        if v and str(v).startswith("="):
            print(f"\n  {labels[ci]}2: {str(v)[:400]}")

# 3) 신 시스템 ★설정 vs 이전 시트 ★설정
print("\n" + "=" * 80)
print("[신 시스템 ★설정 헤더 (참고)]")
print("=" * 80)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'★설정'!A1:Y3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res):
    if row:
        for ci, v in enumerate(row):
            if v:
                col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
                print(f"  {col}{ri+1}: {v[:30]}")
