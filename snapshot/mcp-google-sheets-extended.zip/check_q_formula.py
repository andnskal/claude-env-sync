"""1.일별 Q 컬럼 수식과 차이 분석."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 Q 행 12 (5/8) 수식
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!O6:U15",
    valueRenderOption="FORMULA",
).execute().get("values", [])

# 5/8 행 찾기
print("=" * 80)
print("1.일별 O-U 컬럼 수식 (5/8 행)")
print("=" * 80)
labels = ["O", "P", "Q", "R", "S", "T", "U"]
# 행 12 = 5/8 (4/30=6, 5/1=7, 5/2=8, 5/3=9, 5/4=10, 5/5=11, 5/6=12... 등 데이터에 따라 다름)
# 아래에서 5/8 행을 찾기
date_check = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:A20",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
target_row_idx = None
for ri, r in enumerate(date_check):
    if r and r[0] and "2026-05-08" in r[0]:
        target_row_idx = ri  # 0-indexed from row 6
        break

if target_row_idx is None:
    print("5/8 행 찾기 실패")
else:
    actual_row = 6 + target_row_idx
    print(f"\n5/8은 행 {actual_row}")
    if target_row_idx < len(res):
        for ci, lbl in enumerate(labels):
            v = res[target_row_idx][ci] if ci < len(res[target_row_idx]) else ""
            print(f"  {lbl}{actual_row}: {str(v)[:200]}")
