"""RAW_UserChat에 두 IMPORTRANGE 분할 입력."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# A1 첫 부분 (A:V), W1 두번째 부분 (W:CS)
_sheets.spreadsheets().values().clear(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1:CS3500",
).execute()
print("OK 클리어")
time.sleep(2)

# A1: A:V (22열)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat!A1:V")']]},
).execute()
print("OK A1: UserChat A:V")

# W1: W:CS (75열)
_sheets.spreadsheets().values().update(
    spreadsheetId=NEW, range="'RAW_UserChat'!W1",
    valueInputOption="USER_ENTERED",
    body={"values": [['=IMPORTRANGE("10wg3x0y77xdmLm1tPBwNLMnDpn_VyFkhWUBOtARHSs8","UserChat!W1:CS")']]},
).execute()
print("OK W1: UserChat W:CS")

print("\n로딩 대기 (15초)...")
time.sleep(15)

# 검증
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'RAW_UserChat'!A1:CS3",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
print(f"\n[RAW_UserChat 상태]")
print(f"  헤더 컬럼 수: {len(res[0]) if res else 0}")
if res and len(res[0]) > 5:
    print(f"  헤더 첫 5: {res[0][:5]}")
    print(f"  헤더 V-AB (분할 경계): {res[0][20:28] if len(res[0]) > 28 else res[0][20:]}")
    print(f"  헤더 끝 5: {res[0][-5:]}")

# 6.채팅 검증
print("\n[6.채팅 데이터]")
chat = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z5",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(chat[:3]):
    if row and any(c for c in row):
        non_err = [c for c in row if "VALUE" not in str(c)]
        has_err = any("VALUE" in str(c) for c in row)
        print(f"  Row {ri+2}: {row[:6]}{' [에러 있음]' if has_err else ''}")

# 1.일별 5/8 검증
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:AT60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"\n[1.일별 5/8 KPI]")
        print(f"  H (채널톡 답변): {row[7]}")
        print(f"  M (기술이관): {row[12]}")
        print(f"  P (응대호): {row[15]}")
        print(f"  AC (OB 성공): {row[28]}")
        break
