"""이전 시트 1.일별 첫 데이터 행 수식."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

OLD = "1j_pQSl0cMrqAA-q89Hq3gN0S_r4_bBcgy6Ulr_xmlXY"

# 첫 데이터 행 찾기
data = _sheets.spreadsheets().values().get(
    spreadsheetId=OLD, range="'1.일별 전체 통계'!A4:A60",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, r in enumerate(data):
    if r and r[0] and "2026" in r[0]:
        print(f"첫 데이터 행: {ri+4}, A={r[0]}")
        # 그 행 수식
        formulas = _sheets.spreadsheets().values().get(
            spreadsheetId=OLD, range=f"'1.일별 전체 통계'!A{ri+4}:AT{ri+4}",
            valueRenderOption="FORMULA",
        ).execute().get("values", [])
        if formulas and formulas[0]:
            print("[수식]")
            labels = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N",
                      "O","P","Q","R","S","T","U","V","W","X","Y","Z",
                      "AA","AB","AC","AD","AE","AF","AG","AH"]
            for ci, v in enumerate(formulas[0]):
                if v and isinstance(v, str) and v.startswith("="):
                    lbl = labels[ci] if ci < len(labels) else f"col{ci}"
                    print(f"\n{lbl}: {v[:300]}")
        break
