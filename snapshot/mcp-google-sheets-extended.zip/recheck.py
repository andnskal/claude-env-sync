"""실제 시트 상태 재확인."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

time.sleep(5)

# 시트 목록 다시
print("[현재 시트 목록]")
meta = _sheets.spreadsheets().get(spreadsheetId=NEW).execute()
for s in meta.get("sheets", []):
    print(f"  - {s['properties']['title']}")

# RAW_UserChat A1 수식 + 데이터 확인
print("\n[RAW_UserChat A1 수식]")
try:
    f = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'RAW_UserChat'!A1",
        valueRenderOption="FORMULA",
    ).execute().get("values", [[]])
    print(f"  수식: {f[0][0] if f and f[0] else '없음'}")
    
    v = _sheets.spreadsheets().values().get(
        spreadsheetId=NEW, range="'RAW_UserChat'!A1:E3",
        valueRenderOption="FORMATTED_VALUE",
    ).execute().get("values", [])
    print(f"\n  A1:E3 데이터:")
    for r in v:
        print(f"    {r}")
except Exception as e:
    print(f"  오류: {e}")

# 6.채팅 5/8 데이터
print("\n[6.채팅 5/8]")
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'6.채팅 상담내역'!A2:Z6",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])
for ri, row in enumerate(res[:3]):
    if row:
        print(f"  Row {ri+2}: {row[:7]}")

# 1.일별 5/8 KPI
daily = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'1.일별 전체 통계'!A6:H60",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
print("\n[1.일별 5/8 H 채널톡 답변]")
for row in daily:
    if row and isinstance(row[0], str) and row[0] == "2026-05-08":
        print(f"  H = {row[7] if len(row) > 7 else '?'}")
        break
