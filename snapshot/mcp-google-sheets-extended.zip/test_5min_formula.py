"""5분단위 SUMPRODUCT 단계별 테스트."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

test_formulas = [
    ("X10", '=SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300<>"")*1)'),  # 비어있지 않은 셀 수
    ("X11", '=COUNTBLANK(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300)'),
    ("X12", '=HOUR(\'RAW시간대별 포기호, 통화상세\'!A299)'),  # 빈 셀의 HOUR
    ("X13", '=SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300<>"")*HOUR(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300))'),
    ("X14", '=SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$10<>"")*(HOUR(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$10)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$10)<540))'),  # 9:00 미만 카운트
    # 직접 수동으로 LAMBDA 테스트
    ("X15", '=LET(일시, "2026-05-04 09:30:00", SUMPRODUCT((\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300<>"")*(LEFT(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300,10)=LEFT(일시,10))*((HOUR(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!$A$3:$A$300))<HOUR(일시)*60+MINUTE(일시)+5)*((HOUR(\'RAW시간대별 포기호, 통화상세\'!$B$3:$B$300)*60+MINUTE(\'RAW시간대별 포기호, 통화상세\'!$B$3:$B$300))>=HOUR(일시)*60+MINUTE(일시))))'),
]
for cell, formula in test_formulas:
    _sheets.spreadsheets().values().update(
        spreadsheetId=NEW, range=f"'5분 단위 포기호, 통화상세'!{cell}",
        valueInputOption="USER_ENTERED",
        body={"values": [[formula]]},
    ).execute()
time.sleep(3)
res = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5분 단위 포기호, 통화상세'!X10:X15",
    valueRenderOption="UNFORMATTED_VALUE",
).execute().get("values", [])
labels = [
    "비어있지 않은 셀 수",
    "빈 셀 수",
    "HOUR(빈 셀)",
    "유효한 HOUR 합",
    "9시 미만 카운트 (A3:A10)",
    "9:30 일시 SUMPRODUCT 직접 테스트"
]
for i, label in enumerate(labels):
    val = res[i][0] if i < len(res) and res[i] else 'N/A'
    print(f"  {label}: {val}")
