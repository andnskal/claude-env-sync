"""더 깊은 서식 점검 - 모든 시간/비율 컬럼."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 1.일별 모든 컬럼 type/pat 확인 (행 6 = 데이터 시작)
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'1.일별 전체 통계'!A6:AT6"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue))))"
).execute()
rows = fmt["sheets"][0]["data"][0]["rowData"]

if rows and "values" in rows[0]:
    print("[1.일별 행 6 모든 셀 서식]")
    for ci, cell in enumerate(rows[0]["values"]):
        col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
        fmt_obj = cell.get("userEnteredFormat", {}).get("numberFormat", {})
        val = cell.get("formattedValue", "")
        ftype = fmt_obj.get("type", "AUTO")
        fpat = fmt_obj.get("pattern", "")
        print(f"  {col}: val='{val[:25]}' / {ftype} '{fpat}'")

# 2.시간대별 행 4
print("\n[2.시간대별 행 4 모든 셀 서식]")
fmt = _sheets.spreadsheets().get(
    spreadsheetId=NEW, ranges=["'2.시간대별 전체통계'!A4:AL4"],
    includeGridData=True,
    fields="sheets(data(rowData(values(userEnteredFormat,formattedValue))))"
).execute()
rows = fmt["sheets"][0]["data"][0]["rowData"]
if rows and "values" in rows[0]:
    for ci, cell in enumerate(rows[0]["values"]):
        col = chr(ord('A') + ci) if ci < 26 else 'A' + chr(ord('A') + ci - 26)
        fmt_obj = cell.get("userEnteredFormat", {}).get("numberFormat", {})
        val = cell.get("formattedValue", "")
        ftype = fmt_obj.get("type", "AUTO")
        fpat = fmt_obj.get("pattern", "")
        if val:
            print(f"  {col}: val='{val[:25]}' / {ftype} '{fpat}'")
