"""채널톡과의 1건 차이를 정확히 1초 단위까지 검증.

5/8 IB: 시트 112 vs 채널톡 113 — 운영시간 외(17:30+) IB_성공 = 정확히 1건이어야 하고
                                  그 시각이 17:30 종료 직후 1초여야 함
5/11 OB: 시트 62 vs 채널톡 62 — 매칭 (운영시간 외 OB 성공 케이스 확인)
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 상담내역 데이터 페치 (분할)
print("[5.콜 상담내역 페치]")
calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD11112",
    valueRenderOption='FORMATTED_VALUE',
).execute().get('values', [])
print(f"  총 {len(calls)}행 (헤더 제외)")

# 컬럼 매핑 (0-based)
# 0: A userChatId, 1: B direction, 2: C startedAt, 3: D firstEngagedAt, 4: E endedAt,
# 13: N 날짜, 15: P 시간대, 16: Q 구분, 22: W 상담사, 26: AA firstRingStartedAt,
# 28: AC 인하우스분류, 29: AD 운영시간분류

# ───────────── 5/8 IB 1건 차이 검증 ─────────────
print("\n" + "="*80)
print("[A] 5/8 IB_성공 = 운영시간 내+외 분포")
print("="*80)

ib_in = []   # 운영시간 내
ib_out = []  # 운영시간 외
for r in calls:
    if len(r) < 30: continue
    if r[13] != "2026-05-08": continue
    if r[16] != "IB_성공": continue
    rec = {
        'chatId': r[0],
        'started': r[2],
        'engaged': r[3] if len(r) > 3 else "",
        'ended':   r[4] if len(r) > 4 else "",
        'ring':    r[26] if len(r) > 26 else "",
        'duration': r[17] if len(r) > 17 else "",
        'agent':   r[22] if len(r) > 22 else "",
        'tags':    r[23] if len(r) > 23 else "",
        'house':   r[28] if len(r) > 28 else "",
        'oper':    r[29],
    }
    (ib_in if r[29] == "내" else ib_out).append(rec)

print(f"\n  운영시간 내 IB_성공: {len(ib_in)}건")
print(f"  운영시간 외 IB_성공: {len(ib_out)}건")
print(f"  합계:               {len(ib_in)+len(ib_out)}건  (채널톡: 113)")

if ib_out:
    print("\n  [운영시간 외 IB_성공 상세]")
    for rec in ib_out:
        print(f"    chatId: {rec['chatId']}")
        print(f"    started:    {rec['started']}")
        print(f"    ring:       {rec['ring']}")
        print(f"    engaged:    {rec['engaged']}   ← 응대 성공 시점")
        print(f"    ended:      {rec['ended']}")
        print(f"    duration:   {rec['duration']}")
        print(f"    agent:      {rec['agent']}")
        print(f"    AC(인하우스): {rec['house']}")
        print(f"    AD(운영):   {rec['oper']}")
        # 1초 차이 검증
        if rec['engaged']:
            try:
                t = rec['engaged'].split(" ")[1]
                h,m,s = t.split(":")
                h,m,s = int(h),int(m),int(s)
                secs_from_1730 = (h*3600+m*60+s) - (17*3600+30*60)
                print(f"    → 응대 시각 17:30 기준 차이: {secs_from_1730:+d}초")
            except: pass

# 17:30 직전 후 inbound 콜 — 1초 단위 분포
print("\n" + "="*80)
print("[A-2] 5/8 17:25 ~ 17:35 모든 inbound 콜 (1초 단위)")
print("="*80)
candidates = []
for r in calls:
    if len(r) < 30: continue
    if r[13] != "2026-05-08": continue
    if r[1] != "inbound": continue
    started = r[2]
    if not started: continue
    try:
        t = started.split(" ")[1]
        h, m = int(t.split(":")[0]), int(t.split(":")[1])
        if not (h == 17 and 25 <= m <= 59): continue
    except: continue
    candidates.append((started, r[3] if len(r)>3 else "", r[26] if len(r)>26 else "",
                       r[16], r[29], r[22] if len(r)>22 else ""))
candidates.sort()
for st, eng, ring, q, ad, ag in candidates:
    print(f"    started={st} | engaged={eng or '-':>20} | ring={ring or '-':>20} | {q:>10} | AD={ad} | {ag}")

# ───────────── 5/11 OB 1건 차이 검증 ─────────────
print("\n" + "="*80)
print("[B] 5/11 OB_성공 = 운영시간 내+외 분포")
print("="*80)

ob_in = []
ob_out = []
for r in calls:
    if len(r) < 30: continue
    if r[13] != "2026-05-11": continue
    if r[16] != "OB_성공": continue
    rec = {
        'chatId': r[0],
        'started': r[2],
        'engaged': r[3] if len(r) > 3 else "",
        'ended':   r[4] if len(r) > 4 else "",
        'agent':   r[22] if len(r) > 22 else "",
        'house':   r[28] if len(r) > 28 else "",
        'oper':    r[29],
    }
    (ob_in if r[29] == "내" else ob_out).append(rec)

print(f"\n  운영시간 내 OB_성공: {len(ob_in)}건")
print(f"  운영시간 외 OB_성공: {len(ob_out)}건")
print(f"  합계:               {len(ob_in)+len(ob_out)}건  (채널톡: 62)")

if ob_out:
    print("\n  [운영시간 외 OB_성공 상세]")
    for rec in ob_out:
        print(f"    chatId: {rec['chatId']}")
        print(f"    started:    {rec['started']}")
        print(f"    engaged:    {rec['engaged']}")
        print(f"    ended:      {rec['ended']}")
        print(f"    agent:      {rec['agent']}")
        print(f"    AC(인하우스): {rec['house']}")
        if rec['started']:
            try:
                t = rec['started'].split(" ")[1]
                h,m,s = t.split(":")
                h,m,s = int(h),int(m),int(s)
                # 9시 이전 또는 17:30 이후 또는 점심(13:00~13:59)
                tm = h*3600+m*60+s
                if tm < 9*3600: rel = f"09:00 기준 {tm - 9*3600:+d}초"
                elif 13*3600 <= tm < 14*3600: rel = "점심시간"
                elif tm >= 17*3600+30*60: rel = f"17:30 기준 {tm - (17*3600+30*60):+d}초"
                else: rel = "운영시간 내"
                print(f"    → 운영시간 외 사유: {rel}")
            except: pass

# ───────────── 5/8 시간대별 IB 응대호 — 시트와 매칭 검증 ─────────────
print("\n" + "="*80)
print("[C] 5/8 IB_성공을 시간대별로 분포")
print("="*80)
from collections import Counter
slot_in = Counter()
slot_out = Counter()
for r in calls:
    if len(r) < 30: continue
    if r[13] != "2026-05-08": continue
    if r[16] != "IB_성공": continue
    slot = r[15]
    if r[29] == "내": slot_in[slot] += 1
    else: slot_out[slot] += 1

print(f"\n  {'슬롯':>8} | {'내':>5} | {'외':>5} | {'합계':>5}")
print("  " + "-"*32)
total_in = total_out = 0
for h in range(24):
    s = f"{h:02d}-{h+1:02d}"
    i, o = slot_in[s], slot_out[s]
    if i+o > 0:
        print(f"  {s:>8} | {i:>5} | {o:>5} | {i+o:>5}")
        total_in += i; total_out += o
print(f"  {'합계':>8} | {total_in:>5} | {total_out:>5} | {total_in+total_out:>5}")
print(f"\n  → 시트 1.일별 5/8 IB 응대호 = {total_in}건 (운영시간 내만)")
print(f"  → 채널톡(00-24시) = {total_in+total_out}건")
print(f"  → 차이 = {(total_in+total_out) - total_in}건 = 운영시간 외 케이스")

# ───────────── AD 분류 룰 검증: startedAt 기준인지 확인 ─────────────
print("\n" + "="*80)
print("[D] AD열 운영시간 분류 룰 추적")
print("="*80)
# 운영시간 경계(17:29, 17:30) 근처 콜 케이스 비교
print("  5/8 17:29 / 17:30 / 17:31 inbound 콜의 AD 분류:")
for r in calls:
    if len(r) < 30: continue
    if r[13] != "2026-05-08": continue
    if r[1] != "inbound": continue
    if not r[2]: continue
    try:
        t = r[2].split(" ")[1]
        h, m = int(t.split(":")[0]), int(t.split(":")[1])
        if h != 17 or m not in (28, 29, 30, 31): continue
    except: continue
    print(f"    started={r[2]} | engaged={r[3] if len(r)>3 else '-':>20} | "
          f"{r[16]:>10} | AD={r[29]}")
