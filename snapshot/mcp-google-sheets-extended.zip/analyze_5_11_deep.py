"""5/11 박슬기, 정현호 1건씩 차이 — 심층 분석.
의심 케이스: 콜백/부재중 태그, 빠른 연속 호출, 중복 chatId 등.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"

# 5.콜 전체 (모든 컬럼)
all_calls = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A2:AD3500",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])

# 헤더 확인
headers = _sheets.spreadsheets().values().get(
    spreadsheetId=NEW, range="'5.콜 상담내역'!A1:AD1",
    valueRenderOption="FORMATTED_VALUE",
).execute().get("values", [])[0]
print("[5.콜 헤더]")
for i, h in enumerate(headers):
    print(f"  {chr(65+i) if i < 26 else 'A' + chr(65+i-26)} ({i}): {h}")

# 박슬기의 5/11 모든 콜 (성공/포기/OB 등)
print("\n" + "=" * 80)
print("[박슬기 5/11 — 모든 콜 (IB_성공뿐 아니라 전부)]")
print("=" * 80)
print(f"{'시각':>20} | {'B(dir)':>8} | {'Q(구분)':>12} | {'AD':>4} | {'tags 일부':>40}")
print("-" * 110)
ps_all = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_박슬기": continue
    ps_all.append(row)

ps_all.sort(key=lambda r: r[2])
for row in ps_all:
    B = row[1]  # direction
    C = row[2]  # startedAt
    Q = row[16]  # 구분
    AD = row[29]  # 운영시간
    X = row[23] if len(row) > 23 else ""
    print(f"  {C} | {B:>8} | {Q:>12} | {AD:>4} | {str(X)[:40]}")

# 콜백 태그 있는 콜
print("\n[박슬기 5/11 — '콜백대상' 또는 '부재중전화' 태그 콜]")
for row in ps_all:
    X = row[23] if len(row) > 23 else ""
    if "콜백" in str(X) or "부재중" in str(X):
        print(f"  {row[2]} | {row[16]} | {X}")

# Y열 (콜백/알림톡)
print("\n[박슬기 5/11 — Y열 (콜백/알림톡 분류) 분포]")
from collections import Counter
y_dist = Counter()
for row in ps_all:
    Y = row[24] if len(row) > 24 else ""
    y_dist[str(Y)] += 1
for k, v in y_dist.most_common():
    print(f"  {k!r}: {v}건")

# 정현호 마찬가지
print("\n" + "=" * 80)
print("[정현호 5/11 — 모든 콜 (IB_성공뿐 아니라 전부)]")
print("=" * 80)
print(f"{'시각':>20} | {'B(dir)':>8} | {'Q(구분)':>12} | {'AD':>4} | {'tags 일부':>40}")
print("-" * 110)
jh_all = []
for row in all_calls:
    if len(row) < 30: continue
    if row[13] != "2026-05-11" or row[22] != "CS_정현호": continue
    jh_all.append(row)

jh_all.sort(key=lambda r: r[2])
for row in jh_all:
    B = row[1]
    C = row[2]
    Q = row[16]
    AD = row[29]
    X = row[23] if len(row) > 23 else ""
    print(f"  {C} | {B:>8} | {Q:>12} | {AD:>4} | {str(X)[:40]}")

print("\n[정현호 5/11 — '콜백' 또는 '부재중' 태그]")
for row in jh_all:
    X = row[23] if len(row) > 23 else ""
    if "콜백" in str(X) or "부재중" in str(X):
        print(f"  {row[2]} | {row[16]} | {X}")

print("\n[정현호 5/11 — Y열 분포]")
y_dist = Counter()
for row in jh_all:
    Y = row[24] if len(row) > 24 else ""
    y_dist[str(Y)] += 1
for k, v in y_dist.most_common():
    print(f"  {k!r}: {v}건")

# 매우 짧은 통화 시간 검사 (T열 = 통화시간)
print("\n" + "=" * 80)
print("[통화시간 의심 케이스 — T열 (통화시간)]")
print("=" * 80)
# T = index 19
for name, calls in [("박슬기", ps_all), ("정현호", jh_all)]:
    print(f"\n[{name}] 통화시간 짧은 IB_성공 (5초 이하 또는 비정상):")
    for row in calls:
        if row[16] != "IB_성공": continue
        try:
            T = row[19] if len(row) > 19 else ""
            # 시간 텍스트 (예: "0:00:05")
            if T:
                parts = str(T).split(":")
                if len(parts) >= 3:
                    secs = int(parts[0])*3600 + int(parts[1])*60 + int(parts[2])
                    if secs <= 5:
                        print(f"    {row[2]} | T={T} ({secs}초) | tags={row[23] if len(row)>23 else ''}")
        except Exception as e:
            pass

# chatId 중복 검사
print("\n" + "=" * 80)
print("[chatId 중복 검사 — A열]")
print("=" * 80)
for name, calls in [("박슬기", ps_all), ("정현호", jh_all)]:
    chatids = Counter()
    for row in calls:
        if row[16] != "IB_성공": continue
        chatids[row[0]] += 1
    dups = [(cid, c) for cid, c in chatids.items() if c > 1]
    print(f"\n[{name}] chatId 중복:")
    if dups:
        for cid, c in dups:
            print(f"    {cid}: {c}회 등장")
            for row in calls:
                if row[0] == cid and row[16] == "IB_성공":
                    print(f"      → {row[2]} | tags={row[23] if len(row)>23 else ''}")
    else:
        print("    (중복 없음)")
