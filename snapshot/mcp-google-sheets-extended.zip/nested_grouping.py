"""중첩 그룹 - depth 1 외부 + depth 2 카테고리들."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import _sheets, _get_sheet_id_by_name, _batch_update

NEW = "1_aVwSIp7DMDK-IpolAIKd7ZFCoId5X6B0EpNhzdZzVU"
sid = _get_sheet_id_by_name(NEW, "1.일별 전체 통계")

# 기존 그룹 모두 삭제
print("[기존 그룹 삭제]")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
).execute()
del_reqs = []
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        for g in sorted(s.get("columnGroups", []), key=lambda x: -x.get("depth", 1)):
            r = g["range"]
            del_reqs.append({
                "deleteDimensionGroup": {
                    "range": {
                        "sheetId": sid,
                        "dimension": "COLUMNS",
                        "startIndex": r.get("startIndex", 0),
                        "endIndex": r.get("endIndex", 0),
                    }
                }
            })
        break
if del_reqs:
    _batch_update(NEW, del_reqs)
    print(f"  OK {len(del_reqs)}개 삭제")
    time.sleep(3)

# 카테고리별 분리 그룹 만들기
# 핵심: API는 같은 depth 인접 그룹 병합. 다른 depth로 만들면 분리 가능.
# 시도 1: 모든 카테고리를 다른 depth로 (depth 1, 2, 3, 4, 5, 6, 7)
print("\n[그룹 추가 - 각 카테고리 다른 depth]")
groups = [
    (2, 14, "채팅"),       # C-N
    (14, 26, "IB"),        # O-Z
    (26, 34, "OB"),        # AA-AH
    (34, 36, "콜백"),       # AI-AJ
    (36, 39, "KPI"),       # AK-AM
    (39, 46, "부재중사유"),  # AN-AT
    (46, 49, "참고"),       # AU-AW
]
# 한 번에 1개씩 추가, 각 호출 사이 sleep
for start, end, label in groups:
    _batch_update(NEW, [{
        "addDimensionGroup": {
            "range": {
                "sheetId": sid,
                "dimension": "COLUMNS",
                "startIndex": start,
                "endIndex": end,
            }
        }
    }])
    time.sleep(1)

time.sleep(3)

# 결과 확인
print("\n[결과]")
meta = _sheets.spreadsheets().get(
    spreadsheetId=NEW, fields="sheets(properties,columnGroups)"
).execute()
def cl(idx):
    s, n = "", idx + 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s
for s in meta.get("sheets", []):
    if s["properties"]["sheetId"] == sid:
        for g in s.get("columnGroups", []):
            r = g["range"]
            print(f"  {cl(r['startIndex'])}-{cl(r['endIndex']-1)} depth={g.get('depth', 0)}")
        break
